# Registro delle correzioni dottrinali — 13/08/2026

Regole enunciate da Edu in questa sessione. **Vanno conservate anche se non ancora
confermate dai numeri**: una regola non confermata oggi può servire domani, e riesaminare
le carte una per una è lento e costoso.

Stato: `FISSATA` (confermata dai numeri) · `IN PROVA` (misurata, esito incerto) ·
`ARCHIVIATA` (enunciata, non ancora misurata) · `BOCCIATA` (misurata e respinta).

---

## 1. Clash — validità per pilastro  ·  `FISSATA` (implementata in liuyao.js)

- Clash dal **GIORNO**: sempre effettivo.
- Clash dall'**ANNO**: effettivo solo se il **ramo dell'anno** è in 旺/相
  (chi clasha deve avere forza; non la linea clashata).
- Clash dal **MESE**: **non effettivo da solo**, ma **potenzia** gli altri due quando è presente.

## 2. Combinazione (六合) — bloccante con protezione  ·  `FISSATA` (implementata in liuyao.js)

- La combinazione **dal GIORNO** blocca sempre il ramo (fuori dai giochi).
- Ma protegge anche il ramo da un clash diretto: per colpirlo servono **DUE clash**,
  il primo rompe la combinazione, il secondo attacca.
  - 0 clash → **legata** (bloccata)
  - 1 clash → combinazione rotta, ramo **liberato** (non ancora colpito)
  - ≥2 clash → combinazione rotta **e** ramo colpito (rotta/mossa secondo la stagione)
- Solo dal giorno (non da mese o anno).

## 3. Ripiego del LY quando Shi e Ying sono fuori  ·  `BOCCIATA` come sostituto del PB

Se né Shi 世 né Ying 應 sopravvivono, la lettura passa a:
**G 官鬼 → W 妻財 → linea mobile**, preferendo fra i candidati quelli **timely** (旺/相);
linee molto untimely e non sostenute dalla data hanno poca efficacia.
Direzione: **posizione della linea che regge** (trigramma inferiore L1-3 = SHORT,
superiore L4-6 = LONG). La variante "posizione della linea che essa genera" è **bocciata**
(45,07%).

Misura (301 carte in ripiego, 202 con responso):

| | n | Liu Yao | Plum Blossom |
|---|---|---|---|
| Tutto | 202 | 56,44% · +1.782 pip | 57,92% · +1.321 pip |
| Recente 2023-05→ | 113 | 53,98% · +810 pip | 58,41% · +296 pip |
| Vecchio 2020→2022 | 84 | 59,52% · +574 pip | 55,95% · +567 pip |

Esito: **non sostituisce il PB** (perde nel recente). Sui **pip** però batte il PB su
entrambi i periodi — firma diversa, prende i movimenti più grossi. Da non buttare.
Nota: il ripiego scatta su carte dove il PB va **già bene** (57,92% contro 53,51% di baseline).

**Sequenza verificata la migliore su 66 varianti testate** (G→W→mobile, 56,2%).
G in testa è solido; i criteri "di rilevanza" senza ordine fisso vanno peggio
(più forte in stagione 50,2%; solo timely più basso 52,6%).

## 4. Autopenalità 自刑 dal giorno  ·  `IN PROVA` — misurata, campione troppo piccolo

Carta sorgente: **USDJPY 05/12/2022** (seme 134, sup 8 坤, inf 6 坎, mutante L1).

Quando ci sono **due linee dello stesso parente** candidate a reggere la lettura, quella
che riceve **autopenalità dal giorno** (stesso ramo del giorno: 辰辰, 午午, 酉酉, 亥亥)
è penalizzata ed esce; la generazione va all'altra.

Nella carta: mobile L1 寅 → 巳 Fuoco (caso 2 泄, agisce l'arrivo). Il Fuoco genera Terra e
quindi **entrambi** gli Ufficiali (辰 a L2, 丑 a L4): da sola la generazione non discrimina.
Il giorno è 壬**辰** e il G basso è **辰** → 辰辰自刑 → esce. Resta il G alto 丑 (L4,
trigramma superiore) → LONG. Il mercato sale. ✓

Senza questo criterio la regola sceglieva il G più basso per posizione, cioè a caso.

**Misura (13/08/2026):** esclude solo **6 linee** su 202 carte di ripiego — troppo raro per
essere validato. Win rate complessivo invariato (56,44%), pip +311. Recente 53,10% contro
53,98%; vecchio 60,71% contro 59,52%. Con 6 casi sono scarti di rumore.
Il criterio resta dottrinalmente corretto e va **tenuto**: sulla carta sorgente sceglie
giusto, e potrà contare quando entrerà in una regola con più occorrenze.

## 5. PB — il giorno immobilizza il Yong trasformato  ·  `BOCCIATA` — misurata 13/08/2026

Carta sorgente: **USDJPY 05/12/2022**.

坎 Kan muta in 兌 Dui, il cui palazzo Houtian è **酉**; il giorno **辰** lo combina
(辰酉合) e lo **immobilizza**. Il Yong trasformato legato ⇒ il Trend non può esercitare
la relazione (qui 我剋) ⇒ **non segue**.

Concorre con il **Rafforzamento**, che sulla stessa carta dà lo stesso verdetto per via
diversa (兌 Metallo genera 坎 Acqua ⇒ Yong rinforzato).

**Misura (13/08/2026):** tocca **543 carte** (115 già toccate dal Rafforzamento, 428
indipendenti). Dove **cambierebbe** il verdetto (160 carte, oggi "segue" → "non segue")
vince **44,4%** e rende **−1.160 pip** contro i +1.160 di oggi. Perde su entrambi i periodi
(recente 44,8%, vecchio 43,3%). Imponendo "non segue" su tutte e 543: 53,78% contro 57,09%
del baseline.

**Esito: bocciata.** Il Rafforzamento resta la lettura migliore per questa configurazione.
Il meccanismo è sensato e sulla carta sorgente dà la risposta giusta, ma non generalizza.

## 6. PB — la combinazione blocca il palazzo del Trend  ·  `ARCHIVIATA` — da misurare

Carta sorgente: **EURJPY 04/11/2025** (seme 177, sup 6 坎, inf 1 乾, mutante L3).

Il giorno 丑 combina il palazzo del Trend 子 (子丑合) ⇒ il Trend è legato ⇒ **non segue**.

⚠ **Capovolge una regola esistente**: oggi il motore legge la combinazione sul palazzo del
Trend come *protezione* (→ segue), e solo quando la base dice "non segue" (`protetto`,
flag `CP=verdetto`). Edu dice che è un **bloccante** (→ non segue). Non è un'aggiunta:
è un cambio di polarità. Da misurare prima di applicare.

---

## Correzioni ai fatti, registrate per non ripeterle

- **EURJPY 04/11/2025** — il Metallo *c'è* nel Bazi: 庚 in 戌 è a 衰 (stadio 6, appena oltre
  il picco), 戌 e 丑 custodiscono 辛, e l'ora dal seme è 申. Contare solo l'elemento dei rami
  (巳 Fuoco, 戌 Terra, 丑 Terra) è una lettura grossolana.
- **EURJPY 15/03/2023** — è lo **Shi** a essere combinato dal giorno (巳申合) e l'**Ying** a
  essere clashato da mese e anno (卯酉冲), non il contrario.
- **USDJPY 05/12/2022** — non c'è combinazione dal giorno sul palazzo del Trend: il giorno 辰
  combina 酉, assente dalla carta. L'unica combinazione è 寅+亥 (Tai Sui col **mese**). Il
  palazzo del Trend 未 non è combinato ma **vuoto**.
- Il Liu Yao **v1** (sola relazione Ying→Shi, senza stati di forza) non è "il Liu Yao":
  su 1.800 contrasti col PB ha ragione il PB nel 54,50% (−7.238 pip seguendo il LY).
  Le letture complete di Edu sulle stesse carte sono corrette; è la v1 a fallire.
- Le carte esaminate a mano nelle sessioni di studio sono in prevalenza **casi negativi del
  PB**: in quella popolazione il LY appare superiore per costruzione. Il confronto va sempre
  fatto sull'insieme completo.


---

## 7. PB — il vuoto è sempre vuoto (fuori dal pareggio)  ·  `BOCCIATA` — misurata 13/08/2026

Carta sorgente: **USDCAD 18/03/2020** (seme 142, sup 1 乾, inf 6 坎, mutante L4).
Enunciato: il palazzo del Trend vuoto rende il Trend inagibile in **qualsiasi** relazione,
non solo nel pareggio 比和. Eccezione: se il ramo del Trend è **clashato**, il vuoto è
risvegliato e non vale.

| | baseline | =giorno | =pieno |
|---|---|---|---|
| Tutto | 53,51% · z 3,86 · 17.221 | 53,32% · z 3,49 · 17.600 | 53,34% · z 3,53 · 17.834 |
| Recente | **53,28%** · 10.717 | 52,79% · 9.346 | 52,83% · 9.580 |
| Vecchio | 54,39% · 6.896 | 54,45% · 8.384 | 54,45% · 8.384 |

**Esito: bocciata.** Il guadagno in pip viene **interamente dal periodo vecchio**; il recente
peggiora su entrambe le metriche. La z scende da 3,86 a 3,53.

**Perché il vuoto resta confinato al pareggio** (spiegazione dottrinale, non ancora testata
per relazione): nel 比和 la relazione non decide nulla e serve uno spareggio di sostanza;
nelle altre quattro la forza sta già nella relazione, che agisce fra **elementi**, e il vuoto
di un ramo di palazzo non interrompe un rapporto elementale. Il palazzo Houtian è una
corrispondenza posizionale, il 旬空 una proprietà calendariale: piani diversi.
**Aperto:** il vuoto potrebbe agire in *alcune* relazioni (es. 我剋, che richiede sostanza per
esercitare controllo) e non in altre (生我, dove il Trend riceve). Da scomporre per relazione.

## 8. PB — il Tai Sui non si batte  ·  `BOCCIATA` — misurata 13/08/2026

Carta sorgente: **USDCAD 18/03/2020**. Il Tai Sui non è mai vuoto; se il ramo dell'anno
coincide col palazzo del Trend, il Trend è il trigramma del Tai Sui e non può essere battuto.
Qui: anno 庚**子**, palazzo del Trend 坎 = **子**, e 子 è fra i vuoti del giorno.
Spiegherebbe con una sola regola sia il vuoto inerte sia il mancato drenaggio da 巽.

| variante | tutto | z |
|---|---|---|
| baseline | 53,51% · 17.221 | 3,86 |
| annulla il vuoto | 53,49% · 17.187 | 3,83 |
| annulla il drenaggio | 53,54% · 17.317 | **3,89** |
| annulla tutto | 53,42% · 16.043 | 3,76 |
| impone segue | 53,00% · 13.404 | 3,38 |

**Esito: bocciata.** La sola variante positiva (drenaggio) guadagna +0,03 punti e +96 pip —
indistinguibile da zero — e perde comunque nel recente (53,23 contro 53,28). La forma forte
("impone segue") è la peggiore di tutte.

**Da conservare, osservazione collaterale:** le **280 carte** in cui il palazzo del Trend
coincide col ramo dell'anno si comportano in modo **opposto nei due periodi** —
recente **60,54%** (+2.452 pip), vecchio **50,40%** (+11 pip). Sette punti sopra il baseline
nel recente, neutre nel vecchio. Non stabile, quindi non regolarizzabile, ma la spaccatura è
troppo netta per essere solo rumore e non era mai emersa.

## 9. LY — autocombinazione 自合 della mobile  ·  `FISSATA` (implementata in liuyao.js)

Carta sorgente: **USDCAD 18/03/2020** (訟 Song 6 → 渙 Huan 59), verificata sullo screenshot
del software di riferimento.

Se la **partenza** della linea mobile combina (六合) il proprio **arrivo**, la linea si lega a
se stessa: è **bloccata**, non è più "in movimento" e non regge la lettura.
Qui: mobile L4 兄弟 午 → 未, e 午未合 → lo Shi (che è la mobile) esce dai giochi.
Nuovo stato di linea: `autocombinata`, che conta come morta. Nuovo caso di mutazione: **-4**.

## 10. LY — il G nascosto (伏神) è fuori dai giochi  ·  `FISSATA` (già coerente)

Nella gerarchia di ripiego, un parente presente **solo come 伏神** non conta come candidato.
Qui 官鬼 亥 è nascosto dietro L3 e viene saltato; la lettura passa a W.
Il modulo lo faceva già correttamente (i nascosti non sono linee visibili).

## 11. LY — la linea che coincide col ramo del giorno  ·  `ARCHIVIATA`

Una linea il cui ramo è **uguale al ramo del giorno** (日辰臨爻) è al massimo della forza.
Qui: W 妻財 **申** a L5, e il giorno è 庚**申**. È l'unica linea che sopravvive, sta nel
trigramma **superiore** → LONG. Il mercato sale, EMA su: **segue**. ✓
Da usare come criterio di preferenza fra candidati (più forte del semplice "timely").

## ⚠ QUESTIONE APERTA — l'Ying clashato dal giorno ma timely

Su questa carta Edu dà l'**Ying fuori dai giochi** perché clashato dal giorno:
Ying L1 父母 **寅**, giorno **申**, 寅申冲.

Ma per la **regola 1** già fissata, una linea piena clashata dal giorno e **timely** è in
**暗動 (movimento oscuro): resta viva**. E 寅 Legno nel mese 卯 è 旺, quindi timely.
Il modulo infatti la dà `mossa` = viva, e per questo **non attiva il ripiego** su questa carta.

Ipotesi da sottoporre a Edu: la differenza potrebbe stare nel fatto che 申 non solo clasha
寅 ma lo **controlla** (Metallo controlla Legno) — un 剋冲, distruttivo, diverso da un clash
fra pari come 子午. Se confermato, la regola diventerebbe: *clash + controllo dal clashante =
la linea cade anche se timely*.
**Non implementato:** serve la conferma dottrinale prima di toccare la regola 1.


---

# 12. IL RUOLO DI P 父母 — P È UN CONDOTTO, NON UN ATTORE  ·  `SCOPERTA` (13/08/2026)

**È il risultato più importante della sessione, e l'unico che regge su entrambi i periodi.**

## L'enunciato di Edu

P 父母 **drena G** (il portatore direzionale) e **controlla C** (che a sua volta genera W).
Elementalmente verificato sul palazzo 離 (Fuoco): G=Acqua, P=Legno, B=Fuoco, C=Terra, W=Metallo.
Acqua genera Legno ⇒ **P drena G**. Legno controlla Terra ⇒ **P controlla C**.
Terra genera Metallo ⇒ **C genera W**.
Ipotesi: *P non è mai indicatore di guadagno, casomai di perdita — DA SOLO*.

## Cosa dicono i numeri

**Per posizione** (tasso di successo del PB, baseline 53,51%):

| | Shi | Ying | mobile |
|---|---|---|---|
| P 父母 | 53,77% (n=584) | **55,17% (n=1287)** | **52,41% (n=893)** ← peggiore dell'asse |

Alla **mobile** l'ipotesi di Edu è confermata: P è il peggiore dei cinque parenti.
All'**Ying** invece P è la cella più grande e più redditizia della tabella (+8.210 pip).
La contraddizione è solo apparente e si scioglie scomponendo per rapporto con lo Shi.

## Il cuore della scoperta — P all'Ying, per rapporto con lo Shi

| rapporto | n | tutto | recente | vecchio | pip/trade |
|---|---|---|---|---|---|
| **Shi=B — P GENERA lo Shi (drenato)** | 356 | **59,55%** | 61,58% | 54,55% | **12,01** |
| Shi=P — stesso parente | 199 | 55,28% | 49,00% | 62,64% | 5,21 |
| Shi=C — P controlla lo Shi (domina) | 275 | 53,82% | 53,29% | 58,04% | 7,16 |
| Shi=W — W controlla P (controllato) | 426 | 53,05% | 53,21% | 56,38% | 2,56 |
| **Shi=G — G genera P (nutrito)** | 31 | **45,16%** | 33,33% | 56,25% | **−5,29** |

**È il DRENAGGIO che conta, non il controllo.**
- P **drenato** dallo Shi: 59,55%, sopra il baseline su **entrambi** i periodi, 12 pip a trade.
- P **controllato** dallo Shi: 53,05% — esattamente il baseline. Il controllo non produce nulla.
- P **nutrito** da G: 45,16% e −5,29 pip/trade — l'unica cella negativa dell'intera analisi
  (campione piccolo, n=31, e nel recente crolla al 33%: il segno è chiaro, la regola no).

## Formulazione

**P non è un attore, è un condotto.** Conta solo ciò che passa *attraverso* di lui verso lo Shi.
Quando P **cede** (genera lo Shi) il sistema rende al massimo; quando P **trattiene** — perché
nutrito da G o controllato da W — il vantaggio sparisce; quando riceve e basta, perde.
Questo riconcilia le due facce: alla **mobile** P prende l'iniziativa e drena G, e nuoce
(52,41%, peggiore dell'asse); all'**Ying** P sta fermo e nutre il Soggetto, e giova.

## Il caso "P non fa niente" — controintuitivo

Scomposizione di P all'Ying quando lo Shi è B (cioè P genera lo Shi):

| caso | n | tutto | recente | vecchio | pip/trade |
|---|---|---|---|---|---|
| P→B allo Shi, **B incartato** | 109 | **65,14%** | 64,15% | 62,22% | 10,67 |
| P→B allo Shi, B agibile | 247 | 57,09% | 60,67% | 50,00% | 12,60 |
| P all'Ying, Shi non è B | 931 | 53,49% | 51,75% | 58,23% | 4,23 |

Il caso in cui P "non fa niente" perché il B allo Shi è **incartato** (es. autocombinazione) è
il **migliore**: 65,14%, stabile su entrambi i periodi, ~11,6 punti sopra il baseline, z ≈ 2,4
su 109 carte. Il caso col B agibile è **instabile** (vecchio 50,00%).

⚠ **Attenzione a cosa misura:** è il tasso di successo del **PB** su quelle carte, non un
segnale del LY. Non dice "P incartato predice la direzione" — dice **"su queste carte il PB ci
prende quasi sempre"**, quindi sono carte in cui il LY **non deve correggere nulla**.
Carta esemplare: **USDCAD 18/03/2020**, che sta in questa cella, e il PB ha ragione (+266 pip).

## Perché conta

È **l'unico risultato della sessione che non si è sbriciolato al controllo dei due periodi**.
Tutte le altre regole misurate oggi (vuoto sempre vuoto, Tai Sui, immobilizzazione del Yong
trasformato, ripiego LY) reggevano su un periodo solo.

**Da fare:** estendere la stessa scomposizione per rapporto con lo Shi agli altri parenti
(W 妻財, C 子孫, B 兄弟, G 官鬼) — la chiave "drenato / controllato / nutrito / domina" non era
mai stata usata come asse di analisi e su P ha separato nettamente.


## 12-bis. P allo SHI — completamento (13/08/2026)

**P allo Shi non ha mai la configurazione buona.** Con lo Shi = P, l'Ying risulta solo
W, P o G: **il caso "drenato" (Ying=B) non compare mai**. P al Soggetto non può cedere.

| P allo Shi, rapporto con l'Ying | n | tutto | recente | vecchio | pip/tr |
|---|---|---|---|---|---|
| Ying=W — P controllato | 205 | 55,61% | 52,42% | 59,74% | 6,38 |
| Ying=P — stesso parente | 199 | 55,28% | 49,00% | 62,64% | 5,21 |
| **Ying=G — P nutrito** | 180 | **50,00%** | 49,48% | 50,67% | **0,86** |

Le prime due sono **instabili** (crollano nel recente). La terza è **stabile e cattiva su
entrambi i periodi**.

**Conferma incrociata:** *P nutrito da G* è negativo in **entrambe** le posizioni —
45,16% all'Ying (n=31) e 50,00% allo Shi (n=180), con il campione grande stabile sui due
periodi. Quando P riceve da G invece di cedere, il vantaggio sparisce.

**Stato della linea (P allo Shi):**

| | n | tutto | recente | vecchio |
|---|---|---|---|---|
| fermo | 486 | 54,94% | 51,88% | 58,91% |
| incartato | 226 | 54,87% | 49,14% | 59,79% |
| agibile | 358 | 53,07% | 51,22% | 56,85% |
| **è la linea mobile** | 98 | **47,96%** | 43,64% | 53,66% |

**P che si muove è il caso peggiore** (47,96%, oltre 5 punti sotto il baseline); P fermo 54,94%.
Stesso segnale già visto sull'asse della mobile (52,41%, ultimo dei cinque), qui più netto
perché il Soggetto che prende l'iniziativa pesa di più.

### REGOLA FISSATA — P 父母

> **P vale solo come donatore fermo.**
> - P **cede** allo Shi (Shi=B, P genera il Soggetto) → 59,55%, la configurazione migliore
> - P **fermo** → sopra il baseline
> - P **si muove** → 47,96%, il peggio
> - P **nutrito da G** → nessun vantaggio, in entrambe le posizioni
> - Allo **Shi** P non può mai cedere (il caso drenato non esiste): posizione strutturalmente debole


---

# 13. IL RUOLO DI C 子孫 — VERSARE IN W È UNA PERDITA  ·  `SCOPERTA` (13/08/2026)

## L'enunciato di Edu
*C dovrebbe essere positivo quando genera W, negativo quando controlla G.*
(C genera W e controlla G sempre, per costruzione elementale: nel palazzo 離, C=Terra,
W=Metallo, G=Acqua; Terra genera Metallo, Terra controlla Acqua.)

## Esito: **l'ipotesi è invertita dai numeri**

**C allo SHI — rapporto con l'Ying:**

| | n | tutto | recente | vecchio | pip/tr |
|---|---|---|---|---|---|
| **C controlla G (SOPPRIME)** | 164 | **60,98%** | 54,95% | 73,08% | 13,16 |
| altro = P | 275 | 53,82% | 53,29% | 58,04% | 7,16 |
| **C genera W (VERSA)** | 122 | **46,72%** | 50,00% | 43,33% | **−3,26** |

All'**Ying** lo stesso ordine, più compresso: sopprime 53,11% · versa 50,45%.
Alla **mobile** l'ordine si confonde e le celle sono instabili fra i due periodi.

## La cella peggiore dell'intera sessione

**C allo SHI — bersagli vivi sulla carta:**

| | n | tutto | recente | vecchio | pip/tr |
|---|---|---|---|---|---|
| W assente · G assente | 82 | 63,41% | 60,98% | 71,05% | 10,68 |
| W vivo · G vivo | 77 | 58,44% | 54,76% | 62,86% | 13,63 |
| W assente · G vivo | 313 | 54,63% | 53,44% | 58,62% | 8,06 |
| **W vivo · G assente** | 89 | **41,57%** | 45,28% | 34,29% | **−8,07** |

Quando C ha un **W vivo in cui versare e nessun G da sopprimere**, il sistema scende al
**41,57%** — dodici punti sotto il baseline, **stabile su entrambi i periodi**, −718 pip.
È il segnale negativo più forte e più stabile emerso finora.
**Candidata a filtro di astensione (NO TRADE): 89 carte, −718 pip da evitare.**

## Stato della linea (C allo Shi)

| | n | tutto | recente | vecchio | pip/tr |
|---|---|---|---|---|---|
| **C agibile** | 321 | **57,01%** | 58,86% | 57,35% | 9,80 |
| C è la mobile | 86 | 56,98% | 53,06% | 61,11% | 6,51 |
| C incartato | 154 | 47,40% | 43,56% | 55,77% | 0,16 |

**C agibile allo Shi: 57,01% su 321 carte, stabile su entrambi i periodi.**
A differenza di P, per C l'agibilità conta: incartato scende a 47,40%.

## Formulazione

> **C conserva forza sopprimendo, la perde versando.**
> C che si scarica nella Ricchezza si svuota; C che tiene sotto controllo l'Ufficiale
> mantiene sostanza. È l'inverso dell'intuizione di partenza.

⚠ **Cosa misurano questi numeri:** il tasso di successo del **PB** su quelle carte, non un
segnale direzionale del LY. La cella al 41,57% dice *"qui il PB sbaglia sistematicamente"*,
non *"C predice il ribasso"*.


---

# 14. CORREZIONE 回頭剋 (caso 3)  ·  `FISSATA` (implementata in liuyao.js, 13/08/2026)

Carta sorgente: **GBPUSD 03/10/2022** (seme 111, sup 5 巽, inf 7 艮, mutante L2).
**Errore mio, trovato da Edu:** nel caso 3 (回頭剋, l'arrivo controlla la partenza) il codice
trattava il movimento come inerte (effEl=null). Sbagliato: **muore la partenza, non il
trasformato** — l'arrivo è vivo e agisce sulle altre linee. Ora effEl = elemento dell'arrivo.
Sulla carta: mobile L2 午→亥; 亥 Acqua genera 卯 Legno = G a L6 → LONG. Il mercato sale. ✓
(La variante vecchia resta disponibile con RITORNO=nullo per confronto.)
Nota di misura: la correzione tocca 212 carte in caso 3, che in aggregato restano al 50,47%
(recente 44,55% / vecchio 55,32%): il singolo caso torna, l'aggregato non si muove.

# 15. IL LIU YAO COME SISTEMA DIREZIONALE AUTONOMO  ·  misurato 13/08/2026

Otto letture euristiche + la dottrina completa (eliminazione per stati, vincitore fra
Shi/Ying per controllo/generazione, ripiego G→W→mobile con 日辰臨爻 e timely, varianti con
clash+controllo e autopenalità): **tutte fra 49,3% e 50,9%** contro un riferimento di 50,40%
(4.111 carte). Anche dopo la correzione del 回頭剋 l'aggregato non si muove.
Le celle "buone" trovate in sessione (P drenato 59,55%, C sopprime 60,98%) sono tassi di
successo del **PB**, non del LY: individuano dove il PB lavora bene/male, non una direzione.

# 16. LA CONDIZIONE DI EDU — G allo Ying generato dalla mobile  ·  `IN OSSERVAZIONE FORWARD`

Enunciato (13/08/2026): *"Children al Soggetto non dice niente; Officer in alto su Shi/Ying
dice molto; e se una linea si muove per generarlo deve risvegliare l'attenzione."*
Codifica: mobile con arrivo attivo che genera un **unico G vivo**; direzione dalla **posizione
del G** (inferiore SHORT, superiore LONG).

| condizione | n | tutto | recente | vecchio | pip/tr |
|---|---|---|---|---|---|
| mobile genera un G vivo | 127 | 49,61% | 52,94% | 49,09% | 4,45 |
| **... e il G è allo Ying** | **8** | **100%** | 100% | 100% | **86,94** |
| ... e lo Shi è C (muto) | 46 | 54,35% | 50,00% | 62,50% | 9,35 |
| ... e lo Shi NON timely | 84 | 54,76% | 61,70% | 51,52% | 4,72 |

**8/8 nel campione storico** (GBPUSD 03/10/2022 inclusa). ⚠ Otto carte non bastano a
distinguere regola vera da cella fortunata (8/8 per caso ≈ 1/256, ma con ~250 configurazioni
testate una cella così emerge quasi certamente da qualche parte; la condizione appena più
larga sta a 49,61%). **Decisione: fissata come condizione scritta PRIMA dell'esito, da
verificare in avanti su ogni nuova occorrenza.** Se in forward continua a vincere, è la
dimostrazione pulita della lettura LY; se si sgonfia, era rumore.
Collaterale da tenere d'occhio: la condizione 5 (Shi non timely, n=84, 54,76%) — quando il
Soggetto tace, l'azione parla.


---

# 17. MOVIMENTO OSCURO 暗動 — LA LINEA SI SPOSTA SENZA MUTARE  ·  `FISSATA` (liuyao.js)

Carta sorgente: **EURJPY 11/12/2023** (噬嗑 21 → 无妄 25), verificata sullo screenshot del
software di riferimento.

**Due regole date da Edu, entrambe implementate:**

1. **L'esagramma trasformato è UNICO** — nasce dalla sola mutante ufficiale. Una linea piena
   clashata (暗動) **non genera un proprio trasformato**: si *sposta dal primo al secondo
   esagramma senza mutare*, e il suo arrivo è il ramo alla **sua stessa posizione**
   nell'esagramma trasformato.
   *(Mio errore precedente: facevo mutare ogni linea per flip isolato — su questa carta dava
   戌 invece di 午, e la lettura di Edu risultava incomprensibile.)*
2. **Il bloccaggio da combinazione NON avviene se la linea atterra su una linea che si muove**:
   la combinazione non lega, **salda al movimento**.

Sulla carta: L4 酉 clashata dal giorno 卯 → si sposta a **午** (L4 di 无妄, trigramma 乾);
午未合 sulla partenza 未 della mutante L5; L5 saldata si muove ed emerge **申 = G** nel
palazzo 巽; L5 è nel trigramma superiore → **LONG**. Il mercato sale. ✓

# 18. LA SCALA MOBILE — misurata  ·  `BOCCIATA` sul suo dominio

Regola: linea in 暗動 il cui arrivo combina la partenza della mutante ⇒ la mutante è saldata
e **vince**; direzione dalla sua posizione.

| condizione | n | tutto | recente | vecchio | pip/tr |
|---|---|---|---|---|---|
| almeno una linea in 暗動 | 1268 | 48,82% | 48,95% | 49,60% | −1,15 |
| **scala mobile attiva** | 146 | **46,58%** | 50,62% | 44,83% | −11,61 |
| ... arrivo VUOTO (non porta a niente) | 26 | 53,85% | 64,71% | 37,50% | −13,33 |
| ... arrivo PIENO (porta a qualcosa) | 120 | 45,00% | 46,88% | 46,00% | −11,24 |

**Scomposta per destinazione** (dove porta la scala mobile):

| porta a | n | tutto | recente | vecchio | pip/tr |
|---|---|---|---|---|---|
| G 官鬼 | 46 | 50,00% | 52,17% | 50,00% | −3,40 |
| B 兄弟 | 14 | 50,00% | 60,00% | 33,33% | +6,87 |
| P 父母 | 39 | 46,15% | 52,94% | 45,00% | −19,75 |
| W 妻財 | 19 | 26,32% | 15,38% | 50,00% | −27,22 |
| C 子孫 | 2 | 50,00% | — | — | −0,45 |

**Nessuna destinazione produce segnale.** G, la destinazione dottrinalmente più significativa,
sta esattamente a 50,00% con entrambi i periodi a 50.
Nota: la carta sorgente della distinzione vuoto/pieno (EURJPY 29/04/2024) cade nella riga
"arrivo vuoto", che è la migliore delle due — cioè fra le carte che il criterio *non* copre.

# 19. IL G NASCOSTO RAGGIUNTO DAL BAZI  ·  `BOCCIATA`

Carta sorgente: **EURJPY 29/04/2024**. Doppio 辰 (mese + anno/Tai Sui) che combina il
伏神 官鬼 酉 dietro L3 (辰酉合), trigramma inferiore → SHORT. Il mercato scende. ✓

| condizione | n | tutto | recente | vecchio |
|---|---|---|---|---|
| G nascosto combinato dal Bazi | 176 | 51,14% | 58,24% | 45,33% |
| **... da un ramo DOPPIO** (la condizione esatta) | **16** | **43,75%** | 50,00% | 33,33% |
| ... doppio che include il Tai Sui | 14 | 50,00% | 50,00% | 50,00% |
| ... combinato dal Tai Sui | 109 | 53,21% | 57,81% | 45,45% |

Le forme larghe hanno i due periodi in contraddizione netta (58,24% vs 45,33%): profilo di
cella adattata al periodo recente.

---

# BILANCIO DELLA GIORNATA — il metodo delle carte problematiche

**Sei letture di Edu su sei carte problematiche.** Ogni volta:
- la lettura è risultata **dottrinalmente corretta sulla sua carta** (verificata al passo);
- ha prodotto **una regola vera**, che è rimasta nel modulo (回頭剋, 暗動 con arrivo,
  esagramma trasformato unico, autocombinazione, bloccaggio che non avviene su linea in moto);
- misurata **sul proprio dominio**, ha dato fra 43% e 50%.

| lettura | carta | dominio | esito sul dominio |
|---|---|---|---|
| ripiego G→W→mobile | EURJPY 15/03/2023 | 202 | 56,44% (perde nel recente) |
| generazione della mobile | GBPUSD 03/10/2022 | 944 | 48,94% |
| G allo Ying generato | GBPUSD 03/10/2022 | **8** | **100%** ← in osservazione forward |
| scala mobile | EURJPY 11/12/2023 | 146 | 46,58% |
| G nascosto dal Bazi doppio | EURJPY 29/04/2024 | 16 | 43,75% |
| scala mobile per destinazione | — | 19-46 | 26-50% |

**Posizione di Edu:** il LY ha variabilità enormemente superiore al PB, quindi ogni regola
copre per forza pochi casi; "poche carte" non è motivo per scartare. **Critica accolta**: un
sistema di cento regole da 40 carte è legittimo quanto uno di tre regole da mille.

**Posizione di Claude:** il problema non è la numerosità ma che le regole perdono **sul
proprio dominio** — dove si applicano, non fuori. E il modello "molte regole locali valide"
fa una previsione controllabile: accumulandole, il totale deve salire. Dopo sei aggiunte il
LY autonomo resta a **50,5%** contro un riferimento di 50,40%.

**Protocollo concordato:** ogni regola nuova si fissa con il **dominio dichiarato**, e il
totale cumulativo si aggiorna a ogni aggiunta, così il processo ha un termometro.

**Proposta ancora aperta (Claude):** dieci carte con la configurazione attiva, esiti coperti,
Edu applica le sue regole e scrive LONG/SHORT prima di vedere gli esiti. È l'unica verifica
che con campioni piccoli conserva validità, e produrrebbe letture da studiare per capire cosa
manca ancora al motore.


---

# 20. IL CAPOLINEA DEL FLUSSO — CHI ACCUMULA AGISCE  ·  `SCOPERTA` (13/08/2026)

**Il primo risultato della sessione in cui una lettura Liu Yao AUTONOMA esce nettamente dal
50%.** Nessun PB, nessuna EMA: direzione pura dalla posizione della linea (inferiore L1-3 =
SHORT, superiore L4-6 = LONG), confrontata con la direzione reale del mercato.

## Definizione
**Capolinea** = linea viva che **riceve** da un elemento presente e vivo (nelle linee o nel
Bazi) e **non cede** ad alcun elemento presente e vivo. Accumula il flusso del qi e non lo
disperde. Si conta solo quando il capolinea è **unico** sulla carta.
(È lo stesso principio del flusso del qi discreto già attivo nel PB, applicato alle linee.)

## Risultati — riferimento 50,40%

| capolinea unico è... | n | tutto | recente | vecchio | pip/tr |
|---|---|---|---|---|---|
| **G 官鬼** | **325** | **57,23%** | **59,71%** | **55,88%** | **8,35** |
| W 妻財 | 253 | 54,55% | 53,90% | 53,93% | 4,90 |
| P 父母 | 198 | 54,04% | 58,54% | 47,76% | 1,12 |
| C 子孫 | 425 | 50,82% | 52,65% | 48,40% | −0,54 |
| B 兄弟 | 498 | 48,80% | 50,52% | 46,02% | −4,72 |
| *tutti insieme* | 1699 | 52,38% | 54,03% | 50,29% | 0,94 |

**Capolinea G: 57,23% su 325 carte, sopra il baseline su ENTRAMBI i periodi** (59,71% e
55,88%), 8,35 pip/trade. Campione ampio, cella stabile.
W conferma a 54,55% con i due periodi allineati (53,90% / 53,93%).
C e B in fondo — coerente con la dottrina di Edu: *"Children e Brother non svolgono ruolo,
stanno fermi"*.

## Perché conta
Il capolinea è il criterio che mancava per stabilire **chi agisce** su una carta: non chi è
più prospero in stagione, ma **chi accumula il flusso e non lo cede**. L'ordine dei parenti
che ne risulta (G · W · P · C · B) riproduce esattamente la gerarchia dottrinale enunciata
da Edu durante tutta la sessione.

## Carta sorgente — USDJPY 10/02/2026
Anno 午, mese 寅, giorno 乙卯. Il Legno 寅 cede al Tai Sui 午; il Fuoco 午 genera la Terra 辰
(W a L3); 辰 non cede perché l'unico Metallo (酉, il G) è stato distrutto. **辰 è il capolinea**,
trigramma inferiore → SHORT. Il mercato scende di 175 pip. ✓

## Da stringere (prossimi test)
Capolinea G incrociato con: posizione · stato della linea · coincidenza col Tai Sui ·
coincidenza col ramo del giorno (日辰臨爻) · presenza a Shi/Ying.

---

# 21. 争合 — COMBINAZIONE CONTESA  ·  `ARCHIVIATA` (vale sulla carta, non generalizza)

Principio (classico, non ad hoc): **un ramo non può ricevere due combinazioni insieme**.
Se la partenza della mutante è già combinata da un ramo del Bazi, l'arrivo della linea in
暗動 non ha atterraggio: la scala mobile non si forma, e la linea in 暗動 distrugge la
propria partenza.

**Discrimina perfettamente le due carte gemelle** (stesso esagramma 噬嗑→无妄, stesso seme 156,
stessa mutante L5, stesso ramo del giorno 卯):

| | EURJPY 11/12/2023 | USDJPY 10/02/2026 |
|---|---|---|
| Tai Sui | 卯 (combina 戌) | **午 (combina 未 = L5)** |
| L5 未 | libera → scala mobile si forma | **contesa → non si forma** |
| esito | mercato sale, LY giusto | mercato scende, LY sbagliato |

**Ma non generalizza:** scala mobile libera 46,56% · scala mobile contesa 46,67% (n=15).
Toglie 15 carte su 146 e lascia il quadro identico.
Da conservare: il principio è corretto e potrà servire dentro regole con più occorrenze.


---

# 22. 進神 / 退神 — LINEA AVANZANTE E RETROCEDENTE  ·  `FISSATA` (implementata in liuyao.js)

Dottrina classica, **mancava del tutto** al modulo: il caso 5 (比和, stesso elemento) era
trattato come semplice rinforzo, senza distinguere avanzamento e arretramento.
Carta sorgente: **EURGBP 18/03/2020** (seme 90, sup 3 離, inf 2 兌, mutante L2, giorno 庚申,
mese 卯, anno 子).

## Definizione
Quando la mobile si muove in un ramo dello **stesso elemento**:
- **進神 avanzante** — successione oraria: 寅→卯 · 巳→午 · 申→酉 · 亥→子 · Terra 丑→辰→未→戌
- **退神 retrocedente** — successione antioraria: 卯→寅 · 午→巳 · 酉→申 · 子→亥 · Terra 戌→未→辰→丑

**Chi avanza vince** → direzione dalla sua posizione.
**Chi retrocede perde** → vince il trigramma **opposto**.

## Risultati — riferimento 50,40%

| | n | tutto | recente | vecchio | pip/tr |
|---|---|---|---|---|---|
| 進神 avanzante — vince lui | 278 | 52,52% | 51,30% | 53,85% | 0,18 |
| 退神 retrocedente — vince l'opposto | 399 | 53,13% | 50,44% | 57,23% | 3,71 |

Entrambe sopra il riferimento su **entrambi i periodi** — prima regola sulla mutante a
riuscirci. Celle interne notevoli:
- **退神 con mobile forte in stagione**: 193 · 54,92% (52,63 / 57,53) · +1.381 pip · 7,16 pip/tr
  — la condizione descritta da Edu: *la linea che si muove è molto forte, quindi si muove lo
  stesso e retrocede*
- **退神 con mobile = G**: 110 · 55,45% (51,43 / 62,86) · 6,66 pip/tr

# 23. IL CLASH SULL'ARRIVO AMPLIFICA LA PROGRESSIONE  ·  `FISSATA`

**La scoperta più netta sulla mutante.** Il clash del giorno **sul ramo d'arrivo** porta
entrambe le progressioni da ~52% a **65-67%**:

| | n | tutto | recente | vecchio | pip/tr |
|---|---|---|---|---|---|
| **退神 · ARRIVO clashato dal giorno** | 26 | **65,38%** | 61,54% | 69,23% | **19,17** |
| 退神 · arrivo NON clashato | 373 | 52,28% | 49,77% | 56,16% | 2,63 |
| **進神 · ARRIVO clashato dal giorno** | 21 | **66,67%** | 66,67% | 66,67% | **22,81** |
| 進神 · arrivo NON clashato | 257 | 51,36% | 50,00% | 52,78% | −1,67 |

Due periodi allineati in **tutte e quattro** le celle. Resa per trade da 2,63 a 19,17 e da
−1,67 a 22,81.

**È specifico dell'ARRIVO, non del clash in generale:** con la *partenza* clashata il 退神 fa
54,84% ma con periodi divergenti (38,89 / 75,00) e il 進神 addirittura 45,83%.

**Lettura:** il ramo d'arrivo colpito dal giorno non annulla il movimento, lo **rende visibile**
— il clash attiva l'arrivo invece di spegnerlo.

⚠ **Clausola di Edu NON confermata:** la condizione *"il clash bloccherebbe il movimento, ma
chi clasha è debole e la linea forte quindi si muove lo stesso"* non regge. Il caso
"clashante debole + mobile forte" esiste in 7 carte e dà 50%; il caso opposto dà 65-67%.
**Non serve che il clashante sia debole** — il clash sull'arrivo è il segnale in sé, quale che
sia la forza di chi colpisce. (EURGBP 18/03/2020 cade infatti nella cella al 65%.)

⚠ Campione complessivo delle celle clashate: 47 carte. La coerenza fra le due progressioni
indipendenti e fra i due periodi in tutte e quattro le celle è però un segno forte.


---

# 24. 退神 IMPEDITO DAL TAI SUI  ·  `FISSATA` (Edu, 13/08/2026)

Carta sorgente: **EURJPY 13/06/2023** (seme 150, sup 2 兌, inf 6 坎, mutante L5,
giorno 壬寅, mese 午, anno 卯).

**Regola:** la mobile vuole retrocedere (退神) ma il **Tai Sui clasha la PARTENZA**: non
potendo retrocedere, **prosegue** — la direzione resta quella della sua posizione, non
l'opposta. Qui: mobile L5 酉→申 (退神), Tai Sui 卯 clasha 酉 (卯酉冲) → il retrocedere è
impedito → L5 è nel trigramma superiore → LONG. Il mercato sale di 120 pip. ✓

| | n | tutto | recente | vecchio |
|---|---|---|---|---|
| **退神 bloccato dal Tai Sui → prosegue (sua posizione)** | 30 | **56,67%** | 60,71% | — |
| *(se invece si applicasse l'opposto)* | 30 | 43,33% | 39,29% | — |
| 退神 libero → vince l'opposto | 369 | **53,93%** | 52,02% | 57,23% |

L'eccezione porta quelle 30 carte **dal 43,33% al 56,67%** (+13 punti) e **ripulisce anche la
cella principale**, che sale da 53,13% a 53,93%. Non aggiunge solo un caso: migliora la regola
madre.

⚠ Le 30 carte cadono **tutte nel periodo recente** (il clash Tai Sui↔partenza dipende dal ramo
dell'anno, e certi anni non ricorrono nel campione): il controllo sui due periodi non è
possibile. Da riverificare quando il campione crescerà.

# 25. G AUTOPENALIZZATO DAL MESE — "CHI NON VINCE PERDE"  ·  `FISSATA` (Edu, 13/08/2026)

Stessa carta. Il mese è **午** e il G è **午**: 午午自刑. Di norma il mese non interviene — sono
il Tai Sui e il giorno a farlo — **ma quando il flusso del qi lo carica al punto da non potersi
tirare indietro, è il mese stesso a penalizzare G**. Qui l'anno 卯 e il giorno 寅 sono entrambi
Legno e generano il Fuoco 午: **doppio carico**.
G penalizzato ⇒ non vince ⇒ **perde**: la direzione è l'**opposta** alla posizione di G.
(Qui G 午 è a L3, inferiore ⇒ direzione LONG. Il mercato sale. ✓)

| | n | tutto | recente | vecchio | pip/tr |
|---|---|---|---|---|---|
| G autopenalizzato dal mese — direzione di G | 97 | 45,36% | 43,24% | 50,00% | −4,38 |
| G autopenalizzato dal mese — direzione **OPPOSTA** | 97 | 54,64% | 56,76% | 50,00% | 4,38 |
| ... e il flusso carica il mese (1 ramo) — opposta | 55 | 49,09% | 51,16% | 41,67% | 1,36 |
| **... DOPPIO carico sul mese — opposta** | **14** | **78,57%** | 76,92% | 100,00% | **23,96** |

Il principio generale (direzione opposta a G autopenalizzato) tiene a 54,64%.
Il **doppio carico** è la condizione forte: 78,57%, entrambi i periodi alti.
⚠ Il carico **singolo** peggiora rispetto al caso generale (49,09%): conta il doppio, non il
semplice — coerente con "il mese non può tirarsi indietro" solo quando è caricato due volte.
⚠ Campione del doppio carico: **14 carte**. Fissata su indicazione di Edu; da confermare in
avanti.

## Contesto verificato della carta sorgente
Non era un'inversione: EMA **rialzista alla sesta barra**, dentro una corsa che arriverà a 16
(giorni vicini: +34, **+120**, +52, +173, +150, +135). Sia LY sia PB leggevano SHORT contro un
rialzo maturo e consolidato.


---

# 26. L'ARRIVO VUOTO NON ANNULLA LA PROGRESSIONE  ·  `BOCCIATA`

Carta sorgente: **EURJPY 06/03/2025**. Ipotesi: la progressione che approda a un ramo vuoto
non produce nulla (il mese clasha invano l'arrivo vuoto ⇒ direzione invertita).

| | n | tutto | recente | vecchio | pip/tr |
|---|---|---|---|---|---|
| arrivo PIENO — regola normale | 572 | 53,32% | 52,01% | 55,60% | 0,72 |
| **arrivo VUOTO non risvegliato — regola normale** | 98 | **53,06%** | 52,73% | 56,41% | **8,22** |
| arrivo vuoto non risvegliato — **invertita** | 98 | 46,94% | 47,27% | 43,59% | −8,22 |
| arrivo vuoto **risvegliato** (giorno/anno forte) | 7 | 71,43% | 100% | 60,00% | 24,30 |

Con l'arrivo vuoto la regola normale continua a funzionare (53,06%, come col pieno) e rende
**dieci volte di più per trade**. Invertire porta al 46,94%, sotto il caso su entrambi i periodi.
Il caso "mese che clasha invano" esiste in **6 carte**: 66,67% totale ma 100% recente / 0%
vecchio — indistinguibile dal caso.
**Carta di controllo: USDCAD 03/09/2020** — stessa configurazione (G mobile, arrivo vuoto,
mese che clasha invano, mobile debolissima) ma esito opposto: la regola normale vince.

# 27. LA MOBILE DISTRUTTA — NON SI LEGGE  ·  `FISSATA` (Edu, 13/08/2026)

Carta sorgente: **USDCAD 03/09/2020** (seme 130, sup 8 坤, inf 2 兌, mutante L2,
giorno 己酉, mese 申, anno 子).

**Conflitto risolto dentro il modulo:** 動不為空 teneva viva la mutante anche quando è
**vuota + clashata dal giorno + untimely**, mentre la regola 3 dice che in quel caso è
**eliminata**. Vince la regola 3: la mobile distrutta **non si legge**.

Sulla carta: mobile L2 官鬼 **卯**, vuota (旬空 寅卯), clashata dal giorno **酉** (卯酉冲) e
**死** nel mese 申 ⇒ distrutta. Legge invece **妻財 亥 a L5**, 相 e in alto ⇒ LONG. Il mercato
sale. ✓ (L6 子孫 酉 è escluso due volte: è C — non agisce — ed è in **自刑** col giorno 己酉.)

| | n | tutto | recente | vecchio |
|---|---|---|---|---|
| **progressione applicata comunque** (errore) | 10 | **30,00%** | 0,00% | 33,33% |

Ignorare la distruzione e leggere la progressione **sbaglia sistematicamente**.
Carte con mobile distrutta: **36**.

# 28. CHI LEGGE AL POSTO DELLA MOBILE: LA FORZA, NON LA GERARCHIA  ·  `FISSATA`

Applicando le regole già registrate (C e B non agiscono · 自刑 dal giorno esclude ·
gerarchia G→W→P):

| | n | tutto | recente | vecchio | pip/tr |
|---|---|---|---|---|---|
| **vincitore TIMELY** | 17 | **58,82%** | 57,14% | 62,50% | **+15,72** |
| gerarchia G→W→P completa | 36 | 41,67% | 41,18% | 43,75% | −12,85 |
| vincitore = W (anche non timely) | 18 | 33,33% | 25,00% | 50,00% | −17,75 |

> **Non è l'ordine dei parenti a decidere, è la forza in stagione.**
> La gerarchia applicata a linee deboli fa danno (41,67%); il criterio "chi è timely" da solo
> tiene (58,82%, sopra su entrambi i periodi).

Coerente con il principio ripetuto da Edu — *si legge ciò che è timely, ciò che è rilevante* —
e **contro** l'implementazione precedente, che metteva il parente prima della forza.
Concorda con il **capolinea G** (§20, 57,23% su 325 carte), il risultato più ampio della sessione.

---

## ⚠ PROMEMORIA OPERATIVO PER CLAUDE

Le regole registrate vanno **applicate in ogni test**, non solo ricordate. In §27-28 la
selezione dei candidati inizialmente ignorava due regole già fissate (自刑 dal giorno e
"C e B non agiscono") ed è stato Edu a doverlo segnalare. **Prima di ogni misura: rileggere
l'elenco delle regole attive e verificare che siano tutte applicate.**


# 29. 暗動 AUTOPENALIZZATA — "CHI NON VINCE PERDE"  ·  `FISSATA` (verso confermato)

Carta sorgente: **USDJPY 13/12/2023** (seme 145, sup 2 兌, inf 1 乾, mutante L3,
giorno 乙巳, mese 子, anno 卯).
Una linea clashata dal giorno vuole muoversi; se sta nel trigramma che **non muta**, il suo
arrivo è **lo stesso ramo** — non va da nessuna parte — e se il ramo è di autopenalità
(辰 午 酉 亥) si penalizza. Applicando §25 (*chi non vince perde*): **il suo trigramma perde**.
Qui: L4 妻財 **亥**, 旺 nel mese 子, clashata dal giorno 巳 (巳亥冲); la mutante è L3 quindi il
trigramma superiore non muta e l'arrivo è ancora 亥 → 亥亥自刑 → il **superiore perde** → SHORT.
Il mercato scende di 240 pip. ✓

| | n | tutto | recente | vecchio | pip/tr |
|---|---|---|---|---|---|
| **暗動 autopenalizzata → il suo trigramma PERDE** | 307 | **52,77%** | 50,85% | 57,89% | 4,26 |
| *(se invece vincesse)* | 307 | 47,23% | 49,15% | 42,11% | −4,26 |
| ... linea FORTE (vibrante) | 97 | 52,58% | 47,17% | 61,54% | 4,33 |
| ... linea debole | 210 | 52,86% | 52,42% | 56,00% | 4,22 |

Verso confermato su **307 carte**, sopra il riferimento su entrambi i periodi.
⚠ **Clausola sulla vibranza NON confermata:** forte 52,58% · debole 52,86% — identiche (e la
forte è peggiore nel recente). Conta solo che la linea sia **bloccata**, non che sia vibrante.
⚠ Regola vera ma **debole**: +2,4 punti sul riferimento, non paragonabile al capolinea G.

# 30. LETTURA CON TUTTE LE REGOLE INSIEME  ·  risultato cumulativo (13/08/2026)

Ordine di precedenza applicato: **mobile distrutta → progressione 進神/退神 (con eccezione
Tai Sui) → capolinea G**.

| via | n | tutto | recente | vecchio | pip/tr |
|---|---|---|---|---|---|
| **capolinea G** | 264 | **57,95%** | 61,74% | 55,88% | 9,08 |
| mobile distrutta → timely | 12 | 58,33% | 42,86% | 80,00% | 19,13 |
| 退神 | 395 | 54,18% | 53,33% | 57,05% | 2,90 |
| 進神 | 278 | 52,52% | 51,30% | 53,85% | 0,18 |
| **LETTURA COMPLETA** | **949** | **54,79%** | **54,49%** | **56,04%** | **4,03** |

**Il LY autonomo passa da 50,5% a 54,79% su 949 carte**, sopra il riferimento su entrambi i
periodi, +3.823 pip. La previsione del modello di Edu (*molte regole locali che, accumulate,
alzano il totale*) **si è verificata**: era a 50% stamattina con sei regole, è a 54,79% con
dodici. Il termometro concordato funziona e va aggiornato a ogni aggiunta.


---

# 31. 三會 — COMBINAZIONI DIREZIONALI  ·  `FISSATA` con la condizione del mese

**Sistema classico che mancava del tutto al modulo** (c'erano solo 六合 e mezze triadi).
寅卯辰 東方木局 · 巳午未 南方火局 · 申酉戌 西方金局 · 亥子丑 北方水局.
Quando i tre rami sono presenti fra linee e Bazi, l'elemento diventa "vibrante" e le sue
linee vincono **senza bisogno di essere generate**.

| | n | tutto | recente | vecchio | pip/tr |
|---|---|---|---|---|---|
| **三會 col MESE dentro** | 406 | **53,94%** | 51,83% | 55,63% | 5,80 |
| 三會 senza il mese | 298 | 47,99% | 46,15% | 50,93% | 0,23 |
| tutte insieme | 704 | 51,42% | 49,25% | 53,73% | 3,44 |

**La 三會 vale solo se il mese ne fa parte** (sei punti di differenza): è un raduno
*stagionale* — 方合 — non un semplice incontro di rami. Le 三會 sono frequenti: 1.825 carte
ne contengono almeno una.
Collaterale: elemento formato = **B 兄弟** dà 56,49% (il migliore) — strano perché B "non
agisce", ma nel vecchio scende a 50,88%: non consolidabile.

# 32. L'ORA NEI RADUNI  ·  `BOCCIATA`

L'ora dal seme **è stata aggiunta al modulo** (`liuyao.js`, campo `oraBranch`, funzione
`oraDalSeme`) — prima non esisteva affatto nel LY, pur essendo usata dal PB.
Come **membro delle 三會**, però, peggiora:

| | senza ora | con ora |
|---|---|---|
| 三會 col mese | **53,94%** (n=406) | 50,82% (n=429) |
| mese **e** ora dentro | — | 49,69% (n=159) |
| ora senza il mese | — | 53,37% (n=163) |

# 33. IL CAPOLINEA G DRENATO DAL PROPRIO 伏神  ·  `SCOPERTA` — la cella più forte

| | n | tutto | recente | vecchio | pip/tr |
|---|---|---|---|---|---|
| **capolinea G drenato dal proprio 伏神** | 126 | **60,32%** | **64,71%** | 57,47% | **11,90** |
| capolinea G non drenato | 199 | 55,28% | 58,10% | 54,22% | 6,09 |
| *(direzione opposta)* | 126 | 39,68% | 35,29% | 42,53% | −11,90 |

**60,32% su 126 carte, sopra su entrambi i periodi.** Il nascosto dietro G è **sempre P** per
costruzione elementale (G controlla il palazzo; ciò che G genera è P).
**Nessuna contraddizione con §12** (P sfavorevole): le due popolazioni sono **disgiunte** —
il capolinea è per definizione una linea che non cede a nessun elemento vivo, quindi quando
il capolinea è G il P **non è mai presente in carta** (verificato: 326/326).
⚠ Perché il P *nascosto dietro il G* dia 5 punti in più rispetto a un P nascosto altrove
resta **senza spiegazione dottrinale**. Domanda aperta.

# 34. 刑 PENALITÀ  ·  `FISSATA` — secondo sistema classico aggiunto oggi

三刑 寅巳申 (無恩之刑) · 丑戌未 (恃勢之刑) · 相刑 子卯 (無禮之刑) · 自刑 辰午酉亥.
Ipotesi di Edu: linea in 刑 col proprio 伏神 — se **entrambi forti** la penalità morde e il
suo trigramma **perde**.

| linea in 刑 col proprio 伏神 | n | tutto | recente | vecchio | pip/tr |
|---|---|---|---|---|---|
| **entrambi DEBOLI** — sua direzione | 160 | **55,63%** | 54,64% | 58,33% | 6,39 |
| tutte | 354 | 54,24% | 53,13% | 55,38% | 6,21 |
| **entrambi FORTI** — sua direzione | 53 | **49,06%** | 50,00% | 47,22% | 7,45 |

**Confermata**: forti ⇒ penalità attiva ⇒ il trigramma perde (49,06%); deboli ⇒ penalità
inerte ⇒ il trigramma vince (55,63%). Sei punti e mezzo di differenza, verso coerente sui
due periodi.
⚠ È specifico del rapporto **linea ↔ proprio 伏神**: il 刑 con un ramo del **Bazi** non
funziona (49,06% su 1.333 carte).

# 35. VERIFICA MIRATA — 伏神 父母 巳 dietro G 官鬼 寅

Richiesta da Edu. **326 carte** con la configurazione esatta.

| | n | tutto | recente | vecchio | pip/tr |
|---|---|---|---|---|---|
| totale — direzione del suo trigramma | 326 | 53,99% | 52,45% | 55,43% | 5,78 |
| **UNTIMELY** — direzione del suo trigramma | 217 | **55,30%** | 54,17% | 57,45% | 5,23 |
| TIMELY — direzione del suo trigramma | 109 | 51,38% | **43,48%** | 53,09% | 6,88 |

**È l'untimely a vincere**, non il timely — controintuitivo rispetto a §28.
La spiegazione è arrivata da Edu: **寅 e 巳 formano una penalità** (parte di 寅巳申). Quando
sono forti la penalità è attiva e lo short perde; quando sono deboli non morde.
⚠ Limite strutturale: nel campione la linea è **sempre a L2**, quindi la direzione è sempre
SHORT — la cella non distingue "il trigramma inferiore vince" da "in queste condizioni il
mercato scende". Le carte sono inoltre addensate in periodi contigui (stesso Bazi), quindi la
correlazione fra osservazioni è alta.

# 36. FLUSSO A CASCATA  ·  `BOCCIATA` — e stato della §29

Edu **ritira** l'autopenalità della linea non mobile clashata (§29) e la sostituisce: una
linea non mobile clashata, col ramo futuro identico, **cede energia a chi può prenderla**,
specialmente se adiacente, formando una cascata; la direzione viene dalla linea terminale.

| | n | tutto | recente | vecchio | pip/tr |
|---|---|---|---|---|---|
| cascata → direzione della terminale | 1624 | 47,84% | 48,57% | 46,98% | −2,00 |
| *(direzione opposta)* | 1624 | 52,16% | 51,43% | 53,02% | 2,00 |
| cascata di 2 passi | 318 | 44,34% | 50,33% | 39,24% | −3,26 |
| cascata di 3 passi | 21 | 33,33% | 36,84% | 0,00% | −10,45 |

Peggiora quanto più la cascata è lunga. **Bocciata.**
⚠ **§29 resta in sospeso**: nella forma "il trigramma della linea bloccata perde" misurava
**52,77% su 307 carte**, positiva su entrambi i periodi, ma Edu la ritiene dottrinalmente
sbagliata e l'ha ritirata. La sostituta misura 47,84%. **Decisione non presa.**

## Carta completa — USDJPY 16/01/2024 (lettura confermata da Edu)
seme 145, sup 2 兌, inf 1 乾, mutante L1, giorno 己卯, mese 丑, anno 卯, ora dal seme 子,
palazzo 坤, vuoti 申酉. Mercato **+139 pip** (LONG); PB diceva SHORT e perde.
1. **L4 妻財 亥 è timely di suo** (inverno) e, in mancanza di opposizione più energetica,
   prevale → trigramma superiore → LONG
2. la **penalità 寅巳 su L2** è forte e fa perdere lo SHORT
3. la **combinazione 子丑 su L1** rende la linea inutilizzabile e peggiora lo SHORT


---

# 37. TIMELY vs FORTE — LA DISTINZIONE FONDAMENTALE  ·  `FISSATA` (Edu, 13/08/2026)

> **TIMELY** (dal mese) = effetto **ampio e generalizzato**: coinvolge tutti gli attori
> dell'esagramma, nel bene e nel male.
> **FORTE** (da giorno e anno) = effetto **concentrato ma poco diffuso**: agisce su una linea
> per via diretta, non sulle altre.
> Giorno e anno sono *forti* ma **non** *timely*.

Questa distinzione scioglie la contraddizione emersa in §34/§FORZAB, dove "entrambi forti"
cambiava di segno a seconda della definizione usata: mescolava due meccanismi diversi.

## 37a. TIMELINESS DOPPIA — i mesi di Terra

Il timeliness è dato dal mese in **due modi**: il suo **elemento** e la sua **stagione**.
Coincidono in otto mesi su dodici; divergono nei quattro mesi di Terra:

| mese | elemento | stagione | timely insieme |
|---|---|---|---|
| 辰 | Terra | primavera (Legno) | Terra + Legno |
| 未 | Terra | estate (Fuoco) | Terra + Fuoco |
| 戌 | Terra | autunno (Metallo) | Terra + Metallo |
| 丑 | Terra | inverno (Acqua) | Terra + Acqua |

*(Esempio di Edu: 丑 è Terra e rende timely la Terra, ma è anche inverno e rende timely
l'Acqua — Acqua con Terra crea la fanghiglia.)*

**Misura — stesso tasso, copertura molto maggiore:**

| | n | tutto | recente | vecchio | pip |
|---|---|---|---|---|---|
| Ricchezza timely unica — **semplice** | 652 | 55,83% | 52,20% | 60,53% | +3.890 |
| Ricchezza timely unica — **doppia** | 823 | 55,77% | 51,56% | 62,24% | **+4.828** |
| mesi di Terra — semplice | 169 | 54,44% | 53,64% | 53,19% | +466 |
| mesi di Terra — **doppia** | 340 | **55,00%** | 51,47% | 61,90% | **+1.405** |

+171 carte allo stesso livello; nei mesi di Terra la copertura **raddoppia** (169→340) e i pip
**triplicano**. È il comportamento atteso da una definizione più corretta: più linee attive
riconosciute, stessa affidabilità.
⚠ Il modulo usa ancora `stagione()` con il solo elemento del mese: **da aggiornare in
liuyao.js e nel motore**.

# 38. 刑 — SCOMPOSIZIONE PER TIPO DI FORZA  ·  `FISSATA`

(S = forte in stagione · B = forte solo per sostegno del Bazi · − = nessuna delle due;
prima lettera = linea, seconda = suo 伏神)

**Quando è il NASCOSTO ad avere la forza stagionale, la penalità morde → il trigramma perde:**

| | n | tutto | recente | vecchio | pip/tr |
|---|---|---|---|---|---|
| **−S** → direzione OPPOSTA | 23 | **65,22%** | 71,43% | 55,56% | 26,88 |
| **SB** → direzione OPPOSTA | 32 | 62,50% | 58,33% | 66,67% | 24,51 |
| **−−** → direzione OPPOSTA | 26 | 61,54% | 64,29% | 58,33% | 15,67 |

**Quando è la LINEA a essere sostenuta dal Bazi, il suo trigramma vince:**

| | n | tutto | recente | vecchio | pip/tr |
|---|---|---|---|---|---|
| **B−** → sua direzione | 18 | **77,78%** | 100% | 69,23% | 31,42 |
| **BS** → sua direzione | 54 | 59,26% | 65,00% | 55,88% | 9,27 |
| **BB** → sua direzione | 72 | 58,33% | 57,14% | 62,96% | 6,37 |

Il criterio non è "entrambi forti" ma **chi ha la forza e di che tipo**.
⚠ La cella **BB** (58,33%) sbaglia la carta sorgente USDCAD 20/09/2022, dove la lettura di Edu
dà LONG: lì il Tai Sui 寅 sostiene il G e il nascosto 巳 è a sua volta sostenuto, ma la
direzione la determina **L5 妻財 亥 timely** (mese 酉 lo genera, giorno 子 è suo pari).
Due meccanismi distinti che agiscono insieme: il Tai Sui con forza **concentrata** tiene viva
la penalità; L5 con effetto **ampio** determina la direzione.

# 39. TERMOMETRO — dopo la rimozione del 進神

Il 進神 rendeva −0,61 pip/trade ed è stato **rimosso** dalla catena.

| via | n | tutto | recente | vecchio | pip/tr |
|---|---|---|---|---|---|
| capolinea G **drenato** | 126 | **60,32%** | 64,71% | 57,47% | 11,90 |
| mobile distrutta | 12 | 58,33% | 42,86% | 80,00% | 19,13 |
| capolinea G | 198 | 55,56% | 58,10% | 54,88% | 6,31 |
| 退神 | 350 | 54,57% | 54,07% | 57,36% | 2,18 |
| 三會 col mese | 468 | 54,49% | 52,28% | 56,72% | 6,19 |
| 刑 col 伏神 (deboli) | 102 | 51,96% | 49,25% | 58,82% | 3,90 |
| **TOTALE** | **1256** | **55,10%** | **54,00%** | **57,06%** | **5,60** |

**Progressione della giornata:** 50,4% (8 euristiche, 4.111 carte) → 50,5% (6 regole) →
54,79% (12 regole, 949 carte) → 54,47% (con 三會 e 刑, 1.454) → **55,10% (1.256, +7.039 pip)**.
Togliendo il 進神, le sue carte sono passate alla 三會 che è salita da 53,72% a 54,49%.
⚠ Prossimo candidato al taglio: **刑 col 伏神 (deboli)**, 51,96%.


---

# 40. IL GRUPPO PEGGIORE — "4 LINEE NON AGIBILI"

Ricerca sui gruppi strutturali: il peggiore per il PB è **quattro linee su sei non agibili**
(legate, rotte, dormienti, eliminate, autocombinate): **47,78% su 90 carte**, pip ≈ 0.
Altri gruppi deboli: Shi in stato "mossa" 48,00% · mese 巳 49,54% · mese 寅 49,59% ·
palazzo 巽 51,01% · mutante a L5 51,97% · Shi=G 52,05% · mutante=P 52,41%.

# 41. 飛神空伏神出 — IL NASCOSTO DIETRO UNA COPERTURA VUOTA  ·  `SCOPERTA`

Carta sorgente: **USDJPY 15/01/2025** (seme 158, sup 3 離, inf 6 坎, mutante L6,
giorno 甲申, mese 丑, anno 辰, ora 丑, palazzo 離, vuoti 午未). Mercato **−159 pip** (SHORT).
Principio classico: quando la linea che copre è **vuota**, è *trasparente* e il 伏神 emerge.

**È la COMBINAZIONE dei due fattori a contare, non il nascondimento né il vuoto da soli:**

| G | n | tutto | recente | vecchio | pip/tr |
|---|---|---|---|---|---|
| **nascosto sotto copertura VUOTA** | 75 | **36,00%** | 32,65% | 40,91% | −11,25 |
| nascosto sotto copertura PIENA | 417 | 51,56% | 51,67% | 53,16% | 3,94 |
| visibile, linea vuota | 303 | 50,17% | 49,11% | 53,91% | −1,97 |
| visibile, linea piena | 1757 | 51,00% | 48,88% | 54,77% | 2,09 |

Tre celle su quattro stanno al 50-51%; **solo il G sotto copertura vuota crolla a 36,00%**,
su entrambi i periodi. Specifico di G: dietro copertura vuota P dà 54,55%, C 51,56%,
W 47,47%, B 49,21%.
Il **sostegno del giorno non lo salva**: 32,14% su 28 carte (vs 38,30% senza sostegno) —
coerente con §37 (il giorno è *forte* ma non *timely*: agisce in modo concentrato, e un G
sotto copertura vuota non è in condizione di usarlo).
⚠ Limite strutturale: nel campione la copertura è **sempre a L3**, quindi la direzione è
sempre SHORT.

# 42. IL SALTO DELLA LINEA CLASHATA  ·  `FISSATA`

Carta sorgente: **USDJPY 15/01/2025** — L1 父母 **寅** clashato dal giorno **申** (寅申冲)
*salta* a combinarsi (寅亥合) con il **伏神 官鬼 亥** esposto dietro L3 vuoto. Entrambi nel
trigramma inferiore → SHORT. ✓
Una linea clashata dal giorno non resta ferma: **salta a combinarsi** con un'altra linea o con
un nascosto esposto. **Conta dove ARRIVA, non da dove parte.**

| bersaglio del salto (linea visibile) | n | tutto | recente | vecchio | pip/tr |
|---|---|---|---|---|---|
| **妻財 W** | 138 | **57,25%** | 56,25% | 60,71% | **9,73** |
| 兄弟 B | 144 | 54,86% | 53,09% | 56,14% | 0,52 |
| 官鬼 G | 123 | 51,22% | 49,12% | 55,74% | 1,91 |
| 父母 P | 103 | 47,57% | 45,45% | 51,11% | −5,58 |
| 子孫 C | 72 | 44,44% | 40,00% | 51,85% | −12,07 |
| *direzione del bersaglio (tutti)* | 580 | 52,07% | 50,00% | 55,69% | 0,36 |
| *direzione della sorgente* | 580 | 47,93% | 50,00% | 44,31% | −0,36 |
| **nessun bersaglio** — sorgente | 797 | 49,44% | 48,42% | 49,54% | −4,35 |

Il salto su **W paga (57,25%)**; su C e P no — gli stessi parenti che "non svolgono ruolo".
Il clash **senza destinazione non produce nulla** (49,44%), coerente con la misura sul P
quieto clashato (§43).

# 43. IL SALTO MIGLIORA IL G, MA SOLO SE HA FORZA  ·  `FISSATA`

| G (unico visibile) | n | tutto | recente | vecchio | pip/tr |
|---|---|---|---|---|---|
| **bersaglio · forte dal Bazi** | 19 | **63,16%** | 50,00% | 69,23% | 3,37 |
| **bersaglio · timely** | 25 | **60,00%** | 50,00% | 69,23% | 14,25 |
| bersaglio · debole | 8 | 50,00% | 50,00% | 50,00% | 8,39 |
| non bersaglio · forte dal Bazi | 630 | 52,70% | 52,46% | 53,26% | 1,44 |
| non bersaglio · timely | 995 | 50,85% | 48,42% | 55,43% | 1,74 |
| non bersaglio · debole | 383 | 46,74% | 44,73% | 52,21% | −0,13 |

**Il salto aggiunge ~10 punti a parità di forza** (timely 50,85→60,00; forte 52,70→63,16) e
**non aggiunge nulla a un G debole** (50,00%): porta energia solo a chi può riceverla.
⚠ 19 e 25 carte; in entrambe le celle il **recente sta a 50,00% esatto** e tutto il vantaggio
viene dal vecchio.

## 43a. E se il G è ESPOSTO (copertura vuota)?  ·  `IN OSSERVAZIONE` — 5 carte

| | copre | nascosto | forza | esito |
|---|---|---|---|---|
| USDJPY 19/02/2021 | L3 辰空 | 官鬼 酉 | forte (Bazi) | giusto +21 |
| USDJPY 06/04/2021 | L3 午空 | 官鬼 亥 | forte (Bazi) | giusto +40 |
| NZDUSD 04/04/2024 | L3 辰空 | 官鬼 酉 | forte (Bazi) | sbagliato −12 |
| **USDJPY 15/01/2025** | L3 午空 | 官鬼 亥 | **timely** | **giusto +159** |
| USDJPY 11/03/2026 | L3 午空 | 官鬼 亥 | forte (Bazi) | sbagliato −72 |

Tre giuste, due sbagliate. La cella "timely" contiene **una sola carta**. Ma il contrasto con
le celle vicine è forte: G esposto **senza** salto sta al **31-36%** in tutte e tre le fasce di
forza, coerente sui due periodi; **con** il salto sale al 50-60%.
**Verso compatibile con l'ipotesi di Edu, campione insufficiente per confermarla.**
Configurazione rarissima: ~1 carta ogni 800. Da seguire in avanti.

## Conclusione di Edu sulla carta sorgente
> *La carta è comunque risolta: **G è salvo e lo short è confermato**.*
Su USDJPY 15/01/2025 il G 亥, esposto dalla copertura vuota 午 e raggiunto dal salto di
L1 寅 (寅亥合), è timely per stagione nel mese 丑 (inverno = Acqua) e regge la lettura:
trigramma inferiore → SHORT. Il mercato scende di 159 pip. ✓


---

# 44. IL TAI SUI BLOCCA LA PARTENZA: LA LINEA NON PARTE  ·  `FISSATA`

**Correzione logica di Edu (assoluta):** se la combinazione blocca la **partenza**, la linea
non parte affatto — quindi **non può esserci alcuna mutazione**, e non può rafforzarsi con un
回頭生. Le due cose non possono coesistere.
*(Claude aveva proposto una lettura incoerente: "bloccata ma rafforzata". Ritirata.)*

**Misura — la mobile G o W bloccata sulla partenza dal Tai Sui:**

| | n | tutto | recente | vecchio |
|---|---|---|---|---|
| G — vince | 41 | 48,78% | 44,12% | 71,43% |
| G — perde | 41 | 51,22% | 55,88% | 28,57% |
| W — vince | 70 | 48,57% | 40,00% | 52,27% |
| W — perde | 70 | 51,43% | 60,00% | 47,73% |

**Nessun segnale in nessuna direzione**: tutte fra 48,5% e 51,4%, con i due periodi che si
contraddicono violentemente. Coerente con la dottrina: **una linea che non parte non fa
niente** — né vince né perde; il suo trigramma resta muto e la direzione si decide altrove.

⚠ **Il 66,67% della cella "回頭生 + blocco della partenza" (§43-bis, n=42) resta senza
meccanismo.** Il 回頭生 lì è solo un'etichetta sulla relazione elementale ramo↔trasformato,
non un processo avvenuto. Usabile come filtro calcolabile, **ma è correlazione senza causa
identificata**.

**Dato collaterale ampio e stabile: G mobile LIBERA = 46,57%** su 758 carte (47,47% / 44,92%),
−4,97 pip/trade. **Un Ufficiale che si muove liberamente fa perdere il suo trigramma** —
l'opposto del G *capolinea*, fermo, che accumula (57-60%).
> **G vale da fermo, non in movimento** — come P, ma per ragione opposta:
> **P vale quando cede, G quando trattiene.**

# 45. IL TAI SUI BLOCCA L'ARRIVO — SCOPERTA  ·  `FISSATA`

Qui la partenza è **libera**: la linea parte davvero, e il Tai Sui combina il ramo d'**arrivo**.
Meccanismo coerente (a differenza di §44): il movimento avviene, ma la destinazione è chiusa.

Caso generale piatto (51,22% su 369 carte), **ma la scomposizione per parente separa
nettamente e ricalca la dottrina della giornata:**

| la mobile è... | n | tutto | recente | vecchio | pip/tr |
|---|---|---|---|---|---|
| **C 子孫** | 40 | **65,00%** | 66,67% | 60,00% | 20,09 |
| B 兄弟 | 114 | 56,14% | 59,76% | 48,28% | 3,72 |
| W 妻財 | 83 | 55,42% | 46,67% | 62,86% | −6,65 |
| **P 父母** | 78 | **39,74%** | 42,55% | 37,50% | −14,25 |
| **G 官鬼** | 54 | **40,74%** | 43,75% | 31,58% | −9,81 |

**Con l'arrivo bloccato, C e B vincono il loro trigramma; G e P lo perdono** — su entrambi i
periodi (tranne W, instabile). È il **rovescio esatto** della gerarchia usata tutto il giorno.
Lettura: **G e P devono ARRIVARE da qualche parte per contare**; se la destinazione è chiusa
restano a metà strada. C e B non andavano da nessuna parte comunque, e il blocco non toglie
loro nulla.

## 45a. LA CELLA PIÙ FORTE DELLA GIORNATA

| | n | tutto | recente | vecchio | pip/tr |
|---|---|---|---|---|---|
| **回頭生 con ARRIVO bloccato dal Tai Sui** | 44 | **72,73%** | 70,73% | **100%** | 11,14 |

**Meccanismo coerente:** la partenza è libera ⇒ la linea parte; l'arrivo la genera all'indietro
(回頭生) e la rafforza; il Tai Sui blocca l'arrivo, che non può andare oltre ⇒ **l'energia resta
nella linea di partenza**, che domina il suo trigramma.
Confronto interno: caso 1 (回頭生) 72,73% · caso 2 (泄) 48,72% · caso 0 47,06% · caso −1 49,37%
· caso −4 51,85%. **È specifico del 回頭生.**
⚠ 44 carte. Da seguire in avanti, ma il meccanismo è chiaro e i due periodi sono allineati.


---

# 46. IL TAI SUI URTATO DALL'ARRIVO — CHI LO SCONTRA PERDE  ·  `FISSATA`

La partenza è **libera** (la linea parte davvero) e l'**arrivo CLASHA** il ramo dell'anno.

| | n | tutto | recente | vecchio | pip/tr |
|---|---|---|---|---|---|
| **il suo trigramma PERDE** | 301 | **55,15%** | 55,48% | 57,60% | **7,13** |
| *(se invece vincesse)* | 301 | 44,85% | 44,52% | 42,40% | −7,13 |

**301 carte**, sopra il riferimento su entrambi i periodi, +2.147 pip.
Una linea che parte e va a sbattere contro l'anno **non conquista il suo trigramma: lo perde**.

**Per parente** (colonna = "vince"):

| la mobile è... | n | vince | pip/tr |
|---|---|---|---|
| **B 兄弟** | 73 | **36,99%** | −18,31 |
| C 子孫 | 18 | 38,89% | −12,41 |
| **G 官鬼** | 92 | **41,30%** (41,38 / 41,38) | −7,19 |
| W 妻財 | 56 | 46,43% | −2,46 |
| **P 父母** | 62 | **59,68%** | +3,42 |

Quattro parenti su cinque perdono. **G perde con 41,30% identico sui due periodi.**
L'unico che regge è **P** — coerente con tutta la giornata: non essendo un attore e non
pretendendo di arrivare da nessuna parte, non ha nulla da perdere nell'urto.

## Le due facce del Tai Sui
> **Il Tai Sui che FERMA conserva; il Tai Sui che viene URTATO distrugge.**
> - arrivo **bloccato** dal Tai Sui + 回頭生 → **72,73%** (l'energia resta dentro la linea)
> - arrivo che **clasha** il Tai Sui → **44,85%** (l'energia si disperde nell'urto)

# 47. IL TAI SUI SU DUE FRONTI — CHI È IMPEGNATO DUE VOLTE NON TIENE  ·  `FISSATA`

Carta sorgente: **EURJPY 13/12/2024** (seme 159, sup 3 離, inf 7 艮, mutante L4, giorno 辛亥,
mese 子, anno 辰). Mobile L4 妻財 **酉 → 戌**: il Tai Sui 辰 **combina la partenza** (辰酉合)
**e riceve l'urto dell'arrivo** (辰戌冲). Configurazione esclusa da entrambe le misure
precedenti (§45 e §46), perché in quelle la partenza doveva essere libera o bloccata, non
entrambe le cose insieme.

| | n | tutto | recente | vecchio | pip/tr |
|---|---|---|---|---|---|
| **partenza combinata + arrivo che urta → il trigramma VINCE** | 109 | **55,96%** | 54,24% | 57,14% | 4,82 |
| *(il trigramma perde)* | 109 | 44,04% | 45,76% | 42,86% | −4,82 |

**Il verso si ROVESCIA rispetto al clash semplice** (§46: perde, 44,85%). Undici punti di
differenza in direzione opposta.
**Lettura:** quando il Tai Sui è impegnato su **due fronti** — trattiene la partenza e para
l'urto dell'arrivo — **non riesce a fare nessuna delle due cose**, e la linea la spunta.
È lo stesso principio del **争合** (§21): chi è preso da due impegni contemporanei non ne
onora nessuno.
Su EURJPY 13/12/2024 dà **LONG** (L4 superiore, vince) — direzione corretta, +155 pip.

⚠ **Limite serio da tenere presente:** le 109 carte sono quasi tutte **丑→午 con anno 子**,
concentrate nel 2020. La configurazione dipende dal ramo dell'anno, quindi le osservazioni
sono **fortemente correlate** — statisticamente valgono molto meno di 109 indipendenti.

## Quadro riassuntivo del Tai Sui (13/08/2026)

| configurazione | esito | n | % |
|---|---|---|---|
| blocca la **partenza** | la linea non parte, nessun segnale | 340 | 51,47% |
| blocca l'**arrivo** (partenza libera) | dipende dal parente: C/B vincono, G/P perdono | 369 | 51,22% |
| blocca l'arrivo **+ 回頭生** | il trigramma vince nettamente | 44 | **72,73%** |
| **urtato** dall'arrivo (partenza libera) | il trigramma perde | 301 | **55,15%** (perde) |
| trattiene la partenza **e** subisce l'urto | non tiene: il trigramma vince | 109 | **55,96%** |


---

# 48. GRANDE TEST PB + LY  ·  `FISSATA` — il primo abbinamento completo (14/08/2026)

Impianto (idea di Edu): il PB decide come sempre; il termometro LY completo (55,10%) fa da
correttivo — **convalida** i positivi, **risolve** i casi dubbi, e nel **contrasto** decide.
La politica del contrasto è stata misurata, non scelta a priori.

Su 4.111 carte: concordi 620 · contrasti 612 · LY tace 2.879 · PB deboli 933.

## Il contrasto: vince il LY

| contrasto (612 carte) | tutto | recente | vecchio |
|---|---|---|---|
| vince PB | 46,08% | 47,95% | 44,36% |
| **vince LY** | **53,92%** | 52,05% | 55,64% |

Quando PB e LY si oppongono, il PB ha ragione meno di metà delle volte, su entrambi i periodi.
Il no-trade equivale al "vince PB" come conteggio ma lascia i pip sul tavolo: **override LY
batte no-trade**.

## La convalida e lo spareggio

- **Concordanza** (620 carte): 53,51% → **56,77%** (58,65% nel vecchio). La concordanza è un
  marchio di affidabilità del trade.
- **PB deboli** (933 carte, verdetto = base): lasciare decidere il LY dà **56,06%** (z 3,70) —
  il LY è più bravo del PB proprio dove il PB è incerto. I PB già forti restano a 53,85%.

## I tre sistemi combinati completi

| sistema | n | tutto | z | recente | vecchio | pip |
|---|---|---|---|---|---|---|
| PB da solo (baseline) | 4.111 | 53,51% | 4,51 | 53,28% | 54,39% | +17.221 |
| **S1 — override LY nel contrasto** | 4.111 | 54,68% | **6,00** | 53,85% | 56,19% | **+23.040** |
| S2 — salto i contrasti | 3.499 | 54,82% | 5,70 | 54,15% | 56,29% | +20.131 |
| **S3 — LY spareggia i deboli** | 4.111 | 54,73% | **6,07** | 53,63% | 56,43% | +21.467 |

Tutti e tre battono il PB da solo su entrambi i periodi. Migliore per z: **S3** (6,07);
migliore per pip: **S1** (+23.040, quasi 6.000 sopra il baseline).

## ⚠ AVVERTENZA METODOLOGICA (essenziale)

**Questo è un risultato IN-SAMPLE.** Le regole LY sono nate su questo stesso periodo leggendo
carte a posteriori: lo z 6 qui è il tetto ottimistico, NON lo z atteso in avanti. Il segnale
affidabile è la **coerenza fra i due periodi**: il contrasto perde col PB e vince col LY su
entrambi; tutte e tre le combinazioni migliorano su entrambi. Quella coerenza è ciò che può
sopravvivere fuori campione; il valore assoluto di z no.

Conclusioni strutturali: PB e LY catturano cose **diverse** (concordano solo su 620 carte su
4.111; il LY tace sul 70%); dove il LY parla, migliora il PB in modo consistente nel tempo.
Prossimo passo naturale: verifica sul **holdout** (mai toccato) quando Edu decide che il
sistema è congelato, e osservazione forward di S1/S3.


---

# 49. IL TAI SUI CHE METTE IN MOTO UN UFFICIALE  ·  `FISSATA` (14/08/2026)

Carta sorgente: **EURJPY 11/07/2024** (seme 175, sup 5 巽, inf 7 艮, mutante L1, giorno 丙子,
mese 未, anno 辰, palazzo 艮 Terra). Mercato **−233 pip** (SHORT); il LY, leggendo l'Ufficiale
*fermo* a L6, diceva LONG e perdeva.

**La lettura di Edu:** ci sono DUE Ufficiali (官鬼). Uno **fermo** a L6 (卯, oggetto 應, non
timely — statico). Uno **messo in moto dal Tai Sui**: la mobile L1 è il Tai Sui 辰 e muta in
卯 (回頭剋), cioè in Legno = Ufficiale. Fra i due comanda **il più dinamico**: quello attivato
dal Tai Sui. Principi già fissati che si combinano: (a) *ciò che fa il Tai Sui è importante*;
(b) *una linea mobile che si muove è azione*. → linea a L1, trigramma inferiore → **SHORT**. ✓

**Misura — la lettura di Edu batte quella statica, e i due periodi sono allineati:**

| | n | tutto | recente | vecchio | pip/tr |
|---|---|---|---|---|---|
| **Tai Sui mobile che muta in Ufficiale — sua direzione** | 57 | **57,89%** | 61,76% | 52,63% | 16,71 |
| (confronto) leggo l'Ufficiale FERMO invece | 34 | 52,94% | 42,11% | 66,67% | −4,20 |

L'Ufficiale fermo dà 52,94% ma con i periodi che si contraddicono (42,11 / 66,67): non
utilizzabile. L'Ufficiale attivato dal Tai Sui dà **57,89% con entrambi i periodi sopra il
riferimento**, +953 pip, 16,71 pip/trade (fra le rese per trade più alte trovate).

**Conferma del principio timely/forte (§37):**

| | n | tutto | recente | vecchio |
|---|---|---|---|---|
| arrivo Ufficiale **non timely** | 31 | **64,52%** | 63,16% | 63,64% |
| arrivo Ufficiale timely | 26 | 50,00% | 60,00% | 37,50% |

Il caso più forte è l'Ufficiale **non timely** (64,52%, periodi quasi identici 63/63): quando
l'Ufficiale non ha già forza ampia di stagione, è il **movimento concentrato impresso dal Tai
Sui** a fare la differenza. Se fosse già timely, l'azione dell'anno aggiunge poco.

Implementazione: la mobile è il Tai Sui (isTaiSui) e il suo ramo di arrivo ha l'elemento
Ufficiale del palazzo (l'elemento che controlla l'elemento del palazzo). Direzione dalla
posizione della mobile.
⚠ 57 carte. Verso solido su entrambi i periodi; da confermare in avanti.

## Nota di metodo (Edu, 14/08/2026)
Il codice cercava l'Ufficiale come **linea statica** e sbagliava; Edu legge la **dinamica** —
chi mette in moto chi. Le carte non sono "difficili": la lettura meccanica per classificazione
fallisce dove quella per movimento riesce. Ricordarsi di guardare SEMPRE il ramo di arrivo
della mutazione come possibile secondo attore (qui un secondo Ufficiale), non solo le linee
presenti.


---

# 50. IL TAI SUI CHE COMBINA A DISTANZA — LETTURE DOTTRINALI E MISURE (14/08/2026)

Filone esplorato a lungo. **Le letture di Edu sulle singole carte sono corrette e vanno
conservate**; ciò che NON emerge è un segnale direzionale autonomo misurabile.

## 50a. Le letture (dottrina — da conservare e riusare)

**(1) Il Tai Sui si muove verso dove ATTERRA la mutazione.** Non conta se la partenza è
sospesa: conta il ramo di ARRIVO e con chi si combina (六合).
- *USDJPY 15/11/2024*: Tai Sui-Ricchezza L3, 辰→亥; 亥 combina 寅 = oggetto (應) a L2 →
  trigramma inferiore → SHORT. Mercato −213. ✓
- *USDJPY 30/10/2025*: Tai Sui-Ufficiale L2, 巳→辰; 辰 combina 酉 = soggetto (世) a L4 →
  trigramma superiore → LONG. Mercato +133. ✓ (la partenza 巳 era combinata dal giorno 申 e
  il motore la dava "sospesa": **conta comunque l'arrivo**).

**(2) Una linea VUOTA non può ricevere la direzione.** *USDJPY 12/02/2025*: il Tai Sui atterra
combinando 卯 = Ricchezza L3 **vuota e dormiente** → non può shortare. Principio già fissato
(旬空), qui riconfermato.

**(3) IL CIRCUITO CHIUSO** — *EURUSD 05/03/2025* (seme 106, sup 5 巽, inf 2 兌, mutante L5,
giorno 癸酉, mese 寅, anno 巳, palazzo 艮, vuoti 戌亥). Catena:
**巳 (Tai Sui L5) → 子 (arrivo) → 丑 (Fratelli L3) → 申 (伏神 Figli nascosto in L3) → 巳**.
Il circuito **si richiude sul Tai Sui di partenza**: si legge la posizione dell'ORIGINE (L5),
non quella della prima tappa (L3). L5 = trigramma superiore → **LONG**. Mercato +166. ✓
> La catena non si ferma al bersaglio: se il bersaglio nasconde una linea che rimanda al punto
> di partenza, si legge dove il circuito **si chiude**.
⚠ **Struttura rarissima: 1 carta su 4.111.** Conservata per il futuro, non misurabile ora.

## 50b. Le misure (nessun segnale autonomo)

| condizione | n | tutto | recente | vecchio |
|---|---|---|---|---|
| arrivo del Tai Sui combina una linea — dir. bersaglio | 157 | 51,59% | 47,78% | 55,74% |
| ... bersaglio NON vuoto | 129 | 51,16% | 47,30% | 55,10% |
| ... bersaglio vivo e agibile | 102 | 47,06% | 45,16% | 47,22% |
| ... bersaglio = soggetto (世) | 27 | 55,56% | **22,22%** | 70,59% |
| ... bersaglio = oggetto (應) | 29 | 41,38% | 47,83% | 16,67% |
| capolinea della catena (invece della prima tappa) | 157 | 52,23% | 48,89% | 55,74% |

**Le catene sono quasi sempre di UN passo** (156 su 157): il bersaglio non ha nascosto, o il
nascosto non rimanda a una linea presente. Quindi "capolinea" e "prima tappa" coincidono.
Filtrare per il vuoto **non migliora** (51,59 → 51,16); restringere ai bersagli agibili
**peggiora** (47,06%).

**Conclusione onesta:** la combinazione *a distanza* del Tai Sui è dottrina corretta ma non
isola un edge; resta inchiodata al 51-52% con il recente sempre sotto il riferimento.
Diverso dalla §49, dove il Tai Sui **muta NELL'ELEMENTO** Ufficiale e diventa esso stesso un
attore: lì 57,89% con entrambi i periodi sopra. **Mutazione in elemento = attore misurabile;
combinazione a distanza = legame debole.**

## 50c. Nota tecnica — confine dei termini solari (惊蛰)
Su EURUSD 05/03/2025 è emerso il dubbio se la carta andasse scartata per clash giorno↔mese.
**No**: il 惊蛰 2025 entra alle **08:07 GMT** del 5 marzo, cioè **487 minuti DOPO** l'apertura
della carta (00:00 GMT). Alle 00:00 GMT il mese è ancora **寅**, non 卯. Giorno 酉 vs mese 寅 =
nessun clash. (Se il mese fosse stato 卯 → 卯酉冲 → carta scartata.)
Pilastri verificati: anno 乙巳 · mese 戊寅 · giorno 癸酉.
⚠ **Tutto va sempre espresso in GMT.** La libreria lunar-javascript emette gli istanti dei
termini in orologio di Pechino e `jieqi-gmt.js` converte (−8h) prima del confronto: quella è
l'unica conversione, tutto il resto del sistema è GMT/TST.
Il filtro SKIPCLASH=gm scarta le carte con clash giorno↔mese **prima** che entrino nel dataset:
tutte le misure del Liu Yao sono già al netto di quelle.


---

# 51. LA TOMBA (墓) — L'ATTORE SEPOLTO SI SPEGNE  ·  `FISSATA` (14/08/2026)

Carta sorgente: **USDJPY 30/07/2024** (seme 153, sup 3 離, inf 1 乾, mutante L6, giorno 乙未,
mese 未, anno 辰, palazzo 乾 Metallo). L'Ufficiale (官鬼) mobile 巳 Fuoco a L6 muta in **戌 =
tomba del Fuoco (火墓)**; non c'è un 卯 su cui atterrare, quindi non prosegue: **entra nella
tomba e si spegne** → non porta la direzione in alto → non va Long. (In più 戌 clasha il Tai
Sui 辰 a L3, asse delle tombe 辰戌.)

**Le quattro tombe (墓库):** 辰 = tomba Acqua · 戌 = tomba Fuoco · 丑 = tomba Metallo ·
未 = tomba Legno. Una linea mobile che muta nel ramo-tomba del **proprio** elemento vi entra.

## 51a. L'Ufficiale in tomba — `FISSATA`

| Ufficiale (官鬼) in tomba — leggo l'OPPOSTO | n | tutto | recente | vecchio | pip/tr |
|---|---|---|---|---|---|
| **totale** | 42 | **57,14%** | 62,96% | 54,55% | 3,90 |
| per elemento: Acqua → 辰 | 10 | 70,00% | 71,43% | 66,67% | 19,41 |
| per elemento: Fuoco → 戌 | 32 | 53,13% | 60,00% | 50,00% | −0,95 |
| e la tomba clasha il Tai Sui | 21 | 57,14% | 57,14% | — | 9,95 |

Legno→未 e Metallo→丑 **strutturalmente assenti** nel campione (0 carte): l'Ufficiale è
l'elemento che controlla il palazzo, e quelle combinazioni non si presentano mai. Regola
coerente col principio ma non verificabile per quei due elementi.

## 51b. SCOPERTA CONTROINTUITIVA — è l'Ufficiale VIBRANTE che si spegne

La clausola classica dice: un elemento **vibrante** in stagione NON entra in tomba. I dati
dicono l'**opposto** per l'Ufficiale:

| Ufficiale in tomba | n | tutto | recente | vecchio |
|---|---|---|---|---|
| **VIBRANTE — leggo l'opposto (si spegne)** | 21 | **66,67%** | 66,67% | 100,00% |
| vibrante — leggo il suo trigramma | 21 | 33,33% | 33,33% | 0,00% |
| non vibrante — leggo l'opposto | 21 | 47,62% | 58,33% | 37,50% |

**Lettura (coerente con timely/forte §37):** seppellire un Ufficiale **vibrante** è un evento
FORTE — tanta energia spenta di colpo, effetto netto. Un Ufficiale già debole in tomba non fa
notizia: era già spento. La tomba morde di più quando c'è qualcosa di grosso da seppellire.
⚠ 21 carte; contraddice un principio classico, quindi cautela. Ma verso coerente sui due
periodi (vibrante: 66,67 / 100,00).

## 51c. Gli altri parenti — attori vs passivi

| parente in tomba (opposta) | n | tutto | recente | vecchio |
|---|---|---|---|---|
| **Fratelli NON vibrante** | 28 | **64,29%** | 61,54% | 64,29% |
| Fratelli vibrante | 35 | 42,86% | 31,58% | 56,25% |
| Ricchezza (totale, suo trigramma) | 15 | 53,33% | 55,56% | 40,00% |
| Genitori / Figli | 30 / 9 | — | (contraddittori) | — |

**La tomba distingue due famiglie:**
- **Ufficiale** (azione pura) → si spegne quando è **VIBRANTE** (66,67%)
- **Fratelli** (passivo) → si spegne quando è **DEBOLE** (64,29%, entrambi i periodi)
- **Ricchezza** (bene passivo) → tende a **mantenere** la direzione, non si spegne (53,33%,
  suo trigramma) — coerente ma 15 carte
- Genitori, Figli → campioni insufficienti, non concludibili

È lo stesso asse di tutta la giornata: l'Ufficiale che agisce viene fermato dalla tomba
proprio quando ha più forza; i parenti passivi (Fratelli, Ricchezza) si spengono solo se erano
già deboli, altrimenti resistono. La tomba è anche **magazzino** (墓库): toglie l'azione a chi
agisce, conserva chi è passivo.


---

# 52. "CHI NON VINCE PERDE" — L'ESAGRAMMA MOSTRA IL PERDENTE  ·  `SCOPERTA / PRINCIPIO` (14/08/2026)

Carta sorgente: **EURJPY 11/03/2025** (seme 159, sup 3 離, inf 7 艮, mutante L2, giorno 己卯,
mese 卯, anno 巳, palazzo 離 Fuoco). La mobile L2 兄弟 午 Fuoco (timely nel mese di Legno) muta
in 亥 Acqua = Ufficiale (官鬼): l'arrivo dovrebbe controllare all'indietro (回頭剋) il 午, ma il
Fuoco è troppo forte e **il controllo fallisce**. L'Ufficiale-Acqua si esaurisce. La direzione
SHORT (posizione della mobile in basso) **non può vincere** → LONG. Mercato +177. ✓

## Il principio (con la cautela di Edu)

> **L'esagramma spesso mostra chi NON riesce a imporsi, non chi vince.** Una linea mobile la
> cui azione è contrastata / fallisce non porta la propria direzione: si legge l'OPPOSTO.

⚠ **NON è una lettura di default.** Edu avverte: succede anche il contrario — l'esagramma fa
leggere chi *vince*. Il punto non è che "l'opposto" sia la regola base, ma **riconoscere quale
dei due modi è in atto**. La CONDIZIONE DI FALLIMENTO dell'azione è il segnale che dice di usare
la lettura "al negativo".

## Misura — "azione fallita → leggo l'opposto"

| categoria di azione fallita | n | tutto | z | recente | vecchio | pip |
|---|---|---|---|---|---|---|
| 回頭剋 (arrivo controlla partenza) | 503 | 51,89% | 0,85 | 51,96% | 52,24% | +292 |
| autocombinazione (自合) | 339 | 53,39% | 1,25 | 50,00% | 57,25% | +1.601 |
| arrivo clashato dal giorno | 415 | 52,29% | 0,93 | 51,53% | 54,76% | +1.689 |
| **QUALSIASI azione fallita → opposto** | **1.211** | **52,27%** | 1,58 | 51,05% | 54,60% | **+2.943** |
| *(le stesse lette diretta)* | 1.211 | 47,73% | −1,58 | 48,95% | 45,40% | −2.943 |

Copre **quasi un terzo del campione**, sopra il riferimento su entrambi i periodi. Non forte in
valore assoluto (z ~1,5) ma stabile e ampio: è il **principio unificante SOTTO** regole già
fissate — §14 (回頭剋), §5 (autocombinazione) ne sono casi particolari, non regole separate.

## Il 回頭剋 per parente della mobile (raffinamento)

| mobile in 回頭剋 → opposto | n | tutto | recente | vecchio |
|---|---|---|---|---|
| **Genitori (父母)** | 94 | **59,57%** | 60,78% | 55,00% |
| Ufficiale | 151 | 52,32% | 50,00% | 54,39% |
| Fratelli | 121 | 52,07% | 47,54% | 58,49% |
| Figli | 38 | 47,37% | 42,86% | 60,00% |
| Ricchezza | 99 | 45,45% | 55,00% | 33,33% |

I **Genitori** in 回頭剋 danno 59,57% (condotto colpito che cede, coerente §12). La **Ricchezza**
no (45,45%, periodi opposti): bene passivo, non si fa spegnere.

⚠ **ATTENZIONE alla §14 in produzione:** attualmente il modulo fa "agire l'arrivo dalla
posizione della mobile", che sui 回頭剋 con partenza debole misura **46,94%** (sotto il rif. su
entrambi i periodi). La lettura corretta di Edu ("la mobile non vince, si legge l'opposto") dà
51-53%. **Correzione della §14 NON ancora applicata** — richiede via libera esplicito e
rimisura del baseline PB. Decisione rimandata.


---

# 53. I FRATELLI OSTACOLANO IL TREND  ·  `FISSATA` (14/08/2026)

Recupero dell'impostazione originale: i Fratelli (兄弟) NON danno una direzione assoluta
long/short (misurato: 50%, nessun segnale), ma dicono **se il mercato segue o NON segue il
trend EMA** — come il PB. E il verso è ROVESCIATO rispetto all'intuizione: i Fratelli
**sottraggono/ostacolano**, quindi un Fratello forte fa **NON seguire** il trend.

Carta sorgente del filone: **EURJPY 11/02/2025** (Fratelli 寅 vuoti sullo Ying → niente spinta
short; mercato LONG contro trend EMA SHORT).

## Misura — "Fratello timely → il mercato NON segue il trend"

| lettura (opera CONTRO il trend EMA) | n | win% | z | recente | vecchio | pip |
|---|---|---|---|---|---|---|
| Fratello timely sullo Shi | 344 | 53,49% | 1,29 | 53,67% | 53,42% | +1.754 |
| Fratello mobile vivo | 891 | 51,96% | 1,17 | 51,81% | 53,28% | +3.514 |
| Fratelli forti (nessuno vuoto) | 1.409 | 51,88% | 1,41 | 51,00% | 52,90% | +3.879 |
| **UNICO Fratello timely — qualunque ruolo** | 903 | 52,82% | 1,70 | 52,54% | 54,40% | +4.145 |
| unico e NON sullo Shi | 806 | 53,10% | 1,76 | 52,47% | 54,44% | +4.106 |

**Non è un fatto di RUOLO ma di POSIZIONE.** Lo Shi da solo (unico Fratello) = 97 carte, neutro
(50,52%). Il segnale vive nella posizione:

| posizione del Fratello timely | n | win% | z | recente | vecchio | pip |
|---|---|---|---|---|---|---|
| **L4** | 508 | **55,31%** | **2,40** | 54,58% | 57,14% | +3.415 |
| L1 | 79 | 58,23% | 1,46 | 63,41% | 52,94% | +716 |
| L2 | 240 | 51,25% | 0,39 | 52,99% | 48,04% | +389 |
| L3 | 759 | 50,72% | 0,40 | 49,88% | 50,94% | +1.653 |
| L5 | 514 | 51,17% | 0,53 | 46,32% | 56,42% | −91 |
| **L6** | 345 | 48,41% | −0,59 | 48,82% | 48,00% | −102 |

**La cella forte: Fratello timely a L4 → il mercato NON segue il trend, 55,31% su 508 carte,
z 2,40, entrambi i periodi sopra** (54,58 / 57,14). L4 = prima linea del trigramma superiore.
All'estremo opposto L6 va sotto (48,41%): il Fratello all'apice non ostacola.

**Asimmetria (unidirezionale):** il complementare NON vale — "nessun Fratello forte → segue"
dà 49,32% (sotto rif.), e il sistema a interruttore (forti→non segue, else→segue) è piatto
(50,06%). I Fratelli sono un **filtro verso il non-segue**, non un interruttore bidirezionale.
Come le mutazioni PB, la regola vale in un verso solo.

⚠ Testate 10 caselle (6 posizioni × 4 ruoli): un z 2,40 su 10 prove è in parte atteso per
caso. La credibilità viene dall'**allineamento dei due periodi** (54,58/57,14), non dallo z.
Da confermare in avanti / su holdout.

## 53a. Confronto diretto col baseline (Yong vs Trend vs niente)
Tasso di fondo: il mercato NON segue il trend nel **51,23%** dei giorni.

| | n | NON segue % | recente | vecchio |
|---|---|---|---|---|
| Fratello timely nello YONG | 1.253 | 51,88% | 51,51% | 52,91% |
| Fratello timely solo nel TREND | 421 | 52,49% | 50,21% | 53,85% |
| baseline — nessun Fratello timely | 2.437 | 50,68% | 49,67% | 51,70% |

**L'effetto è modesto (~+1,2 punti sul fondo) e lo Yong NON è decisivo:** confrontati entrambi
col baseline reale, Yong e Trend stanno appena sopra, senza vantaggio netto dello Yong (la
differenza Yong>Trend vista nel confronto interno si assottiglia). L'unica cella davvero netta
resta **posizionale (L4, 55,31%)**, non il gua del PB. **Conclusione di Edu: trasportare il
Fratello dentro il PB NON dà una chiave di lettura decisiva.**

## 53b. B NEL Ti OSTACOLA IL TREND — `FISSATA` (confronto pulito su tutti i parenti)

Fra i 5 parenti timely trasportati nel PB come "segue/non segue", **solo i Fratelli danno
segnale**, e solo verso il NON-segue:

| parente timely → NON segue | n | tutto | recente | vecchio |
|---|---|---|---|---|
| **Fratelli** | 903 | 52,82% | 52,54% | 54,40% |
| Genitori | 772 | 51,04% | 47,93% | 55,65% (recente sotto) |
| Figli | 905 | 50,83% | 47,76% | 55,38% (recente sotto) |
| Ufficiale | 925 | 49,19% | 47,62% | 51,24% |
| Ricchezza | 823 | 48,85% | 49,69% | 47,55% |

E il Fratello ostacola meglio quando sta nel **Ti (gua del Trend, che nel PB È l'EMA)**,
massimo a L4:

| | n | tutto | z | recente | vecchio |
|---|---|---|---|---|---|
| B nel Ti → non segue | 1.192 | 51,59% | 1,10 | 49,85% | 52,37% |
| **B nel Ti E a L4 → non segue** | 266 | **57,14%** | 2,33 | 57,53% | 55,96% |

**REGOLA FISSATA: 兄弟 (Fratello) timely nel Ti del PB → il mercato NON segue il trend;
fortissimo a L4** (57,14%, z 2,33, due periodi allineati). Dottrina: il Fratello sottrae/
compete, e piantato dentro il corpo del trend lo blocca.

**Controparte simmetrica NON esiste:** 妻財 (Ricchezza) nel Ti → SEGUE misura 50,22% (a L4
50,35%, periodi sotto 50%): piatta. Il 57,43% visto prima dipendeva dal filtro "W unica timely"
(restrittivo), non dalla posizione. La Ricchezza è bene passivo: non spinge il trend. Solo i
Fratelli hanno l'effetto.

## 53c. QUADRO COMPLETO — L'ASSE DEGLI AVVERSI (Ti vs Yong) — `FISSATA`

I 5 parenti timely nel **Ti** (>50% = ostacola il trend / <50% = asseconda):

| parente nel Ti | n | tutto | recente | vecchio | |
|---|---|---|---|---|---|
| **Ufficiale (官鬼)** | 964 | 52,18% | 51,95% | 52,25% | ostacola ✓ |
| **Fratelli (兄弟)** | 1.192 | 51,59% | 49,85% | 52,37% | ostacola ✓ |
| Figli (子孫) | 587 | 50,26% | 48,40% | 52,90% | neutro |
| Ricchezza (妻財) | 920 | 49,78% | 51,54% | 48,28% | neutro |
| Genitori (父母) | 998 | 48,40% | 44,81% | 53,33% | instabile |

A L4: **Fratelli 57,14% (z 2,33)**, **Ufficiale 55,41% (z 1,36)**, gli altri piatti.

Nello **Yong** tutto molto più piatto: Fratelli 51,88%, Figli 52,28%, Ricchezza 51,07%,
Ufficiale 50,14%, Genitori 50,00%. "Parente = la mutante" non aggiunge nulla (48-51%).

**CONCLUSIONE — l'effetto vive nel Ti, non nello Yong.** Il Ti *è* il trend (corpo/EMA): un
avverso piantato **dentro il corpo del trend** lo blocca. I due avversi sono **官鬼 (controlla/
reprime)** e **兄弟 (sottrae/compete)**. Ricchezza, Figli, Genitori: nessun effetto stabile.
**C'è un asse "avversi ostacolano" ma NON un asse speculare "favorevoli assecondano"** —
asimmetrico (da indagare: il favore forse è una relazione generativa verso il Ti, non un
parente → prossimo passo).

## 53d. Raffinamenti — presenza, non azione; il vuoto — `FISSATA`

**Ostacolo = presenza statica, non movimento.**
- Nel Ti il parente è per costruzione FERMO (la mutante sta nello Yong): B/G ostacolano da
  fermi. Il 暗動 non cambia (Fratelli quieto 51,58 / in 暗動 51,81).
- **B e G MOBILI nello Yong NON ostacolano il Ti** (50-51,6%), né in partenza né in arrivo.
  Due meccaniche distinte: **ostacolare** = presenza forte nel Ti; **agire** = muoversi nello
  Yong (capolinea, Tai Sui, tomba, 回頭剋).

**Il vuoto (旬空):**
- **B/G vuoti nel Ti**: NON perdono la capacità di ostacolare (Fratello vuoto 52,78%). Il vuoto
  non li spegne come ostacoli.
- **Ufficiale nel Ti + una linea VUOTA nel Ti → 55,65% (z 2,13, 57,22/53,33)**, contro 50,00%
  se il Ti è pieno. Una **falla nel corpo del trend**: l'Ufficiale forte sfrutta la crepa e
  l'ostacolo morde. Regola: *官鬼 timely nel Ti + Ti con linea vuota → NON segue*. Per il
  Fratello questo non cambia (il vuoto conta solo per l'Ufficiale).


---

# 54. IL FAVORE AL Ti È INSTABILE; L'ANTI-SEGNALE MESE-vs-TAI SUI È STABILE  ·  `FISSATA` (14/08/2026)

Cercando la metà "favorevole" mancante (perché nel PB gli avversi ostacolano ma nessuno
asseconda), abbiamo testato: **una mutazione il cui ARRIVO genera l'elemento del Ti → dovrebbe
far SEGUIRE il trend.**

## 54a. Il favore è instabile (per anno e per mese)
| | n | tutto | recente | vecchio |
|---|---|---|---|---|
| arrivo genera il Ti, timely → SEGUE | 466 | 54,08% | 58,58% | 46,41% |

Scomposto per anno oscilla senza ripetersi: 2020 32% · 2021 48% · 2022 49% · 2023 60% ·
2024 72% · 2025 44% · 2026 61%. Non è "il 2020 che sporca": è un segnale ballerino. Per mese:
peggiori i mesi di **nascita** 寅(feb) 30% e 申(ago) 33% (elemento appena sorto); ma anche i
mesi forti hanno recente≫vecchio. **Firma del rumore**, non di una legge — contro l'ostacolo
(controllo del Ti) che è piatto e uguale su entrambi i periodi (51,66/51,37).

## 54b. L'ANTI-SEGNALE stabile — `FISSATA`
La sotto-condizione che regge, isolata dentro il filone instabile:

| | n | tutto | z | recente | vecchio |
|---|---|---|---|---|---|
| **mese CONTROLLA il Tai Sui + mutaz. genererebbe il Ti → NON segue** | 43 | **65,12%** | 1,98 | 61,90% | 68,18% |

Entrambi i periodi alti e allineati (il vecchio più forte). Dottrina: **quando il mese controlla
il Tai Sui, l'anno è sopraffatto dal mese**; in quella condizione anche una mutazione che
nutrirebbe il Ti non riesce a farlo seguire — il mercato va contro (asse "chi non vince perde",
§52: il Tai Sui sopraffatto non porta il favore, si legge l'opposto).

Il favore filtrato (mese NON controlla il TS, fuori dai mesi di nascita) sale a 57,36% (z 2,69)
ma resta con gap 60,73/51,18: **meno instabile, non robusto → non usato come regola**.
Si registra solo l'ANTI-segnale.

## 54c. Ipotesi da testare (Edu): Tai Sui = difensore del Ti, mese = sfidante (Yong)
Se il Tai Sui difende il trend e il mese lo sfida: nei mesi in cui **il mese controlla l'anno**
dovrebbe vincere di più lo **Yong** (non segue); quando **l'anno controlla il mese**, dovrebbe
vincere di più il **Ti** (segue). → test in corso.

---

# 50d. LA COMBINAZIONE DEL TAI SUI: GENERATIVA vs DISTRUTTIVA  ·  `FISSATA` (15/08/2026)

Carta sorgente: **GBPUSD 15/12/2022** (seme 124, sup 7 艮, inf 4 震, mutante L2, giorno 壬寅,
mese 子, anno 寅, palazzo 巽 Legno, vuoti 辰巳). La mobile L2 è il Tai Sui-Fratelli 寅 (anche
ramo del giorno, timely) che AVANZA in 卯; l'arrivo 卯 combina 戌 = Ricchezza sul soggetto (世)
a L4. Lettura di Edu: la combinazione 卯戌 porta un controllo dentro (Legno controlla Terra) —
il Fratello forte non raggiunge la Ricchezza, **la distrugge**. La direzione non è quella del
bersaglio ma l'opposta → SHORT. Mercato −240. ✓

**Il principio**: le sei coppie 六合 si dividono in due famiglie:
- **generative**: 寅亥 (Acqua→Legno) · 辰酉 (Terra→Metallo) · 午未 (Fuoco→Terra) — il legame
  porta → direzione del bersaglio
- **con controllo dentro**: 卯戌 (Legno⊣Terra) · 巳申 (Fuoco⊣Metallo) · 子丑 (Terra⊣Acqua) —
  la combinazione può essere una distruzione

**Misura (sui casi: mobile = Tai Sui, arrivo combina una linea unica, bersaglio non vuoto)**:

| combinazione distruttiva → OPPOSTA | n | tutto | recente | vecchio |
|---|---|---|---|---|
| **distruttore timely + attaccato ANCHE timely** | 6 | **83,33%** | 100,00% | 80,00% |
| distruttore timely + attaccato non timely | 11 | 45,45% | 75,00% | 28,57% |
| distruttore debole + attaccato timely | 14 | 50,00% | 50,00% | 50,00% |
| **entrambi deboli** (l'opposta perde sempre → diretta vince) | 5 | **0,00%** | 0,00% | 0,00% |
| (generativa → direzione del bersaglio) | 73 | 53,42% | 53,06% | 54,55% |

**REGOLA FISSATA (formulazione accettata da Edu il 15/08/2026, corretta sui dati)**:
1. Combinazione **distruttiva** con **distruttore E attaccato entrambi timely** → la distruzione
   si compie, si legge l'**OPPOSTO** del bersaglio (83,33%, periodi 100/80 allineati).
2. Combinazione distruttiva con **entrambi deboli** → la distruzione non ha forza, la
   combinazione **porta normalmente** → direzione del bersaglio (5/5).
3. Le celle miste (uno timely, l'altro no) NON danno segnale stabile (45-50%, periodi in
   contraddizione) → nessuna lettura.
4. La formulazione iniziale di Edu ("distruttore timely + attaccato non timely") misurava
   45,45% con periodi opposti: sostituita dalla n.1 col suo consenso, visti i dati.

**Dottrina**: coerente con la §51b (è l'Ufficiale VIBRANTE che la tomba spegne) — gli eventi
forti si compiono su bersagli forti; lo scontro fra due deboli non lascia traccia e il legame
prevale. ⚠ 6 e 5 carte: campioni piccolissimi, accettati da Edu ("ampia variabilità del LY");
periodi allineati in entrambe le celle. Da monitorare in avanti.

---

# 50e. LA COMBINAZIONE DELL'ARRIVO GENERALIZZATA A OGNI MOBILE  ·  `FISSATA` (15/08/2026)

Carta sorgente: **EURJPY 19/04/2022** (seme 137, sup 1 乾, inf 1 乾, mutante L5, giorno 壬寅,
mese 辰, anno 寅, palazzo 乾 Metallo, vuoti 辰巳). La mobile L5 Fratelli 申→未 è sospesa dal
giorno (寅冲申), ma **conta comunque l'arrivo** (§50a): 未 combina 午 = Ufficiale a L4, timely,
sostenuto dal giorno e dal Tai Sui (寅 Legno genera il Fuoco). Combinazione 午未 generativa →
direzione del bersaglio → L4 → LONG. Mercato +205. ✓ Lettura di Edu.

**Misura — lo schema §50d esteso a QUALSIASI mobile (bersaglio unico, non vuoto):**

| condizione | n | tutto | z | recente | vecchio |
|---|---|---|---|---|---|
| **generativa su bersaglio TIMELY → dir. bersaglio** | 551 | **54,26%** | 2,00 | 52,52% | 56,85% |
| generativa su Ufficiale → dir. bersaglio | 273 | 54,58% | 1,51 | 51,94% | 56,59% |
| **distruttiva, entrambi deboli → dir. bersaglio** | 57 | **64,91%** | 2,25 | 71,43% | 61,54% |
| distruttiva, entrambi timely → OPPOSTA | 53 | 47,17% | — | 45,45% | 50,00% |
| generativa senza filtro timely | 1.068 | 51,22% | — | 49,66% | 52,37% |

**REGOLE FISSATE (per qualunque linea mobile):**
1. Arrivo combina una linea (unica, non vuota) in modo **generativo** e il bersaglio è
   **timely** → direzione del bersaglio (54,26%, entrambi i periodi sopra). Senza il filtro
   timely la regola è piatta: serve un bersaglio vivo di stagione.
2. Combinazione **distruttiva fra due deboli** → nessuno ha la forza di rompere, il legame
   porta → direzione del bersaglio (64,91%, periodi 71/61).
3. **La distruzione compiuta NON generalizza**: per le mobili comuni "distruttiva entrambi
   timely → opposta" misura 47,17% (contro l'83,33% del Tai Sui, §50d). **Solo il Tai Sui ha
   la forza concentrata per compiere una distruzione** — coerente con la dottrina del Tai Sui
   come "capacità di intervento" (grandi istituzioni). La cella distruttiva-forte resta
   esclusiva della via 14 (Tai Sui).

**Dottrina in una riga**: l'arrivo che combina porta la direzione del bersaglio se il bersaglio
è vivo di stagione (o se sono entrambi deboli); la distruzione dentro la combinazione è
privilegio esclusivo del Tai Sui.

---

# 50f. L'ARRIVO DELLA MOBILE GENERA LA RICCHEZZA  ·  `FISSATA` (15/08/2026)

Carta sorgente: **USDJPY 22/09/2022** (seme 144, sup 2 兌, inf 8 坤, mutante L1, giorno 戊寅,
mese 酉, anno 寅, palazzo 兌 Metallo, vuoti 申酉 — il giorno del primo intervento BoJ sullo
yen dal 1998). Mobile L1 Genitori 未→子: l'arrivo 子 Acqua **genera** la Ricchezza 卯 Legno a
L3. La W non è timely (mese 酉 la contrasta) ma è **FORTE**: Tai Sui 寅 Legno e giorno 寅
Legno le danno spalla (stesso elemento, doppia forza concentrata — §47 timely vs forte).
L3 → trigramma inferiore → SHORT. Mercato −188. ✓ Lettura di Edu; la correzione decisiva
("non serve timely, basta il sostegno di giorno/anno") è sua.

**Misura (arrivo genera W; direzione per posizione se le W sbilanciano su un trigramma):**

| condizione | n | tutto | recente | vecchio |
|---|---|---|---|---|
| **W TIMELY o FORTE → dir. linea** | 280 | **54,29%** | 52,69% | 55,00% |
| timely E forte insieme | 111 | 57,66% | 53,73% | 61,11% |
| solo forte | 119 | 52,10% | 52,94% | 51,06% |
| solo timely | 50 | 52,00% | 50,00% | 52,94% |
| **né timely né forte** | 60 | **43,33%** | 55,88% | 30,43% |

FORTE = giorno o anno con lo stesso elemento della W, o che la generano.

**REGOLA FISSATA**: l'arrivo della mobile genera la Ricchezza e la W è **timely o forte** →
direzione della W (per posizione). Le due forze si sommano (insieme 57,66%). Una W **senza
alcun sostegno non riceve** (43,33%) → nessuna lettura. Controllo di specificità: generare gli
altri parenti non dà segnale (Ufficiale 51,63%, Genitori 50,94%, Fratelli 50,17%, Figli
47,99% — coerente con §46: i Figli conservano, non spingono). Integrata come **via 16**.

---

# 50g. LA COMBINAZIONE DOPPIA LEGA IN BASSO  ·  `FISSATA` (15/08/2026)

Carta sorgente: **USDJPY 01/08/2022** (seme 133, sup 8 坤, inf 5 巽, mutante L6, giorno 丙戌,
mese 未, anno 寅, palazzo 震 Legno, vuoti 午未). L'Ufficiale mobile L6 酉 arriva su 寅 (il ramo
del Tai Sui); 寅 combina 亥 — ma di 亥 ce ne sono DUE (Genitori a L5 e a L2). Lettura di Edu:
vince L2 per risonanza (ha il Fratelli 寅 nascosto, gemello dell'arrivo) → SHORT. Mercato −168. ✓

**Misura sui 193 casi di gemelli DIVISI (un bersaglio per trigramma, non vuoti):**

| spareggio | n | tutto | recente | vecchio |
|---|---|---|---|---|
| **il gemello BASSO** | 193 | **55,96%** | 54,08% | 57,65% |
| il gemello alto | 193 | 44,04% | 45,92% | 42,35% |
| risonanza (nascosto = ramo d'arrivo) | 31 | 58,06% | 46,15% | 68,75% |
| il gemello soggetto (世) | 37 | 54,05% | 61,54% | 36,36% |

**REGOLA FISSATA**: quando l'arrivo della mobile combina un ramo presente su DUE linee divise
fra i trigrammi, **il legame si compie in basso** → direzione del gemello del trigramma
inferiore (55,96%, periodi 54/58 allineati). Nella carta sorgente coincide con la scelta di
Edu (L2). La **risonanza del nascosto** resta annotata come lettura dottrinale NON confermata
come criterio generale (periodi opposti: 46,15/68,75 su 31 carte) — nel caso singolo può
spiegare il perché, ma lo spareggio operativo è la posizione. Integrata come **via 17**.

---

# 50h. IL NASCOSTO VUOTO CLASHATO DALL'ARRIVO: LA SCALA DEI SOSTEGNI  ·  `FISSATA` (15/08/2026)

Carta sorgente: **USDJPY 09/03/2020** (seme 103, sup 4 震, inf 7 艮, mutante L5, giorno 辛亥,
mese 卯, anno 子, palazzo 兌 Metallo, vuoti 寅卯 — il lunedì nero Covid+petrolio). Il Fratello
mobile L5 avanza 申→酉; l'arrivo 酉 clasha 卯 = la Ricchezza NASCOSTA (伏神) dietro l'Ufficiale
a L2, vuota ma con TRE sostegni: ramo stesso del mese (旺), generata dal giorno 亥 e dal
Tai Sui 子 (entrambi Acqua). Lettura di Edu: un vuoto così sostenuto esce facilmente — emerge
e genera con forza il volante G → L2 → SHORT. Mercato −166. ✓

**Prima misura (ingenua, "vuoto e timely" con 旺 e 相 mischiati): 44,44% — RESPINTA.**
Correzione di Edu: "non puoi trattare W così come un vuoto qualsiasi" — 旺不为空, e vanno
contati i sostegni concentrati (giorno/anno), non solo il mese.

**Misura graduata (nascosto vuoto clashato dall'arrivo, ospite unico). Sostegni: 旺 dal mese
(elemento o ramo stesso) / giorno stesso elemento o che genera / Tai Sui idem:**

| sostegni | n | tutto | recente | vecchio |
|---|---|---|---|---|
| **≥2 (molto sostenuto)** | 13 | **76,92%** | 75,00% | 80,00% |
| 1 | 27 | 40,74% | 42,86% | 36,36% |
| **0 (abbandonato)** | 17 | **23,53%** | 42,86% | 11,11% |

Scala perfettamente monotona: 23% → 41% → 77%.

**REGOLE FISSATE (via 18):**
1. Nascosto vuoto con **≥2 sostegni** clashato dall'arrivo → esce dal vuoto e agisce →
   **direzione della linea ospite** (76,92%, periodi 75/80).
2. Nascosto vuoto con **0 sostegni** → il clash lo sfonda, l'azione si rovescia →
   **direzione OPPOSTA all'ospite** (76,47%).
3. 1 sostegno: zona grigia, nessuna lettura.
⚠ Campioni piccoli (13 e 17) accettati per scala monotona + periodi allineati agli estremi.
Dottrina: gemella della 旺不为空 di produzione PB, estesa dal solo mese alla forza concentrata
di giorno e Tai Sui (§47 timely vs forte).

---

# 50i. IL GUA INFERIORE INTERAMENTE VUOTO: IL PAVIMENTO CEDE  ·  `FISSATA` (15/08/2026)

Nata dalla domanda di Edu su GBPUSD 28/09/2022 ("il vuoto 午 copre l'intero trigramma
inferiore 離: non rende impossibile lo SHORT?"). La misura ha ROVESCIATO l'ipotesi:

| condizione | n | tutto | recente | vecchio |
|---|---|---|---|---|
| inferiore interamente vuoto → LONG (ipotesi originale) | 567 | 45,33% | 45,54% | 44,09% |
| **inferiore interamente vuoto → SHORT (rovesciata)** | 567 | **54,67%** | 54,46% | 55,91% |
| superiore interamente vuoto → SHORT | 458 | 48,91% | — | — |

**REGOLA FISSATA (via 19)**: quando i rami HOUTIAN del trigramma INFERIORE dell'esagramma
sono tutti nei vuoti del giorno → **è più facile uno SHORT** (54,67%, periodi 54,5/55,9).
Il vuoto sotto non blocca la discesa: **toglie il pavimento**, e il mercato ci cade dentro.
Il trigramma superiore vuoto non dice nulla (48,91%).

Note strutturali:
- I vuoti vengono in coppie fisse (旬空): 乾 (戌亥) e 巽 (辰巳) possono essere interamente
  vuoti; 艮 (丑寅) e 坤 (未申) cavalcano due coppie → non sono MAI interamente vuoti — la
  vecchia regola "Gen e Kun non sono mai vuoti" è scritta nella struttura.
- 旺不为空 coerente: trigramma vuoto ma 旺 di mese → effetto attenuato (52,86% vs 54,93%).
  Cablata SENZA eccezione (cella aggregata).
- La carta GBPUSD 28/09/2022 (LONG da intervento BoE) è una delle eccezioni del 45%.

---

# 50j. DUE FRATELLI DIVISI: OGNUNO CURA LA SUA SEZIONE  ·  `FISSATA` (15/08/2026)

Principio di Edu (da EURUSD 20/04/2022): quando ci sono DUE Fratelli, uno per trigramma,
ognuno rivolge la propria azione al settore di competenza — diversamente dal B singolo
(§53, ostacolo di trend segue/non-segue). Il verso, allineato sui dati e sulle carte:
**il mercato va nella sezione del B mobile che esce RAFFORZATO dalla mutazione** (回頭生 o
avanzante). Il B lavora nel suo settore e il movimento del giorno accade lì.

- EURUSD 20/04/2022: B alto 卯 mobile, sul giorno, timely, 回頭生 → sezione alta → LONG.
  Mercato +56. ✓
- GBPUSD 28/09/2022 (contrasto istruttivo): i due B sono FERMI e clashati dal mese — la
  regola tace; il LONG di quel giorno venne da altro (intervento BoE).

**Misura (carte con esattamente un B per trigramma, 2.248):**

| cella (% giorni in cui il mercato SALE) | n | tutto | recente | vecchio |
|---|---|---|---|---|
| **B ALTO mobile RAFFORZATO** | 100 | **54,00%** | 53,06% | 56,25% |
| **B BASSO mobile RAFFORZATO** | 72 | **44,44%** (=55,56% short) | 39,39% | 47,22% |
| B mobile indebolito (alto) | 58 | 46,55% | 58,06% | 31,82% |
| B fermi (tutte le combinazioni acceso/spento) | 1.473 | ~51% | — | — |

**REGOLA FISSATA (via 20)**: due B divisi fra i trigrammi + il B mobile esce rafforzato
dalla mutazione → **direzione della SUA sezione** (172 carte, 54,65%, quattro sotto-celle
allineate). B indebolito o B fermi: nessuna lettura (periodi in contraddizione / piatti).
Conferma il primato della DINAMICA: conta chi si muove e con che forza, non la presenza.

---

# 50k. IL CLASH DEL GIORNO ROMPE LA COMBINAZIONE DEL TAI SUI  ·  `FISSATA` (15/08/2026)

Nata dalla domanda di Edu su GBPUSD 28/09/2022: "il giorno 申 clasha l'anno 寅 — il clash non
rompe la combinazione 寅亥 col P di L3? E allora cosa accade a G 酉 e P 亥?" (合被冲破).
Il giorno faceva doppio lavoro: clashava il Tai Sui E legava la mobile (申合巳).

**Misura (linea FERMA unica combinata a distanza dal ramo dell'anno):**

| cella | n | tutto | recente | vecchio |
|---|---|---|---|---|
| combinazione intatta → dir. linea | 1.349 | 49,30% | 50,00% | 47,95% |
| **rotta dal giorno → OPPOSTA alla linea** | 109 | **56,88%** | 53,85% | 60,38% |
| solo P: rotta → opposta | 29 | **62,07%** | 63,64% | 64,71% |

**REGOLA FISSATA (via 21)**: una linea ferma unica combinata a distanza dal Tai Sui, nel
giorno che CLASHA l'anno → la combinazione si rompe e la sede si ribalta → **direzione
OPPOSTA alla linea**. Finché la combinazione è intatta: nessun segnale (conferma §50b:
la combinazione a distanza da sola è legame debole — il suo effetto emerge solo quando
si SPEZZA). Sul P il segnale è massimo (62%): il condotto tenuto dall'anno, sferzato dal
clash, perde il verso.

Chiude anche il cerchio del P-condotto (§ pendente): delle due "eccezioni" della cella
G-forte (66,67% dir. sede), GBPUSD 28/09/2022 è spiegata dalla rottura (via 21 la
intercetta con precedenza); EURUSD 20/04/2022 resta l'eccezione semplice.

**REGOLA FISSATA (via 22, subordinata alla 21)**: P vivo che drena un G nascosto FORTE →
direzione della sede (42 carte, 66,67%, periodi allineati). Valutata DOPO la via 21: se la
combinazione col TS è rotta dal giorno, comanda la rottura.

---

# 55. IL GENITORI (P) MOBILE CHE CLASHA IL TAI SUI FERMO ROMPE IL SUO TREND  ·  `FISSATA` (16/08/2026)

Nata dalla carta peggiore del gruppo "LY tace" (USDJPY 23/10/2024, PB perde 155 pip): un P
mobile su L6 (未→戌) il cui arrivo clasha il Tai Sui fermo su L1 (辰), e il mercato sale.
Lettura di Edu: **il P è per natura il distruttore dei trend. Il Tai Sui FERMO rappresenta
il trend consolidato della sua sezione (sotto = ribasso, sopra = rialzo). Il P mobile, col
suo ramo di ARRIVO, lo clasha e quel trend si rompe.** Non c'entrano gli elementi né il
drenaggio: è natura del P + posizione del Tai Sui.

Ipotesi respinte lungo la strada (agli atti): P avanzante sopra → LONG (47 carte, 48,94%);
P che arriva nel trigramma inferiore blocca il ribasso in generale (140 carte, 53,57%,
periodi discordi); clash sul Tai Sui col ramo di PARTENZA (misura dottrinalmente sbagliata:
quando una linea si muove è SEMPRE il ramo di arrivo che agisce).

**Misura (P mobile, arrivo clasha un TS fermo unico; % = trend del TS ROTTO):**

| cella | n | tutto | z | recente | vecchio |
|---|---|---|---|---|---|
| tutte | 32 | 65,63% | 1,77 | 64,29% | 66,67% |
| TS sopra (rialzo rotto → scende) | 11 | 81,82% | 2,11 | 75,00% | 85,71% |
| TS sotto (ribasso rotto → sale) | 21 | 57,14% | 0,65 | 60,00% | 54,55% |
| **TS NON combinato dal giorno** | 27 | **70,37%** | 2,12 | 69,23% | 71,43% |
| TS combinato dal giorno (difeso) | 5 | 40,00% | — | — | — |
| controllo: altre parentele che clashano il TS | — | ~40-60% | — | — | — |

La tempestività del P NON separa (timely 66,67% vs non timely 65,00%). Ciò che separa è la
**difesa del Tai Sui**: se il GIORNO combina il TS, il TS è legato e il clash non passa
(le tre smentite nette — GBPUSD 05/03/2021, USDJPY 15/02/2024, AUDUSD 15/07/2021 — hanno
tutte il TS combinato dal giorno). La combinazione da un'altra linea FERMA non difende:
solo il giorno fa da scudo. Le altre parentele (B, G, W, C) che clashano il TS non mostrano
questo comportamento — il P è davvero il distruttore, gli altri no.

**Criterio di precedenza (Edu, 16/08/2026):** *gli indicatori principali restano G e W; se
non ci sono, si "lavora" su B, P e C.* Le due EURJPY 26/08 e 07/09/2020 (TS sopra difeso dal
giorno, ma il rialzo si rompe lo stesso) NON sono eccezioni: lì il P mobile (亥→午) va a
GENERARE la Ricchezza 丑 su L1 che coincide col giorno — comanda la W, il P è suo servitore,
il clash sul TS è un fatto di tavola non l'azione. Nella USDJPY 23/10 l'arrivo combina solo
una W NASCOSTA (non attiva): né G né W agiscono, allora si legge il P.

**REGOLA FISSATA (via 23, subordinata alle vie di G e W)**: P mobile il cui ramo di ARRIVO
clasha un Tai Sui FERMO → **il trend rappresentato dal Tai Sui si rompe** (TS sotto → SALE;
TS sopra → SCENDE). Se il giorno combina il Tai Sui, il TS è difeso e la regola tace.
27 carte, 70,37%, periodi allineati. n piccolo: le carte arrivano a grappoli (USDJPY 2024,
EURJPY 2020, EURGBP 2022) — sono ~10-12 episodi reali. Pista forte, non ancora sopra soglia.

---

# 56. TRASPORTO DI A SU UN TAI SUI VUOTO  ·  `FISSATA` (16/08/2026)

Nata da EURJPY 21/06/2023 (seconda peggiore del gruppo "LY tace", PB perde 150 pip): L4
Figli 酉→戌; l'arrivo 戌 combina l'Ufficiale 卯 su L2, che è Tai Sui, VUOTO, non timely e
legato anche dal giorno 戌. Il mercato sale.

**Meccanica dottrinale (Edu):** la linea mobile ha due fasi, A (partenza) e B (arrivo).
È SEMPRE B che compie la combinazione con la linea ferma C. Ma quando B lega C, A NON
scompare: viene TRASPORTATA fino a C e lì interagisce con C. B è solo la fermata intermedia.
Qui A=酉 viene portata su C=卯 e lo clasha: il "ragno" trasportato dal legame.
Correzione di Claude registrata: la prima lettura ("la partenza clasha, l'arrivo combina",
come se A agisse da ferma) era sbagliata nella sequenza — il perimetro non cambia, cambia
il senso: prima il legame di B, poi l'azione di A sul bersaglio.

**Misure (agli atti):**
- C mobile che combina un G qualsiasi → G non regge: 55 carte, 43,64% — RESPINTA (l'Ufficiale
  abbracciato dal Figli in generale REGGE; vecchio 23,81%).
- Meccanica larga "A clasha C, B combina C" su tutte le C ferme: 238 carte, 46,22% — RESPINTA.
- Trasporto spaccato per azione di A su C ferma (1.672 carte): due celle vive fuori perimetro,
  annotate come piste: A GENERA un Figli legato → sez. Figli non regge (126, 61,90%, z 2,67,
  periodi allineati); A CONTROLLA un Genitori legato → non regge (20, 70%, allineati). Il
  bersaglio è sempre P o C, mai G/W. Da leggere in una sessione dedicata.
- Ristretta a C = Tai Sui (152 carte): TS pieno muto (45,38%). TS VUOTO 22 carte, 54,55% ma
  periodi discordi (72,73/30,00). Dentro il TS vuoto:

| A trasportata su TS vuoto | n | OK |
|---|---|---|
| A CLASHA il TS | 5 | 80% |
| A CONTROLLA il TS | 5 | 80% |
| **A ostile (clash o controllo)** | **10** | **80%** (recente e vecchio presenti) |
| A controllata dal TS / A drena il TS | 9 | 22% (il TS regge) |

**REGOLA FISSATA (via 24, subordinata alle vie di G e W)**: B combina un Tai Sui fermo VUOTO,
e A trasportata è OSTILE al Tai Sui (lo clasha o lo controlla) → **la sezione del Tai Sui
non regge** (TS sotto → SALE; TS sopra → SCENDE). Il ragno è A ostile; il TS vuoto è il
bersaglio già cavo. Se A arriva debole (controllata o drenante), il TS pur vuoto regge: tace.
Col TS pieno la meccanica è muta: fuori perimetro.
10 carte, 80%, a grappoli (GBPUSD dic 2024, USDCHF nov 2025) → ~5-6 episodi reali. Fissata
per coerenza dottrinale (Edu: "una linea che combina e clasha nello stesso movimento fa
proprio quello che mi aspetterei"), da riverificare quando il campione cresce.

---

# 57. IL RAMO DELL'ORA (dal seme) — IL SOSTENITORE DEL TREND  ·  `FISSATA come RAFFORZATIVO` (16/08/2026)

Domanda di Edu, nata dalla EURJPY 21/06/2023 (§56) dove la partenza A della mobile era proprio
l'ora: "che effetto fa una linea mobile che è lo stesso ramo dell'ora?" E poi: "un paio di giorni
fa eravamo sorpresi che, di fronte a diversi indicatori contro il trend, mancasse un vero
sostenitore del trend. È il ramo dell'ora? Solo come mobile o anche da ferma?"

**Misura — il ramo dell'ora nei suoi cinque ruoli (% = il mercato SEGUE il trend):**

| ruolo dell'ora | n | segue | z | recente | vecchio |
|---|---|---|---|---|---|
| **1. PARTENZA della mobile** | 394 | **56,09%** | 2,42 | 57,21% | 55,00% |
| 2. ARRIVO della mobile | 324 | 45,37% | −1,67 | 44,85% | 45,22% |
| 3. linea FERMA visibile | 1.640 | 48,41% | −1,28 | 50,45% | 45,67% |
| 4. solo NASCOSTA | 120 | 44,17% | — | — | — |
| 5. assente dall'esagramma | 1.633 | 48,38% | — | 48,58% | 48,97% |

**RISPOSTA:** sì, l'ora è il sostenitore del trend — ma **SOLO quando è la PARTENZA della linea
mobile**. Da ferma è muta (identica all'assenza). L'ora che ARRIVA (B = ora) o che viene clashata
dalla partenza va contro il trend (44-45%). Il momento della domanda dà forza a chi lo porta da
subito, non a chi ci arriva.

Dentro il caso "partenza = ora":
- mobile PIENA: 57,27% (330) · mobile VUOTA: 50,00% (64) → l'ora vuota non sostiene.
- caso −4 (mutazione che indebolisce forte): 78,13% (32, allineati 66,67/84,21); caso −1: 60,78%
  (102, allineati). L'ora che si muove e si spegne nel movimento sostiene il trend ancora di più.
- Figli sull'ora: 65,63% (32, allineati). Genitori 57,53% (146, ma discordi 63,74/45,10).

**L'ora livella P e B (i negativi sul trend):**

| mobile | non sull'ora → segue | sull'ora → segue |
|---|---|---|
| P/B (negativi) | 47,52% (1.692) | **55,96%** (218) |
| G/W/C | 48,40% (2.025) | 56,25% (176) |

Quando P o B si muovono sull'ora, vince l'ora: la parentela non conta più. MA: P/B sull'ora e
**rafforzati** dalla mutazione (caso 1/5 o avanzante) → 49,43% (87, vecchio 40%): il negativo torna
a mordere. P/B sull'ora e non rafforzati → 60,31% (131, allineati 60,00/58,33). Il P/B che si
spegne nel movimento non fa danni; quello che esce rafforzato resta un negativo (stesso principio
della via 20, letto al contrario).

**Nel PB: nessun effetto.** L'ora nel palazzo del Ti (640 carte, PB win 51,41%), dello Yong
(602, 54,65%), dello Yong trasformato (519, 54,72%), fuori (2.350, 53,53%): tutto nella banda
naturale del PB. Sul segue/non segue: 46,8-49,2% in tutti i casi. Nel PB i palazzi sono strutture
ferme; l'ora conta solo se si muove — coerente col LY.

**Come via del termometro: RESPINTA.** Via 25 "partenza = ora → segue" in coda: copre 100 carte in
più ma peggiora tutti i sistemi (S1 6,94→6,66; S3 7,00→6,75; −1.000 pip). Stessa asimmetria del PB:
una via "segue" scavalca i PB che avevano ragione a dire "non segue". Interruttore VIAORA=1, spento.

**Come RAFFORZATIVO non decisivo (Edu): FISSATO.** Dove il LY parla e dice SEGUE, con partenza =
ora: 65,83% (120, allineati 70,59/61,22) vs 55,31% senza. Dove il LY dice NON segue, con partenza
= ora: 44,83% (174, vecchio 37%) vs 56,14% senza. L'ora sostiene chi segue e smentisce chi non
segue. Nel sistema: **S4 = S1, ma nei contrasti PB/LY, se la partenza è l'ora e il PB segue il
trend, l'ora sostiene il PB.** S4: z 7,07 · 27.084 pip · 54,34/57,14 — il migliore su z e pip
(S1 6,94/26.527, S3 7,00/27.040). Sempre attivo nel grande test.

**Filtro sulle vie di P/B mobile (20, 23, 24):** cablato (FILTROORA=1: se la mobile P/B è
sull'ora e non rafforzata, la via tace) ma OGGI VUOTO — nessuna carta di quelle vie ha quella
configurazione (la via 20 richiede il B rafforzato). Resta pronto per vie future su P/B.

**Pista aperta (non ancora letta con Edu):** linea FERMA sull'ora CLASHATA DAL GIORNO → il mercato
NON segue il trend: 34,26% segue (108 carte, z −3,27, allineati 35,71/34,69). Il giorno che rompe
l'ora ferma è un "non segue" pulito — la direzione che paga. Candidata a via del termometro.

---

# 58. L'UFFICIALE FERMO SUL RAMO DEL GIORNO ROMPE IL TREND  ·  `FISSATA` (16/08/2026) — via 25

Nata dal giro dei ruoli di giorno/mese/anno (richiesto da Edu dopo la §57): a differenza dell'ora,
giorno, mese e anno NON sostengono il trend in nessun ruolo (partenza della mobile: giorno 49,69%,
mese 46,87%, anno 50,41% — contro l'ora 56,09%). Sono lo sfondo comune a tutte e nove le croci
della giornata; solo l'ora dal seme cambia da croce a croce ed è la domanda specifica.
Ma dal giro esce una cella forte con la firma "non segue":

**Ufficiale (G) FERMO sul ramo del GIORNO → il mercato NON segue il trend.**
234 carte · segue 40,60% · z −2,88 · recente 42,96% · vecchio 37,78%.

Vale in tutte le combinazioni (risposta alla domanda di Edu):
- G sotto: 40,27% (149, allineati 40,23/40,35) · G sopra: 41,18% (85, 47,92/33,33)
- trend LONG: 41,18% (119, allineati) · trend SHORT: 40,00% (115, allineati)
Non è una regola di posizione né di verso: è l'Ufficiale che coincide col giorno che di per sé
dice "non fidarti del trend oggi". Lettura: l'Ufficiale (il trend stesso) sostenuto dal giorno è
"troppo forte" — e nel sistema il troppo forte inverte (stessa logica del PB Rafforzamento).

Condizioni che rafforzano / spengono:
- G anche Tai Sui (giorno + anno): 32,26% (31) — ancora più "troppo forte"
- la mobile lo COMBINA: 48,39% (31) → tace · l'ORA lo combina: 51,52% (33) → tace (il legame lo placa)
- la mobile è una RICCHEZZA: 54,55% (33) → tace (W comanda, criterio Edu)
- il MESE lo combina: 43,48% (23, discordi) — non usato

**Interazione con Ti/Yong del PB (richiesta da Edu):** conta dove SIEDE l'Ufficiale, non dove cade
il giorno nei palazzi. G-giorno nel trigramma del **Ti**: 37,59% (133, z −2,86, allineati
42,11/32,08); nello **Yong**: 44,55% (101, allineati 44,07/45,95). Il Ti è il trigramma fermo,
"io": l'Ufficiale piantato nel soggetto è troppo; nello Yong (che muta) pesa meno.
Sul rendimento PB: PB "non segue" + G nel Ti → PB vince 66,25% (80, +1.177 pip); nello Yong 56,25%;
PB "segue" perde in entrambi (43%, 48%). Il PB coglie già in parte la configurazione ma sbaglia
in 74 carte su 234: la via corregge proprio quelle.

**REGOLA FISSATA (via 25):** G fermo sul ramo del giorno, non combinato dalla mobile né dall'ora,
mobile non W → **NON segue il trend** (restituisce l'opposto dell'EMA). Attiva su Ti e Yong
(GGIORNOVIA=ti+yong, default); variante solo-Ti disponibile.

| sistema | senza via 25 | con via 25 (Ti+Yong) |
|---|---|---|
| LY tace | 879 | 836 |
| S1 | z 6,94 · 26.527 | z 7,03 · 26.766 |
| S2 | z 7,20 · 21.874 | z 7,26 · 21.993 |
| S3 | z 7,00 · 27.040 | z 7,07 · 27.186 |
| **S4** | z 7,07 · 27.084 | **z 7,16 · 27.322** |

Tutti i sistemi migliorano, nessuno peggiora, periodi allineati. È la prima via "non segue"
generica (senza direzione propria) del termometro: dice al sistema di andare contro l'EMA.

Note dal giro giorno/mese/anno (piste minori, agli atti): anno fermo né Shi né Ying → 46% segue
(917, z −2,41); mese come arrivo della mobile → 44,48% (326, allineati 44,83/44,60).

---

# 59. IL GENERALE DEL MESE (月將) AMPLIFICA LA NATURA DELLA MOBILE  ·  `FISSATA` (16/08/2026) — via 26

Indagine di Edu sugli spiriti del DLR nel LY/PB. Il Generale del Mese = ramo del 中氣 corrente
a 00:00 GMT del giorno (helper `generaleDelMese()` in pb_stress.js, da jieqi-gmt.js + daliuren.js;
distribuzione uniforme sui 12 rami, 0 carte mancanti).

**Come ramo generico: MUTO.** Nel LY, i cinque ruoli (partenza 47,18% · arrivo 48,18% · ferma
48,78% · nascosta 49,54% · assente 49,06%): tutto rumore. 伏吟 (Generale = ora) 50,67%, 返吟
(Generale clasha l'ora) 47,40%: niente. Nel PB, palazzi Ti 48%, Yong 52%, trasf. 48%; PB win in
banda (伏吟 55,80% su 371, +1.251 pip — un filo sopra, dentro il rumore).

**Come PARTENZA della mobile: amplifica la parentela di chi muove** (Edu: "quando il Generale
muove un Ufficiale e il trend tiene al 59% non è significativo?" — verificato contro la stessa
parentela SENZA Generale):

| mobile | partenza = Generale | partenza NON Generale | delta |
|---|---|---|---|
| **Ufficiale** | **58,97%** segue (78, 64,29/55,88) | 47,40% (808) | **+11,5** |
| Fratelli | 54,76% (84, discordi 57,50/47,37) | 47,91% (933) | +7 |
| Ricchezza | 45,71% (70, discordi 41,03/53,85) | 50,91% (715) | −5 |
| **Genitori** | **37,50%** segue (72, 37,78/37,50) | 49,45% (821) | **−12** |
| Figli | 32,00% (50, discordi 38,46/22,73) | 49,58% (480) | −17 |

Non è l'ora mascherata: Ufficiale mobile con partenza = ora ma non Generale → 51,52%. Il Generale
è la forza del sole che si posa: sull'Ufficiale (il trend) il trend riceve forza e tiene; sui suoi
drenatori/nemici (Genitori, Figli) quelli si attivano e il trend cede. Le due celle solide (periodi
allineati) sono agli estremi: G tiene, P rompe. Figli va nel verso giusto ma vecchio n=22. Ricchezza
(controparte E generatrice di G): i dati non scelgono.

**Nel termometro:**
- **via 26 — P mobile con partenza = Generale → NON segue: FISSATA.** S1 7,03→7,10 · S2 7,26→7,31 ·
  S3 7,07→7,10 · **S4 7,16→7,28, 27.322→27.783 pip**. LY tace 836→821. Periodi allineati.
- G mobile con partenza = Generale come rafforzativo nei contrasti (S6 = S4 + "Generale su G
  sostiene il PB che segue"): PEGGIORA (27.045 vs 27.322 senza via 26; 27.506 vs 27.783 con).
  RITIRATO. Il 59% è vero da solo, ma nei contrasti il LY che ha parlato ha già ragione più spesso.
  Ancora l'asimmetria: paga solo il segnale "non segue". Il dato G-Generale resta a registro senza uso.

## §59-bis. CAVALLO POSTALE, DING SPIRIT, e l'ALLARGAMENTO della via 26 (16/08/2026)

**Cavallo Postale (驛馬, dal giorno per triade e dall'anno):** MUTO nei ruoli generali (partenza
48,8% · arrivo 47,1% · ferma 46,6% · nascosta 47,8% · assente 51,1%; dall'anno idem). Nel PB
niente. Unico sfondo: Cavallo del giorno fermo su una linea che la mobile ignora → 45,39% segue
(1.150, z −3,13, allineati) — effetto piccolo spalmato su un gruppo enorme, non una regola.

**Ding Spirit (丁神, il ramo col tronco 丁 nel 旬 del giorno; helper `dingSpirit()`):** MUTO nei
ruoli generali (partenza 48,3% · arrivo 52,3% · ferma 48,6% · nascosta 46,2% · assente 48,6%).
Nel PB niente. Nessun rapporto con l'ora.

**Ma su entrambi torna la stessa cella:** P mobile con partenza = Cavallo → 39,39% segue (66);
P mobile con partenza = Ding → 36,76% (68). Stesso segno del Generale sul P (37,50%).

**Verifica (richiesta di Edu, spiegata con calma): il P cede a QUALSIASI carica o solo agli
spiriti?** Su 893 carte con P mobile, per cosa coincide con la PARTENZA del P:

| partenza del P = | n | segue | z |
|---|---|---|---|
| Generale del Mese | 72 | 37,50% | −2,12 |
| Ding | 68 | 36,76% | −2,18 |
| Cavallo del giorno | 66 | 39,39% | −1,72 |
| **uno dei tre SPIRITI** | **188** | **40,43%** | **−2,63** (43,56 / 33,80) |
| ora dal seme | 146 | 57,53% | +1,82 |
| anno | 69 | 57,97% | +1,32 |
| giorno | 66 | 54,55% | +0,74 |
| mese | 80 | 48,75% | — |
| nessuno spirito | 705 | 50,64% | — |

Non è "qualsiasi carica": le due famiglie fanno l'OPPOSTO. Gli **spiriti** (Generale, Ding,
Cavallo — forze in movimento) che si posano sul P lo *svegliano*: il P, drenatore di G, rompe il
trend. I **pilastri** (ora, giorno, anno — la struttura del tempo) che si posano sul P lo
*calmano*: il trend tiene. Non c'entra il sostegno elementale del giorno (46,67%, nulla; lo
spirito agisce con e senza: 40,5% / 40,4%).

**Via 26 ALLARGATA: P mobile con partenza = uno spirito del giorno (月將 / 丁神 / 驛馬) → NON
segue.** GENVIA=generale (solo 月將) | spiriti (default) | off.

| sistema | via 26 spenta | solo Generale | **tre spiriti** |
|---|---|---|---|
| LY tace | 836 | 821 | **794** |
| S1 | 7,03 · 26.766 | 7,10 · 27.124 | 7,10 · **27.218** |
| S2 | 7,26 · 21.993 | 7,31 · 22.173 | 7,32 · **22.220** |
| S3 | 7,07 · 27.186 | 7,10 · 27.271 | 7,13 · **27.440** |
| **S4** | 7,16 · 27.322 | 7,28 · 27.783 | 7,28 · **27.877** |

Nessun sistema peggiora, periodi allineati. Cavallo e Ding restano senza funzione propria: agiscono
solo come "carica" sul P mobile.

---

# 60. LE VIRTU' — mute da sole, ma 天德 e 支德 BENEDICONO LA W  ·  `FISSATA come RAFFORZATIVO` (16/08/2026)

**Le quattro Virtù nel LY e nel PB (ruoli generali): TUTTE MUTE.** 天德 (Cielo, tabella per mese,
tronco→ramo via 旬 del giorno), 月德 (Mese, per triade), 日德 (Giorno, dal tronco: 甲己寅 乙庚申
丙辛巳 丁壬亥 戊癸巳), 支德 (Ramo, giorno+5). Partenza/arrivo/ferma/nascosta/assente: tutto
45-52%. Nel PB in banda. E — a differenza di Generale/Ding/Cavallo — NON caricano il P (天德 sul P
43,3% discorde; 月德 sul P 57,8% con periodi opposti 74/30). Le Virtù sono benevole e statiche,
non forze in moto: non svegliano il drenatore.

**Ma tre Virtù su quattro sostengono la W** (Edu: "di quanto aumentano l'efficacia di W?"):

| W mobile, partenza = | n | segue | z | recente | vecchio | delta vs W senza |
|---|---|---|---|---|---|---|
| tutte le W mobili | 785 | 50,45% | 0,25 | 51,85 | 50,84 | — |
| nessuna Virtù | 603 | 48,59% | −0,69 | 49,30 | 50,00 | base |
| **una Virtù qualsiasi** | 182 | **56,59%** | 1,78 | 60,58 | 53,42 | **+8** |
| due Virtù insieme | 43 | 60,47% | 1,37 | 64,00 | 58,82 | +12 |
| **天德** | 64 | **62,50%** | 2,00 | 68,57 | 57,14 | **+13** |
| **支德** | 68 | **61,76%** | 1,94 | 65,79 | 59,26 | **+12** |
| 日德 | 36 | 58,33% | 1,00 | 77,78 | 38,89 | discorde — no |
| 月德 | 72 | 44,44% | −0,94 | 45,45 | 46,15 | **−6, va al contrario** |
| spirito (Gen/Ding/Cav) | 171 | 53,80% | 0,99 | 57,73 | 50,75 | +5 (debole) |
| pilastro (ora/g/a/m) | 245 | 48,57% | −0,45 | — | — | nulla |

La W da sola NON è un sostenitore del trend (50,45%). Diventa tale se parte da 天德 o 支德: la W
benedetta nutre G (W genera G) e il trend tiene. 月德 anzi la disturba (usato solo come esclusione).
Nel PB su queste carte: PB "non segue" con W benedetta PERDE (43,18%, −108 pip su 88), PB "segue"
VINCE (56,38%, +377 su 94) — il rovescio delle W senza Virtù. È uno dei casi in cui il "non segue"
del PB sbaglia: rafforzativo, non via.

**Nel termometro (rafforzativo nei contrasti, come l'ora):**

| sistema | z | pip |
|---|---|---|
| S1 (LY vince nei contrasti) | 7,10 | 27.218 |
| S8 = S1 + solo Virtù su W | 7,10 | 27.546 |
| S4 = S1 + ora | 7,28 | 27.877 |
| **S7 = S4 + Virtù su W** | **7,31** | **28.257** |

I due rafforzativi si sommano (54,65 / 57,08 allineati). **S7 diventa il sistema di riferimento:**
nei contrasti PB/LY, se il PB segue il trend e (partenza della mobile = ORA) oppure (mobile = W con
partenza = 天德 o 支德), il PB vince; altrimenti vince il LY.

**Tabella riassuntiva del giro degli spiriti (16/08/2026):**

| spirito | funzione propria | sul P mobile | sulla W mobile | sul G mobile |
|---|---|---|---|---|
| Generale 月將 | no | non segue 37,5% → **via 26** | 45,7% discorde | segue 59% (no uso) |
| Ding 丁神 | no | non segue 36,8% → **via 26** | — | — |
| Cavallo 驛馬 | no | non segue 39,4% → **via 26** | — | — |
| 天德 · 支德 | no | no | **segue 62% → S7** | — |
| 日德 · 月德 | no | no | discorde / contro | — |

Le forze in moto svegliano il P (drenatore di G → rompe il trend); le Virtù benevole nutrono la W
(generatrice di G → sostiene il trend). Nessuno spirito agisce da solo nell'esagramma né nel PB.
Note pipeline: helper globali in pb_stress.js — generaleDelMese(), dingSpirit(), tronco2ramo(),
tiande(), yuede(), ride(), zhide().

---

# 61. SPIRITI DALLO STELO DEL GIORNO — Lu, Medico, Tomb Sha, Ghost Sha, Wealth-of-day  ·  `FISSATA` (16/08/2026)

**Correzione di metodo (Edu):** questi si misurano dallo STELO del giorno e dal suo ciclo di 12
stadi, non dal ramo o dal mese. La mia prima misura (Lu dal tronco — coincideva; Medico dal mese;
Tomb come tomba dell'elemento del ramo) era sbagliata per Medico e Tomb ed è stata rifatta.
Tabelle fissate (STELO_SPIRITI in pb_stress.js):
- **Lu 祿** = stadio 4 (臨官): 甲寅 乙卯 丙戊巳 丁己午 庚申 辛酉 壬亥 癸子
- **Medico 天醫** = sede DLR dello stelo (寄宮) + 2: 甲辰 乙午 丙未 丁酉 戊未 己酉 庚戌 辛子 壬丑 癸卯
- **Tomb Sha 墓煞** = stadio 9 (墓): 甲未 乙戌 丙戌 丁丑 戊戌 己丑 庚丑 辛辰 壬辰 癸未
- **Ghost Sha 鬼煞** = ramo il cui stelo principale controlla lo stelo del giorno, stessa polarità:
  甲申 乙酉 丙亥 丁子 戊寅 己卯 庚巳 辛午 壬辰戌 癸丑未
- **Wealth-of-day 日財** = ramo il cui stelo principale è controllato dallo stelo del giorno, stessa
  polarità: 甲辰戌 乙丑未 丙申 丁酉 戊亥 己子 庚寅 辛卯 壬巳 癸午

**Ruoli generali nel LY (partenza/arrivo/ferma/nascosta/assente): TUTTI MUTI (44-53%).** Nel PB in
banda; unico palazzo negativo: Ghost Sha nel palazzo dello Yong, PB win 48,38%, −850 pip (556).

**Sulla partenza della mobile per parentela:**

| spirito dallo stelo | sulla W | altro |
|---|---|---|
| **Ghost Sha** | **61,90%** segue (63, allineati 62,79/64,71) | P 56,4% (94); mobile piena 54,7% vs vuota 44,6% |
| **Tomb Sha** | **59,49%** (79, allineati 62,22/56,25) | Tomb come ARRIVO della mobile 55,10% (343, z 1,89, allineati) |
| Lu | 43,64% (55, allineati 44,83/44,00) — **contro** | piatto |
| Medico | 47,6% | C sul Medico 34,6% (52) ma discorde 44,8/19,0 |
| Wealth-of-day | 46,7% discorde | arrivo sul 日財 → 44,73% (427, z −2,18, allineati 43,3/43,6) |

**Sorpresa sul Lu:** Edu lo indicava come importante per la W, ma la W che parte dal Lu NON sostiene
il trend (43,6%, allineato). Il Lu è la "paga" dello stelo: forse la W sul Lu è una W che si incassa,
non una W che nutre G. Il Ghost Sha (controllore dello stelo) invece la benedice — da leggere.

**Lista completa di cosa benedice la W mobile (segue > 55%, periodi allineati):**
天德 62,5% · Ghost Sha 61,9% · 支德 61,8% · Tomb Sha 59,5%. Contro: Lu 43,6% · 月德 44,4%.
Nulli: pilastri, Generale/Ding/Cavallo, 日德 (discorde), Medico, 日財.

**Nel termometro (rafforzativo nei contrasti):**

| sistema | z | pip |
|---|---|---|
| S4 = S1 + ora | 7,28 | 27.877 |
| S7 = S4 + 天德/支德 su W | 7,31 | 28.257 |
| **S9 = S7 + Ghost/Tomb su W** | **7,38** | **28.433** |

Periodi allineati (54,78 / 57,02). **S9 diventa il sistema di riferimento:** nei contrasti PB/LY,
se il PB segue il trend e (partenza della mobile = ORA) oppure (mobile = W con partenza su 天德, 支德,
Ghost Sha o Tomb Sha), il PB vince; altrimenti vince il LY.

---

# 62. IL G CHE SI CONSEGNA AL C FORTE — e l'AMBIVALENZA DEL C  ·  `FISSATA` (16/08/2026) — via in TESTA

Nata dalla coppia gemella Kun/Li di marzo 2023 (stesso esagramma, stesso C 卯 Tai Sui = mese timely
su L1 Ying, stesso mese/anno 卯):
- **AUDUSD 07/03/2023**: G fermo e legato dal giorno, W nascosta dietro un B vuoto, P mobile debole
  (non timely, clashato dal mese, esce controllato), B vuoti. Edu: *"nello LY si deve lavorare con
  quello che c'è e non su quello che non c'è; quando TUTTO IL RESTO tace il Qi si concentra su C, e
  C è il produttore di W: SHORT è una scelta di buon senso"* (mercato −148, il PB aveva detto LONG).
- **USDJPY 21/03/2023**: qui il G si MUOVE (L2 丑→寅) e arriva nel Legno, l'elemento del C 卯
  fortissimo che lo controlla. Edu: *"L2 G si muove per essere eliminato da un C fortissimo. Non c'è
  altro da vedere. LONG"* (mercato +106).
Le due gemelle leggono in modo opposto per un solo motivo: **chi si muove**.

**Principio nuovo (Edu): C è AMBIVALENTE.** Quando c'è la W, la genera e la aiuta; quando c'è un G
vicino, lo attacca. Finora il C non aveva mai avuto una via propria (solo come generatore della W
nella §50f): questa è la sua prima regola come attaccante.

**Misure:**
- "Quando tutto tace" (G, W, P, B tutti muti) e resta un C forte fermo → sede del C: **110 carte,
  50,00%** — quando l'esagramma è davvero muto, è muto: il C da solo non decide (C su Ying 46%,
  su Shi 58%, C = TS 6/7 ma carico 2 = 43%). Le 110 sono il cuore del gruppo "LY tace": lasciare
  parlare il PB. La AUDUSD resta lettura di caso.
- G mobile che ARRIVA nell'elemento di un C forte fermo (timely, pieno, vivo) che lo controlla:
  49 carte, segue 42,86% (recente 53,3 / vecchio 29,4); C su Ying 24, 37,5% (63,6 / 18,2); carico 2
  6 carte, 5/6. **G sotto che si consegna → LONG: 60,98% (41, allineati 57,7 / 69,2)** — l'unica
  riga con i due periodi d'accordo. Controllo: G indebolito dall'arrivo SENZA C forte → 50,2%
  (non è il caso 3/4 in sé: serve il carnefice).
- Nota: statisticamente sotto soglia e con periodi non allineati sul "segue"; **fissata su
  indicazione esplicita di Edu come pilastro della dottrina.**

**REGOLA FISSATA (§62, IN TESTA al termometro — GELIMTOP, default attiva):** G mobile che arriva
nell'elemento di un C forte fermo (timely, pieno, vivo) che lo controlla → il G si consegna al
carnefice, il trend muore → **opposto della sede del G** (G sotto → LONG, G sopra → SHORT).
In coda al termometro era soffocata dalle vie di G precedenti (1 carta); IN TESTA governa le sue
carte e tutti i sistemi salgono: S1 7,07→7,13 · S3 7,13→7,22 · **S9 7,35→7,41 · 28.408 pip**,
periodi allineati. È il posto giusto per un pilastro sul G (indicatore primario).

**Piste minori registrate (dalla stessa carta):** TS fermo su Ying/Shi con UNA carica (timely o
= mese/giorno) → segue 57-63% (allineati); con DUE cariche → 44% (il "fortissimo" è troppo);
TS altrove → 46% (z −2,41). G-TS su Ying → sede 74% (35, allineati 81/64). Trasporto sulla W
nascosta (arrivo combina la linea che la nasconde, W nutrita da C timely): 21 carte, 100% recente /
36% vecchio — vive solo nel recente, in sospeso.

---

---

## PRINCIPI DI LETTURA DI EDU (raccolti il 17/08/2026 — da rileggere a ogni ripartenza)

Questi principi guidano OGNI lettura, prima delle singole vie. Se una via li contraddice, è la via
da rivedere. Ognuno è già cablato dove indicato, ma il principio vale più della sua cablatura.

1. **Precedenza dello Yong Shen.** G e W parlano per primi. P, B, C si leggono solo se G e W non
   parlano (vivi, pieni, timely o mobili). Il B è notoriamente un indicatore negativo. (§64, §66)
2. **Priorità residua.** Se G e W tacciono, B è vuoto e P debole, decide l'attore forte che resta:
   "quando non ci sono alternative migliori si va all'unica disponibile, anche se non piace". (§63, §64)
3. **Si va dove si svolge l'azione.** È l'azione che guida l'interpretazione, non la forza in sé: la
   forza da sola non dà direzione (misurato: Ying/Shi/mobile forti ≈ 50%), pesa DENTRO un'azione. (§63,
   §67, §68, §69)
4. **Capannello e corridore.** Un raduno completo (tre presenti) basta a richiamare l'attenzione: il Qi
   si ferma lì. Se invece qualcuno "corre" (l'arrivo va a clashare/combinare) si guarda dove va. (§67, §68)
5. **Lo Yong Shen cambia la lettura della stessa azione ("dipende").** Clash dell'arrivo: P clashata
   cede, G e C reggono, W che corre porta il Qi con sé. (§68)
6. **Il vuoto non agisce.** Una linea vuota, anche timely, non si oppone e non difende (lascia libero un
   raduno). Il vuoto prospero di mese resta vuoto quanto ad azione. (§67; nel PB la 旺不为空 vale solo
   per il palazzo del Trend)
7. **Certe carte non hanno alternative: si legge l'unica cosa che c'è.** Movimento nullo → si guarda
   chi tocca il giorno (Ying sul giorno; l'unica ferma clashata dal giorno). (§65, §69)
8. **Chi non vince perde.** L'azione fallita (回頭剋, autocombinazione, arrivo clashato) non porta la
   sua direzione. (§52)
9. **È l'arrivo che agisce**, mai la partenza (salvo il trasporto §56 e i rafforzativi ora/W).
10. **Metodo di verifica.** Per respingere una lettura dottrinale va presentata ALMENO UNA CARTA
    completa (con seme) dove non funziona; le percentuali da sole non bastano. Le confutazioni "a
    percentuale" fallivano perché non pesavano la forza → modello di forza (mese su tutte; giorno e
    anno solo sul focus; ora 20%; raduno completo +2; vuoto −2; nascosto; ferme adiacenti solo se la
    madre è timely).
11. **Le regole devono reggere nei due periodi** (recente / vecchio) e non si ribaltano i verdetti per
    inseguire i numeri.

---

## §63 — 回頭生 BLOCCATO: l'arrivo trova qualcuno da clashare (17/08/2026)

**Carta:** EURJPY 06/02/2025 · Li 離 (Fuoco) sopra Kan 坎 (Acqua) = 未濟 Wei Ji, palazzo Li · mutante L4
W 酉 (Metallo) → 戌 (Terra), caso 1 回頭生 · seme 158 · giorno 丙午 · mese 寅 · anno 巳 · ora dal seme 丑
· vuoti 寅卯 · Tai Sui 巳 su L6 (B, Ying, fermo, timely) · Shi L3 B 午 = giorno, nascosto G 亥.
Trend EMA SHORT · PB dice LONG (non segue) · esito SHORT −147 pip · il mercato ha seguito il trend.
Termometro (27 vie): LY tace → S9 = PB solo → perdita. Prima carta del giro "LY tace" (793).

**Lettura di Edu:** L4 si muove e dovrebbe generare indietro (戌 Terra → 酉 Metallo, 回頭生) decretando
il LONG (sede della W sopra) — ma non lo fa, perché l'arrivo 戌 trova L2 (C 辰) da clashare (辰↔戌).
La W 酉 è debolissima (Metallo in mese 寅), 辰 è fortissimo (Terra generata da giorno 午 e anno 巳):
per mancanza di priorità migliori (G assente, W debole) il C su L2 diventa il decisore → la sua sede,
sotto → SHORT.

**Meccanica cablata:** mobile NON timely + caso 1 (回頭生) + l'arrivo clasha UNA linea ferma FORTE
(timely o sostenuta da giorno/anno) → la generazione di ritorno non si compie, la linea clashata decide
→ la sua sede (sotto → SHORT, sopra → LONG).

**Misure (dopo le 26 vie precedenti; sede del bersaglio):**
| cella | n | giuste | recente | vecchio | pip |
|---|---|---|---|---|---|
| A. arrivo clasha 1 linea ferma → sede del bersaglio (tutte) | 1310 | 47,7% | 48,4 | 47,1 | −1897 |
| D. mobile debole + bersaglio forte | 505 | 49,7% | 47,8 | 52,9 | +76 |
| D su LY tace | 89 | 53,9% | 54,4 | 54,8 | −181 |
| **I. D + caso 1 (回頭生 fallito) su LY tace** | **17** | **70,6%** | **69,2** | **75,0** | **+149** |
| I su LY parla (un'altra via ha già parlato) | 40 | 42,5% | 28,6 | 55,6 | +100 |
| G. D + bersaglio C su LY tace | 9 | 77,8% | 75,0 | 100 | +130 |
| H. D + mobile W + bersaglio C su LY tace | 8 | 75,0% | 71,4 | 100 | +113 |
| H su LY parla | 19 | 36,8% | 33,3 | 42,9 | −292 |
| controllo: mobile forte + bersaglio debole (LY tace) | 20 | 35,0% | 46,2 | 14,3 | −251 |
| controllo: entrambi deboli (LY tace) | 53 | 43,4% | 48,6 | 35,3 | −258 |

La parte che regge è la MECCANICA (回頭生 che non torna perché l'arrivo è occupato a clashare un
forte): 17 carte, 70,6%, allineate. La specificazione W→C è troppo piccola (8-9 carte). Fuori dal
gruppo LY-tace la lettura PERDE (36-42%): va tenuta in coda, dove parla solo se nessuna via ha risposto.
Sotto soglia (z 1,70): **fissata come pilastro dottrinale su indicazione di Edu.**

**REGOLA FISSATA (§63, via 27, IN CODA — VIA63=off per spegnere):** mobile debole, caso 1, arrivo
clasha una linea ferma forte → sede della linea clashata.
Grande test: LY tace 793 → 776 · S1 7,13→7,16 (26.938) · **S9 7,41→7,47 · 28.209 pip** (z sale,
−199 pip: quattro carte grandi contro) · periodi allineati (54,92 / 57,02).
Parità software ↔ pb_stress.js dopo la cablatura: 0 disallineamenti su 4.111 (LY e S9).

**Chiarimento sulle linee ferme (richiesto da Edu).** Nel resoconto della carta avevo notato che i due
B fermi (L3 = giorno 午, L6 = Tai Sui 巳) sono entrambi Fuoco timely, e avevo ipotizzato che questo
sostenesse il "segue" (SHORT). Misurato: **B fermo sul giorno + B fermo sul Tai Sui, entrambi timely
→ segue 32,0% (25 carte, 30,8 / 30,0)** — è l'OPPOSTO: la carta segue il trend NONOSTANTE i due
Fratelli, non grazie a loro. In generale "linea ferma = giorno + linea ferma = Tai Sui, stessa
parentela" → segue 40,9% (88); B fermo timely sopra E sotto → 48%. La mia ipotesi (a) è RESPINTA;
resta valida solo la lettura di Edu (§63). Ipotesi (b) "W rafforzata da un arrivo = Tomb Sha → W falsa"
non misurata: la carta si spiega già con la §63.

**§63-bis — la W assediata (17/08/2026, stessa carta).** Edu: sulla EURJPY c'è anche un raduno
direzionale del Fuoco 三會 巳午未 fra **L6 巳** (Tai Sui, B), **L5 未** (C) e il **giorno 午** (che è
anche L3 Shi); il Fuoco raccolto controlla il Metallo della W 酉 (L4, la mobile) → W inagibile, e di
nuovo si va su L2 a cercare l'azione (il clash dell'arrivo). "Si deve andare dove si svolge l'azione,
specie in queste carte così sbilanciate."

**Misure (raduno 三會 o 三合 fra linee FERME + giorno/mese/anno, dell'elemento che CONTROLLA la mobile):**
| cella | n | giuste | recente | vecchio | pip |
|---|---|---|---|---|---|
| raduno controllante da solo → sede della mobile | 418 | 51,2% | 53,5 | 47,3 | — |
| raduno controllante da solo → segue? | 418 | 47,6% | 46,5 | 46,7 | — |
| **mobile timely ma assediata + caso 1 + arrivo clasha 1 ferma forte → sede bersaglio (LY tace)** | **10** | **70,0%** | **66,7** | **100** | **+356** |
| stessa cella, tutte le carte | 21 | 61,9% | 62,5 | 60,0 | +457 |
| §63 allargata (debole O assediata), tutte | 78 | 53,8% | 50,0 | 59,3 | +706 |
| controllo: raduno che SOSTIENE la mobile (stesso el. o la genera) | 737 | 51,8% | 51,4 | 51,3 | — |

Il raduno da solo non decide nulla: conta solo come SECONDA CAUSA di inagibilità della mobile dentro la
meccanica della §63 (l'azione va cercata dove l'arrivo agisce). Piccola ma allineata; **fissata su
indicazione di Edu.**

**REGOLA FISSATA (§63-bis, dentro la via 27):** la mobile è inagibile se NON timely **oppure** se
timely ma assediata da 三會/三合 controllante (linee ferme + giorno/mese/anno); poi come §63.
Grande test: LY tace 776 → 766 · S1 7,16→7,22 (27.234) · S3 7,28 · **S9 7,47→7,50 · 28.266 pip**
(recente 54,96 / vecchio 57,02). Parità software ↔ pb_stress.js: 0/4.111.
Nel software la via si chiama "Return-generation blocked: go where the action is" e la lettura scrive
"weak / besieged by the Fire gathering 巳午未 …" con i rami reali.

---

## §64 — PRIORITÀ RESIDUA: G e W tacciono, decide il più forte fra P e C (17/08/2026)

**Carta:** AUDUSD 07/03/2023 · Kun 坤 (Terra) sopra Li 離 (Fuoco) = 明夷 Ming Yi, palazzo Kan · mutante L6
P 酉 → 寅 (caso 4, arrivo 寅 combina 亥 che è VUOTO su L3/L5 → il movimento finisce nel vuoto) · seme 67
· giorno 甲子 · mese 卯 · anno 卯 · ora 午 · vuoti 戌亥 · Tai Sui 卯 su L1 (C, Ying, = mese, = Ding, 旺).
G L2/L4 legati dal giorno 子 (子合丑); B L3/L5 vuoti; W solo nascosta sotto L3 (午, clashata dal giorno);
P mobile debole (Metallo in primavera). Trend EMA SHORT · PB dice LONG · esito SHORT −148 · perdita.
Termometro (27 vie): LY tace. Seconda carta del giro.

**Lettura di Edu:** "Ying fortissimo con C vince → SHORT". E richiamo del criterio già enunciato: questo
modo di leggere si basa sull'ASSENZA delle priorità precedenti — G e W non parlano, B vuoto, P
debolissimo — per cui decide l'attore forte residuo. Il criterio di precedenza (16/08) era a registro
come principio ma NON era cablato come via: corretto oggi. Edu: "è il secondo caso quando tu mi avevi
detto che era rarissimo" (il 16/08 avevo misurato "quando tutto tace + C forte" a 50% su 110 e lasciato
al PB — quella cella era mal definita: non filtrava G/W per forza e non sceglieva il decisore per forza).

**Letture intermedie misurate e RESPINTE su questa carta:** (a) giorno clasha il nascosto W 午 sotto L3
→ sede dell'ospite: 330 carte 46,4%, su LY tace 60 carte 35,0% (ospite vuoto: 16 carte 18,8%) —
il clash del giorno sul nascosto DISPERDE, non estrae (conferma del 15/08); (b) nascosto clashato
"costretto a generare" il G 丑 di L2 → sede della generata: 120 carte 50,8%, su LY tace 15 carte 26,7%;
(c) Ying C = Tai Sui → sede: 39 carte 41,0% (solo recente); Ying = TS timely qualunque parentela:
108 carte 56,5%, su LY tace 28 carte 60,7% — regge come sottocaso della §64.

**Misure della PRIORITÀ RESIDUA (G/W "non parlano" = nessuno vivo, pieno e timely-o-mobile; decisore =
più forte fra P/B/C per punteggio timely+TS+mese+giorno+sostegno del giorno, unico):**
| cella | n | giuste | recente | vecchio | pip |
|---|---|---|---|---|---|
| decisore unico, tutte le carte | 815 | 51,8% | 52,2 | 50,6 | +636 |
| **decisore FERMO, su LY tace** | **116** | **56,0%** | **56,7** | **53,8** | **+955** |
| decisore C, LY tace | 47 | 59,6% | 54,2 | 61,9 | +599 |
| decisore P, LY tace | 60 | 56,7% | 57,9 | 54,5 | +266 |
| **decisore B, LY tace** | 52 | **42,3%** | 45,8 | 38,5 | −111 |
| decisore = Tai Sui, LY tace | 27 | 51,9% | 52,6 | 50,0 | +317 |
| decisore su Ying / su Shi, LY tace | 26 / 20 | 53,8 / 60,0 | — | — | — |
| controllo: G/W parlano, decisore residuo | 1411 | 50,2% | 50,4 | 50,8 | −238 |

Fuori dal gruppo LY-tace la regola è muta (le vie di G/W hanno già parlato): sta in CODA. Il B residuo
va contro: escluso.

**REGOLA FISSATA (§64, via 28, IN CODA — VIA64=off per spegnere):** G e W non parlano → il più forte fra
P e C, se unico per punteggio, decide → la sua sede (sotto → SHORT, sopra → LONG); il B residuo non decide.
Grande test: LY tace 766 → **659** · S1 7,22→7,44 (27.942) · S3 7,28→7,41 · **S9 7,50→7,72 · 29.004 pip**
(recente 55,14 / vecchio 57,14, entrambi su). Parità software ↔ pb_stress.js: 0/4.111.
Nel software: "Residual priority: G and W silent → strongest P or C decides", con la lettura che elenca
le cariche del decisore (timely, Tai Sui, = month, = day, backed by the day).

---

## §65 — NIENTE SI MUOVE: lo Ying sul giorno decide (17/08/2026)

**Carta:** EURJPY 05/03/2025 · Li 離 (Fuoco) sopra Gen 艮 (Monte) = 旅 Lü, palazzo Li · mutante L2 B 午 →
亥 VUOTO (caso 0, movimento nullo) · seme 159 · giorno 癸酉 · mese 寅 · anno 巳 · ora 寅 · vuoti 戌亥 ·
Tai Sui 巳 su L6 (B) · Shi L1 C 辰 legato dal giorno (辰合酉) · Ying L4 W 酉 = GIORNO. Trend EMA LONG ·
PB dice SHORT · esito LONG +145 · perdita. Terza carta del giro (LY tace 659).

**Lettura di Edu:** "Semplicissima: Shi genera Ying, LONG. Certe carte non hanno alternative, quindi si
legge l'unica alternativa possibile: la mobile finisce nel nulla, non si muove niente, l'unica cosa che
salta all'occhio è Shi che genera Ying, che è il giorno stesso."

**Misure.** "Shi genera Ying → sede Ying" in generale NON regge: 445 carte 51,0%; su LY tace 55 carte
43,6%; con Ying W 24 carte 33,3%; Shi-Ying che si combinano (辰酉) 20 carte 30,0% (conferma: la lettura
statica Shi/Ying non ha mai misurato, v. LY autonomo v1-v4 bocciato l'11/08). Ristretta al MOVIMENTO
NULLO: Shi genera Ying → 195 carte 48,7%; ciò che decide è **Ying = giorno**:
| cella (→ sede dello Ying) | n | giuste | recente | vecchio | pip |
|---|---|---|---|---|---|
| Ying fermo sul giorno, tutte | 295 | 50,2% | 52,7 | 47,8 | −237 |
| Ying sul giorno, LY tace | 35 | 54,3% | 56,3 | 52,9 | +64 |
| **Ying sul giorno + movimento NULLO, LY tace** | **12** | **91,7%** | **100** | **83,3** | **+372** |
| Ying sul giorno + movimento VIVO, LY tace | 23 | **34,8%** | 36,4 | 36,4 | −308 |
| Ying sul giorno + movimento nullo, LY parla | 135 | 47,4% | 49,4 | 44,2 | −518 |
| Shi sul giorno + movimento nullo → sede Shi | 26 | 34,6% | 41,7 | 30,8 | +17 |
Le 12: USDJPY 09/11/2020 (unica sbagliata, −213), AUDUSD 15/09/2025, USDCAD 31/03/2021, 07/04/2022,
31/01/2023, NZDUSD 06/04/2022, 31/07/2023, 08/11/2024, EURJPY 30/09/2020, 10/06/2021, 26/02/2025,
05/03/2025. Il controllo è pulito: il giorno sullo Ying parla SOLO nel silenzio della carta; con la
mobile viva è la mobile che comanda. Vale per lo Ying, non per lo Shi. Fuori da LY tace è muta → coda.
Assorbe la pista del 16/08 "TS su Ying con una carica → segue 57-63%" e quella di oggi "Ying con ≥3
cariche → 80% (10)": era il movimento nullo a farle funzionare, non il numero di cariche.

**REGOLA FISSATA (§65, via 29, IN CODA — VIA65=off per spegnere):** movimento nullo della mobile + Ying
fermo sul ramo del giorno → sede dello Ying (sotto → SHORT, sopra → LONG).
Grande test: LY tace 659 → **647** · S1 7,50 (28.062) · S3 7,47 · **S9 7,72→7,78 · 29.124 pip**
(recente 55,23 / vecchio 57,08). Parità software ↔ pb_stress.js: 0/4.111.
Nel software: "Nothing moves: Ying on the day branch decides".

---

## §66 — B AVANZANTE nel gua inferiore: il trend vince sopra (17/08/2026)

**Carta:** USDJPY 30/04/2024 · Li 離 (Fuoco) sopra Zhen 震 (Tuono) = 噬嗑 Shi He, palazzo Xun 巽 · mutante
L2 B 寅 → 卯 (caso 5, AVANZANTE 進神, partenza = Cavallo, arrivo = Ding, arrivo clasha G 酉 L4) · seme 156
· giorno 甲子 · mese 辰 · anno 辰 · ora 亥 · vuoti 戌亥 (nessuno in carta) · Tai Sui 辰 su L3 (W = mese)
· Shi L5 W 未 · Ying L2 (la mobile) · tutte le linee piene e timely (carta densa). Trend EMA LONG · PB
dice SHORT · esito LONG +140 · perdita. Quarta carta del giro (LY tace 647).

**Lettura di Edu:** "B avanza su L2 per clashare il G L4, che è combinato da mese e anno (辰酉合) e non si
fa spazzare via → LONG. Inoltre un B che avanza nel gua inferiore sarebbe già indicazione di un trend
vincente sull'altro lato. Il B è notoriamente un indicatore negativo."

**Misure.** (a) Bersaglio clashato DIFESO (combinato da giorno/mese/anno) → sede del bersaglio: 256 carte
48,0%; su LY tace 54 carte 44,4%; con bersaglio G 34 carte 41,2%; controllo (bersaglio NON difeso) 47,6%
— nei dati la difesa per combinazione non cambia l'esito del clash → RESPINTA. (b) B avanzante:
| cella | n | giuste | recente | vecchio | pip |
|---|---|---|---|---|---|
| B avanzante → lato opposto (sotto→LONG, sopra→SHORT), tutte | 120 | 45,0% | 44,8 | 44,8 | −396 |
| idem, LY parla | 106 | 42,5% | 39,6 | 44,4 | −773 |
| **B avanzante SOTTO → LONG, LY tace** | **11** | **72,7%** | **75,0** | **66,7** | **+347** |
| mobile avanzante (ogni parentela) sotto → LONG, LY tace | 19 | 68,4% | 66,7 | 75,0 | +572 |
| mobile avanzante SOPRA → SHORT, LY tace | 32 | 37,5% | 36,8 | 38,5 | −89 |
L'avanzata del B paga solo dal basso e solo dove nessuna via ha parlato; fuori da lì dà l'opposto.
Edu sceglie la versione stretta al B (indicatore negativo). Sotto soglia; **fissata per dottrina.**

**REGOLA FISSATA (§66, via 30, IN CODA — VIA66=off per spegnere):** B mobile avanzante nel gua inferiore
→ LONG. Grande test: LY tace 647 → **636** · S1 7,50→7,66 (28.624) · S3 7,60 · **S9 7,78→7,94 · 29.686 pip**
(recente 55,40 / vecchio 57,14). Parità software ↔ pb_stress.js: 0/4.111.
Nel software: "B advancing in the lower trigram: the trend wins above".

---

## MODELLO DI FORZA (17/08/2026) e §67 — raduno del Legno sotto: forte sale, debole affonda

**Origine.** Su USDJPY 30/04/2024 (LONG +140) e sulla sua gemella USDCHF 16/09/2024 (SHORT −30, stesso
esagramma Zhen sotto, stessa mobile L2 B 寅→卯, stesso G 酉 clashato) le mie confutazioni "a percentuale"
non reggevano: Edu — "le carte che mi proponi per confutare ribaltano quasi sempre la tua aspettativa a
causa del timeliness/forza delle linee". Il motore conosceva solo timely/non timely e "sostenuto dal
giorno". Costruito il MODELLO DI FORZA (liuyao.js `forzaModello`, esposto nel software colonna "Force"
+ "Hidden force", riga arrivo/raduni, dettaglio al click), dottrina fissata da Edu:
- Mese: SEMPRE, su tutte le linee — prospero +2 · in crescita +1 · riposo 0 · imprigionato −1 · morto −2.
  Terra prospera nei quattro mesi di Terra, e lo è anche l'elemento stagionale (si prende il migliore).
- Giorno e anno: forti SOLO sul FOCUS (la linea che la regola sta esaminando). Giorno: stesso +1,5,
  genera +1, controlla −1, clasha −1 (il clash RIEMPIE una linea vuota solo se timely), combina: forza
  invariata ma legata. Anno: stesso +1, genera +0,5, controlla −0,5.
- Ora dal seme: 20% del timeliness — stesso ramo +0,4, stesso elemento +0,3, genera +0,2.
- Raduno (三會/三合, linee + arrivo + giorno/mese/anno): solo COMPLETO, niente mezzo raduno, NON vale
  con uno dei tre vuoti; +2 all'elemento del raduno.
- Vuoto −2 salvo prospero di mese (0). MA: una linea vuota, anche timely, NON AGISCE (non si oppone
  a un raduno, non difende).
- Mobile: alla partenza l'effetto dell'arrivo — 回頭生 +1 · 比和 +0,5 · 回頭剋 −2 · 進神 +1 · 退神 −1 ·
  movimento nullo → la partenza non agisce.
- Nascosto: forza del proprio elemento; ospite vuoto lo lascia uscire, ospite pieno lo copre (−1).
- Ferme adiacenti: si nutrono SOLO se la madre è timely (+1 al figlio); un figlio timely può esaurire
  la madre non timely (−1 alla madre).

**Correzione mia (svista):** in una lista precedente avevo letto "via —" come "nessuna via" e detto "6/6
sul gruppo LY tace"; "—" è invece l'etichetta delle vie 1-6 (senza § nel registro): quelle carte erano
spiegate dalle vie 2 e 6. Corretto qui.

**Misura col modello (raduno 三會 completo nel trigramma della mobile, forza della mobile come focus):**
| cella | n | giuste | recente | vecchio | pip |
|---|---|---|---|---|---|
| **sotto, forte (≥3) → LONG, LY tace/coda** | **7** | **100%** | 100 | 100 | +363 |
| **sotto, debole (<3) → SHORT, LY tace/coda** | **4** | **100%** | 100 | — | +90 |
| sotto forte → LONG, LY parla | 30 | 36,7% | 57,1 | 20,0 | −40 |
| sopra (forte → SHORT / debole → LONG) | 13 | 46% | — | — | — |
Le 7 forti: USDJPY 30/04/24, USDCHF 02/01/24, EURJPY 24/02/25, EURGBP 25/11/21, 18/05/22, 14/05/25,
EURUSD 21/07/25 (tutte LONG). Le 4 deboli: USDCHF 10/09 e 16/09/24, EURGBP 10/09 e 16/09/24 (Legno
morto nel mese 酉, forza 1,7, G 酉 vuoto che non si oppone; tutte SHORT). Fuori dal gruppo di coda la
lettura non vale (37%): coda. Le tre carte perse dalla §66 erano proprio le "deboli".

**REGOLA FISSATA (§67, via 31, in coda PRIMA della §66 — VIA67=off per spegnere):** raduno 三會 completo
nel trigramma inferiore (mobile partenza/arrivo + ferme, nessun vuoto) → forza della mobile ≥ 3 → LONG;
< 3 → SHORT. Grande test: LY tace 636 → 635 · S1 7,66→7,72 (28.720) · S3 7,66 · **S9 7,94→8,00 ·
29.782 pip** (recente 55,49 / vecchio 57,14). Parità software ↔ pb_stress.js: 0/4.111.
Nel software: "Wood gathering in the lower trigram: strong rises, weak sinks", con la forza e il suo
dettaglio nella lettura.

**Da fare col modello di forza:** rimisurare le letture di forza già respinte "a percentuale" (G difeso
dalla combinazione, Ying forte, W assediata §63-bis, nascosto clashato) usando i punteggi; valutare se
il modello può sostituire "timely" nelle vie esistenti (una via alla volta, parità dopo ogni cambio).

---

## §68 — CLASH DELL'ARRIVO letto per YONG SHEN (17/08/2026)

**Origine.** Coppia USDJPY 24/06/2024 (seme 159: L6 B 巳→戌 clasha L1 辰 Shi+Tai Sui, mercato SHORT) e
USDJPY 02/06/2026 (seme 159, stessa azione, Tai Sui su L2, mercato LONG). Poi USDCHF 03/01/2023 (seme 92,
L5 W 未→申 clasha il Tai Sui B 寅 di L2 MA combina il C 巳 di L6 → LONG +113).
Edu: "capannello per strada → ti fermi (raduno: il Qi resta); uno che corre attraversando → guardi dove
va (si segue l'arrivo)". E: "dipende — esiste lo Yong Shen (Spirito del Focus): nel LY sono B, C, W, G, P,
ognuno fa cose diverse e l'interpretazione si adatta a quello che fanno".

**Misure (arrivo che clasha SOLO una linea ferma piena, nessuna combinazione; → sede della clashata):**
| cella | n | giuste | recente | vecchio | pip |
|---|---|---|---|---|---|
| tutte | 332 | 43,7% | 45,8 | 41,2 | −1739 |
| **clashata P, coda** | 35 | **25,7%** (→ 74% opposto) | 30,0 | 20,0 | −788 |
| clashata P, tutte | 105 | 36,2% | 36,7 | 38,5 | −1017 |
| **clashata G, coda** | 13 | **76,9%** | 87,5 | 60,0 | +411 |
| **clashata C, coda** | 25 | **64,0%** | 64,7 | 62,5 | +666 |
| clashata B / W | 141 / 111 | 45,4 / 45,0 | — | — | — |
| **mobile W che clasha, coda** | 33 | **60,6%** | 57,7 | 71,4 | +584 |
| mobile W clasha W | 30 | 63,3% | 68,2 | 57,1 | +256 |
| mobile B che clasha, coda | 33 | 45,5% (B clasha P: 1/16) | — | — | — |
| mobile G / C che clasha, coda | 15 / 12 | 26,7 / 33,3 | — | — | — |
Il corridore che va a COMBINARE arriva davvero (clasha E combina → sede combinata 60% vs 40%; solo
combina, altro lato 54,8%). Quello che va a CLASHARE: la P investita cade sempre, G e C reggono il colpo;
se chi corre è una W ci si volta e si va dove va lei.
Il caso "clashata = Tai Sui" da solo NON regge (35 carte 40%; coda 10 carte 60%): la 24/06/2024 si spiega
per il C clashato (L1 C 辰 → regge → SHORT), non per il Tai Sui.

**REGOLA FISSATA (§68, via 32, IN CODA — VIA68=off per spegnere), ordine come proposto e accettato:**
1) clashata P → sede opposta; 2) clashata G o C → sede clashata; 3) altrimenti mobile W → sede clashata.
Grande test: LY tace 635 → **578** · S1 7,72→7,94 (29.192) · S3 7,88 · **S9 8,00→8,25 · 30.378 pip**
(recente 55,62 / vecchio 57,44). Parità software ↔ pb_stress.js: 0/4.111.
Nel software: "Arrival clash read by the Yong Shen (who is hit, who hits)".

---

## §69 — UNICA AZIONE: il giorno clasha una ferma mentre nulla si muove (17/08/2026)

**Carte:** USDJPY 13/02/2024 (seme 149; Dui/Xun, L3 G 酉→午 sospeso dal giorno 未; il giorno clasha lo
Ying L1 W 丑 PIENO → "rotto" → LONG +137) e USDCHF 27/12/2023 (seme 85; stessa carta, Ying L1 W 丑
VUOTO clashato dal giorno → "esce dal vuoto e decide" → SHORT −105 per la lettura opposta).
Edu: "due tentativi non riusciti, chi non vince perde" (13/02); "l'unica differenza è L1: era vuoto ed è
clashato fuori dal vuoto → diventa il fattore che decide" (27/12). E, richiamato il principio: "se non
ci sono migliori alternative si va verso l'unica disponibile anche se non ti piace. È l'azione che
guida l'interpretazione. Se W è vuoto e viene clashato fuori dal vuoto — e altrove non succede niente —
è QUI che si DEVE guardare."

**Misure (movimento nullo, nessun raduno, il giorno clasha esattamente UNA ferma; vuota → sede, piena →
opposta):** tutte 134 carte 47,0% (53,1 / 40,3); **coda 31 carte 61,3% (72,2 / 46,2), +280**; ramo
"piena → opposta" coda 28 carte 60,7% (72 / 40); ramo "vuota → sede" 19 carte 36,8% (di cui 3 in coda).
Famiglia più larga (già misurata prima): "ferma vuota clashata dal giorno → sede" 348 carte 48,9%;
"nascosto vuoto/debole estratto dal clash del giorno" 15/08 44%, 17/08 46%: nei dati il clash del giorno
non riempie. Movimento nullo → lato opposto (chi non vince perde esteso): 1.966 carte 51,2%.
**Nessuna carta singola contraria decisiva** da opporre (celle a metà, non un controesempio netto):
per metodo, fissata come **pilastro dottrinale su insistenza di Edu**, con sostegno statistico DEBOLE e
periodi non allineati — da tenere d'occhio nell'holdout.

**REGOLA FISSATA (§69, via 33, IN CODA — VIA69=off per spegnere):** movimento nullo + nessun raduno + il
giorno clasha una sola ferma → vuota: sua sede; piena: sede opposta.
Grande test: LY tace 578 → **553** · S1 7,97 (29.114) · S3 7,85 · **S9 8,25→8,28 · 30.270 pip** (−108 pip,
recente 55,67 / vecchio 57,44). Parità software ↔ pb_stress.js: 0/4.111.

## §70 — NA YIN dell'esagramma iniziale come INDICATORE DI CONFIDENZA del LY (18/08/2026)

**Ipotesi Edu:** il Na Yin dell'esagramma iniziale (XKDG: esagramma → jiazi → Na Yin) entra come attore in più
nel gioco delle relazioni a cinque elementi, rafforzando o indebolendo Ti, Yong o le parentele LY (B/C/W/G/P).

**Misura (universo LY parla, 3.550 carte):**
- Na Yin INDEBOLISCE il B (lo controlla o lo drena): 1.453 carte · 57,67% · z 5,85 · +11.817 pip
- Na Yin RAFFORZA il B (uguale o lo genera): 1.246 carte · 56,02% · z 4,25 · +9.497 pip
- Na Yin neutro sul B: 851 carte · 54,76% · z 2,78 · +3.000 pip
- baseline LY solo: 56,39% · z 7,62 · +24.314 pip

**Verdetto:** il Na Yin che colpisce il B (bandiera negativa) segnala che il LY è più affidabile su quella carta;
non è un segnale di direzione. Provato come:
- rafforzativo del PB nel contrasto (S10): −3.298 pip rispetto a S9 → **danneggia**
- decisore nel gruppo LY tace (561 carte): tutte le varianti peggiori del PB da solo → **danneggia**
- override del LY (forza segue/non segue, salto contrasti): tutte peggiori della baseline → **danneggia**

**Registrato come:** indicatore di confidenza del LY, NON cablato come via né rafforzativo. Da tenere per
un'eventuale pesatura delle posizioni (LY più preciso quando Na Yin indebolisce B).

**Osservazione collaterale:** Na Yin vs Yong PB, "Yong controlla il Na Yin" → 699 carte · 57,51% · z 3,97,
concentrato nella via 我生 (253 carte, 60,47%, z 3,33). Sotto soglia, in osservazione.

**Piste chiuse (18/08/2026, provate senza esito):**
- ~~Tre Messaggi 三傳 del DLR · 1a–4a lettura 四課 · ramo celeste sopra anno/mese/ora~~
  **SPOSTATE il 31/08/2026 in `REGISTRO_DLR_31_08_2026.md` §8.** Erano misurate sul "seguire il
  trend"; la lettura direzionale (LONG/SHORT) è aperta e va in quel registro. Non citarle più da qui.
- numerazione XKDG (Kun1 Xun2 Li3 Dui4 Zhen8 Gen6 Kan7 Qian9), somma Hetu 5/10/15, Sheng/Ke In-Out
  senza Terra: nessuna cella oltre z 3, nessun rinforzo combinato
- risonanza (scala mobile) su tutto il dataset: pulita 49,8%, bloccata 44,9% → nessun edge; regge solo
  su 34 carte LY tace bloccate (58,8%) — troppo poche per cablare
- Qi bloccato su B via combinazione 六合 → SHORT: 36 carte LY tace, 44,4% → non regge

## §71 — GUA SHEN (卦身) e confronto SHI↔YING: piste chiuse (18/08/2026)

**Gua Shen (卦身).** Definizione (Edu): sulla linea Shi, se yang L1..L6 → 子丑寅卯辰巳; se yin → 午未申酉戌亥.
Provate tre formulazioni, tutte con la lettura doctrinale di Edu integrata:
1. GS singolo, ruolo nell'esagramma (partenza/arrivo mobile, ferma, nascosto, assente): nessuna cella oltre z 2,5 come direzione
2. Due GS (Shi e Ying, uno per clan), parteggiamento a punteggio (stesso ramo +2, combina/genera +1, clash/controlla −1): 3.482 carte, 50,57%
3. Due GS come innescatori di AZIONI, con la regola del clash corretta ("il clash muove la linea sulla propria
   trasformazione: conta solo se il ramo futuro è diverso"), combinazioni doppie che si annullano, vuoto che non
   conta: 3.335 carte, 50,85%; nel LY tace 49,25%. Il codice riproduce fedelmente la lettura di Edu su EURJPY
   28/04/2022 (SHORT attivo ma non vince → LONG) ma generalizzata non predice.
   Contro-esempio: USDJPY 15/11/2024 (GS-Ying = ramo dello Shi = giorno, margine 4 → LONG; mercato sceso −213).
Osservazione: il sistema va meglio dove il GS è "muto"/assente (57–60%). Non cablato.

**Confronto diretto Shi↔Ying.** Rimisurato con motore attuale in 7 forme (elementale, mobile=Shi/Ying, arrivo che
colpisce Shi/Ying, coppie di parentele, sostegno della data, vuoto, giorno che tocca): tutte ≈50%, nessuna oltre z 2.
Ripetuto con Shi/Ying letti ATTRAVERSO la mobile (tomba 墓 = 辰Acqua/未Legno/戌Fuoco/丑Metallo, clash/controllo
dall'arrivo, vuoto), regola "la tomba spegne l'azione di chi la subisce": 2.647 carte, 48,21%, −4.842 pip.
Il codice riproduce la lettura di Edu su EURJPY 19/12/2024 (Ying in tomba non genera lo Shi → Shi non vince → LONG),
ma su 401 carte simili: 46,38%.
Dato chiave: LY contrario al modello Shi/Ying vince 58,13% vs 55,45% quando concorde.

**Perimetro (Edu):** chiuso SOLO il confronto diretto Shi↔Ying come fonte di direzione. Shi e Ying restano
attori in tutte le vie che già li usano (§65 Ying sul giorno, clan/sede, bersagli di clash e combinazione, ecc.).
La carta continua a essere interpretata come sempre.

**Errori di sessione (18/08/2026):** due errori di segno sul movimento del mercato (EURJPY 09/12/2024 e 28/04/2022)
e un contro-esempio presentato senza verificare il blocco da linea vuota (EURUSD 27/01/2022). Regola per il futuro:
prima di presentare una carta, verificare esplicitamente move (>0 = salito), segnale finale e pnl dal dump CARTA=.

## §72 — MODELLO "dove va il Qi" per Shi↔Ying: codificato ma sotto soglia (18/08/2026)

Riscrittura pulita del confronto Shi↔Ying secondo il principio di Edu "dove va il Qi":
- l'arrivo della mobile è il Qi; se l'arrivo è vuoto → azione nulla
- la mobile in vuoto NON è vuota (il movimento la riempie); l'arrivo vuoto non produce effetto
- il Qi si ferma alla PRIMA cattura: combinazione (con linea non vuota) > clash > tomba
- combinazione con Shi/Ying → quella linea si carica e prevale → vince il suo clan
- clash → la linea avanza alla linea futura (esagramma trasformato); conta solo se il ramo futuro è diverso
- tomba → la linea intombata non agisce (perde generazione/controllo verso l'altra)

Le tre carte di controllo tornano tutte con la lettura di Edu (EURUSD 12/05/2022 → SHORT; USDJPY 04/01/2024
e EURJPY 19/12/2024 → il Qi combina una linea non-Shi/Ying, quindi il modello tace, niente più SHORT sbagliato).

**Misura:** dove il Qi combina proprio Shi o Ying (mobile esclusa): 473 carte, 51,59%, +1.500 pip. Nel LY tace: 37
carte, 43,24%. LY concorde col modello 57,95% vs contrario 56,40% (differenza trascurabile). Sotto soglia, non
cablabile, ma la lettura è ora codificata correttamente (blocco QIMODEL in pb_stress.js per riferimento).

**Stato:** capitolo Shi↔Ying come DIREZIONE chiuso (§71-§72). Shi e Ying restano attivi in tutte le vie che già li
usano. Na Yin resta come indicatore di confidenza (§70). Nessuna nuova via cablata oggi: S9 invariato.

## §73 — MECCANICA CORRETTA del "dove va il Qi" Shi↔Ying: sette raffinamenti dottrinali, ancora sotto soglia (19/08/2026)

Ripresa del confronto Shi↔Ying (§72) partendo dai contro-esempi. Edu ha corretto la meccanica carta per carta;
ogni correzione legge bene la carta specifica e TUTTE le carte di controllo, ma l'aggregato non supera mai il 52-55%
(la versione "forza/elemento dominante" scende addirittura al 45,71%). Non cablabile. Qui si SALVANO le spiegazioni.

### La meccanica finale (dottrina), passo per passo
1. **Cattura.** L'arrivo della mobile (ramo di arrivo) combina in 六合 con una linea Shi o Ying non vuota: quella è la
   linea "catturata" (C); l'altra fra Shi/Ying è "l'altra" (O). Perimetro: mobile ≠ Shi/Ying, arrivo non vuoto.
2. **Trasformazione della catturata.** La catturata riceve il ramo di PARTENZA della mobile e assume il suo elemento
   — TRANNE quando forma un 三合 (vedi §3). Es. semplice: Ying 巳 + partenza mobile 未 → Ying diventa Terra.
3. **三合 PIENO (三合, raduno/trigono) — regola forte.** Se il ramo della catturata + il ramo di partenza della mobile
   + un TERZO membro formano un 三合 pieno, la catturata si RINFORZA nell'elemento del trigono (non conversione).
   - I MEZZI-TRIGONI (半合) NON contano: serve il trigono pieno a tre membri.
   - Il terzo membro può essere: una linea VISIBILE non vuota, una linea NASCOSTA (伏神/fushen), OPPURE un ramo del
     BAZI (anno/mese/giorno). Anche l'arrivo della mobile (linea futura) conta come membro presente.
   - Un membro VUOTO non chiude il trigono (il vuoto non agisce) — MA una linea in vuoto che si MUOVE non è vuota
     (il movimento la riempie), quindi un 伏/ramo che partecipa al movimento conta anche se sta nei vuoti del giorno.
   - Trigoni: Acqua 申子辰 · Legno 亥卯未 · Fuoco 寅午戌 · Metallo 巳酉丑.
4. **Chi prevale (controllo/generazione).** Fra la catturata (nel suo elemento, trasformato o rinforzato) e l'altra:
   - la catturata CONTROLLA l'altra → prevale la catturata (vince il controllore);
   - l'altra controlla la catturata → prevale l'altra;
   - generazione in un verso o nell'altro → prevale L'ALTRA (la catturata prevale SOLO se controlla);
   - 比和 (stesso elemento) → muto.
   Direzione = clan della linea che prevale (L1-3 = SHORT, L4-6 = LONG).
5. **Drenaggio col 伏神 (interp 1).** Se la mobile ha una linea NASCOSTA (伏神), il movimento la porta fino alla
   catturata, che assume l'elemento del 伏. Se a quel punto l'altra GENERA la catturata (es. Shi-Metallo genera
   Ying-Acqua), l'altra è DRENATA e la catturata prevale. Questo drenaggio scatta SOLO se c'è un 伏 da portare
   (senza 伏 → lettura normale del §4). Ed è subordinato alla forza (vedi §6).
6. **Elemento dominante / forza (interp 2, principio unificante).** La forza dominante del quadro (三合 + Bazi) UCCIDE
   una delle due linee: la linea CONTROLLATA dal dominante è spenta, la linea che GENERA il dominante è drenata;
   vince chi sopravvive. Il drenaggio del §5 "vince" solo se la linea drenata è davvero DEBOLE/untimely.
   Una linea allineata col dominante (stesso elemento, prospera) resiste e vince.

### Carte di controllo (tutte lette correttamente dalla dottrina; seme + trigrammi nel testo sessione)
- EURUSD 12/05/2022 (SHORT): catturata→Legno controlla Terra → vince catturata → SHORT. ✓
- USDJPY 04/01/2024 (LONG): catturata→Metallo controlla Legno → vince catturata → LONG. ✓
- GBPUSD 15/12/2022 (SHORT): Shi 戌 riceve partenza 寅 → Legno; niente 伏 sulla mobile → Ying-Acqua genera Shi-Legno,
  vince l'altra (Ying) → SHORT. ✓ (il drenaggio NON scatta senza 伏.)
- USDJPY 19/12/2024 (LONG): Acqua dominante — 三合水 申子辰 (anno 辰 + mese/伏 子 mobile + arrivo 申), col 子 nascosto
  che si muove (non vuoto). L'Acqua controlla la Ying-Fuoco → Ying spenta → vince la Shi → LONG. ✓
- USDJPY 05/02/2025 (SHORT): Fuoco dominante (anno/giorno 巳巳 + Ying 巳). Il 伏 子 (Acqua) è untimely, non riesce a
  drenare la Shi debole in modo decisivo; la Ying-Fuoco resiste ed è forte → vince la Ying → SHORT. ✓
  (Gemella figurale della 19/12/2024 — stesso esagramma 3/2 L5 seme 154, stesso palazzo Terra, stessa mobile 未 伏 子 —
   ma esito opposto deciso dall'elemento dominante: Acqua vs Fuoco.)
- USDJPY 28/04/2025 (SHORT): 三合火 寅午戌 pieno (寅 伏 sotto la Shi) → Shi rinforzata Fuoco, controlla Ying-Metallo →
  vince la Shi → SHORT. ✓
- USDJPY 09/03/2020 (SHORT): 三合水 申子辰 (子 dall'anno) sulla Ying → Ying-Acqua controlla Shi-Fuoco → vince Ying → SHORT. ✓
- USDJPY 02/08/2022 (LONG): 三合legno 亥卯未 col 未 dal MESE ma 未 è VUOTO → trigono non si forma → conversione
  semplice, Ying→Acqua, Shi-Terra la controlla → vince la Shi → LONG. ✓

### Misure (env pb_stress.js, tutte spente di default; S9 invariato)
- v7 (conversione + 三合 pieno con 伏/Bazi, membro vuoto escluso + controllo/generazione): 288 carte, 52,78%, z 0,94,
  +2.282 pip. LY tace 19 carte, 31,58% (negativo).
- interp 1 corretta (drenaggio solo con 伏神): 305 carte, 53,11%, z 1,09, +1.964 pip. Rompe solo USDJPY 19/12/2024
  (poi spiegata dall'elemento dominante).
- interp 2 (forza Shi/Ying come direttore): 48,38%, z −0,60 — scartata, sotto testa-o-croce, rompe 3 controlli.
- MODELLO ELEMENTO DOMINANTE (forza a punteggio su Shi/Ying con bonus 三合 e soppressione): 315 carte, 45,71%,
  z −1,52, −2.491 pip — la codificazione a punteggio NON cattura la lettura esperta.

### Verdetto
Ogni carta è spiegabile dottrinalmente e la meccanica è ora ben definita, ma NESSUNA codificazione meccanica supera
il ~55%, e la più completa va sotto il 50%. Nel gruppo LY-tace (dove servirebbe come voce autonoma) sono 18-22 carte,
mai con edge. Firma di un giudizio esperto non riducibile a regola a punteggio su questo dataset. Shi↔Ying "dove va
il Qi" resta NON cablabile come decisore (coerente con §71-§72). Le regole dottrinali (三合 pieno; terzo membro anche
伏神/Bazi; mezzi-trigoni no; membro vuoto non chiude; vuoto-che-si-muove non è vuoto; drenaggio solo con 伏; elemento
dominante uccide la linea controllata/drenata) si TENGONO come sapere dottrinale, non come segnale. Blocchi di prova
in pb_stress.js: QIFIX/QIV5/QIV6/QIV7/QICHOOSE2/QIFORCE (tutti sotto flag, default off).

## §74 — CLASH DEL GIORNO SULLA LINEA MOBILE: la mobile SI MUOVE COMUNQUE, e il LY è più affidabile (19/08/2026)

**Domanda (Edu):** una linea mobile clashata dal ramo del giorno riesce a muoversi o no? (test generale, non legato a Shi/Ying)

**Test (sonda LY):** il termometro legge sempre l'ARRIVO della mobile. Se la mobile clashata non si muovesse, l'arrivo
sarebbe rumore e il LY crollerebbe in quel gruppo. Invece:
- mobile CLASHATA dal giorno: LY **60,26%** (234 carte, z 3,14, +2.751 pip) · recente 54,2% / vecchio 68,0%
- mobile NON clashata: LY 56,12% (3.316 carte, z 7,05)
**Risposta: la mobile clashata dal giorno SI MUOVE — e si muove meglio.** Il clash non la ferma, la rende più decisa
(coerente col 冲起, il clash che "alza/attiva" la mobile). Il vantaggio è TRASVERSALE alle vie: 11 su 12 vie con ≥8
carte clashate fanno meglio nel gruppo clashata (R5 68% vs 54%, R12 67% vs 53%, R13 63% vs 53%, R11 82% vs 58%, R6 61% vs 54%).
Non è un artefatto di composizione delle vie.

**Timeliness (dal mese, elemento di partenza della mobile):**
- clash su mobile TIMELY (旺/相): 62,1% (103, z 2,46) · neutra (休): 66,7% (45) → il vantaggio sta qui
- clash su mobile UNTIMELY (囚/死): 54,7% (86, z 0,86) — recente 47% → NESSUN vantaggio, il clash su una linea debole
  non la rilancia, la disturba e basta
- nel gruppo NON clashato la timeliness NON conta (timely 55,0% / untimely 57,4%, piatto): l'effetto è l'INTERAZIONE
  clash × forza, non la forza da sola.
(Il saldo Bazi dà un segnale opposto e controintuitivo su 65 carte con 89% nel vecchio — non affidabile; vale il taglio di stagione.)

**Natura:** AMPLIFICATORE DI CONFIDENZA del LY (stessa famiglia di §70 Na Yin), non direzione nuova. Utile per pesare
posizioni, non per cambiare verdetti. Cautela: vantaggio più piccolo nel periodo recente — da riverificare nel tempo.
Non cablato. Blocchi MOBCLASHGEN / MOBCLASHVIE / MOBCLASHTIME in pb_stress.js (flag, default off).

**Ricaduta su Shi↔Ying:** conferma la carta USDJPY 20/03/2026 (LY tace, mercato LONG +116): la Shi/mobile L2 亥,
clashata dal giorno 巳, SI MUOVE comunque, arriva su 午 che combina la Ying L5 未 (vuota, 午未合) → la Ying sveglia
vince → LONG. Spiegata.

**§74 — CABLATO come PESATURA (19/08/2026, sera).** Nel blocco PBLY di pb_stress.js il sistema S9 ha ora una riga
parallela "S9p. S9 PESATO §74": lotto x2 quando la PARTENZA della mobile e' clashata dal ramo del GIORNO (290 carte);
i verdetti non cambiano. Risultato canonico: S9 4.111 · 56,46% · z 8,28 · +30.270 pip  →  S9p +34.200 pip (+3.930).
Attivo di default; si spegne con PESO74=off. La versione condizionata alla timeliness (x2 solo timely/neutra) rende
MENO (+604 su pnl PB), e penalizzare le untimely (x0,5) azzera il vantaggio: cablata la forma semplice.
Non ancora nel PWA (liuyao.js/app.js): da aggiungere come indicazione "lotto x2" nel verdetto quando serve.

## §75 — "CLASH DEL VUOTO" (冲空) come via LY: testato, sotto soglia (19/08/2026)

Meccanica (da USDJPY 14/06/2022): una linea VUOTA non mobile clashata dal ramo del GIORNO viene svegliata (il primo
clash solo la sveglia, non la muove); da svegliata può fare da intermediario (drena una linea, combina/nutre un'altra).
Test come via:
- perimetro stretto (la svegliata combina Shi o Ying e la nutre -> prevale la nutrita): 8 carte su 4.111 (5 col "nutre"),
  62% ma z 0,7 — TROPPO RARA per essere misurata. LY tace: 1-2 carte.
- perimetro largo (qualsiasi linea vuota svegliata dal giorno, 274 carte): sede della svegliata 48,54% — nessun segnale.
- per PARENTELA della svegliata: W (Ricchezza) -> sede 58,82% (51, z 1,26; recente 57,7 / vecchio 56,5, allineati);
  B (Fratelli) -> sede 40,00% (75, z -1,73) cioè l'OPPOSTO al 60%. Firma coerente con "W vince, B perde", ma z ~1,3-1,7:
  SOTTO SOGLIA. LY tace: W 11 carte (72,7%), B 4 carte.
Verdetto: NON via. Meccanica reale come evento (W svegliata bene, B svegliata male) ma troppo debole/rara per decidere.
Tenuta come sapere, in osservazione. Blocchi VIACHONGKONG / VIACHONGKONG2 (flag, default off).

## §76 — R13_52 "chi non vince perde": TOLTO il sotto-caso "arrivo clashato dal giorno" (19/08/2026) — CABLATO

Analisi delle tre vie grosse e deboli (R13_52 727 carte 53,1% · R6 464 54,1% · R5 357 54,6%, insieme 38% delle carte).
In R13_52 le perdite si concentravano nel sotto-caso "arrivo clashato dal giorno": 211 carte, 49,76%, -481 pip
(gli altri due sotto-casi reggono: 回頭剋 313 carte 51,4%, autocombinazione positiva). Sette letture alternative
provate su quelle 211 carte (sede, timeliness arrivo/partenza/giorno, parentela, bersaglio del clash, "segue sempre"):
TUTTE ~44-56%, nessuna regge — sono carte SENZA informazione direzionale, e il LY ci stava dando un verdetto rumore.
Premessa dottrinale corretta dal §74: il clash del GIORNO sulla mobile la ATTIVA (la mobile si muove, e meglio), quindi
un arrivo clashato dal giorno NON e' "azione fallita". Tolto il sotto-caso: R13_52 resta con 回頭剋 + autocombinazione.
Effetto su S9: 4.111 · 56,46% · z 8,28 · +30.270  →  56,58% · z 8,44 · +30.460 (+190 pip), MIGLIORA SU ENTRAMBI i
periodi (recente 55,67→55,76 · vecchio 57,44→57,56). Modifica "togli, non aggiungi". Cablata in pb_stress.js (lyDir,
regola 13) e in liuyao.js (via R13_52). NUOVO BASELINE S9: 4.111 · 56,58% · z 8,44 · +30.460 · S9p +34.390.

**Nota su pesatura per via (verifica cieca):** lotti per via fissati sul periodo VECCHIO e applicati al RECENTE a
esposizione pari: PEGGIORANO (11.920 -> 10.973 pip). I tassi per via non sono stabili fra periodi: pesare per via NON
regge fuori campione, NON cablare. Il §74 (x2 mobile clashata) in cieco sul recente: +1% (12.013) — marginale ma
credibile (nessun parametro aggiustato). ESCLUDERE i gruppi deboli perde pip (i gruppi deboli sono comunque positivi).
Linea operativa: ~3,2 trade/giorno su 9 cross, lotto uniforme + §74.

## §77 — R6 三會 (raduno dei tre col mese): TACE quando la mobile è G (19/08/2026) — CABLATO

R5 退神 analizzata: 8 letture alternative provate, la regola attuale ("opposto, salvo Tai Sui che clasha la partenza")
è la MIGLIORE (54,6%); sede-sempre 46,5%, timeliness 49%, clash giorno+anno 52,7%. R5 CONFERMATA, non toccata.
Il recente di R5 (-199 pip) viene da pochi colpi grossi su USDJPY/EURJPY, non da un difetto della regola.
(Nota a campione piccolo: R5 con mobile W 68%/19 carte, C 62%/16; B 53%/100, P 52%/120.)

R6 三會 analizzata: 7 letture alternative, nessuna batte la maggioranza attuale (54,1%); "raduno controlla il palazzo ->
opposto" 42% da scartare; senza COVID 54,3%, senza Legno 54,7% (non vale eccezione). Ma per PARENTELA della mobile:
  mobile P  89 carte 67,4% z 3,29 (recente 61 / vecchio 74) — fortissima e stabile
  mobile G  95 carte 45,3% — recente 36% — qui R6 perde davvero
  B/C/W 51-55%.
Cablato: R6 TACE quando la mobile e' G (coerente col principio 5, "il Yong Shen cambia la lettura della stessa azione").
Effetto su S9: 56,58% z 8,44 +30.460  →  56,80% z 8,72 +30.272. Win% e z SALGONO (z massimo mai toccato), MIGLIORA SU
ENTRAMBI i periodi (recente 55,76→56,02 · vecchio 57,56→57,68), ma -188 pip (le 95 carte G riprese da altre vie/PB
indovinano piu' spesso su movimenti piu' piccoli). Cablato per z e stabilita' (i 188 pip sono entro il rumore di 3-4 carte).
In pb_stress.js (lyDir regola 6) e liuyao.js (via R6).
NUOVO BASELINE S9: 4.111 · 56,80% · z 8,72 · +30.272 pip · S9p (§74) +33.866.

## §78 — IL GIORNO LEGATO (六合) DAL TAI SUI: inversione del ramo segue/non-segue del PB (19/08/2026) — CABLATO (S11)

**Domanda di Edu:** quando il Tai Sui lega il giorno, o quando e' il mese a legarlo, ci sono carte positive che
diventano negative o l'opposto? RISPOSTA: SI, e l'inversione e' sul Tai Sui.

Misura su tutte le 4.111 carte (giorno legato = 六合 fra ramo del giorno e ramo dell'anno / del mese):
| gruppo | n | PB "NON segue" | PB "SEGUE" |
| giorno LIBERO | 3.417 | 54,61% (+12.813) | 53,33% (+3.172) |
| legato dal MESE | 351 | 46,09% (-154) | 50,00% (-497) |
| legato dal TAI SUI | 316 | 46,78% (-110) | **66,27% z 2,96 (+1.503)** |
| legato da entrambi | 27 | 70,6% (17 carte) | 50% |

- **TAI SUI lega il giorno -> SI CAPOVOLGE il pilastro del sistema.** Normalmente il profitto vive nel "non segue"
  e il "segue" e' il ramo debole; li' il "segue" fa 66,27% (83 carte, z 2,96, recente 70,27% / vecchio 63,04% —
  COERENTE SUI DUE PERIODI) e il "non segue" scende a 46,78%. Lettura dottrinale: il Tai Sui che lega il giorno
  fissa la giornata sull'anno e in quel regime il trend TIENE.
- **MESE lega il giorno -> nessuna inversione, si SPEGNE tutto:** il PB va sotto il 50% in entrambi i rami
  (47,29% complessivo, -651 pip). Il mese che lega il giorno neutralizza il PB, non lo rovescia. (Non cablato:
  gruppo negativo ma senza lettura alternativa; da riprendere.)
- **Il LY NON risente di nessuno dei due** (57,75% col TS · 55,86% col mese · 56,97% libero): e' solo il PB a essere sensibile.

**Cablato come S11** (rafforzativo nella stessa forma di S4/S7/S9): se il giorno e' legato dal Tai Sui E il PB segue
il trend, il PB e' forte e il LY non lo scavalca nel contrasto.
Effetto: S9 56,80% z 8,72 +30.272  →  **S11 56,90% z 8,84 +31.000** (+728 pip). Vecchio 57,68→57,98; recente
56,02→55,98 (piatto). Migliora win%, z E pip insieme (le §76/§77 scambiavano pip per z). Con pesatura §74: +34.594.
Lato motore (pb_stress.js, blocco PBLY); la PWA non implementa le policy S1-S11 (mostra PB e termometro separati).

**NUOVO BASELINE: S11 · 4.111 carte · 56,90% · z 8,84 · +31.000 pip · S11p (con §74) +34.594.**

**Nota — meccaniche dottrinali testate e NON cablabili (19/08, sera):** "il clash del giorno e' neutralizzato se il
giorno e' combinato dal Tai Sui" (da AUDUSD 02/08/2022): solo 41 carte nel perimetro, sede 48,8% vs opposto 51,2%,
periodi discordi (recente 64 / vecchio 40) — NESSUNA differenza misurabile. Conferma inoltre che l'intero gruppo
"arrivo clashato dal giorno" (415 carte) e' rumore puro (sede 47,6% / opposto 52,4%): §76 era la mossa giusta.

## §79 — RAMO DEL TRIGRAMMA CHE SI MUOVE: pista quasi tutta chiusa, un candidato in osservazione (19/08/2026)

Idea di Edu: il trigramma che CONTIENE la mobile porta con se' il suo ramo (Houtian: 坎=子 · 艮=丑寅 · 震=卯 · 巽=辰巳 ·
離=午 · 坤=未申 · 兌=酉 · 乾=戌亥) e quel ramo agisce sul quadro.
Testate: clash/combinazione del ramo su una linea (48-51%), clash su Shi o Ying (51%), la catena esatta della carta
(冲空 su Shi/Ying che poi controlla l'altra: 46 carte, 50,00%, periodi opposti), elemento del trigramma che controlla
Shi/Ying (51%). Poi, su indicazione di Edu, azione elementale (controlla/drena/nutre) col FILTRO "mobile bloccata da
combinazione o clash": tutte le celle 48-51%, LY tace 50,0% su 174 carte. PISTA CHIUSA in queste forme.

**CANDIDATO IN OSSERVAZIONE (non cablato):** "il ramo del trigramma che si muove CLASHA una linea VUOTA -> quella linea
e' spenta (NON svegliata) e il suo lato PERDE -> clan OPPOSTO". E' il rovescio del 冲空 del giorno (il giorno risveglia,
il ramo del trigramma annulla).
- LY TACE: 44 carte, **72,73%**, z 3,02, +934 pip · recente 66,7% / vecchio 75,0% (coerente) · senza COVID 43 carte 72,1%
- taglio piu' pulito: la vuota clashata NON e' ne' Shi ne' Ying -> **25 carte, 84,0%, z 3,40** (recente 90 / vecchio 77)
- se la vuota E' Shi o Ying: sparisce (50% / 63,6%)
- LY PARLA: 297 carte, 50,84% — NESSUN segnale (funziona solo dove il LY non ha voce: via "di riserva")
Cautela: 44 carte (25 nel taglio migliore), z 3,02 sotto la soglia z>4. NON cablato, da riverificare con piu' dati.
Blocchi TRIGRAMO / TRIGRAMO2 / TRIGVUOTO in pb_stress.js (flag, default off).

## §80 — ESISTE UN INDICATORE DI TREND DENTRO IL LY? Risposta: NO (19/08/2026)

Domanda di Edu: il LY produce solo alto/basso (clan) — chi vince — e mai "segue / non segue". Il segue/non-segue lo
produce SOLO il PB. Si e' cercato un indicatore di trend interno al LY. Provate CINQUE costruzioni, decine di varianti:

1. **La MOBILE rappresenta il trend** (bloccata -> non segue). Tutte le forme di "blocco" da COMBINAZIONE/CLASH/回頭剋
   danno SOTTO il 50% (48,3-49,9%): quando la mobile e' impedita il trend TIENE, il contrario dell'intuizione.
   L'unico verso giusto e' la FORZA: mobile untimely -> non segue 51,7% z 2,17 (LY tace 54,8%).
   Per parentela della mobile: W 53,6% z 2,03 · C 55,3% z 2,43 (LY tace 59,2%) · B 49,0% · P periodi opposti · G 51,1%.
2. **Parentela dell'ARRIVO.** Arrivo W -> "non segue" 53,2% (LY tace 168 carte **57,74% z 2,01**, recente 58,1/vecchio 58,5).
   Arrivo G -> NIENTE (49,7/50,3, periodi opposti). Altri arrivi 50,8-51,5%.
   **Provato come S12 sopra S11: PEGGIORA (56,90->56,43%, z 8,84->8,25, 31.000->28.276 pip).** Il PB su quelle carte fa
   gia' meglio: un tasso alto in isolamento NON implica additivita'. Non cablato.
3. **La SHI rappresenta il trend.** Le singole condizioni sono quasi tutte negative (Shi clashata dal giorno 48,9% ·
   Shi e' la mobile 48,7% · combinata dal giorno 48,9% · drenata 49,7% · controllata 49,6%): quando la Shi e' colpita
   il trend TIENE. Miglior combinazione (controllata o drenata o vuota -> non segue): 51,5% z 1,98 (LY tace 55,6% z 2,87).
   Sotto il PB (53,5% / 53,75%).
4. **Shi qualificata dalla PARENTELA** (Edu: Shi B o P che vince = negativo per il trend, e l'opposto). Quattro varianti:
   49,1-50,0% (LY tace 49,0-51,7%). La parentela della Shi NON discrimina. Dettaglio: "seguire" e' sotto il 50% in quasi
   tutte le celle per ogni parentela; l'unica sopra (Shi P sana 53,7%) ha periodi opposti (59,5/47,6) = rumore.
5. **Rappresentante scelto dall'EMA** (rialzista -> quello in alto fra Shi/Ying, e viceversa).
   NOTA CONCETTUALE: nella forma letterale "il rappresentante vince -> segue" questa idea e' MATEMATICAMENTE IDENTICA
   alla lettura per clan che il LY gia' usa (alto vince = LONG = segue quando l'EMA e' up, ecc.). Il LY quindi UN rapporto
   col trend ce l'ha: e' esattamente la lettura per clan, vista dall'altro lato. La versione non banale (rappresentante
   forte -> segue) da' 49,4-50,7%. Anche "Shi allineata + non contrastata -> trend confermato" (7 definizioni di
   contrasto): 49,3-51,4%.

**CONCLUSIONE: il LY non contiene un secondo canale di lettura del trend, indipendente dal PB.** Legge chi vince fra
alto e basso; il "segue/non segue" resta compito del PB (53,5% da solo, z 4,51). La divisione del lavoro PB(trend) +
LY(chi vince) e' cio' che produce S11 56,90% z 8,84.

### Le SEI BESTIE (prima esplorazione, 19/08/2026)
- **青龍 Drago Azzurro** — unico segnale reale del filone: **"Drago in ALTO -> segue, in BASSO -> non segue": 4.111 carte,
  51,79%, z 2,29, +9.843 pip, recente 51,0 / vecchio 52,2 (coerenti).** Come DIREZIONE invece non funziona (sede del
  Drago -> clan 50,1%; LY tace 46,9%). Altre celle: Drago sulla mobile -> NON segue 52,6% · Drago sulla Shi -> non segue 52,8%.
  Provato come rafforzativo sopra S11 (S13: Drago in alto sostiene chi segue): 56,87% z 8,81 **+31.601 pip** e RECENTE
  MIGLIORE (55,98->56,24) ma z e vecchio leggermente peggio. Le varianti S14 (Drago in basso sostiene chi non segue) e
  S15 (entrambi i versi) PEGGIORANO nettamente (56,31 / 56,29%). NON cablato: guadagno dentro il rumore, pagato con z.
- **白虎 Tigre Bianca** — NIENTE, in 13 letture (49,1-50,8%). Come impulso ribassista ("Tigre -> SHORT sempre") 49,6%:
  nessuna spinta ribassista intrinseca. Come trend: Tigre in alto -> non segue 50,3%; Tigre sulla Shi -> non segue 49,1%.
  Miglior cella "sede della Tigre -> clan opposto" 50,8% (contro-immagine del Drago, meta' del suo segnale).
  Nel LY tace "Tigre forte -> SHORT" fa 44,5% (z -2,58): una Tigre forte NON implica ribasso, semmai il contrario.
  **Asimmetria Drago/Tigre: non sono una coppia simmetrica.**
- **DA FARE:** esplorazione sistematica di tutte e sei le bestie incrociate con Shi/Ying/mobile, parentela e forza,
  in sessione dedicata. E' l'unico filone di oggi che ha mostrato un segnale coerente sui due periodi.
Blocchi MOBTREND / MOBTREND2 / SHITREND / SHITREND2 / REPTREND / SHIALLIN / BESTIE / TIGRE in pb_stress.js (flag, default off).

---

## §81 — Il Serpente 螣蛇 morto o imprigionato sostiene chi NON segue (20/08/2026)

**Regola.** Se il Serpente siede sulla **Shi**, sulla **Ying** o sulla **linea mobile** ed è **untimely** nel mese
(囚 o 死), e il PB dice **"non segue il trend"**, il PB è forte e il LY non lo scavalca.

**Numeri.** Perimetro 527 carte. Lasciando decidere il PB: 59,20% (recente 57,0 / vecchio 61,8).
Lasciando decidere il LY: 54,84%. Contributo al sistema: da 56,94% a 57,48%, +766 pip.

**Dottrina.** Il Serpente non indica una direzione: indica che **l'azione è attorcigliata**. Quando è debole
su una linea che conta, il movimento non regge e il trend non tiene. È un indicatore di fragilità
dell'azione, non di direzione.

**A una faccia sola.** Il ramo simmetrico (Serpente timely sostiene chi segue) PEGGIORA il sistema
(56,58% contro 56,94%). Non cablato. Rispetta l'asimmetria nota: il profitto vive nel "non segue".

**Perimetro largo, non stretto — attenzione.** Da solo il 死 è molto più forte del 囚
(死: 365 carte 62,47% z 4,76 · 囚: 369 carte 51,49% z 0,57). Ma **dentro il contrasto** il rapporto si
inverte: 囚 fa vincere il PB nel 57,78% dei casi, 死 solo nel 54,55%. Motivo: sulle carte in 死 il LY è
già d'accordo col PB, quindi la regola non ha nulla da correggere. Restringere al solo 死 costa 868 pip.
Interruttore `SERP81=stretto` nel motore, spento.

**Indipendente dalla parentela.** P 61,4% · W 58,2% · C 57,1% · G 55,0% · B 53,3% — tutte positive,
nessuna che ribalta il segno.

---

## §68-bis — Il clash dell'arrivo che è anche controllo distrugge (20/08/2026)

**Origine.** Carta EURJPY 11/12/2023, letta da Edu.

**Regola.** Nel perimetro del §68 (l'arrivo della mobile clasha esattamente una ferma piena, nessuna
combinazione): se l'**arrivo controlla (剋) anche l'elemento** della linea colpita, non è un urto ma una
distruzione. La colpita non regge — chi non vince perde — e prevale la **mobile** (= sede opposta alla
colpita, che su tutte le carte del perimetro coincide).

**Numeri.** Sulle 85 carte interessate: il §68 di prima faceva 45,88% (−828 pip), la lettura nuova fa
56,47% (+871). Il §68 intero passa da 54,80% z 1,81 (+699) a 57,34% z 2,76 (+2.399), con entrambi i
periodi in miglioramento. Sul sistema: +96 pip. Vale per dottrina più che per pip.
Interruttore `VIA68BIS=off`.

**La timeliness non entra.** Verificato su richiesta di Edu: "vince la mobile" funziona in tutti e quattro
i quadranti (arrivo timely/untimely × colpita timely/untimely): 56,4 / 53,1 / 54,6 / 56,5. Il quadrante
che l'ipotesi dava per più forte (arrivo timely, colpita untimely) è il **più debole** e l'unico spaccato
fra i periodi (45,9 recente contro 63,8 vecchio). Conferma il principio: **l'azione, non la forza**.

---

## Piste chiuse il 20/08/2026

- **Le Sei Bestie, esplorazione sistematica.** Vincolo strutturale: le bestie si dispongono in sequenza
  fissa dallo **stelo del giorno**, quindi due bestie a 3 posizioni di distanza sono sempre in specchio.
  Non esistono sei indicatori ma tre assi, e la posizione di una bestia è un filtro di calendario
  travestito. Bestia su Shi/Ying/mobile: niente (43–55%). Bestia con B/C/W/G/P: segnali deboli
  (45–46% "segue"), tutti entro ~3 punti dalla base EMA di 48,77%. Nessuna casella a z > 4.
- **Serpente come indicatore di trend.** No: 48,77%, identico all'EMA nuda.
- **Serpente che tocca il trigramma opposto.** Clash 50,00% esatto su 198 carte, combinazione 50,92%.
  Nulla. Nota: il Serpente è l'unica bestia per cui la mobile che clasha l'opposto non prevale — ma
  l'effetto sulle altre è della mobile, non della bestia, e comunque debole (z 1,94).
- **Drago che si combina col Serpente.** 41 carte; la casella "segue il trend" fa 58,54% ma spaccata
  (73,3 vecchio / 52,0 recente) su undici carte. Il Drago mobile da solo fa 49,32% su 365 carte.
  Unica casella con segno: la partenza del Drago clasha il Serpente → vince il Serpente, 66,7% su 36
  carte. Troppo poche e trovata cercando: segnalata, non usata.
- **Linea legata dal giorno liberata dal clash della mobile.** 113 carte, 53,98%, **+8 pip** netti — vince
  piccolo e perde grosso. Segnale contraddittorio fra clash di partenza e clash di arrivo. Non è una via.
- **得位 (linea intera su posto dispari, spezzata su posto pari).** Come predittore: niente
  (Shi al posto 49,90%, Ying 49,22%, "vince il trigramma più ordinato" 49,04%). Come rafforzativo del PB:
  **respinto** — vedi sotto.

---

## Nota di metodo (20/08/2026) — misurare dentro il contrasto, mai sul totale

Due volte nella stessa sessione la stessa trappola:

1. Il Serpente in 死 fa 62,47% (z 4,76) sul totale ma solo 54,55% dentro il contrasto; il 囚 fa 51,49%
   sul totale e 57,78% dentro il contrasto.
2. Il PB con esagramma ordinato (4+ linee al posto) fa 55,72% sul totale contro 52,09% — ma dentro il
   contrasto fa 45,62%, cioè **peggio** che con l'esagramma disordinato (46,03%).

In entrambi i casi il guadagno apparente veniva da carte dove **il LY era già d'accordo col PB**, dove il
verdetto sarebbe stato lo stesso comunque. **Sul totale si misura l'accordo, non l'informazione.**
Una condizione candidata a rafforzativo va sempre misurata sulle sole carte in contrasto.

---

## Nota software (20/08/2026) — la PWA non applicava il LY

Scoperto durante la sessione: `fsadvisor.org/trading/` mostrava un segnale calcolato **solo dal Plum
Blossom** (53,51%). Il pannello Liu Yao disegnava l'esagramma ma `combinaS9` non veniva mai chiamata.
Corretto in `app.js`: il segnale ora è quello del sistema completo (57,48%), verificato **0 disallineamenti
su 4.111 carte** contro il motore. Aggiunta nel pannello la riga "六爻 Liu Yao corrective".
Al modulo `liuyao.js` mancavano anche i rafforzativi §78 (TSLEGA) e §81 (SERPENTE): cablati.
Condizione necessaria: `app.js` deve passare `corpoEl` (elemento del trigramma del Trend) nel contesto,
altrimenti il §54b non può valutare e 16 carte divergono.

Tolta la parola "inverte" dall'output del motore (8 occorrenze) — ora stampa "NON SEGUE".

---

# §82. IL GIORNO LEGATO DAL MESE NON INTERVIENE  ·  `FISSATA` (Edu, 21/08/2026) — NEL MOTORE

Carte sorgente: **EURUSD 22/04/2025** (seme 115, giorno 辛酉, mese 辰: 辰酉合) e
**USDJPY 28/07/2022** (seme 136, giorno 壬午, mese 未: 午未合).

Se il ramo del GIORNO è legato in 六合 dal ramo del MESE, la sua capacità di combinare e
clashare è già impegnata: **il giorno non combina e non clasha nessuna linea dell'esagramma,
e non sospende la mobile** (né su partenza né su arrivo).

Implementata di default in `liuyao.js` (stati linee, 暗動, sospensione caso −1) e in
`pb_stress.js` (F3, 5 punti). Audit: `GIORNOLEGATO=off`.

**Effetto sul baseline: S17 da 57,48/z9,59/+32.039 a 57,55/z9,69/+32.512 (pesato +36.306);
LY tace da 652 a 636.** Coerente su entrambi i periodi (56,78/58,40).

# §83. IL TRASPORTO — VERSO E FILTRO  ·  `IN PROVA` (Edu, 21/08/2026) — watchlist

Continuazione del blocco TRASPORTO del 16/08. Verso dettato da Edu: "fa vincere il trigramma
opposto" = **vince il trigramma DOVE ATTERRA**. G/W → vince la destinazione; B/P → il
contrario; C senza verso (52/48). Ribaltamento: **il vincitore deve poter vincere** (da
USDCAD 11/06/2020: Shi vuota + G legato + C debole → il basso non può → vince l'alto).
Filtro di validità obbligatorio (`trasportoValido`): movimento compiuto, arrivo non vuoto,
伏 della mobile non sul ramo del giorno (M4), partenza non clashata da giorno+mese (F4),
atterraggio unico, destinazione non rotta/eliminata/autocombinata (da USDCAD 25/03/2020).
Numeri in CANDIDATI_OSSERVAZIONE.md. NON cablata: base 51,60%, celle migliori sotto z 4.

# §11 — RITIRATA DA EDU (21/08/2026)

Sulla carta USDCAD 18/03/2020: "La mia interpretazione era affrettata e sbagliata. P 寅 non
può essere fuori dai giochi perché il Legno è vibrante nel mese 卯. La vera interpretazione:
L4 muove, genera e si combina con C 未." Decade anche la QUESTIONE APERTA annotata sotto §11
(clash+controllo dal giorno): non c'era contraddizione da risolvere.

# §9 — REVISIONE TESTATA E RESPINTA (21/08/2026)

Ipotesi di Edu (自合 blocca solo se l'arrivo genera la partenza): misurata in tutte le forme
(`AUTOCOMB9=off|indietro|soloavanti`), ogni indebolimento costa (−1.405/−2.332/−2.493 pip su
S17). Resta la FORMA PIENA. Nota: sulla carta sorgente il sistema vince già (+266); per
riaprire serve un controesempio con seme (principio 10).

# §41 — RIMISURATA E RIDIMENSIONATA (21/08/2026)

Col campione attuale la copertura vuota copre L1-L5 (limite L3 caduto): forma generale
49,7-49,8% → **BOCCIATA**. Sopravvive solo: **nascosto G sotto copertura vuota FERMA**
(esclusa la mobile, 動不為空): 68 carte, 36,76% (rovescio 63,2%), coerente 34,9/38,1.
In watchlist (`FEISHENCHK`).

# §84. LA DESTINAZIONE GIÀ LEGATA NON RICEVE (doppia combinazione)  ·  `FISSATA NEL FILTRO` (Edu, 21/08/2026)

Carta sorgente: **EURJPY 19/12/2024** (seme 160, Zhen/Kun, L6). Il giorno 巳 lega già L5 申
(巳申合); l'arrivo della mobile è lo stesso 巳: la seconda combinazione sulla stessa linea
NON avviene ("double combination"). **Il trasporto fallisce e la mobile si legge per il suo
caso di mutazione, in sede**: qui 回頭生, W rinforzata a L6 in alto → LONG (mercato +306).
Nel filtro `trasportoValido`: destinazione rotta / eliminata / autocombinata / **legata** non
riceve. Risolve nella pratica anche la configurazione di §21 (争合): il legame esistente
vince, il nuovo arrivato fallisce.

**Effetto sul filone trasporto**: perimetro 719→611; base 51,60→52,70% (55,1/51,0);
ribaltamento ora INUTILE sui numeri (49,49% dove scatta — le carte che lo giustificavano
erano in gran parte destinazioni legate, ora fuori; definizione "non può vincere" indifesa);
**cella A=B GENERA C → vince la partenza: 45 carte, 75,56%, z 3,43** (94,7/64,0) — la più
vicina alla soglia, mancano ~25 carte. A=G CONTROLLA C: 18 carte, 72,22% (54,5/100 ⚠ n basso).

# §85. L'ELASTICO ROTTO × FORZA  ·  `IN PROVA — OPERATIVA IN LETTURA` (Edu, 21/08/2026)

Carta sorgente: **USDCAD 13/09/2022** (seme 129, Kun/Qian, L3).

**Meccanica**: una linea ferma tenuta in combinazione (dall'anno o dal mese) e clashata dal
giorno viene liberata di colpo, carica ("elastico rotto"). Il verdetto NON è la sede della
liberata: è il **confronto di energia fra i due trigrammi** (somma degli score forzaModello
di tutte le linee, per trigramma) — **vince il trigramma più forte** ("l'energia in gioco
qui è superiore a quanto avviene sotto").

**Numeri (21/08, flag `ELASTICOF=1`, affilatura `ELAFF=1`)**:
- vecchia ipotesi (vince il trig. della liberata): 268 carte, 50,75% — MORTA
- vince il più forte: 268, 54,85%, z 1,59 (56,2/53,6)
- energie nette |diff|≥3: 149, 57,72%, z 1,88 (56,6/60,3)
- **|diff|≥3 + liberata NEL trigramma più forte: 41 carte, 63,41%, z 1,72 (58,3/70,6)**
- tagli interni (tutti coerenti, tutti piccoli): liberata piena 33/66,7% · liberata sotto
  19/73,7% · legame MESE 20/65,0% · |diff|≥5 21/66,7%

**Stato operativo**: definita al millimetro e misurabile con un flag; VA APPLICATA in ogni
lettura di carta (checklist) da subito. NON entra nel motore live: per il criterio fissato
(z≥4 coerente sui due periodi) mancano ~100 carte di accumulo. Rimisurare a ogni
aggiornamento di full1h.json.

**Chiusura collegata — LA FORZA NUDA NON È UN VERDETTO** (stessa sessione, `FORZANUDA=1`):
il confronto di forza da solo, su tutte le carte: 51,10%; dove LY tace 53,27%; ma DENTRO IL
CONTRASTO (LY tace, forza dissente da PB): **48,04% su 306 carte** — quando disobbedisce al
sistema, perde. Nessuna soglia di differenza la salva. Conclusione: la forza pesa le braccia
ma serve la dottrina a dire quale braccio tira; usarla solo dentro configurazioni dottrinali
(come §85). NON rimisurare come verdetto autonomo.

---

# §87. LA TECNICA DEGLI STELI  ·  `FISSATA COME STRUMENTO DI LETTURA` (Edu, 21-22/08/2026)

**Collocazione (scala fissa)**: L1 porta SEMPRE lo stelo del giorno; poi la scala prosegue
verso l'alto dentro la propria polarità e ricomincia da capo:
- giorno YANG: 甲 丙 戊 己 庚 壬 (partendo dallo stelo del giorno)
- giorno YIN:  乙 丁 戊 己 辛 癸 (partendo dallo stelo del giorno)
Gli steli dei quattro pilastri della data (anno, mese, giorno, ora) cadono ciascuno sulla
propria linea di casa. Uno stelo di polarità opposta al giorno non ha casa.
Ora: 五鼠遁 dallo stelo del giorno. Pilastri via lunar-javascript (mezzogiorno).

**Censimento (4.507 carte)**: accumulo massimo 1 stelo 62,3% · 2 steli 33,8% · 3 steli 3,7%
(168 carte) · 4 steli 0,1% (4 carte: EURUSD+EURGBP 06/11/2024, GBPUSD 18/01/2022,
NZDUSD 23/09/2025). L'accumulo forte è un fenomeno di L1 (il giorno vi abita).

**Il condotto**: gli steli interagiscono FRA LORO per Cinque Elementi: un gruppo di 2+
steli dello stesso elemento GENERA lo stelo di un altro pilastro -> quel pilastro è CARICO.
Struttura verificata; lo sbocco cade sulla mobile con frequenza da caso (16,3%).

**Il principio d'uso (Edu)**: il peso segnala IMPORTANZA della linea, non direzione.
"C'è un accumulo su Lx, quindi quella linea è importante" — il significato emerge dalla
lettura, non da una formula. La riga degli steli è ora parte del formato di presentazione
delle carte.

**Misure direzionali chiuse (NON rimisurare — flag conservati)**:
- peso=vela (trigramma pesante vince): 49,1-49,6% · nel contrasto col sistema 41,0% (PESOTRIG)
- peso su linea inerte: 48,1% rumore perfetto (PESOINERTE). Peso senza azione = niente.
- peso come amplificatore dell'arrivo B/P: nessun gradiente (PESOAMP)
- condotto -> sbocco: direzione piatta 50,5% (PESOFLUSSO)
- steli->bestia della destinazione: ordinamento giusto ma debole (TRASPBESTIA)
- pilastro carico che clasha -> verso trigramma/trend/carattere/mobile-piena: TUTTI caduti
  sotto controllo (v. §88)
- "torna a casa" (trigono pieno data+mobile -> il capo accoglie): 48,0% vs controllo 49,9%;
  giorno-famiglia irrilevante; sospese 44,8% (TORNACASA). Resta tecnica di lettura di Edu.

# §88. IL PILASTRO CARICO CHE CLASHA  ·  `STRUTTURA FISSATA, DIREZIONE APERTA` (21-22/08/2026)

Carta sorgente: **USDJPY 10/01/2024** (seme 144, Dui/Kun, L2; tre 癸 su L1, 乙 del mese
carico dal condotto, 丑 clasha L1 未).

**FISSATO (regge ai controlli)**:
1. Un pilastro muto (mese / anno non timely / ora) da solo NON agisce sulle linee: né
   clash, né combinazione, né stesso ramo (tutte 48-51% su 700-1600 carte).
2. Il test discriminante RAMI vs PALAZZI (coppie palazzo-opposte senza clash: 寅未, 丑申,
   戌巳, 亥辰): comanda il RAMO. L'opposizione di palazzo senza clash è rumore (50,1%).
3. La combinazione del pilastro e lo stesso-ramo non muovono e non fanno vincere (49,5-51,1%).
4. Se qualcosa accade, accade SOLO con: clash di rami + pilastro CARICO dal condotto.

**APERTO (sei versi provati, tutti caduti sotto controllo)**: bersaglio perde · colpita
vince · trend vince (54,6% -> 50,0% tolto l'artefatto giorno=mese) · per carattere ·
mese-P · colpita-come-mobile per relazione elementale. La direzione si deciderà dalle
letture di Edu sui mazzi puliti (94 mese / 102 anno-muto).

**TRE ARTEFATTI documentati (lezione di metodo)**: (a) §41: campione confinato a L3;
(b) ramo del pilastro = ramo del GIORNO (il clash funziona di suo) — ora escluso in ogni
misura; (c) anno TIMELY (clasha di suo per §1) — idem. Regola: una cella non è pulita
finché non le togli le carte dove una meccanica già nota agisce da sola.

**Scala residua non spiegata**: bersaglio della linea clashata dal mese, per steli sulla
linea: 0: 53,9% vince · 1: 50,4 · 2: 48,6 · 3: 26,7 (=73,3% perde, 15 carte, periodi
allineati). Monotona, piccola in cima, in watchlist (MESECLASH).

# §89. FORZARE IL BLOCCO  ·  `FISSATA — IN USO OPERATIVO DI LETTURA` (Edu, 22/08/2026)

Carta sorgente: **USDJPY 10/01/2024**. I tre 癸 generano il 乙 (condotto); il 乙 carico è
DI CASA sulla L2 — che è la MOBILE SOSPESA dal giorno. La linea riceve potenza, FORZA il
blocco: il movimento negato SI COMPIE, l'arrivo raggiunge il suo bersaglio di combinazione
(qui 辰->酉 su L5), e **la squadra della linea raggiunta VINCE** (qui: LONG, mercato +133).

**Regola**: mobile sospesa dal giorno (caso −1) + uno stelo della data CARICO dal condotto
la cui casa è la posizione della mobile -> il blocco cede, il movimento si compie, vince
la squadra della linea raggiunta dall'arrivo.
Nota: il raffinamento "lo stelo genera il ramo della mobile" pare NON necessario (anche i
carichi che non generano: 66,7% su 15) — basta la carica in casa.

**Misura (22/08, flag FORZABLOCCO)**:
| cella | n | win% | periodi |
|---|---|---|---|
| stelo CARICO di casa sulla sospesa | **22** | **68,18%** | **66,7 / 62,5 (allineati)** |
| stelo di casa ma scarico (controllo) | 139 | 50,36% | — |
| nessuno stelo di casa (controllo) | 405 | 51,85% | — |

Controlli a rumore, periodi allineati, specificità completa: unico verso direzionale della
pista steli sopravvissuto a tutti i controlli. Per z≥4 servono ~120 carte: accumulo +
letture di Edu sulle 22. **STATO: fissata come regola di lettura (Edu: "gli steli
sopravvivono e adesso useremo questi"); NON nel motore live fino a soglia.**
Rimisurare a ogni aggiornamento di full1h.json.


# §90. LA MESSA IN MOTO DAL CLASH SULLA LINEA CARICA · `FISSATA IN LETTURA` (Edu, 22/08/2026)
Gerarchia: il clash su una linea che è CASA di uno stelo RADICATO (radice = almeno un ramo
della data del suo stesso elemento) non dà verdetto da ferma: LA METTE IN MOTO. Da lì si
legge come movimento: se avanza vince (EURUSD 12/03/2020: L1 avanza e combina L3); altrimenti
parla il Carattere (EURUSD 28/07/2020: L6 P in moto → perde la sede → SHORT ✓).
Per Edu vale per ogni fonte di clash, incluso il MESE (che normalmente non clasha ma muove la
linea carica). Misure 22/08 a soglia 25: fonte ARRIVO, P/B → 47 carte, 65,96%, z 2,19,
periodi 69,2/61,9 (flag CLASHSTELI, cella G1). Fonte MESE: 52,4% su 147, piatta — giro carte
in corso. Criterio di "avanzamento" da definire con Edu (quello tabellare di Claude: 44,6%).

# §92. IL FLUSSO DEL QI DELLA DATA — FORMA DEFINITIVA · `FISSATA` (Edu, 22/08/2026)
Otto caratteri, tutti partecipano, nessuna soglia. Punto terminale SEMPRE uno stelo della
polarità del giorno; il flusso avanza solo verso elementi con stelo utilizzabile; RADICE
obbligatoria per agire sulle linee; capolinea vuoto → ripiego sul precedente timely.
Anello chiuso: NON esiste (4 steli, 5 elementi). Carte d'origine: USDCHF 11/05/2022,
USDCHF 24/11/2021, GBPUSD 29/08/2023, EURUSD 12/03/2020. Dettaglio completo in
RIPARTENZA_22_08_2026_SERA.md.

# SOGLIA DI ENERGIA · `REGOLA DI SISTEMA` (Edu, 22/08/2026)
Carte sotto i 25 pip ELIMINATE a monte (pb_stress.js). Nuovo baseline S17: 2.788 carte,
58,07%, z 8,52, +29.503 (S17p +33.146). Audit SOGLIAPIP=0. Tutti i numeri precedenti di
questo registro sono sul campione 4.111 e NON confrontabili senza audit.

# §92. IL RIGETTO DEL G  ·  `CABLATA — VIA 35, IN CODA` (Edu, 22/08/2026)

Carta sorgente: **EURUSD 12/01/2026** (seme 643, Li/Zhen, L3).

**Meccanica.** La mobile **G** si muove e il suo ARRIVO combina (六合) una linea **C**.
La C **rigetta** il G venuto a darle la vittoria. Non è uno scontro di forza: è un rifiuto,
e il rifiuto costa a chi rifiuta. **Perde il trigramma DOVE STA LA RAGGIUNTA** — dentro il
proprio trigramma perde il proprio clan, se arriva all'altro perde l'altro.

**Conferma indiretta del meccanismo**: la forza della C NON conta (C debole 18 carte 72,22%,
C forte 14 carte 57,14%). Rigettare non richiede di essere forti, richiede solo di essere C.
Questo esclude la lettura "la C controlla e abbatte il G", che avrebbe richiesto una C forte.

**ECCEZIONE — alleanza di trigono.** Se G e C sono membri dello stesso **三合 completo**
(trigono; terzo membro anche 伏神, vuoti esclusi se non in movimento) non c'è rifiuto ma
accoglienza: la via non si applica. Carta: **USDCHF 23/03/2022** (seme 93 — 亥 L2 mobile,
未 L5 raggiunta, 卯 伏神 su L1: trigono 亥卯未 di Legno completo).

**Numeri (flag di misura `RAGGCTRL=1`)**
| cella | n | win% | z | recente/vecchio |
|---|---|---|---|---|
| forma larga: perde la sede della raggiunta | 32 | 65,63% | 1,77 | 60,87 / 75,00 |
| **STRETTA: dentro il proprio trigramma** | **14** | **78,57%** | **2,14** | **70,00 / 100,00** |
| arriva all'altro trigramma | 18 | 55,56% | 0,47 | 53,85 / 50,00 |
| senza alleati di trigono (forma larga) | 22 | 68,18% | 1,71 | 62,50 / 83,33 |

**Cablaggio.** Forma **STRETTA** come default. In coda cattura 2 carte nuove e le legge
entrambe giuste: baseline **INVARIATO** (S17 58,07% · z 8,52 · +29.503), LY tace 438 → 436.
La forma larga cattura 3 carte in più e le sbaglia: S17 58,03% · z 8,48 · 29.345 (−158 pip)
— **non si usa**. Audit: `VIA92=off` spegne · `VIA92LARGA=1` per la forma larga.

**Decisione metodologica di Edu (22/08/2026):** cablata per DOTTRINA nonostante n basso.
"Anche con altri sei anni di storici sarebbero comunque poche in relazione al tutto": la
rarità è strutturale del calendario, non un difetto della regola. La soglia z≥4 **non si
applica** a questo tipo di regola. Si toglie davanti a una carta che la smentisce nel suo
perimetro.

**FALSIFICATO nello stesso giro (non riaprire senza carta nuova):**
- "il G che si trasferisce fa vincere il trigramma dove arriva": 60 carte, 46,67%
  (38,89/59,09) — e il ribaltamento dà 53,33% (61,11/40,91). Periodi incoerenti in
  entrambi i versi: rumore. Flag `GARRIVA=1`.
- "dove la C non resiste (debole o alleata) il G si stabilisce e vince": 22 carte, **31,82%**
  — il verso della via sulle stesse carte fa 68,18%. Flag `RAGGCTRL=1`, celle Y1/Y2.
- "la raggiunta controlla la mobile → perde la sede della MOBILE" (verso su cui era partita
  la misura): 267 carte, 49,44%. È leggere il verso sulla linea sbagliata.

---
## §93 — L'ATTERRAGGIO ANNULLATO SULLA DESTINAZIONE ROTTA (23/08/2026, DEFINITIVA)

**Da EURJPY 11/08/2020 (seme 124), giro carte M1.**

**Dottrina (Edu):** la linea mobile viaggia e atterra combinando (六合) il proprio arrivo
con un ramo presente nell'esagramma. Ma se la linea di destinazione è **ROTTA dal giorno**
(clashata dal ramo del giorno, non timely nel mese, ferma, non vuota) **la combinazione non
si forma e l'atterraggio è annullato**: la mobile si ferma al proprio arrivo (capannello).

Nella carta: L4 (Shi, mobile W) parte da 戌 e arriva su G 酉; 酉 combinerebbe 辰 (L3),
ma 辰 è rotta dal clash del giorno 戌 → nessun atterraggio. Il G d'arrivo agisce nella
sede della mobile (trigramma superiore) → il superiore vince → LONG ✓ (+65 pip).

**Test di supporto (flag `ATTROTTA=1`):**
| cella | n | win% | z | recente/vecchio |
|---|---|---|---|---|
| destinazione sana: atterraggio azzecca | 489 | 51,53% | 0,68 | 46,40 / 55,61 |
| destinazione ROTTA: atterraggio azzecca | 38 | 44,74% | −0,65 | 50,00 / 33,33 |

Il verso conferma la dottrina (sotto il caso dove la destinazione è rotta); numeri deboli,
ma la regola è cablata **per dottrina** secondo la decisione metodologica del 22/08/2026.
Si toglie davanti a una carta che la smentisca nel suo perimetro.

**Cablaggio:** annullamento dell'atterraggio in `liuyao.js` (calcolo dell'atterraggio in
readManual) e nella copia LIUTAG di `pb_stress.js` — parità mantenuta. La destinazione non
conta come rotta se: è la mobile stessa (動不為空), è vuota (stato diverso), o è timely
(il clash la muove, non la rompe). Baseline S17 **INVARIATO** (2.788 · 58,07% · z 8,52 ·
+29.503): la regola agisce solo sulle letture, non sulla catena del verdetto.
Audit: `ATTROTTAOFF=1` ripristina il comportamento precedente.

**Nota di metodo (Edu, 23/08/2026, correzione al filtro delle carte):** il filtro "carta
già spiegata" non si fa solo sulle vie cablate: si fa sulla **lettura combinata** della
carta intera. Una regola non spiega tutto; è l'uso combinato di tutte le regole che porta
al successo.

---
### §93-bis — ECCEZIONE: LA DESTINAZIONE CARICA DAL CONDOTTO RESISTE (23/08/2026, DEFINITIVA)

**Da GBPUSD 15/01/2021 (seme 136), giro carte M1.**

**Dottrina (Edu):** la destinazione rotta dal giorno annulla l'atterraggio (§93), MA se la
linea di destinazione è **casa dell'attore del capolinea** (carica dal condotto del flusso
del Qi) **riceve il flusso e resiste al clash del giorno**: la combinazione si forma e
l'atterraggio VALE.

Nella carta: L3 (Shi, W 卯 mobile) arriva su 申; 申 combina il G 巳 in L2. L2 è clashata
dal giorno 亥 (sarebbe rotta), ma è casa dell'attore del capolinea (flusso Acqua → Legno,
attore 乙, casa L2): resiste. La combinazione si compie su L2 (inferiore) → SHORT ✓
(mercato −100; il sistema diceva LONG).

**Misura (flag `ATTROTTA2=1`, eseguita con `ATTROTTAOFF=1`):**
| cella | n | win% | z | recente/vecchio |
|---|---|---|---|---|
| dest. rotta CARICA (casa attore capolinea): atterraggio vale | 10 | 80,00% | 1,90 | 75,00 / 100,00 |
| dest. rotta SENZA carica: atterraggio fallisce | 28 | 67,86% | 1,89 | 66,67 / 71,43 |

Le due celle si separano nel verso della dottrina, periodi allineati in entrambe.
Cablata per dottrina (classe di regole del 22/08/2026).

**Cablaggio:** nuova funzione `setCasaAttore(pos)` in `liuyao.js` (il chiamante che conosce
la data completa calcola la casa dell'attore del capolinea e la comunica prima di
read/readManual; se null vale la §93 senza eccezione — stesso schema di `setSblocco` §89).
In `pb_stress.js`: helper `casaAttoreFrom(...)` (flusso definitivo 22/08), impostato al
sito di chiamata di `leggi` (loop principale e CARTA), campo `casaAttore` nelle rows, e
`LYM.setCasaAttore(r.casaAttore)` nei tre termometri `lyDir`. Baseline S17 **INVARIATO**
(2.788 · 58,07% · z 8,52 · +29.503 · pesato +33.146). Audit: `ATTROTTAOFF=1` spegne §93
ed eccezione insieme.

**Nota per la PWA:** `app.js` dovrà chiamare `setCasaAttore` col valore calcolato dalla
data completa prima della lettura; finché non lo fa, l'app applica la §93 senza eccezione.

---
## FLUSSO DEL QI — IL TERMINALE SENZA RADICE SCENDE DI UNO STEP (23/08/2026, DEFINITIVA)

**Da EURUSD 30/01/2025 (seme 104), giro carte M1.**

**Dottrina (Edu):** se lo stelo del capolinea (terminale del flusso) NON è radicato nella
data, si prende ANCHE lo step precedente della generazione: il suo stelo, se radicato,
è attore insieme al terminale. Le case cariche possono quindi essere due.

Nella carta: flusso → Metallo, terminale 辛 senza radice; step precedente Terra, 己
(giorno) molto forte, radicato → attore anche 己, casa L1 (la mobile). L1 così carica
VINCE il clash del mese 丑, si muove e raggiunge il W in L3 (卯), formando il trigono di
Legno 亥卯未 col giorno → inferiore → SHORT ✓ (+33).

**Cablaggio:** `casaAttoreFrom` in `pb_stress.js` ritorna una o due case (numero o array);
`setCasaAttore` in `liuyao.js` accetta entrambi; §93-bis verifica l'appartenenza; replica
allineata in `carta_check.js`. Baseline S17 **INVARIATO** (2.788 · 58,07% · z 8,52).
Carta guida §93-bis riverificata.

---

---
## §94 — L'ATTERRAGGIO DI CHI GENERA: LA SQUADRA DELLA CARICATA PERDE (24/08/2026, DEFINITIVA)

**Da USDJPY 10/03/2020 (seme 103, Zhen/Gen, palazzo 兌), persa dal sistema −215.**

**Dottrina (Edu):** nell'atterraggio "si DEVE vedere chi ci guadagna". Se il MOSSO (la
linea di partenza) GENERA la destinazione su cui atterra, si scarica caricandola e NON
si impone: **la squadra della linea caricata PERDE** — il verdetto è il ribaltato della
sede raggiunta (destinazione in basso → LONG, in alto → SHORT). È la stessa lettura
della carta guida: il 午 debole (doppio clash di giorno e anno, il nascosto 亥 che lo
controlla da sotto) arriva sulla Ying 辰 P, non può imporsi e finisce col generarla;
la P rafforzata fa perdere la propria squadra → LONG ✓.

**Misura sul perimetro degli atterraggi validi** (tutte le carte, regola "sede raggiunta
vince"): mosso CONTROLLA la destinazione 76 · 57,9% (si impone davvero); destinazione
controlla il mosso 128 · 56,3%; destinazione genera il mosso 160 · 51,3% (piatta);
**mosso GENERA la destinazione 113 · 44,3% (43,9 recente / 40,4 vecchio)** → letta al
ribaltato **55,8%**, coerente sui due periodi.

**Codifica:** default in `liuyao.js` (blocco atterraggio, campo `atterraggio.caricata`)
e in `pb_stress.js` (stesso blocco); la checklist `carta_check.js` mostra la dicitura
"il mosso GENERA la destinazione → la squadra della caricata perde (§94)".
Audit: `ATTGENOFF=1` ripristina il comportamento precedente.

**Nota:** l'atterraggio a oggi NON entra in nessuna via del termometro (è dato di
lettura e perimetro d'analisi): baseline S17 **INVARIATO** (2.788 · 58,07% · z 8,52 ·
+29.503 · pesato +33.146). La regola serve alla lettura delle carte e alla gerarchia;
quando l'atterraggio verrà promosso a via, entrerà già con la distinzione giusta.

## 25/08/2026 — MODELLO A 12 STADI (十二長生): IL FILTRO PIÙ IMPORTANTE (Edu)
Lo stadio dell'elemento di una linea (o di un arrivo) si calcola rispetto al ramo del MESE.
Stadi: 1 長生 Nascita · 2 沐浴 Bagno · 3 冠帶 Vestizione · 4 臨官 Ufficio · 5 帝旺 Apice ·
6 衰 Declino · 7 病 Malattia · 8 死 Morte · 9 墓 Tomba · 10 絕 Recisione · 11 胎 Embrione · 12 養 Nutrimento.
- Stadi 1–6 = TIMELY (i migliori: 1, 4, 5) · stadi 7–12 = UNTIMELY (i peggiori: 8, 9, 10).
- Leggi di sopravvivenza:
  1. Una linea untimely NON SOPRAVVIVE se clashata.
  2. Una linea timely è ANCORA PIÙ FORTE se clashata.
  3. Una linea untimely GENERATA (dal giorno o da un'altra linea) può ancora operare.
  4. Una linea timely DRENATA (dal giorno o da un'altra linea) può ancora operare.
- TERRA (regola di Edu, 25/08/2026, sostituisce il ciclo): timely nei quattro mesi dei rami di
  Terra (丑, 辰, 未, 戌); vibrante (相) anche in estate nei mesi 巳 e 午; untimely negli altri periodi.
- Prova sulle gemelle USDCHF: guida 13/11 arrivo 卯 nel mese 亥 = stadio 1 長生 (top) → il controllo
  indietro vince; sfidante 28/07 arrivo 卯 nel mese 未 = stadio 9 墓 (peggiore) → il controllo muore.
- Cablato in carta_check ([3-ter]): stadio per ogni linea + arrivo, con annotazione di sopravvivenza
  sulle clashate. Prossima carpenteria: cablare anche le leggi 3–4 (soccorso per generazione,
  tenuta al drenaggio) come valutazioni attive.

## 26/08/2026 — §50i CANCELLATA e §99 CABLATA: la lettura base della mobile G/W (Edu)

### §50i "trigramma inferiore interamente vuoto" — CANCELLATA
**Carta che l'ha falsificata: USDJPY 02/08/2022** (seme 131 · sup 8 坤 · inf 3 離 · mutante L5 ·
giorno 丁亥 · mese 丁未 · anno 壬寅 · vuoti 午未 · palazzo 坎 Acqua · Shi L4 · Ying L1).
Lettura di Edu: la mobile L5 è **B 亥** (Fratelli, Acqua) e mutando diventa **戌** (Terra), che nel
palazzo 坎 (Acqua) è **G** (Ufficiale): la B **diventa Ufficiale** e fa **vincere la propria squadra**
→ sede alta → **LONG**. Mercato LONG **+181**. §50i imponeva SHORT.

Perché la regola è caduta: §50i non guarda le linee del trigramma inferiore (qui 子寅辰, tutte piene)
ma i due rami-direzione Houtian del palazzo; scatta per una coincidenza di calendario (i vuoti che
cadono su quei rami) ed è **cieca alle bestie e al flusso degli steli**. Dopo l'introduzione di quei
due filtri la regola non serve più (giudizio dottrinale di Edu).
Misura: §50i decideva **149 carte al 54,4%** (+843 pip). Toglierla **da sola costa −434 pip**; le 38
carte che restano leggibili senza di lei fanno **60,5%**, cioè meglio del 54,4% cieco.
Default **SPENTA** in entrambi i file. Audit: `VIA50I=1` ripristina.

### §99 — LETTURA BASE DELLA MOBILE G/W (nuova via, ultima in priorità)
**Il buco:** "G e W fanno vincere la propria squadra" **non esisteva come via generale**. §64 (priorità
residuale) **cede il passo** a ogni G/W viva — ma sotto non c'era nessuna lettura, e una mobile G/W non
catturata da un perimetro speciale (§62, §68, §94, §98, M18…) **cadeva nel vuoto**: 294 carte mute.

**La via, due rami OPPOSTI distinti dal fatto che la linea AGISCA o no:**
- **(a) MOVIMENTO VERO** — la G/W è coinvolta nell'azione → fa vincere la propria squadra →
  **la sua sede** (alto LONG, basso SHORT).
- **(b) MOVIMENTO NULLO** — non è una linea ferma e non coinvolta: è un'azione **tentata e fallita** →
  *chi non vince perde* → **la sede cade** (opposto). Esclude i due casi già letti da §52
  (回頭剋 caso 3 e autocombinazione) per non duplicarne il perimetro.

**Misura di sostegno** (tutte le carte con mobile G/W, n 1.135): movimento vero **51,9%** sede ·
movimento nullo **43,3%** sede = **56,7% opposto, z 3,17**. Tutto il segnale negativo sta nel
movimento nullo, coerente con "chi non vince perde". *Nota metodologica: una misura precedente
(40,7%) era stata fatta sul solo residuo muto — campione selezionato — ed è stata RITIRATA.*

**Regressione (le due branche si sommano, nessuna traina l'altra):**
- solo (a): 58,93% · z 9,43 · +34.743
- solo (b): 58,93% · z 9,43 · +34.938
- **entrambe: 59,00% · z 9,51 · +35.424**

**BASELINE S17 NUOVO: 2.788 · 59,00% · z 9,51 · +35.424 pip** (pesato +39.064) ·
recente 58,72 · vecchio 58,93 — **+733 pip** sul canonico precedente, entrambi i periodi tengono.
Default **ACCESA** in entrambi i file. Audit: `VIAGW=off` la spegne; `VIAGW_RAMO=a|b` isola un ramo.
Co-guida: **USDCAD 08/03/2023** (vedi nota GIORNOLIBERA sotto).

### IL GIORNO LIBERA LA MOBILE — tecnica CONFERMATA da Edu (26/08/2026)
**Nome:** correzione di Edu — NON e' un "autoclash" (nome sbagliato, inventato da Claude e ritirato):
la linea non si clasha da sola, **e' il giorno che clasha l'arrivo**. Flag: `GIORNOLIBERA`.
**Carta: USDCAD 08/03/2023** (seme 137 · sup 1 · inf 1 · mutante L4 · giorno 乙丑 · vuoti 戌亥).
Lettura di Edu: la mobile **L4 G 午** (Ufficiale) **si muove ma non può trasformarsi in P 未**
(Genitori) perché **l'arrivo è clashato dal giorno 丑** (丑未 冲): il clash **rompe l'autocombinazione
午+未 e libera la mobile**. La G resta G, è coinvolta nell'azione → vince la sua sede → **LONG**.
Mercato LONG **+53**.
Implementato in `liuyao.js` come caso di mutazione **6** ("autocombinazione rotta dal clash del giorno
sull'arrivo: la mobile si muove non trasformata"). Perimetro: **36 carte**.
**Tensione da sciogliere:** con `GIORNOLIBERA` acceso la carta si legge correttamente via §99 → LONG, ma
la regressione **cala di 606 pip** (59,00 → 58,90 · z 9,51 → 9,39). Con `GIORNOLIBERA` spento la carta
ricade su §52 e resta **SHORT (sbagliata)**. Nessuna carta falsifica la lettura di Edu: è solo il conto
aggregato ad andare in direzione opposta. Default **SPENTO** in attesa della decisione. `GIORNOLIBERA=1` accende.

### DEBITO TECNICO EMERSO — due termometri separati
`pb_stress.js` **non usa le vie di `liuyao.js`**: ha una reimplementazione interna (`lyDir`) con la sua
copia di ogni via. Le due vanno tenute in parità A MANO — ed è da qui che è nato il buco di oggi
(la cancellazione di §50i nel solo `liuyao.js` non era visibile alla regressione).
Controllo di parità `CHKLY=1`: disallineamenti **49 prima di §99, 45 dopo** (§99 non li ha creati).
Dato di fondo: prima di §99 l'app taceva su **666** carte e il motore su **622** → **il motore ha ~44
letture che l'app non ha: il sito vivo legge meno del motore di ricerca.** Debito da sanare a parte.


## 26/08/2026 — COMBINAZIONE DIREZIONALE COL CAPO NEL MESE: PROPOSTA E ANNULLAMENTO (Edu)

**La regola proposta.** Quando si forma una combinazione DIREZIONALE 三會
(亥子丑 Acqua · 寅卯辰 Legno · 巳午未 Fuoco · 申酉戌 Metallo) e il CAPO — il ramo CENTRALE
(子 · 卯 · 午 · 酉) — è il ramo del MESE, le due laterali PERDONO LO STATUS che avevano e
assumono l'elemento del mese. Condizioni fissate da Edu nel corso della sessione:
- le due laterali devono stare **entrambe nello stesso trigramma** (entrambe L1–L3 o entrambe
  L4–L6, l'ordine non conta). Divise fra i due trigrammi: la combinazione NON si forma.
- il membro mancante può venire dai rami di data (giorno/mese/anno non vuoti), ma non è obbligatorio:
  vanno bene anche entrambe le laterali dentro l'esagramma.
- se la coppia compare in ENTRAMBI i trigrammi (najia ripetuta) la conversione è simmetrica:
  **parità — la squadra che prevale si trova in altro modo**, non da questa regola.
Perimetro implementato: 342 carte, 370 linee convertite (306 a trigramma singolo, 36 in parità).

**ANNULLATA lo stesso giorno. Carta che la falsifica: EURGBP 20/03/2026**
(seme **86** · sup **2** 兌 · inf **6** 坎 · mutante **L2** · anno 丙午 · mese 辛卯 · giorno 癸巳 ·
ora 癸丑 · vuoti 午未 · palazzo 兌 Metallo · Shi L1 · Ying L4).
Combinazione 寅卯辰 col capo 卯 = mese; laterali 寅 (L1) e 辰 (L2) **entrambe nel trigramma
inferiore** — condizione pienamente soddisfatta, nessuna parità. La regola convertirebbe L2 da
**P a W**: mobile W che vince la propria sede, bassa → **SHORT**. Il mercato **sale (+72)**.
Lettura di Edu: il LONG si spiega **solo** con L2 辰 che **resta P** e, generata indietro
dall'arrivo 巳 (回頭生, arrivo 相 vibrante nel mese 卯), **fa perdere la propria squadra** →
sede opposta → **LONG**. Imbuto completo: nessuna via, nessuna meccanica, nessun candidato la
spiega altrimenti. Regola rimossa secondo il criterio: *una regola si toglie quando una carta la
falsifica dentro il suo perimetro*.
Default **SPENTA**. Audit: `TRIGCAPO=1` la riaccende.

**Procedura di vaglio delle contrarie (fatta per intero).** 16 carte contrarie passate una a una
per `carta_check`: **12 spiegate da un altro attore** (§56, §65, §99, §53d ×2, §50h, §50g, §59 e
tre vie senza numero) → non falsificanti; **3 in parità** (USDJPY 04/01/2023, NZDUSD 22/12/2021,
GBPUSD 17/12/2021: la coppia 亥/丑 compare in entrambi i trigrammi) → escluse per dottrina;
**1 genuinamente nuda**, EURGBP 20/03/2026, che ha falsificato la regola.

**Misure raccolte prima dell'annullamento** (a titolo di archivio): testa a testa sulla mobile
convertita 19/35 (54,3% · z 0,51 · saldo pip −311); regressione S17 58,43% · z 8,90 · +33.288
(−2.136 pip); nessuna interferenza con la via R6 "raduno stagionale col mese" (spegnendola i
numeri restano identici).

**Errori di Claude in questa istruttoria (registrati per non ripeterli):** (1) implementato il
trigono 三合 (申子辰…) al posto della combinazione direzionale 三會, con un falso guadagno di
+220 pip; (2) richiesti due membri dentro l'esagramma quando ne basta uno; (3) condizione di
trigramma applicata a tutte le laterali insieme invece che dentro ciascun trigramma; (4) misure
aggregate presentate come obiezione alla dottrina senza la carta richiesta dal metodo.


## 26/08/2026 — GUARDIA DEL PESO DELLE BESTIE SU §99 (Edu) — il salto della giornata

**Carta guida: USDCAD 27/01/2026** (seme **137** · sup 1 · inf 1 · mutante **L4** · anno 乙巳 ·
mese 己丑 · giorno 辛丑 · ora 壬辰 · vuoti 辰巳 · palazzo 乾 Metallo · Shi L6 · Ying L3).
È la **gemella esatta** della guida di §99 (USDCAD 08/03/2023): stesso seme, stessi trigrammi,
stessa mobile G 午 su L4, stessa mutazione 午→未 liberata dal clash del giorno 丑 — ed esito opposto.

**Lettura di Edu:** *"Il peso delle bestie cade tutto su L6 che viene penalizzata. Short.
La mobile non c'entra niente."*
Verifica meccanica: tre dei quattro rami di calendario sono **Terra** (丑 丑 辰), quindi le due
bestie di Terra — **螣蛇 su L6** e **勾陳 su L5** — hanno **3 radici ciascuna**; tutte le altre
0 o 1. **L6 è lo Shi** (戌 Terra, P) e porta il 螣蛇 carico e **dello stesso elemento della linea**:
lo Shi è penalizzato → la sede alta cade → **SHORT**. Mercato SHORT −136.
La mobile ha la bestia 朱雀 con **una sola radice**: è la linea più scarica della carta.

**LA GUARDIA.** Se la mobile ha la bestia **scarica (0–1 radici)** e il peso (**≥2 radici**) sta
sullo **Shi** o sull'**Ying**, l'attore non è la mobile → **§99 TACE**.
Misura del gradiente (dove §99 decide, n 309, 52,1%):
- mobile col **peso massimo**: 56,1% · n 114 · **+1.479**
- mobile scarica e peso ≥2 altrove: 48,7% · n 187 · −901
- mobile scarica e peso su **Shi/Ying**: **42,2% · n 90 · −1.030**

**Regressione: 58,90% → 59,25% · z 9,39 → 9,77 · +34.818 → +36.276 (+1.458 pip)**,
recente 58,45 → 58,59 · vecchio 59,10 → 59,68 — **entrambi i periodi salgono**.
Verificata sulle due gemelle: zittisce §99 su USDCAD 27/01/2026, lascia intatta USDCAD 08/03/2023.
Cablata in **entrambi** i file. Audit: `G99BESTIE=off`.

**Conseguenza importante — "il giorno libera la mobile" non costa più nulla.** Con la guardia
attiva: accesa +36.276, spenta +36.217 (59,25% e z 9,77 in entrambi i casi). I 606 pip che
sembravano il costo della tecnica erano in realtà il costo di §99, che leggeva la mobile liberata
anche quando l'attore stava altrove. La posizione di Edu (tecnica giusta, non va cancellata) era
corretta e il dato aggregato che sembrava contraddirla era un artefatto di una via a valle.

**Come si è arrivati qui — il vaglio delle contrarie.** Le 22 carte contrarie del perimetro
"il giorno libera la mobile" passate una a una per `carta_check`: **11 spiegate da un altro attore**
(§68, §99, atterraggio, Shi, arrivo che clasha) e **11 nude**, di cui **6 nella stessa cella**
della carta guida (G su L4, 午→未, giorno 丑). La lettura della più cara di quelle sei ha prodotto
la guardia. È la conferma del metodo: l'aggregato non diceva nulla di utile, la carta sì.

---

## §103 — LA GEMELLA DELL'ARRIVO SALTA NELLA SEDE DELLA MOBILE (Edu, 27/08/2026)

**Carta guida: USDCAD 11/04/2022** (trend LONG, il sistema diceva SHORT, mercato LONG +54 → perdeva).
Passata per l'imbuto completo di `carta_check.js`: nessuna via cablata, nessuna meccanica,
nessun candidato la spiegava. L'unica che parlava era il raduno del Legno nel trigramma
inferiore (§67) e sbagliava.

**LA LETTURA (Edu).** Siamo nel caso in cui **il giorno libera la mobile** (caso 6: il giorno
clasha l'arrivo e rompe la combinazione fra partenza e arrivo). Qui il giorno 午 (Wu, Fuoco)
clasha 子 (Zi, Acqua), che è **sia l'arrivo della mobile L1 sia il ramo della linea ferma L5**.
La P su L1 — cioè l'arrivo — è resa inefficace; ma la **P di L5, clashata dallo stesso giorno,
salta nella sede della mobile e la sostituisce**. Il trigramma inferiore perde → **LONG**.

**LA CONDIZIONE CHE MANCAVA (misura, poi approvata da Edu).** La lettura secca faceva 5 su 7
nel suo perimetro. Le due falsificatrici — NZDUSD 09/10/2024 (−69) e USDCAD 17/01/2022 (−27) —
si separano da sole: sono le uniche in cui la mobile 丑 (Chou, Terra) ha **due radici del proprio
elemento fra anno e mese** (anno 辰 + mese 戌; anno 丑 + mese 丑). Nelle altre cinque ne ha una o
nessuna. Dottrina: **se la mobile è radicata nel calendario regge la sostituzione e si tiene la
propria sede; se non lo è, la linea che salta la rimpiazza davvero e il suo trigramma perde**.
Il **giorno non si conta**: in questo perimetro è per costruzione sempre il clash dell'arrivo,
quindi costante e senza potere di distinguere (e per giunta genera la Terra in tutte e sette).

**IL PERIMETRO.** Caso 6 + esiste una linea **ferma** che porta lo **stesso ramo dell'arrivo**.
Sono **7 carte** e sono tutte lo stesso esagramma (superiore 7, inferiore 5, mutante L1,
mobile 丑 → 子, P 子 ferma su L5): un perimetro strutturalmente raro, non una scelta di taglio.
Con la condizione del radicamento: **7 su 7, +378 pip**.

**REGRESSIONE: 59,36% → 59,47% · z 9,89 → 10,00 · +36.758 → +37.133 (+375 pip)**
recente 58,72 → 58,79 · vecchio 59,77 → 59,93 — **entrambi i periodi salgono**.
Tre carte raddrizzate (USDCAD 23/03/2021, USDCAD 11/04/2022, NZDUSD 09/10/2024), **nessuna
rovinata**. La quarta del perimetro che perdeva (USDCAD 17/01/2022) non cambia verdetto perché
lì il verdetto finale S9 lo decide il Plum Blossom, non il Liu Yao.

Cablata in **entrambi** i file (`pb_stress.js` in coda alle altre due letture del caso 6,
`liuyao.js` come via `R43_103` subito dopo §102). Verificata la parità: la via di produzione
scatta sulle stesse 7 carte e dà gli stessi 7 verdetti del motore di ricerca. Audit: `GIORNOSALTO=off`.

**Avvertenza onesta, agli atti.** La soglia delle due radici è stata tarata su sette carte:
statisticamente non vale nulla da sola (z 2,65 anche a 7 su 7). Sta in piedi perché Edu l'ha
riconosciuta come dottrinalmente giusta, non perché la misura la sostenga. Va rimossa se una
carta la falsifica dentro il suo perimetro.

---

## §104 — MOBILE UNTIMELY SENZA LA GENERAZIONE ALL'INDIETRO: DECIDE IL DUELLO SHI/YING (Edu, 27/08/2026)

**Carta guida: EURUSD 22/08/2023** (trend SHORT, il sistema diceva LONG, mercato SHORT −52 → perdeva).
Passata per l'imbuto completo: nessuna via, nessuna meccanica, nessun candidato la spiegava.
Le due che parlavano — il clash dell'arrivo letto dallo Yong Shen (§68) e la mobile G/W che vince
la propria sede (§99) — dicevano LONG tutte e due e sbagliavano.

**LA LETTURA (Edu).** Caso in cui **il giorno libera la mobile** (caso 6). La mobile L4 未 (Wei,
Terra) è **molto untimely** — Terra fuori dai suoi mesi, nel mese 申 (Shen, Metallo) — e l'unica
cosa che potrebbe reggerla è la **generazione all'indietro dall'arrivo** 午 (Wu, Fuoco → Terra,
回頭生 hui tou sheng). Ma è proprio quella che il clash del giorno 子 (Zi) spegne: la mobile parte
e non conclude. **Chi non vince, perde** → la mobile esce dalla decisione.

**A DECIDERE RESTA IL DUELLO SHI/YING.** Lo Shi è L3 辰 (Chen, Terra), la Ying è L6 卯 (Mao,
Legno): è la **Ying che controlla lo Shi**, non il contrario. Ma qui **la Ying è in vuoto**, e
**il vuoto non agisce**: l'attacco non parte, lo Shi resta in piedi e vince. Sede dello Shi, che
sta in basso → **SHORT**.

**IL PERIMETRO.** Caso 6 + mobile untimely + la mutazione è 回頭生 (l'arrivo genera la partenza)
+ la Ying controlla lo Shi. Sono **3 carte**, tutte lo stesso esagramma (superiore 5, inferiore 4,
mutante L4, 未 ← 午): **3 su 3, +196 pip**, una nel vecchio e due nel recente. Le due sorelle
(EURUSD 27/02/2020 e 01/03/2024) hanno la Ying **piena** — mese 寅 (Yin, Legno) — quindi il Legno
controlla davvero la Terra dello Shi, vince la Ying, sede alta → LONG, e LONG sono andate davvero.

**REGRESSIONE: 59,47% → 59,51% · z 10,00 → 10,04 · +37.133 → +37.237 (+104 pip)**
recente 58,79 → 58,86 · vecchio 59,93 invariato. Una carta raddrizzata, **nessuna rovinata**.

**Vicolo cieco misurato, agli atti.** Prima di arrivare al vuoto avevo proposto come discriminante
la **difesa col proprio 伏神** (fu shen, spirito nascosto): lo Shi 辰 genera il nascosto 酉 (You,
Metallo), timely nel mese 申, che controlla l'attaccante 卯. Sulle tre carte separa allo stesso
modo, ma **è la spiegazione sbagliata**: Edu ha indicato il vuoto della Ying. E infatti la difesa
col nascosto, misurata da sola su tutto lo storico dove ricorre (**81 carte, 53,1%, z 0,56**), è
rumore puro: non è un attore autonomo.

**Allargamento provato e scartato.** Togliendo il vincolo della 回頭生 e tenendo solo "caso 6 +
mobile untimely + duello", il perimetro sale a 11 carte ma crolla a **6/11 (54,5%)**, e per giunta
va a sbattere contro tre carte già lette bene da §103. Il confine giusto è quello stretto, ed è
esattamente quello dottrinale: conta che il giorno spenga **proprio** il sostegno di cui la mobile
untimely avrebbe bisogno.

Cablata in **entrambi** i file (`pb_stress.js` dopo §103, `liuyao.js` come via `R44_104`).
Parità verificata: stesse 3 carte, stessi 3 verdetti. Audit: `GIORNODUELLO=off`.

---

## §105 — MOBILE TIMELY AL CAPOLINEA DEL FLUSSO: IL QI ARRIVA SULLA P (Edu, 27/08/2026)

**Carta guida: USDCAD 20/03/2023** (trend LONG, il sistema diceva LONG, mercato SHORT −47 → perdeva).
Il Liu Yao taceva: decideva il Plum Blossom da solo.

**LA LETTURA (Edu).** Caso in cui il giorno clasha l'arrivo. La mobile L4 午 (Wu, Fuoco) è **G**
ed è **molto timely**: è Fuoco generato da molto Legno nella data (anno 卯, mese 卯, tronco del
mese 乙, tronco dell'ora 甲) ed è il **punto terminale del flusso** degli steli. Perciò la linea
si muove per **generare in avanti** la P 未 (Wei, Terra); il fatto che l'arrivo riceva il clash
del giorno **non conta**, perché una G carica spinge con forza. Il Qi arriva quindi sulla P, e
**la P fa perdere la propria squadra** → sede opposta alla mobile, che sta in alto → **SHORT**.

**IL CAPOLINEA È CIÒ CHE SEPARA LE DUE GEMELLE.** USDCAD 08/03/2023 ha lo stesso esagramma, lo
stesso ramo di giorno 丑 e la stessa mobile, ma cambia il **tronco del giorno** (乙 invece di 丁)
e con esso il flusso: lì il capolinea è il **Legno**, la mobile non è caricata, resta libera e
fa vincere la propria squadra → LONG (lettura di Edu del 26/08, mercato LONG +53). Qui il
capolinea è il **Fuoco**, cioè la mobile stessa. Cambiano anche i vuoti (戌亥 contro 申酉), ma è
il capolinea l'attore.

**IL PERIMETRO.** Caso 6 + mobile G/W + timely + genera in avanti l'arrivo + l'arrivo è una P +
la mobile è il capolinea del flusso: **1 carta**. Senza il vincolo del capolinea il perimetro sale
a 3 carte ma scende a **2/3**, e la carta che sbaglia è **proprio la gemella**: è la prova che il
capolinea non è un ritaglio ma l'attore. La terza sorella, EURJPY 29/06/2022, non ha capolinea
(nessuno stelo utilizzabile) e resta fuori: è già letta bene dal Plum Blossom.

**REGRESSIONE: 59,51% → 59,54% · z 10,04 → 10,08 · +37.237 → +37.330 (+93 pip)**
recente 58,86 invariato · vecchio 59,93 invariato. Una carta raddrizzata, **nessuna rovinata**,
e la gemella non viene toccata.

**Avvertenza onesta, agli atti.** Il perimetro è di **una sola carta**: la regola sta in piedi
sulla dottrina e sul fatto che spiega la divergenza di una coppia di gemelle, non sulla misura.
Va rimossa se una carta la falsifica dentro il suo perimetro.

**Nota di implementazione.** Il capolinea non era disponibile nel motore di produzione: nel
motore di ricerca è stata aggiunta `capolineaElFrom()` (stessa camminata di `casaAttoreFrom`,
ma restituisce l'elemento invece della casa), e nell'app `capolineaDelFlusso()`, che lo calcola
dai quattro pilastri della carta e lo passa al termometro come `capolineaEl`. Parità verificata:
stessa carta, stesso verdetto. Audit: `GIORNOCAPOLINEA=off`.

**Ipotesi mia scartata, agli atti.** Avevo proposto che a distinguere le gemelle fosse il
**三合 completo di Fuoco 寅午戌** (san he, trigono pieno), che il 20/03 si chiude dentro
l'esagramma e inghiotte la mobile (capannello: raduno completo, il Qi si ferma), mentre l'08/03
salta perché 戌 è in vuoto. Separa le due carte allo stesso modo, ma Edu ha indicato il flusso:
la mobile non è imprigionata, è **caricata** e spinge.

---

## §106 — MOBILE SENZA FORZA E SHI IN VUOTO: VINCE LA YING (Edu, 27/08/2026)

**Carta guida: AUDUSD 14/09/2021** (trend LONG, il Plum Blossom e il Liu Yao dicevano LONG,
mercato SHORT −45). Terza sorella della coppia USDCAD 08/03 e 20/03/2023: stesso esagramma,
stessa mobile L4 午 (Wu, Fuoco) G che va su 未 (Wei, Terra) P, stesso ramo di giorno 丑.

**LA LETTURA (Edu).** L4 è allo **stadio 8 (死, si, morte)** nel mese 酉 (You, Metallo): la linea
**non ha forza e non riesce a fare niente**, quindi esce dalla decisione. Tutto il flusso finisce
sul **Metallo di L5** (申, Shen — timely all'apice 帝旺, e casa del tronco del Tai Sui), che va a
**generare L1** 子 (Zi, Acqua): il Qi si scarica in basso. In aggiunta, **fra Ying e Shi vince la
Ying, perché lo Shi è in vuoto** (戌 dentro i vuoti 戌亥) e il vuoto non agisce. La Ying sta su
L3, in basso → **SHORT**. Le due strade convergono sul trigramma inferiore.

**COSA È STATO CABLATO.** Solo il duello, che è formalizzabile: caso 6 + mobile untimely +
**Shi in vuoto e Ying no** → sede della Ying. La lettura del flusso che finisce sul Metallo di L5
e genera L1 non è ancora rappresentata nel motore (il flusso oggi è calcolato sugli steli, non
sulle linee) ed è **coerente ma non cablata**.

**IL PERIMETRO.** 3 carte, **3/3, +204 pip** (2 nel vecchio, 1 nel recente).
Due controlli che delimitano il confine:
- **senza il vincolo della mobile senza forza** il perimetro sale a 4 carte e scende a 3/4, e la
  carta che sbaglia è **proprio la gemella USDCAD 08/03/2023**, dove la mobile è timely e agisce:
  è la conferma che è la mancanza di forza a far passare la decisione al duello;
- **il duello da solo**, su tutto lo storico (Shi vuoto e Ying piena, 403 carte), fa **50,1%**:
  rumore assoluto. Non è un attore autonomo, funziona solo quando la mobile è gia' fuori gioco.

**IL RAMO SPECULARE NON VALE.** "Ying vuota → vince lo Shi", dentro lo stesso caso 6 con mobile
senza forza, fa **3 su 7**. Va lasciato a §104, che lo restringe alla sola 回頭生 spenta dal
giorno. La forma unificata dei due rami (uno solo dei due in vuoto → vince l'altro) fa **6/10**:
**da non fare**. I due rami non sono la stessa regola.

**REGRESSIONE: 59,54% → 59,58% · z 10,08 → 10,11 · +37.330 → +37.421 (+91 pip)**
recente 58,86 → 58,93 · vecchio 59,93 invariato. Una carta raddrizzata (USDCAD 22/12/2025, del
periodo recente), **nessuna rovinata**.

**Nota.** Sulla carta guida il verdetto finale S9 era già SHORT — perdeva il Plum Blossom da solo,
non il sistema. La via non cambia quel verdetto ma toglie il disaccordo fra i due motori.

Cablata in **entrambi** i file (`pb_stress.js` dopo §105, `liuyao.js` come via `R46_106`).
Parità verificata: stesse 3 carte, stessi 3 verdetti. Audit: `GIORNOSHIVUOTO=off`.

---

## DOTTRINA · I TRE MECCANISMI DI CARICA DI UNA LINEA (Edu, 27/08/2026)

Chiarimento dato leggendo GBPUSD 12/01/2022 e USDCAD 17/10/2024. **Sono tre meccanismi
distinti**, finora usati nel codice senza distinguerli.

**1. Coincidenza di ramo.** Il ramo del **giorno** — ma anche del **mese**, dell'**anno** o
dell'**ora** — coincide col ramo di una linea dell'esagramma. Attiva quella linea **in modo forte**.

**2. La bestia attivata dal flusso.** Il punto terminale del flusso degli steli — steli radicati
nei rami, rispettando la **polarità del giorno** — individua una bestia nell'esagramma. Attiva
quella linea **in modo forte**. Vale in **due forme, entrambe importanti**:
   - **2a · casa dell'attore**: la posizione che il tronco terminale occupa nella scala delle sei
     bestie a partire dal tronco del giorno (è ciò che il codice chiama `casaAttoreFrom`);
   - **2b · bestia per elemento**: la bestia il cui **elemento** coincide con l'elemento del
     capolinea del flusso (青龍 Legno · 朱雀 Fuoco · 勾陳 Terra · 螣蛇 Terra · 白虎 Metallo ·
     玄武 Acqua).

**3. Capolinea generico del Bazi.** Il punto terminale del flusso **senza** che serva la 1 o la 2.
Può dare energia a **qualsiasi linea in grado di riceverla**. È il meccanismo più debole dei tre.

**Gerarchia (Edu): tutti e tre sono efficaci, ma 1 e 2 lo sono di più. E 1 e 2 quasi sempre
lavorano IN CONGIUNZIONE** — la carica forte è quella che le vede insieme sulla stessa linea.

**CONDIZIONE FONDAMENTALE, che vale su tutti e tre.** Devono **intervenire dove succedono le
cose**. Se potenziano una linea che non fa nulla, **non servono**. Una carica su una linea inerte
non è un attore.

**Le due carte che l'hanno fissato.**
- *GBPUSD 12/01/2022* (mercato LONG +67): il Metallo è capolinea del flusso e la sua casa è **L5,
  la mobile stessa**. La carica aiuta L5 a muoversi nonostante la sospensione del giorno, e il suo
  arrivo 未 (Wei) **combina con la G di L4** — che è anche la sede di una bestia radicata nei rami.
  Il Qi atterra in alto → LONG.
- *USDCAD 17/10/2024* (mercato LONG +38): qui **non c'è capolinea affatto** (nessuno stelo
  utilizzabile), quindi la mobile L5 非 riceve niente. La congiunzione 1+2 cade invece su **L3**:
  il ramo 辰 (Chen) coincide con L3 e arriva **due volte** (anno e ora), e la bestia di L3, 勾陳,
  è la più radicata della carta. **E su L3 sta succedendo qualcosa**: il mese 戌 (Xu) la clasha.
  L3 è una P, e la P fa perdere il proprio clan → la sede bassa cade → LONG.

**Conseguenza operativa.** La lettura della B timely sospesa (sotto) **non va corretta, va
subordinata**: quando la congiunzione 1+2 carica un'altra linea su cui sta accadendo qualcosa,
comanda quella, non la mobile.

### IN OSSERVAZIONE · B timely sospesa: carica o sola (Edu, 27/08/2026)

Da USDJPY 28/02/2020 e GBPUSD 12/01/2022. Caso −1 (il giorno sospende la mobile) + la mutazione
sarebbe una generazione all'indietro, quindi bloccata + la mobile è una **B timely**:
- se la mobile sta sulla **casa carica** dal flusso, si muove e **atterra** dove il suo arrivo
  combina → sede della linea di atterraggio;
- altrimenti **resta sola** e fa perdere la propria squadra → sede opposta alla mobile.

Misura: **15 carte · 10 giuste (66,7%) · z 1,29 · +318 pip** (vecchio 63% su 8, recente 71% su 7).
Il ramo singolo "sola" da solo faceva 9/15 e +184 pip: i due rami insieme valgono più della somma.
Delle 5 contro, **4 hanno già il loro attore** (§50d/e su EURJPY 19/04/2022; §94 su USDJPY
30/03/2021 e EURUSD 28/02/2020; una meccanica in osservazione su EURUSD 15/02/2024) e la quinta,
USDCAD 17/10/2024, è spiegata dalla congiunzione 1+2 qui sopra. Perimetro effettivo **11 carte,
10 giuste**. **Non ancora cablata**: manca la formalizzazione di "dove succedono le cose".

### DOTTRINA · "DOVE SUCCEDONO LE COSE" — le linee attive (Edu, 27/08/2026)

Definizione data da Edu per rendere applicabile la condizione fondamentale dei tre meccanismi di
carica. Una carica conta solo se cade su una **linea attiva**. Le linee attive sono:

1. **La linea mobile**, con tutto il suo movimento: la **partenza**, l'**arrivo**, e la
   **combinazione o il clash** che l'arrivo (o la partenza) produce su un'altra linea — anche
   quell'altra linea è attiva;
2. **la linea clashata**;
3. **la linea combinata**;
4. **lo Shi e la Ying**.

Queste linee possono essere **timely o untimely**, e possono **ricevere bestie, steli o flusso**:
la carica si somma allo stato, non lo sostituisce. Una linea fuori da questo elenco, per quanto
caricata, **non è un attore**.

---

## 27/08/2026 — SESSIONE 24 · Il doppio legame del giorno e il padrone della linea inerte

### Carta guida 1 · EURGBP 19/11/2025 (seme 88, mercato LONG +25)

Mobile L4 酉 (You, Metallo), B (Fratelli), timely, Shi. Il giorno 辰 (Chen, Terra) **combina la
partenza 酉 e clasha l'arrivo 戌** (Xu, Terra): la mobile non può né partire né arrivare.

**Lettura di Edu:** la linea è inutile per valutare chi vince. Si passa al duello Shi/Ying:
la Ying L1 未 (Wei, Terra) è **in vuoto** e il vuoto non agisce → **vince lo Shi**, in alto →
LONG ✓.

### Carta guida 2 · NZDUSD 22/06/2023 (seme 62, mercato SHORT −27) — IL CASO SPECIALE

Mobile L1 寅 (Yin, Legno), P (Genitori), **in vuoto** (vuoti 寅卯) e chiusa ai due capi dal giorno
亥 (Hai, Acqua): combina la partenza 寅, clasha l'arrivo 巳 (Si, Fuoco). La Ying è la mobile stessa.

**Lettura di Edu (testuale nella sostanza):** un caso speciale — **niente si muove**. L1 è vuoto ed
è bloccato, per cui rimane vuoto: **non parte neanche; l'arrivo non esiste se non c'è partenza**.
A questo punto si vede il Qi degli steli/bestie: il **Metallo è il terminale del flusso — non il
Gui (癸), per via della combinazione fra gli steli 戊 e 癸**. La bestia su L1 è la **Tigre Bianca
白虎, Metallo**: è lì che termina il flusso. Ma poiché la linea non si muove, **辛亥 (il giorno)
diventa padrone di L1**. Duello Ying vs Shi: **vince la Ying perché è Metallo → Acqua, mentre lo
Shi è Terra → Metallo** → SHORT ✓.

### Principi fissati (Edu, 27/08/2026)

1. **Doppio legame del giorno**: quando il giorno combina la partenza e clasha l'arrivo (o lo
   speculare), la mobile non può né partire né arrivare: esce dalla decisione. Si passa al duello
   Shi/Ying, dove il vuoto non agisce.
2. **Mobile vuota e chiusa ai due capi**: resta vuota, non parte nemmeno. **L'arrivo non esiste
   se non c'è partenza.** Linea inerte.
3. **Combinazione degli steli nel flusso** (甲己 · 乙庚 · 丙辛 · 丁壬 · 戊癸): lo stelo legato in
   combinazione non può essere il capolinea del flusso.
4. **Il padrone della linea inerte**: se il flusso (così corretto) termina sull'elemento della
   bestia della linea inerte, vi si ferma, e il pilastro del giorno diventa padrone della linea.
5. **Duello per generazione** (generalizzazione confermata da Edu): fra i due contendenti — col
   padrone al posto della linea inerte quando questa è Shi o Ying — **chi genera cede il Qi, chi
   riceve vince**; verdetto = sede del ricevente.

Misure e perimetri completi in `CANDIDATI_OSSERVAZIONE.md` (sezioni DUELLO-24). Il duello normale
fa 13/13 (+874 pip); il caso speciale 4/4 (+256 pip), rarissimo, e spiega **USDJPY 29/11/2024
(+141)**, la carta più cara del bacino caso −1 ancora da leggere. La gemella NZDUSD 19/12/2023
resta al duello normale (combinazione 甲己, capolinea altrove): il discriminante del mese era la
combinazione degli steli.

### Cablatura (27/08/2026, decisione di Edu)

§107 (duello del doppio legame: la Ying vuota non agisce → vince lo Shi) e §108 (padrone della
linea inerte, duello per generazione) **cablate in entrambi i motori**, in testa al termometro —
§108 prima di §107 perché più specifica; entrambe prima di §101–§106 e di tutte le vie generiche
(nel perimetro il §50d/e sbagliava la carta guida). Audit: `DUELLO24=off` · `SPECIALE24=off`.
Parità verificata carta per carta su tutte le 17 del perimetro. Nuovo baseline canonico:
**2.788 carte · 59,90% · z 10,45 · +38.918 pip** (recente 59,34 · vecchio 60,10 · 45 vie).

### CORREZIONE TECNICA GRAVE (27/08/2026, sessione 24): steli di anno/mese dal pilastro di mezzogiorno

Scoperta da una domanda di Edu su EURUSD 05/03/2020 (giorno del Jingzhe, 02:56 GMT). In più punti
gli steli di anno e mese venivano presi dal pilastro delle 12:00: nei giorni a cavallo di un
termine solare appartengono al mese (o, al Lichun, all'anno) sbagliato rispetto alle 00:00 GMT.
Impatto: 28 carte su 10 giorni di confine (4 anche sullo stelo d'anno). Il filone principale del
motore di ricerca era già corretto (五虎遁 dal ramo del motore): il baseline non è mai stato toccato.

**REGOLA PERMANENTE: gli steli di anno e mese NON si prendono MAI dal pilastro di un'ora
convenzionale. Si derivano SEMPRE dai rami del motore (00:00 GMT): anno dall'anno civile + ramo
d'anno; mese con la regola delle cinque tigri (五虎遁) dallo stelo d'anno; ora con le cinque
sorci (五鼠遁) dallo stelo del giorno.** Il pilastro di mezzogiorno resta legittimo SOLO per
disambiguare il pilastro del GIORNO (solar-time.js) e per leggere la tabella dei termini solari
(daliuren.js).

Ripuliti: pb_stress.js (23 blocchi di misura → helper unico `pilastriDerivati`), carta_check.js,
caso_speciale.js, perim_btim.js. Scoperto e chiuso anche un buco peggiore in app.js: il sito NON
passava affatto steli di anno/mese/ora al termometro (§108 vi sarebbe rimasta muta) → aggiunto
`steliDiData` in entrambi i punti. Verifiche: baseline identico (59,90% · +38.918), §108 stesse
5 carte, §107/§108 sparano uguali nei due motori sulle carte di sessione.

### Principio fissato (Edu, 27/08/2026): il mese delle carte a cavallo di un termine solare

**Comanda il mese vivo alle 00:00 GMT dell'ingresso**, anche se il termine solare scatta poche
ore dopo, dentro il trade. (Su EURUSD 05/03/2020: mese 寅, benché il Jingzhe arrivi alle 02:56
GMT.) La convenzione del motore è confermata.

### Lettura di Edu · EURUSD 05/03/2020 (seme 111, mercato LONG +102)

Il mese, **caricato su L2** (lo stelo di mese 戊 ha la sua casa proprio su L2, ed è il capolinea
del flusso), **fa muovere la mobile sospesa**: la linea si muove e il suo arrivo 亥 (Hai, Acqua)
**clasha L5 巳** (Si, Fuoco), liberando la **nascosta W 子** (Zi, Acqua) che sta sotto.
L'Acqua è debole nel mese e di norma non potrebbe farlo, **ma la bestia su L5 — il 玄武
(Xuan Wu, Acqua) — ha la sua radice proprio nel 子 della data** (il ramo d'anno): per questo
può. La W liberata parla → **LONG** ✓.

Tre insegnamenti:
1. Lo stelo di mese (qui anche capolinea) con casa sulla mobile sospesa **la libera**: la carica
   sulla linea vince sulla sospensione del giorno. ("Qualcosa succede" → il duello non si apre.)
2. L'arrivo della mobile liberata **agisce**: qui clasha la linea sopra la nascosta e la fa uscire.
3. Un attore debole di stagione **può agire se la bestia della linea ha radice nel ramo di data
   del suo stesso elemento** (qui 玄武/壬 Acqua radicata nel 子 dell'anno).

### §109 CABLATA (27/08/2026, sera) — Linea incompatibile col trigramma, ULTIMA ISTANZA

**Edu certifica la direzione della B: la B incompatibile carica fa PERDERE la propria squadra.**
Cablata §109 in entrambi i motori, in ULTIMA ISTANZA — parla solo quando tutte le altre vie
tacciono, prima di ricorrere al duello Shi/Ying (indicazione esplicita di Edu; in testa avrebbe
reso +71 pip col recente in calo, in ultima istanza rende +275 senza costi). Perimetro: cinque
coppie (丑∈坤 卯∈兌 辰∈乾 午∈坎 申∈艮), movimento nullo, linea non vuota unica che si prende
bestia e steli; G/P/W vince · B perde · C tace. Nota d'ordine: 6 carte stanno anche nel doppio
legame del duello (cinque B): oggi lì parla prima il duello (§107/108 in testa); sotto-ordine da
rifinire con misura dedicata se serve. Nuovo baseline canonico:
**2.788 carte · 59,94% · z 10,49 · +39.193 pip** (recente 59,34 · vecchio 60,18 · **46 vie**).
Audit: `INCOMP24=off` → 59,90.

---

# DOTTRINA DELLE PENALITÀ (刑) — `FISSATA` · 29/08/2026 · REGISTRAZIONE DEFINITIVA

Edu ha dovuto ripetere questa dottrina più volte perché era rimasta soltanto dentro
il codice come condizione, mai scritta qui come **relazione**. Questa voce la chiude.

## Enunciato di Edu (testuale, 29/08/2026)
> "La penalità fa quella che la parola dice: **penalizza chi la riceve**."

Non è una regola del giorno né una regola della mobile: è una **relazione fra due rami**.
Va sempre cercata fra TUTTE le coppie presenti, non solo quelle a cui si sta pensando.

## Tavola completa (unica, da usare ovunque)
- **Autopenalità (自刑)**: 辰辰 · 午午 · 酉酉 · 亥亥
- **Triangolo 寅巳申**: 寅→巳 · 巳→申 · 申→寅
- **Triangolo 丑戌未**: 丑→戌 · 戌→未 · 未→丑
- **子卯** (penalità senza cortesia): 子→卯 · 卯→子

## Chi può mandarla, chi può riceverla
Vanno controllate tutte queste coppie, non una sola:
1. **ramo di data → partenza della mobile** — la partenza è colpita;
2. **ramo di data → arrivo della mobile** — l'arrivo è colpito;
3. **ramo di data → linea ferma** — quella linea è colpita;
4. **arrivo → propria partenza** — la mobile penalizza se stessa.

## Effetti (uno solo, sempre lo stesso)
**Chi riceve la penalità è penalizzato: non fa vincere la propria squadra, la sua sede cade.**
Con una sola conseguenza indiretta già certificata: se è l'ARRIVO a essere penalizzato,
l'arrivo non agisce e **la partenza resta attiva ma ferma**, quindi parla lei col proprio
carattere (guida EURUSD 14/07/2021 s117, giorno 亥 su arrivo 亥).

## Condizione di forza (Edu, stessa sessione, dal controllo indietro)
Chi penalizza deve **pesare almeno quanto chi riceve** (modello di preponderanza sulla data
intera). Senza forza la penalità non abbatte. Misura: con la condizione 42 carte · 71,4%
· +1.560 pip; senza, 67 carte · 62,7% · +1.411.

## Carte guida
- **EURUSD 22/07/2025 s116** — giorno 辰 sulla partenza 辰 (autopenalità): la sede della
  mobile cade → LONG ✓
- **EURUSD 14/07/2021 s117** — giorno 亥 sull'arrivo 亥: la partenza resta attiva ma ferma,
  W in L5 vince la sede → LONG ✓
- **EURUSD 25/05/2021 s122** — l'arrivo 寅 penalizza la partenza 巳: la sede bassa cade → LONG ✓

## Misura registrata (non dottrina)
Mese, anno e ora come mittenti della penalità: **peggiorano** il motore di oltre un punto
(52,11% contro 53,31%). Il **giorno** penalizza; per gli altri rami servirebbe una condizione
non ancora individuata. Flag di prova: `MPPENADATA=1`.

---

# CONTROLLO INDIETRO (回頭剋) — `FISSATA` · 29/08/2026

## Enunciato di Edu (testuale)
> "Se c'è un controllo indietro questo ha la **precedenza**, quindi l'arrivo non va da nessuna
> parte se non a controllare indietro. Se la partenza genera l'arrivo, questo può andare dove
> gli pare perché la linea è **lanciata in avanti**."
> "Zi è generata dal giorno quindi **ha l'energia** per controllare indietro."
> "Quando il metallo che genera l'acqua è così forte, **Xu non può controllare** P hai."

## Lettura
1. Il controllo indietro ha la precedenza su ogni destinazione: l'arrivo non corre.
2. Riesce **solo se l'arrivo pesa almeno quanto la partenza** (preponderanza sulla data intera).
   - riesce → l'arrivo controlla davvero e parla il suo carattere;
   - non riesce → l'azione fallisce, chi non vince perde, la sede della mobile cade.
3. Carte guida: **EURUSD 05/03/2025 s106** (4 a 4, riesce → LONG ✓) ·
   **GBPUSD 22/04/2025 s133** (4 a 6, non riesce → SHORT ✓).

---

# MODELLO DI FORZA (preponderanza sulla data) — `FISSATA` · 29/08/2026

Peso di un ramo, contato sulla **data intera**:
- **stagione**: +2 se il ramo è dell'elemento del mese/stagione o da questi generato;
- **rami di data** (anno, giorno, ora — il mese è già nella stagione): +1 ciascuno se dello
  stesso elemento o se lo generano;
- **steli** di anno, mese, giorno e ora: +1 ciascuno alle stesse condizioni. Gli steli di anno
  e mese si derivano dai rami del motore (Cinque Tigri 五虎遁), l'ora dai Cinque Topi (五鼠遁),
  **mai** dal pilastro di un'ora convenzionale;
- **raccolte complete** (三合 e 三會): +2, **ma solo se l'elemento della raccolta è quello del
  ramo**. 巳酉丑 è Metallo: chi ci entra si converte, non si ingrossa. 亥子丑 è Acqua e quella
  sì rinforza il 亥. Questa distinzione viene dalla lettura di Edu su GBPUSD 22/04/2025.

---

# SHI O YING VUOTA: LA PARTE VUOTA PERDE SUBITO — `FISSATA` · 29/08/2026

## Enunciato di Edu (test richiesto e approvato in sessione 28)
> "Se Shi o Ying sono vuoti, questo diventa subito la **prima cosa da vedere** e fa perdere
> immediatamente la parte vuota."

Prima lettura della catena, prima ancora della mobile. Vuoti pari (entrambi o nessuno):
la regola tace e si prosegue.

## Eccezioni (mostrate da Edu sulle tre controcarte del test)
La regola CEDE quando nella carta opera un meccanismo con precedenza:
1. una **penalità (刑)** tocca gli attori (linee del duello, partenza o arrivo della mobile)
   — EURUSD 14/01/2025 s102 (triangolo 丑戌未 fra mese, giorno e mobile);
2. il **giorno combina la linea vuota** e la tiene (non è abbandonata)
   — NZDUSD 05/02/2026 s59 (giorno 戌, stesso ramo della Ying, combina la Shi 卯 vuota,
   e la bestia del giorno siede proprio lì);
3. **tomba+penalità sulla mobile** (caso −4): decide quella lettura
   — USDJPY 30/12/2024 s157 (spiegata anche dal raggruppamento di stagione col mese).

Cercata in tutto il mazzo una G vuota che vinca SENZA altri meccanismi in carta: non esiste.
Da qui l'approvazione ("se la prossima non lo è approviamo la regola").

## Misura al cablaggio (in testa alla catena del motore a principi, con le eccezioni)
Gradino: 499 carte · 51,70% · +1.263 pip. Motore intero: 2.581 · 53,20% · +11.416
(vecchio 52,15 · recente 54,11). Cella nuda senza eccezioni, per memoria: 918 · 50,8%,
con le W/P vuote a ~56% e le G vuote al contrario (38,9% sulla Ying) — le G "al contrario"
sono risultate tutte carte con meccanismi a precedenza. Flag: MPSHIVUOTO=no per spegnere.

---

# LE BESTIE (六獸): QUANDO AGISCONO E QUANTO PESANO — `FISSATA` · 29/08/2026

## Perché è registrata qui
Questa dottrina era già stata enunciata da Edu e si era **persa**. Va tenuta come
**relazione**, non come elenco di casi: è la ragione per cui il motore a principi
sbaglia le carte guida di Edu quando la lettura passa dalla bestia
(5 giuste / 15 sbagliate contro 34 / 25 delle carte senza bestia).

## Il principio
La bestia non è un attore autonomo: è la **porta attraverso cui l'energia della data
entra in una linea**. Conta chi la nutre. A seconda di chi la nutre, la bestia ha
poteri diversi, in tre gradi di forza decrescente.

## Primo grado — un PILASTRO DELLA DATA cade sulla linea della bestia
Quando uno dei quattro pilastri (anno, mese, giorno, ora) cade sulla linea che
corrisponde alla propria bestia — esempio: giorno 戊子 (Wu Zi), si guarda la linea di
勾陳 (GouChen, Terra yang, la bestia dello stelo 戊) e lì arriva il ramo 子 — quella
linea ha **peso energetico maggiore**.

Poteri pieni. La bestia può:
- **far muovere** la linea, facendole superare combinazioni, blocchi, penalità, vuoti;
- **bloccarla**, attraverso una combinazione;
- **eliminarla**, attraverso un clash.

## Secondo grado — lo STELO TERMINALE del flusso del Qi nella data, SE RADICATO nei rami
La bestia corrispondente a quello stelo, sulla linea dell'esagramma, ha gli **stessi
poteri del primo grado**. La condizione della radice è vincolante: stelo terminale non
radicato nei rami → non si arriva a questo grado.

## Terzo grado — il FLUSSO DEL QI GENERICO della data e il suo ELEMENTO TERMINALE
La bestia corrispondente è **energetizzata** nella linea, ma **NON** ha i poteri di cui
sopra: non muove, non blocca, non elimina. Pesa soltanto — vale come forza quando gli
attori sono altrimenti pari.

## Ordine operativo
Primo grado prima del secondo, secondo prima del terzo. I primi due gradi intervengono
**prima** che si decida se la mobile si muove (sbloccano o impediscono il movimento);
il terzo interviene **dopo**, solo come peso fra attori pari.

## Carte guida della dottrina (già lette da Edu, in carte_lette.json)
- Primo grado, bestia che BLOCCA: USDJPY 09/10/2024 — giorno 丙午, pilastro omogeneo,
  la bestia 朱雀 (Passero rosso, Fuoco) di L1 sta dentro il pilastro del giorno e blocca
  la linea, che non parte proprio.
- Distinzione del primo grado: USDJPY 29/11/2024 — giorno 丁酉, stelo Fuoco ma ramo
  Metallo: la bestia Fuoco NON è il pilastro del giorno, quindi carica la linea e la fa
  partire, non la blocca.
- Primo grado, bestia che SBLOCCA: USDCHF 13/11/2025 — 朱雀, bestia dello stelo del
  giorno 丙, radicata in anno 巳 e ora 午, fa muovere L1 malgrado il clash del giorno
  sulla partenza.
- Secondo grado: USDJPY 31/07/2024 — l'unico stelo radicato è di polarità opposta e non
  conta; l'abbondanza di Terra del Bazi va alla bestia 勾陳 di L2 e potenzia la linea.
- Secondo grado: EURGBP 21/01/2022 — la Terra sovrabbondante, tramite 螣蛇 su L4, attiva
  e genera l'arrivo 申 benché vuoto.
- Terzo grado, peso che rompe il pareggio: EURJPY 31/10/2023 — Shi e Ying stesso elemento
  (Fuoco), stallo; vince chi ha la bestia nutrita dagli steli (白虎 nutrita da 辛 contro
  朱雀 senza nutrimento).
- Bestia SENZA radici, che quindi non salva: EURGBP 08/12/2021 · USDCHF 28/07/2025
  (radici della bestia in penalità 戌刑未 fra loro: flusso avvelenato, non sblocca).

## Aggiunta del 29/08/2026 — dove si va DOPO che la bestia ha tolto la mobile
Carta guida: **USDJPY 09/10/2024, seme 148** (giorno 丙午, mese 戌, anno 辰, ora 卯).
Lettura di Edu: l'intero pilastro del giorno arriva su L1 attraverso la bestia 朱雀 e,
clashandola, **elimina completamente** la linea (che era anche untimely di suo). Per vedere
chi vince si va altrove: Shi (L3 辰 W) e Ying (L6 未 W) sono entrambe Terra, **pari**; mese
e anno portano entrambi lo stelo 甲, che corrisponde al 青龍 di L6, quindi il peso maggiore
ce l'ha lo Ying, che vince la battaglia → sede alta → LONG (mercato LONG +104).

**Vincolo trovato alla misura.** Il salto diretto al duello vale **solo quando Shi e Ying
sono dello stesso elemento**. Applicato ogni volta che la bestia toglie la mobile, il motore
scende a 40 giuste / 45 sbagliate sulle carte guida; ristretto alla parità, sale a 48/41.
La ragione dottrinale è nelle parole stesse di Edu: il peso decide *fra S e Y che sono
uguali*. Se non sono pari, la catena prosegue normalmente (caricati dalla data, 伏神,
penalità) e il peso delle bestie interviene solo in coda.

## Misura al cablaggio dello strato delle bestie (29/08/2026)
Carte guida (91 lette da Edu): da **42 giuste / 44 sbagliate / 5 tace** a
**48 giuste / 41 sbagliate / 2 tace**. Termometro sulle stesse: 35 / 34 / 22.
Motore intero: da 2.581 carte · 53,20% · +11.416 pip a **2.953 carte · 53,20% · +12.418 pip**
(vecchio 51,07% · recente 54,92%), con i silenzi da 458 a 86.
Contributo separato dei gradi: 1° e 2° da soli portano 2.568 carte · 53,50% · +11.913 pip e
migliorano quasi tutti i gradini (controllo indietro con forza da 53,1% a 58,5%, senza forza
da 55,8% a 57,1%); il 3° grado aggiunge le carte del duello pari.
Interruttori: `MPBESTIE=no` spegne tutto lo strato, `MPBESTIE3=no` solo il terzo grado.

---

# PENALITÀ DENTRO LA DATA — `FISSATA` · 29/08/2026

## Enunciato di Edu (da EURJPY 21/10/2021, seme 133)
Un ramo della data penalizzato (刑) da un **altro ramo della data** non è in grado di
svolgere il suo ruolo: **non completa i trigoni** (三合) e il suo pilastro, portato dalla
bestia su una linea, la **depotenzia** invece di rafforzarla. Sulla carta guida: l'anno 丑
penalizza il mese 戌 → 戌 non fa la sua parte nel trigono 寅午戌 → la L4 resta depotenziata;
il pilastro del mese 戊戌 cade via 勾陳 sulla Shi e, nel confronto Shi vs Ying **pari**,
la Shi perde → SHORT (mercato SHORT −75). PB concorde: Kun si muove in Zhen che controlla
indietro → il basso vince.

## Confine con USDJPY 09/10/2024 (seme 148)
Il 刑 come semplice relazione d'arrivo NON depotenzia: sul quel seme il mese 甲戌 tocca in
刑 lo 青龍 di L6 (戌刑未) ma il mese NON è penalizzato dentro la data, e lì decide il
**nutrimento degli steli** (i due 甲ø nutrono 青龍 → lo Ying vince → LONG). Il veleno
viaggia solo col pilastro avvelenato; la penalità è anche la sua porta d'arrivo.

## ERRORE DI SESSIONE, registrato per onestà del metodo
La prima lettura di EURJPY 21/10/2021 è avvenuta con l'esito **trascritto al contrario da
Claude** (presentato LONG +75 anziché SHORT −75). La regola derivata da quella lettura
(generazione indietro con trigono → vince la sede della mobile, `B1-genera-indietro-forte`)
misurava 1/14 nel suo perimetro ed è stata SPENTA (`MPGENFORTE=si` per riattivarla a fini
di studio). Correzione di processo: le righe d'esito delle carte presentate a Edu vengono
generate meccanicamente dai dati del motore, mai trascritte a mano.

## Misura al cablaggio
Guide: 48 / 41 / 2 (invariate al netto delle due carte guida della dottrina, entrambe lette
correttamente). Motore: 2.958 carte · 52,94% · +11.224 pip. Perimetro del nuovo gradino
`B4-bestia-avvelenata`: 11 carte · 27,27% · −467 pip — ATTENZIONE: nel suo perimetro la
regola al momento perde; portare a Edu una carta falsificante completa (regola 10) prima
di qualsiasi modifica.

## Vincolo di ADIACENZA (Edu, 29/08/2026, da EURJPY 30/04/2020 s115)
La penalità dentro la data funziona **solo se i rami sono vicini**: anno↔mese, mese↔giorno,
giorno↔ora. Sulla carta del vincolo 子 sta nell'anno e 卯 nel giorno: non si toccano,
nessun veleno — la carta esce dal perimetro dell'avvelenamento (e con lei il dubbio della
penalità mutua, che si pone solo fra vicini). Misura dopo il vincolo: guide 49/41/2 (su 92),
perimetro `B4-bestia-avvelenata` ridotto a 4 carte (la guida vinta; GBPUSD 28/10/2021 s137,
GBPUSD 06/03/2026 s133, GBPUSD 17/03/2026 s133 perse — candidate a lettura, regola di coda
congelata in attesa di falsificante nel perimetro).

---

# C DISTRUGGE G — `FISSATA` · 29/08/2026

## Enunciato di Edu (da USDCAD 21/12/2023, seme 133)
Nel controllo indietro riuscito, quando l'arrivo è un **C** e la partenza una **G**, il C
distrugge la G a due condizioni **alternative**:
1. il C è **timely**, oppure
2. la G è **untimely**.
La timeliness si giudica per **stagione** (rapporto dell'elemento col ramo del mese, come
da registro sulla vita delle mobili): il soccorso del giorno non salva la G dalla
distruzione. Distrutta la G, la mobile ESCE di scena e la lettura prosegue come per
l'eliminazione della bestia (salto al duello pesato se Shi e Ying sono pari, altrimenti
catena normale). Sulla guida: 酉 G in 死 nel mese 子, il C 午 la distrugge; Shi/Ying pari
(entrambe W 丑), la 玄武 nutrita da tre steli d'Acqua vince → SHORT (mercato SHORT −77).

## Nota di misura al cablaggio
Sul mazzo la regola oggi NON sposta verdetti (2.957 · 52,93% · +11.286 identici con
MPCDISTRUGGE=no): le carte instradate arrivavano alla stessa risposta per la via
dell'atterraggio. Valore dottrinale: attore corretto, instradamento pronto per i gradini
a valle. Interruttore: MPCDISTRUGGE=no.

## PB alto/basso — due relazioni certificate da Edu (29/08/2026)
Analisi PB obbligatoria su ogni carta nuova (logica alto/basso sul trigramma Yong che muta):
- il trasformato **controlla indietro** l'originale → il lato che si muove PERDE
  (guida EURJPY 21/10/2021: Kun alto → Zhen, il basso vince).
- il trasformato **genera indietro** l'originale → lo Yong si nutre muovendosi e il suo
  lato VINCE (guida USDCAD 21/12/2023: Xun basso → Kan, il basso vince, SHORT).
Le altre relazioni (controllo/generazione in avanti, 比和) restano a lettura di Edu.

---

# PROTEZIONE DEL PILASTRO SULLA LINEA FERMA — `FISSATA` · 29/08/2026

## Enunciato di Edu (da USDJPY 24/06/2020, seme 106)
"Il mese 壬午 sta su L4 ed elimina ogni problema." Il pilastro di 1° o 2° grado seduto su
una linea FERMA via la propria bestia le fa superare la penalità della data: la penalità
non opera e la lettura prosegue come se la linea fosse sana (sulla guida: cade l'eccezione
alla regola del vuoto, la Ying P vuota perde, LONG — mercato LONG +60).

## Confine (dalla carta guida USDJPY 09/12/2024, già in registro)
La protezione portata dalla COMBINAZIONE (il ramo del pilastro combina la linea) cade se un
ramo della data CLASHA la linea: vale la regola fissata "1 clash rompe la combinazione".
Sulla 09/12/2024 il mese 丙子 combina la Ying 丑 ma il giorno 未 la clasha: combinazione
rotta, nessuna protezione, la penalizzata parla (LONG, corretto). Proteggono: arrivo dello
stesso ramo (carica) sempre; combinazione solo se non clashata. Clash (elimina) e pilastro
avvelenato (depotenzia) non proteggono mai.

## Misura al cablaggio
Guide: **50 / 41 / 2 su 93** (massimo di sessione). Motore: 2.959 carte · 52,86% · +10.697.
Il gradino della penalizzata resta in perdita (188 · 47,87% · −480): prossimo ciclo di
lettura. Interruttore: MPPROTEZ=no.

---

# IL C NON TACE — `FISSATA` · 29/08/2026 (da USDCHF 29/02/2024, seme 87)
1. Il C può GENERARE la W → la W è nutrita e vince la sua sede.
2. Il C può DRENARE il B → il malus si scarica e la sua squadra vince.
3. In ASSENZA di W il C fa vincere la propria squadra, A MENO CHE
4. il C controlli la G → allora la propria squadra perde.
Cablate nel carattere dell'attore, valgono ovunque il C sia interrogato (MPCPARLA=no spegne).

# ELIMINATA vs BLOCCATA, e il duello — `FISSATA` · 29/08/2026 (stessa guida)
"Se non c'è azione e le bestie non dicono più nulla, vai a S vs Y."
- Linea ELIMINATA (clash della bestia di 1°/2° grado, o C che distrugge la G): non esiste
  più. Si va SEMPRE al duello, e se l'eliminata era Shi o Ying quella parte PERDE subito
  (chi non c'è più non vince la sede) — gradino B4-eliminata-perde.
- Linea BLOCCATA (combinazione della bestia): resta SEDUTA al suo posto; la catena prosegue
  normale e si salta al duello solo se Shi e Ying sono pari.
Il salto incondizionato anche per le bloccate rompe le guide (43/46 contro 51/41): il
confine è la differenza fra non-esserci-più e non-potersi-muovere.
Misura: guide 51/41/2 su 94 (massimo di sessione) · motore 2.965 · 52,61% · +10.115.

---

# LA PROGRESSIONE DELLA MOBILE — `FISSATA` · 30/08/2026 (dottrina enunciata da Edu)
Quando la mobile si trasforma nello STESSO elemento c'e' progressione: 進神 avanza,
退神 retrocede. Avanzare rafforza cio' che la linea e'; retrocedere lo indebolisce.
Le due squadre reagiscono in verso opposto perche' una porta bene e l'altra porta male:
- **G o W che AVANZA** -> fa VINCERE la propria squadra -> la sua sede (alto LONG, basso SHORT)
- **G o W che RETROCEDE** -> la fa PERDERE -> la sede cade
- **B o P che AVANZA** -> fa PERDERE la propria squadra -> la sede cade
- **B o P che RETROCEDE** -> la fa VINCERE -> la sua sede
Il C tace. Cablata nel motore a principi come gradino dopo la data e il 伏神
(MPPROG=no la spegne; MPPROGPOS=presto la porta in testa alla catena).

MISURA AL CABLAGGIO (30/08/2026)
- Perimetro totale (tutte le carte con progressione, chiunque sia l'attore): 433 carte, 48,0%.
- Dove la dottrina E' L'ATTORE nella catena: 56 carte.
  G/W retrocede  18 carte  77,8%  +909 pip
  B/P retrocede  10 carte  60,0%   -13 pip
  G/W avanza      8 carte  37,5%    -7 pip
  B/P avanza     20 carte  25,0%  -458 pip
- In testa alla catena il perimetro sale a 316 carte ma la lettura scende al 45,6% e il
  mazzo perde (52,49% contro 53,18%): la progressione NON e' un attore di prima istanza.
- Effetto sul mazzo nella posizione scelta: 53,16% -> 53,18%, +12.781 -> +12.765 pip. Neutra.

NOTA DI MISURA, non di dottrina: il ramo **B o P che avanza** e' quello che il mazzo
contraddice piu' nettamente (25,0% su 20 carte dove agisce; 43,6% su 101 in testa alla
catena). Nessuna carta guida e' ancora stata letta su questo ramo. Va in osservazione.

---

# §122 — LA YING CHE RESTA SOLA SI MISURA CON LA SHI · `CABLATA` 30/08/2026
Guida: USDCHF 21/07/2021, seme 92 (震 Zhen + 離 Li, mutante L2, 寅→卯).
Catena logica dettata da Edu, tre passaggi:
1. L'arrivo 卯 e' incompatibile col trigramma FUTURO (震 muta in 兌, e 卯 clasha 酉, ramo
   proprio di 兌) -> la linea PARTE MA NON ARRIVA. Caso -5, movimento nullo.
2. Non arriva, quindi NON AVANZA: senza arrivo non c'e' 進神 ne' 退神. La progressione
   viene azzerata sul caso -5, e le regole del malus che avanza non parlano piu' li'.
3. La mobile era la YING: resta SOLA, e allora si misura con la SHI. Vince chi CONTROLLA
   e la sua sede decide; se nessuna controlla, il vuoto asimmetrico; poi la generazione
   (vince il nutrito). Sulla guida la Ying 寅 Legno controlla la Shi 未 Terra pur essendo
   nella tomba del mese 未: IL CONTROLLO BATTE LA STAGIONE. Verdetto SHORT, esito SHORT.
Il caso speculare (mobile = Shi) NON vale: 40,0% su 50 carte.
Parla in PRIMA priorita': altrimenti la raccolta stagionale col mese parla sopra e dice LONG.

MISURA
  perimetro §122: 10 carte  60,0%  +85 pip  [vecchio 4/1 · recente 2/3]
    di cui ramo del controllo: 7 carte 71,4%
  S17 baseline                                  2.788  58,82%  z 9,32  +35.869
  + "parte ma non arriva" (caso -5, 176 carte)  2.788  58,75%  z 9,24  +36.005
  + "non arriva quindi non avanza"              2.788  58,64%  z 9,13  +35.505
  + §122 in prima priorita'                     2.788  58,64%  z 9,13  +35.505
COSTO NETTO sul mazzo: -0,18 punti e -364 pip rispetto alla baseline. Cablata perche'
dottrina certificata da Edu, non perche' la statistica la chieda. REGOLA DI CODA, congelata.
VIA122=off · INCFUT=off (per la causa di movimento nullo).

# IL PONTE DELLA DATA — `FISSATA` 30/08/2026 (guida USDJPY 30/04/2024, seme 156)
Gemella esatta della guida di §122: stesso 離 Li + 震 Zhen, stessa L2, stesso 寅→卯, esito
opposto. Edu: "L'acqua e' molto piu' forte nella data e permette di far vivere 卯 dentro 兌,
quindi la linea si muove."
DOTTRINA. L'arrivo e' incompatibile col trigramma futuro perche' il ramo proprio di quel
trigramma CONTROLLA l'arrivo (卯∈兌: 酉 Metallo controlla 卯 Legno). Ma se l'elemento IN MEZZO
— generato dal primo e generatore del secondo, qui l'Acqua — e' forte nei RAMI della data, il
controllo diventa generazione: l'arrivo vive laggiu' e la linea SI MUOVE davvero.
Vale per le tre coppie con controllo: 卯∈兌 (ponte Acqua) · 午∈坎 (ponte Legno) · 申∈艮 (ponte
Acqua). Su 丑∈坤 e 辰∈乾 non c'e' controllo, solo clash: nessun ponte.
Forza contata sui QUATTRO RAMI della data (anno, mese, giorno, ora), non sugli steli — sugli
steli il segno si rovescia: guida 1 stelo d'Acqua e 0 rami, gemella 0 steli e 2 rami.
SOGLIA misurata: 2 rami. PONTE=0 la spegne.
  soglia 0 (nessun ponte)  58,64%  z 9,13  +35.505
  soglia 1                 58,61%  z 9,09  +35.157
  soglia 2  <-- scelta     58,68%  z 9,17  +35.785
  soglia 3                 58,64%  z 9,13  +35.505
La gemella torna a vincere (+140). La guida continua a leggere SHORT con §122.

# §126 — LA LINEA SEDUTA SUL MESE NON SI LASCIA SVALUTARE · `CABLATA` 30/08/2026
Guida GBPUSD 15/12/2022 (seme 124) · gemella USDCHF 28/01/2026 (seme 76).
L'ORA arriva INTERA su una linea: il ramo dell'ora la PENALIZZA (刑) e la bestia dello stelo
dell'ora (五鼠遁) e' gia' seduta sopra. Se quella linea SIEDE SUL MESE (stesso ramo), e'
CARICATA dal pilastro del mese: la penalita' non la scalfisce, tiene la propria sede e la sua
squadra VINCE. Sulla gemella il mese 丑 COMBINA il 子 della Ying (六合): li' e' legata E
penalizzata insieme, e cade -> sede bassa che cade -> LONG.
Misura: 19 carte 78,9% z 2,52 +795 pip [vecchio 6/1 · recente 9/3].
La forma senza guardia NON tiene (245 carte 49,8%): il numero forte e' la guardia, non la regola.
VIA126=off.

# IL PONTE: L'ACQUA SI CONTA TUTTA (correzione di Edu, 30/08/2026)
Il ponte della data si conta sui rami PIU' gli steli del giorno e dell'ora (ora coi 五鼠遁).
Soglia 2. Con questo conto la GBPUSD 15/12/2022 e la USDCHF 28/01/2026 hanno il ponte e la
mobile ARRIVA; la guida USDCHF 21/07/2021 no. PONTEMODO=rami per l'audit sui soli rami.

# STATO DEL MAZZO A FINE SESSIONE 30 — bilancio onesto
  baseline di apertura                       2.788  58,82%  z 9,32  +35.869
  §125 (direzionale) + §126, SENZA il caso -5 2.788  58,97%  z 9,47  +36.129
  tutto acceso (col caso -5)                  2.788  58,79%  z 9,28  +35.463
Le due vie nuove valgono +0,15 punti e +260 pip. Il caso -5 "parte ma non arriva" ne toglie
-0,18 e -666: le ~150 carte che porta a movimento nullo non sono lette bene da nessuna via
(dentro il caso -5: §65 24 carte 54,2%, §99 21 a 61,9%, silenzio 23 a 47,8%, il resto intorno
al 50%). NON esiste un riordino di priorita' che lo recuperi: la perdita e' sparsa, non
concentrata su una via. La decisione se tenerlo e' dottrinale, non statistica.
§124 (la Ying sola contro la Shi) e' scesa a 6 carte al 50,0% e non muove piu' il mazzo.

# §127 — L'AUTOPENALITA' DAL MESE: CHI NON VINCE PERDE · `CABLATA` 30/08/2026
Guida EURJPY 15/06/2023 (seme 151). Quattro rami si penalizzano da soli (自刑): 辰辰, 午午,
酉酉, 亥亥. Quando la PARTENZA della mobile e' uno di questi e il MESE e' lo stesso ramo,
sedere sul mese NON e' una carica: e' un'autopenalita'. La mobile non porta a casa l'azione —
chi non vince perde — la sua sede cade. Speculare della §126: per gli altri otto rami il mese
carica, per questi quattro punisce. Sulla guida la G 午 sul mese 午 e sull'ora 午 sembrava
fortissima: sede bassa caduta, LONG, esito LONG +173.
Perimetro (catena liuyao): 83 carte 54,2% z 0,77 +659 pip [vec 21/20 · rec 24/18].
S17 con la via: 58,75% z 9,24 +35.017. Nel motore di ricerca la via e' in coda (parla nel
silenzio); nella catena della PWA parla davanti a §126. APERTO: allineare la posizione nelle
due catene e' un conflitto di priorita' da sessione dedicata. VIA127=off.

# §129 — IL PILASTRO COMPLETO RENDE LA LINEA DOMINANTE · `CABLATA` 30/08/2026
Guide: AUDUSD 18/04/2022 (seme 73, Tai Sui 壬寅 su L2 W -> domina, SHORT) e AUDUSD 02/09/2020
(seme 73, mese 甲申 completo su L5 B). Primo grado delle Sei Bestie portato a via: ramo del
pilastro sulla linea E bestia dello stelo gia' seduta = pilastro COMPLETO, linea DOMINANTE.
- G, P o W dominante -> la sua squadra vince la sua sede
- B dominante -> il male a pieni poteri: la sua sede CADE (connessione dai principi, non dettata)
- C dominante -> tace · due dominanti su sedi opposte -> tace
- Dominano solo i pilastri GRANDI (anno e mese): l'ora intera su L1 nella 23/11 NON domina
  (PILDOM=tutti per audit). Eccezione §127: ramo autopenalizzante (辰午酉亥) non carica.
- Parla PRIMA dell'incompatibilita' (§128), come da dettato ("basta solo questo").
Perimetro: 295 carte 51,5% +1.930 pip. VIA129=off.

# §128 — AGGIORNATA: L'INCOMPATIBILE NON CONTA SE NON E' ATTIVA (Edu, 30/08/2026)
Attiva = non vuota-ferma (il vuoto non agisce) E toccata dalla data (bestia di uno stelo dei
pilastri seduta sopra, o ramo dei pilastri = suo ramo) oppure mobile. Sulla guida 23/11 la Shi
G 卯 porta 玄武 e lo stelo d'anno 壬 e' Acqua: attiva, perde, LONG (giusto). Sulla 18/04 la
Ying 辰 e' vuota e ferma: non andava nemmeno nominata.
Perimetro dopo §129: 487 carte 46,6% -2.163 pip [vec 104/110 · rec 112/136]. Resta cablata e
congelata (regola #10: la carta portata contro e' stata spiegata dalla dominanza). PRIMA
INDIZIATA per la prossima lettura: nel suo perimetro la parte incompatibile attiva VINCE piu'
spesso di quanto perda. S17 a fine sessione 30-bis: 58,39% z 8,86 +34.138.

# PRINCIPIO FONDANTE — IL CARATTERE E IL DUELLO (Edu, 30/08/2026, dettato a fine S30-bis)
Quando una linea AGISCE, il suo carattere decide il segno:
- P e B fanno PERDERE la propria squadra
- G e W la fanno VINCERE
- C fa VINCERE se frena una B, fa PERDERE se controlla una G
MA tutto questo NON vale nel confronto fra SHI e YING: nel duello si vede solo CHI VINCE,
senza il carattere. Il duello e' forza contro forza; il carattere parla solo nell'azione.

# §128 — TERZA STESURA (fine S30-bis): PONTE DEL PILASTRO + VUOTO AUTOMATICO
Due dottrine di Edu sulla EURJPY 07/12/2023 (seme 158):
1. IL PONTE DEL PILASTRO SALVA L'INCOMPATIBILE: se il ramo proprio del trigramma CONTROLLA
   la linea, ma un pilastro della data le cade sopra (ramo uguale o bestia del suo stelo
   seduta) col ramo dell'elemento IN MEZZO, il controllo diventa generazione: linea salvata.
   Guida: Tai Sui 癸卯 -> 玄武 sulla Shi 午, il 卯 Legno fa ponte fra l'Acqua di 坎 e il Fuoco.
2. IL VUOTO NEL DUELLO PERDE AUTOMATICAMENTE: quando si arriva al confronto Shi/Ying (qui:
   almeno una delle due incompatibile, prima di salvezze e attivita'), chi e' vuoto perde,
   primo criterio, prima del controllo. Applicato anche al duello di §124 (vuoto prima del
   controllo). Nel duello NON conta il carattere (principio fondante).
Catena di §128: (a) confronto invocato da incompatibilita' grezza; (b) vuoto asimmetrico ->
il vuoto perde; (c) incompatibile ATTIVA e non salvata dal ponte -> perde, vince l'altra.
Perimetro: 581 carte 49,9% -373 pip. Guide: 07/12 SHORT (vuoto automatico) · 23/11 LONG.
S17 a chiusura: 2.788 · 58,50% · z 8,98 · +34.842. Parita' verificata sulle guide.

===========================================================================
31/08/2026 (S31) — §130: I DUE PILASTRI INTERI SUL NASCOSTO
===========================================================================
Dottrina di Edu (guida EURJPY 11/03/2025, seme 159, caso -5):
"La nascosta P e' super forte e si prende pure i pilastri del mese e giorno.
Niente nell'esagramma puo' competere con questa P che fa perdere la propria
squadra."
Il peso va fatto coi 12 STADI (十二長生), massimo agli stadi 4-5: sul mese 卯
il Legno e' all'apice 帝旺 (stadio 5) e il Fuoco al bagno 沐浴 (stadio 2) —
il vecchio peso piatto (旺+2/相+1) li faceva sembrare vicini. L'ora 寅
aggiunge Legno. Le bestie degli steli di mese e giorno (己己 -> 螣蛇) sedute
sulla linea del nascosto raddoppiano almeno la sua forza.
VIA CABLATA (§130, R69_130, in TESTA alla catena — la dominanza parla prima
delle vie d'azione; sulla guida batteva la §68): ramo del nascosto = ramo di
mese E giorno, bestie di ENTRAMBI gli steli sedute sulla sua linea (due
pilastri interi), unico nascosto candidato, ramo non autopenalizzante
(辰午酉亥 esclusi da §127/§129). Il carattere decide per la sede della linea
che lo copre: G/W vince, P/B cade, C tace in attesa di guida.
Confine fissato da USDCAD 26/02/2025 (seme 143): stesso nascosto su mese e
giorno ma UN SOLO pilastro completo (bestia del giorno altrove) -> tace.
Perimetro alla nascita: 1 carta su 2.788.
S17: da 58,50% +34.842 a 58,54% · z 9,01 · +35.196 (solo la guida).
NOTA APERTA: sulla guida la catena della PWA tiene ancora SHORT perche' il
rafforzativo del Serpente (§81) scatta li' nella forma larga; nel motore no.
E' parte dello scarto residuo PWA/motore (0,25 punti) gia' in agenda.
DA FARE: ripesare forzaModello coi 12 stadi (bozza FORZA12 in pb_stress).

---------------------------------------------------------------------------
31/08/2026 (S31, seguito) — IL SERPENTE CEDE ANCHE NELLA PWA
---------------------------------------------------------------------------
La dottrina del 29/08 ("il Serpente cede davanti a una via cablata: il
rafforzativo statistico non scavalca la dottrina") era cablata nel motore
(guardia _serpViaCab su S17) ma MAI arrivata in combinaS9 di liuyao.js: la
PWA lasciava ancora vincere il PB nel contrasto quando il Serpente untimely
toccava Shi/Ying/mobile. Scoperto perche' sulla guida della §130 la PWA
teneva SHORT col Serpente mentre il motore dava LONG.
Corretto: il ramo del Serpente in combinaS9 ora e' spento (ogni verdetto del
termometro viene da una via cablata). SERPPWA=vecchio lo ripristina per audit.
Aggiornata anche la ricostruzione dentro PARITA17.
Catena PWA misurata da sola: da 58,75% +32.989 a 58,14% +33.243 (percentuale
giu', pip su). Scarto residuo PWA/motore ora 0,40 punti (58,14 vs 58,54):
sono le differenze della reimplementazione lyDir, in agenda.

---------------------------------------------------------------------------
31/08/2026 (S31, seguito) — §131: LA G/W VUOTA DEL CASO -5 NON VINCE, PERDE
---------------------------------------------------------------------------
Dottrina di Edu (guida USDCHF 28/09/2022, seme 99): "Chi non vince perde.
Short." La W mobile parte e non arriva (caso -5) ED e' in vuoto (旬空): il
vuoto non agisce, l'azione vincente non c'e', la sede della mobile CADE
(alta -> SHORT, bassa -> LONG). Vale per G e W (chi doveva far vincere).
E' l'eccezione di vuoto alla §99 e lo speculare della §114 (li' il carattere
regge perche' la linea e' piena; qui la linea stessa dorme).
Gemella verificata: USDCHF 04/10/2022 (stesso seme, stessa mutazione), +134.
POSIZIONE (misurata, non solo dottrinale): prima del raduno stagionale R6
(che sulla guida diceva LONG), quindi prima anche di §64 e §99; restano
sopra le vie precedenti a R6 (fra cui §62). Nota: §68 nella catena sta DOPO
R6, quindi la §131 parla anche prima di lei — il conflitto reale misurato
li' era 1 raddrizzata / 1 rotta, neutro.
Perimetro grezzo: 24 carte G/W vuote nel caso -5 (54,2%; vec 72,7 / rec
38,5 — perimetro grezzo, sporco di carte gia' spiegate da vie certificate).
S17: da 58,54% +35.196 a 58,57% · z 9,05 · +35.634 (+438 pip; vecchio
58,60->58,76, recente 57,69->57,62: una carta recente rotta, a registro).
Catena PWA da sola: 58,14% · +33.706.

===========================================================================
31/08/2026 (S31) — PRINCIPIO FONDANTE: "CIO' CHE SALTA ALL'OCCHIO"
===========================================================================
Dettato da Edu, testuale: "Per trovare le risposte giuste si deve cercare
cio' che salta all'occhio. Una linea che si muove per diventare vuota salta
all'occhio. Una linea che ha una grande forza salta all'occhio. Poi controlli
anche il resto. Non mettere tutto sul tavolo come se tutto fosse uguale, non
lo e'. Ci sono cose piu' importanti e cose meno importanti. Solo quando non
vedi nulla di decisivo ti metti a guardare piu' in profondita'."

Conseguenza architetturale: la lettura ha TRE PIANI, non una lista piatta.
  PIANO 1 — la salienza (si guarda per primo):
    · movimento verso il vuoto / vuoto che si muove (arrivo in vuoto §114,
      G/W vuota del caso -5 §131, W in moto oscuro con arrivo vuoto §97)
    · la grande forza (dominanti: pilastro completo §129, due pilastri sul
      nascosto §130; in prospettiva la forza pesata sui 12 stadi)
  PIANO 2 — il resto (le azioni ordinarie: casi di mutazione, clash e
    combinazioni dell'arrivo, progressioni, raduni)
  PIANO 3 — la profondita' (solo se nulla di decisivo sopra: residui §64,
    duelli, silenzi, nascosti deboli).
Le due vie di oggi sono nate gia' cosi': §130 in testa (grande forza),
§131 sopra il raduno stagionale (vuoto che si muove). Conferma del pattern.

DA FARE (agenda):
  1. Riordinare il motore a principi (motore_principi.js) per piani di
     salienza invece che per sequenza storica dei gradini.
  2. Nel termometro NON riordinare le vie certificate esistenti (lo stato
     sotto di loro e' gia' incarnato — lezione S30); il principio guida la
     POSIZIONE DELLE VIE NUOVE da oggi in avanti.
  3. Il ripeso della forza sui 12 stadi (gia' a registro) e' il prerequisito
     del piano 1 lato "grande forza".

---------------------------------------------------------------------------
31/08/2026 (S31, seguito) — MOTORE A PRINCIPI v3: L'ORDINE DELLA SALIENZA
---------------------------------------------------------------------------
Applicato il principio fondante di oggi al motore a principi. Tre mosse,
ognuna misurata da sola:
1. A0 (Shi/Ying vuota, primo gradino dal 29/08) SCENDE NEL DUELLO: in
   apertura assorbiva 440 carte al 50,68% (un sesto del mazzo per niente).
   Il vuoto statico non salta all'occhio: decide nel confronto, dove per il
   principio fondante del 30/08 chi e' vuoto perde automaticamente. Le sue
   440 carte si ridistribuiscono bene (B4-bestia-nutrita 174 al 56,3%,
   duello 106 al 51,9%, B2-data che sale a 53,3%). MPSHIVUOTO=si lo rialza.
2. L'AZIONE CHE FALLISCE SOTTO GLI OCCHI (chi non vince perde: 回頭剋,
   autocombinazione, moto nullo della G/W) SALE AL PIANO 1, prima della
   data e del fushen: 219+382+179 carte, tutte sopra il 52%.
3. La PROGRESSIONE resta al suo posto: provata al piano 1 PEGGIORA (345
   carte, GW-avanza 33%) — e' una proprieta' del passo, si legge nel passo.
   MPPROGPOS=presto per audit.
MISURA: v3 53,76% · +14.813 pip (vecchio 52,79 / recente 54,56) contro
v2 53,29% · +12.466 — +0,47 punti e +2.347 pip, meglio in entrambi i
periodi. MPORDINE=v2 riproduce l'ordine storico esatto (verificato).
Sulle carte guida: motore 54/52/2 · termometro 53/41/14.
Comando di misura: PRINCIPI=1 MPCHINONVINCE=si (+ flag canonici S17).

---------------------------------------------------------------------------
31/08/2026 (S31, seguito) — LA PROGRESSIONE FUNZIONA: SE NON FUNZIONA
C'E' UN MOTIVO, E IL MOTIVO E' SEMPRE VISIBILE
---------------------------------------------------------------------------
Domanda di Edu sulla misura del gradino presto (GW-avanza 3/16): "Se non
funziona c'e' un motivo, come nella carta di sopra, altrimenti funziona!"
Censimento (flag GWAV): TUTTE le G/W avanzanti a passo concluso del mazzo,
19 carte, una per una. NESSUNA fallisce senza un motivo in vista:
- 12 su 19 sono l'avanzamento 未->戌, dove l'arrivo PENALIZZA (刑) la
  propria partenza: l'avanzata nasce avvelenata (triangolo 丑戌未 dentro
  cui viaggiano le avanzate di Terra). Spesso col secondo colpo: l'arrivo
  戌 clasha il 辰 di L3, e quando quel 辰 e' CARICO (sul mese o timely)
  chi attacca il carico perde (lettura di Edu su EURGBP 04/04/2022 e
  USDJPY 25/10/2022, 未->戌 contro 辰 timely).
- famiglia 申->酉: l'arrivo 酉 clasha un 卯 nel campo;
- piu' mobili VUOTE e mobili untimely.
Le due che vincono nonostante il 刑 (EURGBP 21/06/2023, 03/10/2024) hanno
anch'esse il quadro in vista, da leggere.
La cella dell'avanzata PULITA — nessun veleno in vista — su questo mazzo
e' VUOTA: non esiste una G/W avanzante senza niente intorno. La dottrina
della progressione non ha mai parlato da sola e non e' mai stata smentita.
CONSEGUENZA PER IL MOTORE: la progressione non si declassa — si guardano
PRIMA i suoi killer (刑 fra partenza e arrivo, vuoto, chi viene colpito
dall'arrivo e quanto e' carico). L'ordine v3 fa gia' questo: il suo
vantaggio non e' che la progressione conta poco, e' che un'avanzata
avvelenata non e' un'avanzata.
Lettura guida collegata: EURGBP 04/04/2022 (in carte_lette): il mese 癸卯
intero su L5 distrugge la G untimely (clash + bestia 玄武 dello stelo),
unica voce del LONG -> SHORT. Il metodo della lettura, dettato da Edu:
1) dove sta l'avanzamento; 2) dove va l'arrivo; 3) chi colpisce; 4) quanto
e' carico chi viene colpito. Ogni passo pesa il successivo.

---------------------------------------------------------------------------
31/08/2026 (S31, seguito) — IL TAI SUI DIFENDE LA SUA LINEA (dottrina di stato)
---------------------------------------------------------------------------
Dottrina di Edu (guida USDJPY 06/11/2024, seme 151): "L1 non puo' essere
clashata se il Tai Sui la difende. S e' vuota quindi vince Y."
La linea su cui SIEDE il Tai Sui (ramo = ramo dell'anno) non puo' essere
clashata dalla data: niente 暗動, niente rotta/mossa/eliminata da quel
clash. Sulla guida il giorno 戌 (mese 戌 a potenziare) non tocca la L1 辰:
la carta resta nuda, si va al duello, la Shi 申 e' vuota -> vince la Ying,
sede alta, LONG +320 (il mio primo inquadramento — "timely clashata piu'
forte", "attore in moto oscuro" — era sbagliato: il clash non avviene
proprio).
CABLATA in readManual (liuyao.js, dentro clashSu): vale per ENTRAMBE le
catene perche' gli stati si fabbricano li'. TSDIFENDE=off per audit.
APERTO: il clash dell'ARRIVO sulla linea del Tai Sui non e' toccato
(shiValido/yingValido e stati da arrivo restano come prima) — da leggere
con una guida.
S17: da 58,57% +35.634 a 58,64% · z 9,13 · +35.800 (+166 pip, vecchio
58,76 -> 58,93, recente invariato). Catena PWA da sola: 58,21% +33.872.
La carta era gia' vinta da S17 (LONG): il guadagno viene dalle altre carte
del perimetro. Carta e cella "mese che distrugge" collegate: il 45% della
cella era fatto anche di linee DIFESE (Tai Sui) o cariche scambiate per
vittime.

## S43 — 08/09/2026 · La checklist leggeva le carte con impostazioni diverse dal motore · `CORRETTA`

**Il difetto.** `carta_check.js` chiamava il motore senza la base canonica. Misurato su tutte
e 2.788 le carte: il verdetto del Plum Blossom risultava diverso su **311 carte (11,2%)** e il
Liu Yao non parlava affatto, perche' la sua voce si accende solo con `PBLY=1`. Su quelle 311
carte si ribaltava anche la riga dell'esito. Esempio: EURUSD 04/03/2020 seme 111 — la checklist
diceva che il PB segue il trend e perde 42 pip, il sistema vero dice il contrario e la vince.
Il difetto peggiorava a ogni sessione: la base canonica e' cambiata in S41 (tolto RAFFORZA) e
in S42 (tolta l'eccezione del ramo prospero) e la checklist non se ne accorgeva.

**Altri due difetti trovati nella stessa correzione**, tutti e due sul contesto del Liu Yao:
1. mancava l'elemento del Ti (`corpoEl`), quindi la via del mese che controlla il Tai Sui e
   nutre il Ti (§54b) non poteva mai scattare nella checklist. Carta: EURJPY 03/12/2025 s116.
2. mancava il ramo dell'ora nell'ottavo argomento della lettura, quindi vuoto dell'ora, forza
   e Tai Sui erano costruiti senza l'ora. Carta: EURUSD 06/11/2024 s109.

**La correzione.** La base canonica sta ora in **un solo file**, `base_canonica.json`, che la
checklist legge all'avvio; se manca, la checklist si ferma invece di leggere con impostazioni
sbagliate; se un flag e' forzato a mano lo dichiara in testa con un avviso. Quando la base
cambia, si cambia li' e basta.

**Verifica.** Scansione completa delle 2.788 carte con la checklist corretta: **zero differenze**
fra motore e checklist su verdetto del Plum Blossom, verdetto del Liu Yao, via che comanda e
direzione.

**Nota di igiene.** Una via cablata non ha numero di sezione (si stampa `§—`, "il raduno
stagionale col mese"). Comanda 461 carte al 57,9% e senza numero non e' cercabile nei registri.

## S43 — 08/09/2026 · Lo Hu Gua: il ciclo di assistenza vale come sostegno · `CABLATA`

**La dottrina** (Edu, 08/09/2026): nel Plum Blossom il ciclo di assistenza — lo stesso elemento
— e' considerato **positivo**, quindi vale come sostegno e non solo la generazione. La regola
dello Hu Gua cablata in S41 contava come sostegno la sola generazione.

**Carta guida: EURJPY 23/07/2024, seme 170** (sup 5 Xun · inf 2 Dui · mutante L2 · giorno 戊子
· mese 辛未 · anno 甲辰). Il Yong Dui (Metallo) controlla il Ti Xun (Legno) e la base va LONG,
ma il Yong trasformato e' Zhen (Legno), lo stesso elemento del Ti: il concorrente. Nessuno dei
due nucleari genera la propria parte, quindi la regola di S41 non interveniva e la carta
perdeva 197 pip. Il nucleare inferiore e' Zhen (Legno), lo stesso elemento del Ti, e contiene
la linea mutante: il Ti e' sostenuto, segue il trend, SHORT. Lettura di Edu: "Zhen e Xun sono
una coppia marito moglie, quindi e' come fossero una cosa sola".

**Come e' cablata.** In questo perimetro il trasformato e il Ti sono dello stesso elemento per
definizione, quindi un nucleare di quell'elemento li sosterrebbe entrambi: Edu ha stabilito che
il sostegno va al **Ti**. Vale solo per il nucleare **attivo**, quello che contiene la linea
mutante. Regola **generale** su tutti e cinque gli elementi (scelta esplicita di Edu).
Flag `HUGUAPAR=off` per spegnerla. Cablata in `pb_stress.js` e in `plumblossom.js`.

**Misure sul perimetro dei 608** (il caso del concorrente):

| lettura del sostegno | giuste | pip | vecchio | recente | girati |
|---|---|---|---|---|---|
| come cablato in S41 (solo genera) | 54,77% | 4.794 | 54,6% | 54,9% | — |
| nucleare **attivo** stesso elemento del Ti | **55,76%** | **5.417** | 56,8% | 54,9% | 54 (30 giuste, 24 no) |
| nucleare attivo = Ti o la sua coppia | 54,11% | 4.144 | 56,0% | 52,5% | 66 (31 giuste, 35 no) |
| uno dei due nucleari = Ti o la sua coppia | 50,49% | 1.533 | 50,9% | 50,1% | 148 (61 giuste, 87 no) |

Il legame di coppia fra elementi diversi (Qian-Kun, Dui-Gen, Li-Kan) **peggiora**: conta lo
stesso elemento, non la coppia. Dei 54 verdetti girati, 28 hanno il Ti di Legno (467 dei 623
pip guadagnati), 18 di Metallo (150 pip), 8 di Terra (6 pip); nessuno di Fuoco o Acqua, perche'
li' il trigramma e' uno solo. Il guadagno viene quasi tutto dalla coppia Zhen-Xun: i numeri su
Metallo e Terra sono troppo pochi per sapere se la regola valga davvero su tutti gli elementi.

**Effetto sul sistema.** Plum Blossom da solo: da 54,20% · 19.033 pip a **54,41% · 19.656**,
in salita su tutti e due i periodi (vecchio 54,53→54,67, recente 54,09→54,59). Le 110 carte
guida non cambiano di una (78 giuste, 32 storte). Il motore DLR non e' toccato (3.253 carte,
60,81%, 41.467 pip). **Ma il sistema peggiora**: la base canonica del Liu Yao scende da 59,22%
a 59,15% e da 37.026 a 36.885 pip; nella scala a voci le cinque voci concordi scendono da 221
carte al 76,02% (8.005 pip) a 211 al 75,36% (7.366 pip), mentre le sei voci restano 51 all'84,31%.
E' lo stesso caso del rafforzamento ritirato in S41: il Plum Blossom nel sistema fa da filtro,
non da voce. **Edu ha scelto di tenerla accesa**: la dottrina e' giusta e il PB da solo migliora.

**Parita PWA/backtest dopo la modifica:** 465 carte, 0 differenze su tutti i campi.

## S44 — 09/09/2026 · Il raduno stagionale (R6, via senza numero) · `RIDEFINITO DA EDU`

R6 e' una delle sei regole originali del motore (R1-R6, senza numero di sezione: nate prima
della numerazione, dalla dottrina classica del raduno dei tre rami della stagione 三會). Non ha
carta guida. Edu ha ridefinito COME SI COMPONE: due rami nella data e uno in una linea, o due
nelle linee e uno nella data; la linea che porta il ramo deve FARE QUALCOSA (mobile, Shi o Ying,
ferma clashata dal giorno, combinata, oppure con sopra la bestia dello stelo di un pilastro); e
l'ELEMENTO del raduno nel suo insieme deve essere timely. Lista di "linee che fanno qualcosa"
diversa da quella del 27/08 ("linee attive"): restano separate.
Misure (S17, 2.788 carte, base 59,15% · 36.885): regola completa con "timely" letto come 旺 o 相
58,86% · 36.254 (vec 57,01 / rec 60,85); solo filtro delle linee attive col mese fra i tre
59,00% · 36.691 (rec 60,77) — NON 59,15 come detto a Edu in chat: quel numero era il vecchio
R6 coi quattro pilastri (R6TIMELY=off R6ATTIVA=off). R6 SPENTA del tutto: 59,00% · 36.677. Col filtro la via
comanda 209 carte al 50,7% (mazzo 4.111): **la via da sola vale zero**. Cablata in liuyao.js
con flag: R6=vecchia (versione precedente), R6=off, R6TIMELY=off (mese fra i tre), R6ATTIVA=off,
R6COMB=mobile. Le carte guida restano 110/78.
**Lezione di Edu:** il raduno non e' un verdetto, e' una traccia; cablarlo come interruttore
che decide con la maggioranza di linee sopra/sotto e' l'errore rigido. Su USDJPY 08/02/2024
Edu lo legge col CARATTERE del suo elemento nel palazzo sulla linea che tocca (Legno = B nel
palazzo 震 -> fa perdere la squadra di L3); su USDCHF 15/07/2026 non lo usa affatto.

## S44 — 09/09/2026 · Il motore a principi v4: la raccolta delle prove · `MISURATA, BOCCIATA`

Impegno preso una settimana prima e lasciato cadere per dodici sessioni (v3 del 31/08, S31).
Cablato in motore_principi.js dietro MPRACCOLTA=1: ogni gradino che parla e' una prova (una per
ambito, con peso di salienza), conclusione sulla somma. MOSTRA=CROSS|data stampa il RACCONTO
(cosa salta all'occhio, lungo la strada, altre prove, conclusione). v3 riverificata: 53,80%.
Misure: somma pesata 52,60% · +9.065; pesi piatti 52,53%; prova piu' saliente 53,36%; parita'
= tace 51,99%. Tre o quattro prove concordi: 54-55%, come una sola. Carte guida: 53 giuste
contro 55 (termometro 64).
**Conclusione:** i gradini dopo il primo NON sono osservazioni indipendenti, sono ripieghi
("se non c'e' altro, il duello"); sommarli somma rumore. Il difetto e' COSA il motore vede.
La forma di Edu (dalle sue letture, sotto) NON e' una somma: protagonista -> conclusione
provvisoria -> cercare chi puo' ROVESCIARLA -> se nessuno la rovescia, e' fatta.

## S44 — 09/09/2026 · Tre carte lette da Edu e da Claude nella forma di Edu · `LETTURE GUIDA`

**USDJPY 08/02/2024 s148 (ema LONG, mercato LONG +123; catena SHORT via R6 ✗).** Edu: 1) la
prima cosa e' la Shi con W che si muove (mobile, Shi, W = spesso vittoria); 2) si muove in una
P perdente; 3) e' bloccata in posizione dal giorno (寅 combina l'arrivo 亥): non puo' saltare,
arriva e si ferma — sembra la fine; 4) cerca chi smentisce; 5) la bestia del mese cade su L3:
potrebbe sostituire la mobile col ramo del mese 寅, ma 寅 nel palazzo 震 e' un B perdente, non
cambia; 6) raduno di Legno 寅(mese)卯(ora)辰(L3): il Legno e' B, non cambia; 7) LONG.
**USDCHF 15/07/2026 s80 (ema LONG, mercato SHORT -40; catena SHORT via R6 ✓ per un'altra
strada).** Claude LONG ✗ (ha messo a dormire il raduno per i vuoti della data e ha fatto parlare
il carattere della PARTENZA, P). Edu: 1) L1 si muove per trasformarsi in C 子; 2) niente la
blocca, quindi cerca di fare qualcosa; 3) cosa? combinare, clashare O SEMPLICEMENTE GENERARE;
4) l'unica disponibile e' L3 W (子 genera 卯): SHORT, anche se la W e' untimely; 5) trigono
亥卯未 col mese, L3, L4: sostiene poco (Legno untimely, 亥 di L4 dell'altro campo) ma nulla
smentisce; 6) le bestie arrivano su quelle stesse linee: conferma; SHORT. **La mancanza di
energia = il trade manca di energia: va SHORT ma si muove poco** (-40).
**AUDUSD 22/12/2025 s66 (ema SHORT, mercato LONG +46; catena LONG via R6).** Claude LONG ✓:
L6 C -> 寅 timely, libera; l'arrivo combina la Ying W 亥 vuota ma svegliata dall'ora 辛巳 che
cade su L5 (clash 巳-亥) — W all'apice, tenuta: vince l'alto; Shi G ferma e non caricata non
smentisce; raduno d'Acqua e trigono di Metallo confermano. In attesa della lettura di Edu.

**Quattro correzioni di Edu (da cablare, non solo da annotare):**
 1. La mobile libera CERCA qualcosa da fare; tre porte: combinare, clashare, GENERARE.
 2. Parla chi RICEVE l'azione (la linea nutrita/tenuta), non il carattere della partenza.
 3. Il vuoto della data non addormenta la carta: pesa sulla linea che dovrebbe agire.
 4. L'energia decide la MISURA del movimento, non il verso.

**Cablaggi dalle correzioni (S44, stesso giorno):**
- Motore a principi, la terza porta GENERARE (MPGENERA, default acceso): se l'arrivo non combina
  e non clasha nessuna linea ferma, nutre la linea ferma del suo elemento figlio e parla chi
  riceve. Misura per carattere della nutrita: W 26 carte 57,7% +256 · G 17 al 23,5% -521 ·
  P 35 al 51,4% · B 21 al 42,9%. L'estensione a G/P/B era di Claude, non di Edu: bocciata,
  si cabla SOLO la W (MPGENERA=tutti la riapre). Mazzo 53,76% (da 53,80, dentro il rumore);
  carte guida 55 invariate.
- R6 col carattere (R6DIR=carattere, ancora dietro flag): il raduno agisce col carattere del suo
  elemento nel palazzo sulla linea toccata (G/W: la sede toccata vince; P/B: perde; C tace;
  serve una sede sola). Con il mese fra i tre: S17 59,15% · z 9,66 · 37.340 pip (vec 57,21 /
  rec 61,44) contro 59,15 · 36.885 (vec 57,76 / rec 60,60) della maggioranza; la via comanda
  199 carte al 55,3% (+1.512) contro 209 al 50,7% (+484) della maggioranza col filtro attive.
  Da decidere con Edu se diventa il default.

## S44 — 09/09/2026 · EURUSD 28/05/2026 s116: la guerra fra titani sulla mobile · `DOTTRINA DI EDU, CABLATA nel motore di lettura`

Carta: ema SHORT, mercato LONG +34; catena LONG per R4 "capolinea del flusso su una G sola"
(regola originale di Claude, non di Edu). Edu: "se il flusso finisce sulla Terra perche' non
il G 未 che e' anche mobile? Se la regola vale deve farlo per tutte le linee, specialmente
quelle mobili che sono quelle che agiscono." Cablato FLUSSOARR (l'arrivo della mobile entra
nel flusso di R2/R4): S17 da 59,15 a 58,79% (-1.500 pip): la regola tace su 55 carte (44 -> 33
giuste) e sull'arrivo come capolinea fa 6/14. Claude ha proposto di togliere R4; Edu: "ecco il
tuo errore, vedi che la % diminuisce e pensi subito che devi tagliare. Perche' non pensi che
quella traccia era una falsa pista e ce n'e' un'altra che ti e' sfuggita?"
La traccia vera (validata da Edu): la Ying 戌 G riceve il trigono di Fuoco 寅午戌 timely
(Fuoco genera Terra) -> la G nutrita vince la sede alta -> LONG, energia poca (mese 巳 vuoto).
Ma prima serve chi da' il COLPO FINALE a L1, perche' "una mobile che diventa G controllando
indietro la B salta all'occhio": Claude ha proposto l'anno 午 che clasha la partenza 子 e
combina l'arrivo 未. **Edu: NO — anno e mese non hanno la forza di clashare una linea, solo
il giorno puo' farlo. Ma le BESTIE hanno capacita' di intervento e intromissione.** Su L1
(玄武, bestia di 壬 e 癸) cadono il giorno 壬寅 e il mese 癸巳: 寅巳 e' una penalita' (刑), e
poiche' le bestie sono due e' una cosa grossa che salta all'occhio. **Uno scontro fra titani
in una linea la blocca completamente: nessun G, annullato causa guerra.**
Cablato in motore_lettura.js (MLGUERRA): due pilastri sulla stessa linea con rami in penalita'
o in clash fra loro -> linea annullata (la mobile non agisce, la ferma non e' bersaglio ne'
attore). Insieme: la linea ROTTA (untimely + clashata dal giorno) non agisce e non e' bersaglio
(MLROTTA); il trigono/raduno che non decide per sede NUTRE le G/W del suo figlio (MLNUTRE).
Il motore di lettura ora rifa' la lettura di Edu su questa carta (L1 annullata, L4 rotta,
il trigono di Fuoco nutre la Ying G -> LONG). Mazzo: 51,55% (invariato nel rumore); 486 carte
hanno una guerra su qualche linea. Correzione a chat: Claude aveva presentato il 未 come P;
nel palazzo 坎 la Terra e' G.

**PRINCIPIO DI RAGIONAMENTO (Edu, 09/09/2026, ripetuto due volte perche' Claude non l'aveva
scritto come principio):** trovare una traccia che porta alla vittoria NON basta se in carta
resta in piedi un segnale forte che dice il contrario (qui: la mobile che diventa G controllando
indietro la B, che "salta all'occhio"). Bisogna trovare anche CHI ANNULLA quel segnale (qui: la
guerra fra titani su L1). Finche' non lo si trova, la lettura non e' completa. "E' questo il
modo di ragionare, lascia stare i numeri." Nel motore di lettura: una traccia secondaria non
puo' scavalcare la mobile per 'forza' (MLSMENTITA=forza per l'audit); la mobile che parla decide,
e le altre confermano; solo l'ANNULLAMENTO della mobile (guerra, blocco del giorno con arrivo
muto, vuoto, autocombinazione...) apre la strada alla traccia successiva.

## S44 — 09/09/2026 · EURJPY 28/07/2025 s173: la mobile si occupa prima di se' stessa · `LETTURA DI EDU, CABLATA nel motore di lettura`

Carta: ema LONG, sistema LONG (§50d/e, l'arrivo combina la W di L4), mercato SHORT -159. Motore di
lettura: la Ying G va in 午 e tiene la W 未 di L4 -> LONG ✗. Edu: 1) la Ying si muove, salta
all'occhio; 2) PRIMA di occuparsi di altro si occupa di se' stessa: controlla indietro (回頭剋)
il G, negativo per la propria squadra; 3) poiche' e' la Ying, linea importante, e il Fuoco e'
forte, il G e' ANNULLATO e il C 午 ne prende il posto; 4) NON va a combinarsi con L4 perche'
una linea mobile non puo' fare due cose contemporaneamente; 5) il C resta sulla Ying, si
confronta con la Shi (B 卯, legata dal giorno, nella tomba) e vince -> sede bassa -> SHORT.
Principi: (a) il controllo indietro con arrivo forte e' l'AZIONE della mobile, e sostituisce il
carattere di partenza con quello d'arrivo; (b) una mobile non fa due cose: niente combinazioni
o clash su altre linee dopo il controllo indietro; (c) poi la linea col nuovo carattere, se e'
Shi o Ying, si confronta con l'altra e vince la piu' forte. Cablato MLINDIETRO (arrivo timely
che controlla la partenza -> nuovo carattere; Shi/Ying -> confronto di forza; altrimenti parla
il nuovo carattere). Il motore rifa' la lettura di Edu. Mazzo 51,14%, 153 carte per questa via.
Regola di presentazione (Edu, ripetuta): il SEME va scritto in testa alla carta, con cross e data.
**Precisazione di Edu (subito dopo): il principio (a) vale SOLO se avviene sulla Shi o sulla Ying.**
Altrove la mobile segue la strada normale. Cablato: MLINDIETRO solo con mobile Shi/Ying.

## S44 — 09/09/2026 · EURUSD 22/01/2026 s116: il pilastro sulla mobile si intromette nel passo · `LETTURA DI EDU, CABLATA nel motore di lettura`

Carta: ema LONG, sistema SHORT (§52), mercato LONG +83. Edu: 1) il pilastro 丙申 (il giorno)
arriva su L1 con la sua bestia e toglie al G 未 la possibilita' di controllare indietro — anche
perche' 申 Metallo assorbe la Terra di 未; 2) il B resta vincitore e fa perdere la propria
squadra -> il basso perde -> LONG. "Questa era facile, perche' non l'hai vista?" — perche' il
pilastro che cade sulla mobile era trattato solo come una CARICA (+forza), mai come una
INTROMISSIONE nel suo passo. Principio: il pilastro che cade sulla mobile, se il suo ramo drena
o controlla l'arrivo, neutralizza l'arrivo; la mobile resta col carattere di partenza e agisce
come tale. Cablato MLINTROMISSIONE (prima del controllo indietro e delle porte). Il motore
rifa' la lettura di Edu.

## S44 — 09/09/2026 · EURUSD 17/06/2026 s116: "e' sempre lo stesso meccanismo" · `VALIDATA DA EDU, CABLATA`

Carta: ema LONG, sistema LONG (§137), mercato SHORT -106. Mobile L3 G 辰 -> 亥, il giorno 戌
clasha la partenza; su L3 (朱雀) cadono 丙午 e 丁未. Edu: "il mese arriva su L3 e fa vincere la
squadra. Ma il motivo spiegamelo tu." Motivo (Claude, validato da Edu: "giusto, mi fa piacere
che inizi a pensare"): il 午 e' Fuoco e nutre la partenza 辰 direttamente sulla linea (anno e
mese 午, ora 未 Terra: la G e' alimentata tre volte); l'arrivo 亥 e' Acqua in prigione nel mese
di Fuoco e non ha la meglio sul 午 seduto sulla linea: la trasformazione in B non prende, la G
resta G nutrita e fa vincere la sua sede, il basso -> SHORT. Il clash del giorno sulla partenza
piena e nutrita non la rompe: la sveglia (暗動). Stesso meccanismo di EURUSD 22/01/2026 letto
dall'altro lato: la' il pilastro toglieva forza all'arrivo, qui ne da' alla partenza. Principio
allargato e cablato (MLINTROMISSIONE): il pilastro non vuoto che cade sulla mobile si intromette
nel passo quando il suo ramo assorbe o controlla l'arrivo, nutre la partenza o e' controllato
dall'arrivo — sempre, salvo quando nutre l'arrivo o e' del suo stesso elemento; la mobile resta
col carattere di partenza e agisce come tale.
**Correzione dello stesso giorno (Claude, verificata sulle sette carte lette in S44):** cablare
"la mobile resta col carattere di partenza" faceva sbagliare USDJPY 08/02/2024 (la W 辰 di L3
sarebbe rimasta W -> SHORT ✗). Il meccanismo generale e' quello che Edu aveva gia' detto su quella
carta: il pilastro che cade sulla mobile LA ANNULLA E SI SOSTITUISCE A LEI — il ramo del pilastro
prende la sede della mobile e parla col SUO carattere nel palazzo (G/W: la sede vince; P/B: perde;
C: tace). Verifica: 寅 = B -> LONG (08/02/2024 ✓), 申 = P -> LONG (22/01/2026 ✓), 午 = W -> SHORT
(17/06/2026 ✓). Ordine: dopo il blocco del giorno sull'arrivo, prima delle porte. Il giorno che
clasha una partenza piena e timely la sveglia (暗動), non la ferma; una partenza untimely e'
fermata. Il motore di lettura rifa' ora tutte e sette le carte di S44 come Edu.

## S44 — 09/09/2026 · USDJPY 09/02/2026 s157: letta da Claude da solo (Edu: "prosegui a cercare e trovare la via giusta da solo") · `VALIDATA CON COMPLETAMENTO`

Carta: ema LONG, sistema LONG (§137), mercato SHORT -135. Palazzo 離 Fuoco, mobile L5 C 未 Ying
-> 申 W. Lettura di Claude: 1) la Ying si muove: C che diventa W, salta all'occhio; 2) ma
l'arrivo 申 e' nato morto nel mese 寅 (絕) e il giorno 寅 lo clasha: la trasformazione in W non
prende, la linea parte e non arriva; 3) chi toglie di mezzo la mobile: il mese 庚寅 cade sulla
Ying con la Tigre Bianca e si sostituisce a lei — 寅 Legno nel palazzo di Fuoco e' un P, e il
P fa perdere la sua squadra: l'alto perde -> SHORT; 4) chi potrebbe smentire: la Shi G 亥 con
l'anno 丙午 sopra (午 = B qui, direbbe LONG) — ma e' legata dal giorno e untimely, non ha forza;
il trigono di Legno 亥卯未 col mese nutre il B 巳 di L6 (Legno genera Fuoco): B nutrito fa
perdere l'alto, conferma; 5) SHORT, con energia (pilastro intero del mese sulla Ying): -135.
Cablato nel motore di lettura la distinzione: il giorno che COMBINA l'arrivo lo tiene (arriva e
si ferma, parla il suo carattere); il giorno che CLASHA l'arrivo lo distrugge (parte e non
arriva: sostituzione se c'e' un pilastro sulla mobile, altrimenti resta se' stessa). Con questo
il motore rifa' tutte e otto le carte lette in S44.
**Edu: "Analisi giusta ma non fino alla fine. Se le bestie prendono possesso di Y o S poi si passa
al CONFRONTO DIRETTO."** Qui: il mese 庚寅 possiede la Ying (porta il Legno), l'anno 丙午 possiede
la Shi (porta il Fuoco); Legno genera Fuoco: la Shi e' nutrita e vince -> sede bassa -> SHORT.
Cablato (MLPOSSESSO): dopo la sostituzione su una Shi o una Ying, confronto diretto con l'altra,
ognuna col suo elemento (quello del pilastro che la possiede, altrimenti il proprio ramo): chi
riceve la generazione vince, chi controlla vince, altrimenti la piu' forte; pari -> nessuno. Vale
anche per la Shi/Ying FERMA posseduta da un pilastro (prima "agiva da sola", 50%). Le otto
carte di S44 restano lette come Edu.

## S44 — 09/09/2026 · USDJPY 30/09/2025 s148: gemella della prima carta, letta da Claude da solo · `BOCCIATA DA EDU (il legame), LETTA DA EDU COL RADUNO`

Stesso esagramma, stessa mobile (L3 W 辰 Shi -> 亥), stesso giorno 壬寅 e stessa ora 癸卯 di
USDJPY 08/02/2024 (+123 LONG, letta da Edu). Qui: anno 乙巳, mese 乙酉; ema LONG, sistema LONG
(§99), mercato SHORT -77. Lettura di Claude: 1) come nella gemella, la Shi W va in P e il giorno
la ferma: provvisoria LONG; 2) chi la annulla: il mese 乙酉 cade su L2 col Drago, accanto alla
Shi, e il suo 酉 combina la partenza 辰 (辰酉合): la Shi e' LEGATA PRIMA DI PARTIRE dalla bestia
del mese e presa dal Metallo, il re del mese; 3) confronto diretto con la Ying 未 Terra: Terra
genera Metallo, la Shi e' nutrita e vince -> sede bassa -> SHORT; 4) conferme: L5 酉 G all'apice
e' il vero padrone della carta; i raduni di Legno che a febbraio erano timely qui non lo sono e
non contano; il trigono 亥卯未 (B) sta in alto e fa perdere l'alto. Cio' che cambia fra le due
gemelle e' SOLO il mese: 寅 che cadeva sulla Shi e non cambiava nulla (B), 酉 che cade su L2 e
lega la Shi. Cablato MLLEGAME (pilastro non vuoto su un'altra linea il cui ramo combina la
partenza della mobile: mobile legata e posseduta da quell'elemento; Shi/Ying -> confronto
diretto), SUBORDINATO al possesso diretto (un pilastro sulla mobile stessa viene prima; senza
questa precedenza sbagliava USDJPY 09/02/2026 e EURUSD 22/01/2026). Le nove carte di S44 lette
come Edu (o come Claude, dove in attesa di validazione).
**Edu: "il mese 酉 che cade accanto NON combina."** Il legame da bestia su un'altra linea e' un'ipotesi
sbagliata di Claude: MLLEGAME spento (solo audit). Lettura di Edu: il raduno 寅卯辰 sta tutto con le
bestie nel trigramma inferiore (寅 su L2, 卯 dell'ora su L1, 辰 la Shi mobile su L3); un membro e' la
mobile, quindi il raduno SERVE LA LINEA (§133m del 04/09, estesa dal trigono al raduno): prende il
carattere della Shi, W, il basso vince -> SHORT. APERTO: nella gemella di febbraio (stesse bestie su
L1, stessa mobile) Edu aveva letto lo stesso raduno per ELEMENTO (Legno = B, "non cambia nulla") e
la carta era LONG. Cosa decide fra "serve la mobile" e "si legge per elemento" non e' ancora detto.

**LA DIFFERENZA FRA LE DUE GEMELLE s148 (Edu, 09/09/2026, risposta alla domanda aperta sopra):**
in USDJPY 08/02/2024 il mese 丙寅 arriva COMPLETAMENTE sulla linea mobile e la ANNULLA — "Chen non
c'e' piu'" — quindi 辰 non e' piu' membro del raduno 寅卯辰, che non serve la linea e resta un
contorno letto per elemento (Legno = B, non cambia il responso; il sostituto 寅 e' B e fa perdere
il basso -> LONG). In USDJPY 30/09/2025 nessun pilastro cade su L3: 辰 NON e' interferito, resta,
e il raduno — tutto con le bestie nel trigramma inferiore — HA LA MOBILE FRA I MEMBRI e serve la
linea: prende il carattere della Shi, W, il basso vince -> SHORT.
Cablato: (a) la mobile su cui cade un pilastro non vuoto e' ANNULLATA e non e' membro di raduni o
trigoni; (b) un raduno/trigono che ha la mobile fra i membri serve la linea e ne prende il
carattere (MLSERVE); (c) il confronto diretto dopo il possesso vale quando le bestie possiedono
ENTRAMBE le sedi (USDJPY 09/02/2026), altrimenti parla il carattere del ramo sostituito
(USDJPY 08/02/2024). Con questi tre, il motore rifa' tutte e dieci le letture di S44.

## S45 — 09/09/2026 · Il motore di lettura ricostruito · `RICOSTRUZIONE`

Il `motore_lettura.js` scritto in S44 non e' mai arrivato nell'archivio: non era nell'elenco di
consegna.sh, quindi non e' finito nello zip e non e' stato spinto sul repo. pb_stress.js lo
richiedeva e si fermava con un errore. Ricostruito da questa sezione del registro e verificato
sulle NOVE carte lette in S44: le rifa' tutte, ognuna per la traccia con cui era stata letta.
Ordine delle tracce: guerra fra titani (T0) · il malus che retrocede o avanza (T1a) · la
sostituzione (T1) · il confronto diretto (T1b) · la mobile si occupa di se' (T2) · il raduno che
serve la linea (T3) · il giorno sull'arrivo (T4) · le tre porte (T5) · il trigono che nutre (T6).
Mazzo intero 50,54% · +4.610 pip (la versione di S44 stava fra 50,5 e 51,5).

**Tre correzioni fatte da Claude in S45, tutte DA VALIDARE:**
1. *L'intromissione del pilastro vale solo a passo chiuso.* Il pilastro si intromette nel PASSO
   della mobile: puo' farlo solo quando il passo non esce verso un'altra linea — movimento nullo
   (il giorno lo ferma) o controllo indietro sulla partenza (回頭剋, caso 3). Se la mobile e'
   libera e va ad agire fuori, il pilastro non la ferma. E' la differenza fra USDCHF 15/07/2026
   (libera, caso 4: Edu la legge con le tre porte) e USDJPY 08/02/2024, EURUSD 22/01/2026,
   EURUSD 17/06/2026, USDJPY 09/02/2026 (passo gia' fermo o controllo indietro: Edu usa il
   pilastro). La relazione fra pilastro e arrivo e' la stessa in tutte — 寅 Legno assorbe
   l'Acqua sia in USDCHF sia in USDJPY 08/02/2024 — quindi non e' li' la differenza.
   Con questo USDCHF torna a essere letta con le porte come l'ha letta Edu.
2. *Il pilastro che CLASHA il ramo della linea non ne prende possesso.* Dottrina gia' di Edu
   (29/08/2026: stesso ramo carica, la combinazione blocca, il clash scaccia); nel motore
   mancava, e ogni pilastro caduto su una linea contava come possesso. Tocca la sostituzione
   e il confronto diretto fra le due sedi.
3. *Il malus che retrocede o avanza era rimasto fuori.* Rimesso, e messo PRIMA della
   sostituzione, perche' nella regola sopra le regole "ritirata/avanzata" sta dentro l'azione
   della mobile, che viene per prima. Nessuna delle nove carte di S44 ha una progressione,
   quindi lo spostamento non le tocca.

**Carta letta da Claude da solo · USDJPY 01/12/2022 seme 137 · `DA VALIDARE`**
E' la peggiore delle 25 perdenti del gradino "confronto diretto fra le due sedi possedute"
(-201 pip). Palazzo 乾 Qian (Metallo), mese 亥 (Acqua di stagione), giorno 戊子, ora 丙辰,
anno 壬寅. Mobile L3, la Ying, Genitori 辰 Terra che va in 丑 Terra.
Lettura di Claude: 1) il protagonista e' la Ying che si muove, e la prima cosa che salta
all'occhio e' che si muove DENTRO il proprio elemento, all'indietro: 辰 → 丑 e' una ritirata
(退神); 2) un Genitori e' un danno per la propria squadra, e un danno che si ritira porta via
se stesso: la sede bassa vince → SHORT; 3) chi puo' smentire: il mese 辛亥 cade sulla Ying
con la Tigre Bianca e potrebbe sostituirsi a lei, ma 亥 Acqua nel palazzo di Metallo e' un
Figli, che tace, quindi non rovescia niente; l'ora 丙辰 cade sulla Shi ma il suo 辰 clasha il
戌 della Shi, quindi la disperde invece di possederla — il confronto diretto fra le due sedi
non si apre; 4) conferma: le uniche linee vive del basso sono la Ricchezza 寅 di L2, di stagione
e con il Tai Sui, e i Figli 子 di L1 caricati dal giorno — il basso e' la parte in forza;
5) SHORT. Esito: SHORT -201.
**VALIDATA da Edu** (09/09/2026): "Analisi giusta, il pezzo forte e' la P che retrocede che fa
vincere la propria squadra. Il resto sono conferme che convalidano." Quindi: la traccia che
decide e' la ritirata del Genitori; il mese che non riesce a sostituirsi, l'ora che clasha la
Shi invece di possederla e la forza del basso NON sono voti che si sommano — sono conferme che
non smentiscono la conclusione provvisoria. Confermato anche l'ordine: la ritirata della mobile
viene prima della sostituzione del pilastro.

Il gradino del malus che retrocede, misurato da solo, sta al 47,8% su 161 carte: la forma e'
giusta su questa carta ma su molte altre la traccia seguita e' una falsa pista, da cercare
carta per carta.

**Carta letta da Claude da solo · USDJPY 28/04/2025 seme 143 · `DA VALIDARE`**
Peggiore delle perdenti del gradino "il malus che retrocede" (-178 pip). Palazzo 乾 Qian
(Metallo), mese 辰 (Terra e Legno di stagione), giorno 丁卯, ora 戌, anno 巳, vuoti 戌 亥.
Mobile L6, Genitori 戌 Terra che va in 未 Terra: e' la stessa ritirata (退神) validata da Edu
su USDJPY 01/12/2022, ma qui il verdetto e' rovesciato.
Lettura di Claude: la differenza sta in COSA il giorno tiene. Su USDJPY 01/12/2022 il giorno
子 combinava l'ARRIVO 丑: la linea partiva, arrivava e si fermava — la ritirata si compiva, il
danno si portava via, la sede vinceva. Qui il giorno 卯 combina la PARTENZA 戌 (卯戌合): la
linea resta impigliata dov'e' e non parte affatto. Non si ritira nulla. Il Genitori resta al
suo posto, pieno e di stagione, e un danno che resta fa perdere la propria squadra: la sede
alta perde -> SHORT. Esito: SHORT -178.
Cablato come `T1a il malus impigliato` (interruttore MLIMPIGLIO), dentro il gradino della
progressione, prima della ritirata. Vale su 21 carte al 47,6%: la carta e' giusta e il
meccanismo regge, ma il gradino della ritirata resta al 47,6% su 143 carte — sulle altre
perdenti la falsa pista e' un'altra e va cercata carta per carta, non con un filtro.

**Carta letta da Claude da solo · USDJPY 11/07/2024 seme 161 · `DA VALIDARE`**
Peggiore delle 383 perdenti del gradino "le tre porte" (-263 pip). Palazzo 坤 Kun (Terra),
mese 未, giorno 丙子, ora 辰, anno 辰, vuoti 申 酉. Mobile L6, Fratelli 戌 Terra di stagione
che va in 巳 Fuoco. Caso 1: l'arrivo GENERA la partenza (回頭生).
Lettura di Claude: e' il gemello del controllo indietro che Edu ha letto su EURJPY 28/07/2025.
Li' l'arrivo tornava indietro e CONTROLLAVA la partenza; qui torna indietro e la NUTRE. In
entrambi i casi la mobile si occupa prima di se' stessa, e una linea mobile non puo' fare due
cose insieme (parole di Edu su quella carta): quindi NON va alle porte a cercare qualcosa da
combinare o da generare. Resta se' stessa, rinforzata. La linea e' un Fratelli, cioe' un danno
per la propria squadra, e sta in alto: l'alto perde -> SHORT. Esito: SHORT -263.
Differenza con la carta di Edu: li' l'arrivo sostituiva il carattere della partenza, e per
questo Edu aveva limitato il principio alla Shi e alla Ying. Qui non c'e' nessuna sostituzione
di carattere - la partenza viene nutrita e resta quello che era - quindi la limitazione a
Shi/Ying non serve.
Cablato come `T2b nutrita dall'arrivo` (interruttore MLNUTRITA), accanto al gradino "si occupa
di se'". Comanda 252 carte al 54,76% (+1.178 pip); il gradino delle tre porte scende da 760 a
579 carte. Mazzo intero da 50,25% a 50,91% (+4.948 pip), periodo recente 51,77%.

## S45 · CORREZIONE DI EDU su USDJPY 11/07/2024 — `CONFERMATA DA EDU`
La lettura di Claude (l'arrivo nutre la partenza, la B resta se' stessa rinforzata) arrivava al
verso giusto per la ragione sbagliata: quella B non parte nemmeno.
Parole di Edu (09/09/2026): "B Xu L6 non puo' neanche partire perche' il Tai Sui con la bestia
arriva su quella linea. Clasha e blocca tutto. Se non l'avesse fatto il risultato sarebbe stato
long perche' P si generando indietro sarebbe entrato nella sua tomba (Xu e' la tomba del fuoco),
e se P o B entrano nella tomba non fanno piu' perdere la propria squadra."

**Regola 1 — il Tai Sui che clasha blocca.** L'anno 甲辰 arriva su L6 con il Drago Azzurro
(stelo 甲) e il suo 辰 clasha il 戌 della linea. Non e' lo scacciamento di un pilastro qualunque
(che toglie il possesso ma lascia agire): il Tai Sui ferma il passo in partenza. La linea resta
quello che era — una B in alto — e la B fa perdere la propria squadra: l'alto perde -> SHORT.
Cablata come `T0b il Tai Sui blocca` (MLTAISUI), subito dopo la guerra fra titani e prima di
ogni altra traccia. 34 carte, 44,12%, +165 pip.

**Regola 2 — P o B nella tomba non nuocciono piu'.** Senza il blocco, il passo sarebbe stato:
l'arrivo 巳 Fuoco e' un P nel palazzo 坤 (il Fuoco genera la Terra) e generando indietro finisce
in 戌, che e' la TOMBA del Fuoco. Un P o una B che entrano nella propria tomba smettono di far
perdere la loro squadra: la sede su cui stanno vince -> sarebbe stato LONG.
Tombe: Legno 未 · Fuoco 戌 · Metallo 丑 · Acqua 辰 · Terra 辰.
Cablata come `T2b sepolto nella tomba` (MLTOMBA), dentro il ritorno che nutre. 4 carte.

DA CHIARIRE CON EDU (Claude ha cablato stretto per non inventare):
- il blocco del Tai Sui vale solo sulla mobile o su qualunque linea su cui il Tai Sui cade
  clashando? E vale solo il Tai Sui, o anche mese/giorno/ora che clashano la linea su cui cadono?
- la tomba: cablata solo dentro il ritorno che nutre. La frase di Edu suona generale — ogni P o
  B che entra nella propria tomba, comunque ci arrivi.
Mazzo intero: 50,91% -> 50,67% (+4.365 pip), recente 51,40%. Le dodici carte di riferimento
restano tutte giuste.

## S45 · REGOLA DELLE BESTIE — parole di Edu (09/09/2026)
"Se una bestia arriva e clasha una linea mobile la blocca e non puo' muoversi, se la controlla o
la drena, si impadronisce della linea. Se clasha una linea ferma la fa muovere e se la controlla
o la drena si impadronisce della linea."

CABLATO — la parte del clash: il blocco della mobile non e' piu' riservato al Tai Sui, vale per
qualunque pilastro che cada sulla linea con la sua bestia e ne clashi il ramo. Se piu' pilastri
cadono sulla stessa linea comanda il piu' forte, giorno > mese > anno > ora. Il gradino passa da
34 a 108 carte, dal 44,12% al 53,70% (+734 pip). Mazzo 50,77%, recente 51,29%. Dodici carte di
riferimento tutte giuste. La linea ferma clashata da una bestia era gia' trattata come linea che
"fa qualcosa".

NON CABLATO — la parte del possesso, perche' contraddice tre carte lette da Edu stesso. In tutte
e tre il pilastro che Edu usa NON controlla ne' drena la linea: la NUTRE, o e' controllato da lei.
  · EURUSD 22/01/2026 — giorno 丙申 su L1 子: 申 Metallo genera l'Acqua 子, la nutre.
  · EURUSD 17/06/2026 — anno 丙午 su L3 辰: 午 Fuoco genera la Terra 辰, la nutre.
  · USDJPY 09/02/2026 — anno 丙午 sullo Shi L2 亥: e' 亥 che controlla 午, non il contrario.
Domanda aperta per Edu: il nutrimento e' una terza via per impadronirsi della linea, oppure in
quelle tre carte il pilastro fa qualcosa di diverso dall'impadronirsi?

**Carta letta da Claude da solo · USDJPY 02/10/2024 seme 143 · `DA VALIDARE`**
Peggiore perdente di tutto il motore (-265 pip), sul gradino "la mobile si occupa di se'".
Palazzo 乾 Qian (Metallo), mese 酉 (Metallo di stagione), giorno 己亥, ora 戌, anno 辰,
vuoti 辰 巳. Mobile L2, lo Shi, G 午 Fuoco che va in 亥 Acqua: controllo indietro (回頭剋).
Il Fuoco nel mese di Metallo e' morto, l'Acqua e' in crescita: il controllo indietro riesce e
lo Shi finisce ucciso dal proprio arrivo, diventando un C.
Lettura di Claude: fin qui il motore faceva come sulla carta di Edu (EURJPY 28/07/2025) e poi
decideva il confronto fra le due sedi con la relazione — il Metallo della Ying genera l'Acqua
dello Shi, chi e' nutrito vince, quindi lo Shi -> SHORT. Sbagliato di 265 pip.
Il punto: dopo un controllo indietro la linea non e' "diventata" l'arrivo per scelta sua, ci e'
finita perche' il proprio arrivo l'ha uccisa. Li' non decide chi genera chi, decide chi delle
due sedi resta piu' forte. Qui la Ying L5 e' una B 申 Metallo prospera e piena, lo Shi e' un C
appena scampato: vince la Ying, sede alta -> LONG. Esito: LONG +265.
Sulla carta di Edu la stessa prova da' lo stesso verdetto che aveva dato lui: la sua Ying era
un 午 Fuoco prospero e lo Shi un B 卯 legato dal giorno e in tomba — vince la Ying, SHORT.
Cablato: nel confronto dopo il controllo indietro decide la FORZA (peso di stagione 旺+2 相+1
休0 囚-1 死-2, meno la linea vuota, meno la linea legata/rotta/dormiente, piu' o meno il giorno,
piu' la bestia che ci cade). Nel possesso delle bestie invece resta la relazione, come l'ha
letta Edu su USDJPY 09/02/2026.
Gradino "si occupa di se'": da 42,86% a 75,00% su 24 carte (+963 pip).
Mazzo intero da 50,99% a 51,46% (+5.528 pip), recente 52,46%. Dodici carte tutte giuste.

**CORREZIONE DI EDU sulla stessa carta (USDJPY 02/10/2024) — `CONFERMATA DA EDU`**
Parole di Edu: "Se C elimina G, W ne prende il posto e Shi vincerebbe comunque contro Ying.
Quello che succede e' che C 亥 va a generare W 寅 che quindi diventa Shi e... perde."
Claude aveva il verso giusto ma la sede sbagliata: aveva lasciato sullo Shi l'ARRIVO (il C 亥).
Non e' cosi'. Quando il controllo indietro elimina il carattere della linea, il 伏神 nascosto
sotto quella linea NE PRENDE IL POSTO, e ci arriva perche' l'arrivo lo tira fuori — qui il C 亥
combina e genera il W 寅 nascosto sotto lo Shi. Da quel momento lo Shi e' un W 寅 Legno, non un
C Acqua. E il Legno nel mese 酉 e' morto, mentre la Ying e' una B 申 Metallo prospera che lo
clasha e lo controlla: lo Shi perde, la sede bassa perde -> LONG.
Cablato dentro il gradino "si occupa di se'" (interruttore MLFUSHEN): se la linea ha un nascosto
e l'arrivo lo combina o lo genera, il nascosto prende la sede col proprio elemento e carattere,
e il confronto di forza si fa con lui.

**Carta letta da Claude da solo · GBPUSD 15/12/2022 seme 124 · `DA VALIDARE`**
Peggiore perdente del motore (-240 pip), sul gradino "il malus che avanza". Palazzo 巽 Xun
(Legno), mese 子 (Acqua di stagione), giorno 壬寅, ora 卯, anno 寅, vuoti 辰 巳.
Mobile L2, B 寅 Legno, Tai Sui e ramo del giorno, che avanza in 卯 (進神).
Il motore diceva: un B che avanza fa crescere il proprio danno, la sua sede perde, il basso
perde -> LONG. Sbagliato di 240 pip.
Lettura di Claude: il B non se ne sta fermo a nuocere a casa propria. Avanza, e avanzando il suo
arrivo 卯 va a combinare (卯戌合) la W 戌 di L4, che e' lo Shi. Un B e' il ladro della W: non la
fa parlare, gliela porta via. Il danno non resta alla sede del B, va dove il B colpisce — la
sede alta perde -> SHORT. Esito: SHORT -240.
Conferma che non smentisce: su L1 cadono tutti e quattro i pilastri (stelo 壬 o 癸, tutti Tartaruga
Nera), e fra i loro rami 子 e 卯 sono in penalita': scontro fra titani, la Ying e' annullata e
non puo' rispondere del furto.
Cablato come `T0c il B ruba la W` (MLLADRO), prima del gradino della progressione: vale quando
l'arrivo della mobile e' un B nel palazzo e combina o controlla una W viva.
195 carte al 52,82%. Il gradino "il malus avanza" scende da 87 a 69 carte e sale al 49,28%.
Mazzo intero 51,48% (+4.785 pip), recente 52,17%. Dodici carte di riferimento tutte giuste.

**CORREZIONE DI EDU su GBPUSD 15/12/2022 — `CONFERMATA DA EDU`**
Parole di Edu: "Dal momento che S riceve una B avanzante 'diventa' legno. Ma anche Y diventa
legno perche' tutti i pilastri convergono li'. La penalita' fra Mao e Zi non c'e' perche' Mao
non e' da solo su L1 ma sta insieme a due Yin (la penalita' fra due rami esiste come rapporto
univoco fra i due, se ce ne sono altri non c'e'). Quindi se Y e S sono entrambi legno, chi vince?
Vince Y perche' 1) c'e' anche Zi acqua che genera il Legno, 2) i pilastri sono molto piu' forti
delle singole linee."

1. **La penalita' e' un rapporto univoco.** 刑 fra due rami vale solo se sono soli. Se sulla
   linea ce ne sono altri, la penalita' non c'e'. Il "titano" di L1 in questa carta quindi non
   esiste: 卯 sta insieme a due 寅. Cablato nella guerra fra titani: la penalita' vale solo con
   esattamente due pilastri sulla linea (il clash resta come prima).
2. **Il furto non chiude il conto: apre un confronto.** La W derubata non perde per il fatto di
   essere derubata — "diventa" dell'elemento del B che l'ha presa. Se anche l'altra sede e'
   stata presa dai pilastri, diventa a sua volta del loro elemento, e le due sedi si confrontano.
   Qui tutti e quattro i pilastri cadono su L1 (steli 壬/癸, tutti Tartaruga Nera) e sono 寅寅卯,
   Legno: la Ying diventa Legno. Lo Shi diventa Legno anche lui. Pari elemento, quindi decide la
   forza, e vince la Ying perche' i pilastri pesano molto piu' delle singole linee e perche' c'e'
   il 子 Acqua che nutre il Legno. Sede bassa -> SHORT.
3. **I pilastri pesano.** Nella misura della forza ogni bestia che cade sulla linea conta una
   volta (prima contava uno solo che ce ne fosse almeno una), piu' un punto se un ramo della
   data genera l'elemento.
Il confronto si apre solo quando ANCHE l'altra sede e' posseduta dai pilastri; se l'altra sede e'
rimasta se stessa, la W derubata perde e basta (cablato cosi': aperto sempre costava 3 punti).
Gradino T0c: 199 carte al 52,26% (+547 pip). Mazzo 51,42% (+5.022 pip), recente 51,86%.
Dodici carte di riferimento tutte giuste.

**Carta letta da Claude da solo · USDJPY 13/12/2023 seme 145 · `DA VALIDARE`**
Peggiore perdente del motore (-240 pip), sul gradino nuovo "il B ruba la W". Palazzo 坤 Kun
(Terra), mese 子 (Acqua di stagione), giorno 乙巳, ora 子, anno 卯, vuoti 寅 卯.
Mobile L3, B 辰 Terra che va in 丑 Terra: stesso elemento, RETROCEDENTE (退神). L'arrivo 丑
combina la W 子 di L1.
Il motore leggeva il furto: il B raggiunge la W, gliela porta via, quella sede perde -> LONG.
Sbagliato di 240 pip.
Lettura di Claude: quel B non sta andando da nessuna parte, si sta RITIRANDO. Le parole di Edu
sulla carta precedente erano precise: "S riceve una B AVANZANTE". Un B che avanza cresce e
arriva addosso alla W; un B che si ritira porta via il proprio danno, ed e' la regola che Edu
ha validato su USDJPY 01/12/2022. Qui il giorno 巳 non combina ne' clasha la partenza 辰, quindi
la ritirata si compie davvero: il danno se ne va, la sede bassa vince -> SHORT. Esito: SHORT -240.
Cablato alla lettera: ruba solo il B che AVANZA (進神). Misurate tutte e due le versioni:
escludendo solo la ritirata il gradino fa 157 carte al 50,96% e il mazzo 51,32%; alla lettera
(solo 進神) fa 13 carte al 53,85% e il mazzo 51,53% (+6.065 pip), recente 52,20%. Tenuta la
versione alla lettera: le altre 144 carte si leggono meglio da sole, per altre tracce.
Dodici carte di riferimento tutte giuste.

**CORREZIONE DI EDU sulla stessa carta — `CONFERMATA DA EDU`**
"Se la B si ritira perde energia quindi non si combina con niente a meno che sia Timely. In ogni
caso la tua analisi e' giusta: B che si ritira fa vincere la propria squadra."
E' la ragione fisica sotto la regola: non e' che il B "sceglie" di non rubare, e' che ritirandosi
non ha piu' l'energia per combinarsi con nessuno. Se pero' e' di stagione, l'energia ce l'ha
ancora e puo' agire lo stesso. Qui il 辰 Terra nel mese 子 e' 囚, quindi niente.
Cablato come `MLRITIRATA`: la mobile che retrocede e non e' di stagione non arriva alle tre
porte. Costa 14 carte e un decimo di punto sul mazzo (51,53% -> 51,43%, +5.745 pip, recente
52,02%): non si taglia, e' una regola di Edu e la carta e' giusta.

**Carta letta da Claude da solo · EURJPY 11/07/2024 seme 175 · `DA VALIDARE`**
Peggiore perdente del motore (-233 pip). Palazzo 艮 Gen (Terra), mese 未, giorno 丙子, ora 午,
anno 辰, vuoti 申 酉. Mobile L1, B 辰 Terra, Tai Sui, di stagione, che va in 卯.
Caso -4: l'arrivo 卯 e' nella tomba del mese (未 e' la tomba del Legno) ed e' punito dal giorno
(子刑卯). La linea NON SI MUOVE.
Il motore la faceva servire da un raduno e leggeva la B: sede bassa perde -> LONG. Sbagliato.
Lettura di Claude: una mobile che non si muove non e' un passo finito male, e' un passo che non
parte. E' fuori dai giochi e non puo' nemmeno essere servita da un raduno. Tocca a chi resta.
Sulla Ying L6 arrivano DUE bestie, l'anno 甲辰 e l'ora 甲午, tutte e due Drago Azzurro (stelo 甲):
due bestie si impadroniscono sempre della linea. La Ying, che era un G 卯 Legno — per giunta in
tomba nel mese e punito dal giorno — diventa 辰 Terra, che nel palazzo 艮 e' un B. Il B fa perdere
la propria squadra: sede alta perde -> SHORT. Esito: SHORT -233.
Cablati due pezzi: `MLFERMA` (il caso -4 mette la mobile fuori dai giochi) e `MLSEDEPRESA`
(con la mobile ferma parla la sede di cui le bestie si sono impadronite; se sono prese tutte e
due si confrontano con la relazione, come su USDJPY 09/02/2026).
T4b la sede presa: 119 carte al 50,42%. T4b le due sedi prese: 26 carte al 46,15%.
Mazzo da 51,43% a 51,33% (+5.428 pip), recente 52,22%. Dodici carte di riferimento tutte giuste.

## S45 · CORREZIONE DI EDU su EURJPY 11/07/2024 — `CONFERMATA DA EDU`
"Su Y arrivano le bestie e che si prende l'energia finale che parte da Mao va su Wu e finisce su
Chen. Quindi Y e' Chen. E poiche' questo avviene su Y deve partire subito il confronto con S.
E S vince."
L'elemento che resta su una linea presa dalle bestie NON e' quello del pilastro piu' forte: e' il
CAPOLINEA della catena dell'energia. Si parte dal ramo della linea e si passa di bestia in bestia
seguendo la generazione: 卯 Legno -> 午 Fuoco -> 辰 Terra. La Ying e' 辰 Terra.
E poiche' la presa avviene su una SEDE, parte subito il confronto con l'altra: la Terra della Ying
genera il Metallo dello Shi, lo Shi e' nutrito e vince, sede bassa -> SHORT.

## S45 · DUE RETTIFICHE DI CLAUDE
1. **La stagione era misurata male.** Claude aveva detto a Edu che la divisione timely/untimely
   su un gradino era artefatto di una prova sbagliata, e aveva messo al suo posto una prova che
   guardava SOLO l'elemento della stagione: sbagliata in senso opposto (nel mese 未 il Metallo
   risultava morto invece che in crescita). La regola vera e' quella di liuyao.js (stadioMese):
   il migliore fra il conto sul ramo del mese e quello sulla stagione, e la Terra prospera nei
   quattro mesi di Terra. Rimessa cosi'.
2. **La linea impigliata dal giorno non "fa qualcosa".** Il giorno che COMBINA una linea la
   impiglia: quella linea non agisce e non puo' essere membro di un raduno. Claude la contava
   fra quelle attive, cioe' l'opposto. Per questo USDCHF 15/07/2026 (una delle nove di Edu) era
   finita sul trigono 亥卯未, che prendeva il suo 亥 da L4 tenuta legata dal giorno 寅. Corretta:
   la carta torna sulle tre porte come l'ha letta Edu.
   Corretto anche il controllo delle dodici carte, che passava in silenzio quando il motore
   andava in errore (zero righe di output = "tutte giuste").
Stato: dodici carte di riferimento tutte giuste. Mazzo 50,45% (+665 pip), recente 51,56%.
Il buco piu' grande e' ora il gradino del raduno: 477 carte al 48,64%, -1.416 pip.

**Carta letta da Claude da solo · EURJPY 10/02/2026 seme 185 · `DA VALIDARE`**
Peggiore perdente del gradino del raduno (-223 pip). Palazzo 艮 Gen (Terra), mese 寅 (Legno di
stagione), giorno 乙卯, ora 辰, anno 午, vuoti 子 丑. Mobile L6, G 寅 Legno, di stagione.
Caso -1: il giorno 卯 clasha l'arrivo 酉, che quindi non arriva.
Il motore faceva servire la mobile dal raduno 寅卯辰 e leggeva il G: sede alta vince -> LONG.
Lettura di Claude: quel raduno di Legno non fa vincere nessuna sede, perche' il Legno non sta
solo su L6. Sta anche sullo Shi L2, che e' un G 寅 identico, di stagione e pieno. Lo stesso
carattere seduto tutte e due le parti della carta non fa pendere niente. Lo stesso vale quando
il giorno distrugge l'arrivo e parlerebbe la partenza: e' sempre lo stesso Legno da tutte e due
le parti.
Allora restano il soggetto e l'oggetto, ed e' l'ultimo gradino della regola sopra le regole.
La Ying L5 e' una W 子 vuota ED ELIMINATA: non c'e'. Lo Shi L2 e' un G di stagione, pieno, con
l'anno che ci cade sopra. Vince lo Shi, sede bassa -> SHORT. Esito: SHORT -223.
Cablati due pezzi: `MLRADSEDE` (la mobile che NON e' una sede non fa vincere la propria sede se
lo stesso elemento siede sullo Shi o sulla Ying dall'altra parte; se la mobile e' lei stessa una
sede parla per se' e basta, come su USDJPY 30/09/2025) e `MLDUELLO` (l'ultimo gradino: il duello
Shi/Ying, che decide SOLO quando una delle due sedi e' fuori dai giochi e l'altra no).
Costo onesto: col duello acceso il mazzo fa 50,22% (recente 50,94%), spento 50,49% (recente
51,14%). Il duello parla su 222 carte al 47,75%. Il pezzo e' mio, non di Edu: la carta e' giusta
ma la mia versione del duello e' debole, ed e' il prossimo posto da cui prendere carte.
Dodici carte di riferimento tutte giuste.

**CORREZIONE DI EDU su EURJPY 10/02/2026 — `CONFERMATA DA EDU`**
"Le bestie Geng Yin e Geng Chen arrivano su Y e prendono possesso. Bing Wu arriva su S e va a
coincidere con la nascosta P 午. Fra S e Y vince S."
Claude era arrivato a SHORT col duello fra le sedi misurato a forza. La strada vera e' un'altra:
non un duello di forza, ma le due sedi prese dalle bestie e confrontate con la relazione.
  · Ying L5: ci arrivano il mese 庚寅 e l'ora 庚辰, tutte e due Tigre Bianca (stelo 庚). Due
    bestie prendono sempre possesso. Dal 子 Acqua l'energia passa in 寅 Legno: la Ying e' Legno.
  · Shi L2: ci arriva l'anno 丙午 (Uccello Rosso) e il suo ramo 午 COINCIDE con la P 午 nascosta
    sotto lo Shi: la tira fuori. Lo Shi diventa Fuoco.
  · Legno genera Fuoco: la Ying nutre lo Shi, lo Shi e' nutrito e vince, sede bassa -> SHORT.
NUOVO: il pilastro che arriva su una linea con lo STESSO RAMO del suo 伏神 ci coincide e lo tira
fuori — la linea prende l'elemento e il carattere del nascosto. Cablato in elDopoLeBestie.
Cablato anche che le sedi prese dalle bestie parlano non solo quando la mobile e' annullata, ma
anche quando la mobile e' viva e non riesce a far pendere niente.
Stato: dodici carte tutte giuste. Mazzo 50,28% (+3.110 pip), recente 50,91%; col duello spento
50,47% e 51,00%.

**ATTENZIONE — andamento da guardare prima di aggiungere altro.** Negli ultimi quattro giri il
mazzo e' sceso da 51,53% a 50,28%. Ogni correzione di Edu e' giusta sulla sua carta, ma le
generalizzazioni che ne ha tratto Claude girano sotto il 50%: T4b la sede presa 341 carte al
47,80%, T3 il raduno serve 359 al 48,75%, T7 il duello 195 al 48,21%. Il problema non sono le
regole di Edu, e' l'ampiezza con cui Claude le applica. Prossimo passo: non aggiungere tracce,
ma ripassare queste tre e restringerle sulle carte che le autorizzano.

## S45 · RIPASSO DEL GRADINO "la sede presa dalle bestie" (341 carte al 47,80%)
Spaccato per numero di bestie sulla sede presa: 1 bestia ~51%, 2 bestie ~45%, 3 bestie ~30%.
Cioe' piu' bestie ci sono, peggio va — il contrario di quello che dice la regola di Edu.

**Carta letta da Claude da solo · USDCAD 18/03/2020 seme 142 · `DA VALIDARE`**
Peggiore perdente del gradino (-266 pip). Palazzo 離 Li (Fuoco), mese 卯 (Legno di stagione),
giorno 庚申, ora 酉, anno 子, vuoti 子 丑. Mobile L4, lo Shi, B 午 Fuoco, caso -4: si
autocombina col proprio arrivo 未 e resta ferma.
Il motore prendeva possesso della Ying L1 e concludeva SHORT. Due errori, tutti e due di Claude:
1. **Una bestia col ramo VUOTO non prende possesso di niente.** Sulla Ying arrivano l'anno 庚子
   e il giorno 庚申, tutte e due Tigre Bianca. Ma 子 e' VUOTO in questa decade: non prende niente.
   E il giorno 申 CLASHA il 寅 della Ying, quindi non la possiede — la SVEGLIA (暗動), com'e'
   scritto nella regola di Edu. Quindi la Ying non e' presa da nessuno: resta un P 寅 Legno,
   di stagione e sveglio.
2. **La linea svegliata dal giorno non veniva mai letta.** Con la mobile ferma, quella Ying
   svegliata e' l'unica linea che sta agendo in tutta la carta. E' un P, e il P fa perdere la
   propria squadra: sede bassa perde -> LONG. Esito: LONG +266.
Cablati: il ramo vuoto non possiede (dentro l'azione delle bestie) e `T4c la svegliata dal
giorno` (con la mobile fuori dai giochi parla l'unica linea svegliata dal clash del giorno).
Effetto: le sedi prese da UNA bestia salgono a 52,8% e 54,9%; quelle da due o tre restano
intorno al 45% e sono il prossimo posto da guardare — probabilmente sbaglia la catena
dell'energia quando le bestie sono piu' d'una. T4c: 23 carte al 56,52% (+528 pip).
Mazzo 50,24% ma +3.445 pip contro +3.110, recente 51,20%. Dodici carte tutte giuste.

**CORREZIONE DI EDU su USDCAD 18/03/2020 — `CONFERMATA DA EDU` (ma vedi la nota finale)**
"Innanzitutto una bestia che arriva non e' mai vuota. Zi e Shen arrivano su Y dove c'e' Yin e
hanno scambio di Qi che finisce su Yin (Shen genera Zi che genera Yin), quindi la Y rimane legno.
Su Shi: autocombinazione avviene se l'arrivo torna indietro a combinare e qui non succede. B 午
si trasforma in 未 e basta. Confronto finale S e Y: vince Y, legno vince su terra, short."
Tre regole, tutte cablate:
1. **Una bestia che arriva non e' mai vuota.** Il vuoto non tocca i pilastri. Tolta la regola che
   Claude aveva appena scritto (era sbagliata).
2. **Con piu' bestie sulla linea c'e' scambio di qi.** La catena puo' finire sul ramo della linea
   stessa: 申 genera 子 che genera 寅, quindi la Ying resta Legno. Con UNA sola bestia che prende
   possesso invece la linea diventa quella bestia (come su USDJPY 09/02/2026, dove l'anno 丙午
   fa Fuoco lo Shi 亥).
3. **L'autocombinazione c'e' solo se l'arrivo torna indietro a combinare.** 午 che diventa 未 non
   lo e': la linea si muove normalmente. Resta ferma solo l'altro caso -4, l'arrivo in tomba nel
   mese e punito dal giorno (EURJPY 11/07/2024).
Dodici carte di riferimento tutte giuste. Mazzo 49,92% (+1.923 pip), recente 50,45%.

**NOTA IMPORTANTE — DA CHIARIRE CON EDU.** La lettura di Edu su questa carta conclude SHORT.
Il mercato del 18/03/2020 e' andato LONG di 266 pip. Col cablaggio delle tre regole il motore
adesso arriva anch'esso a SHORT (per il raduno 寅午戌 che serve la mobile) e la carta e' una
perdita. Prima, con la mobile trattata come ferma e la Ying svegliata dal giorno, il motore
arrivava a LONG e la prendeva. Quindi: le tre regole sono cablate perche' sono di Edu, ma su
questa carta la conclusione a cui portano e' contraria all'esito.

**EDU CORREGGE SE STESSO su USDCAD 18/03/2020 — `CONFERMATA DA EDU`**
"Ho fatto io un errore. L4 si ricombina con L3. 未 non rimane da sola, cerca qualcosa da fare e
trova L3 午, quindi si', S rimane 午 fuoco perche' raggiunge la copia di se' stesso su L3 e
quindi il finale e' Long."
NUOVA REGOLA: l'arrivo non resta mai da solo, cerca qualcosa da fare. Se quello che trova e' una
linea ferma con lo STESSO RAMO della partenza, la mobile raggiunge una copia di se' stessa e
RESTA QUELLO CHE ERA — non diventa l'arrivo. E se la mobile e' una sede, da li' parte il
confronto con l'altra. Qui: 午 va in 未, 未 combina il 午 di L3, lo Shi resta Fuoco; la Ying e'
Legno (catena 申->子->寅); il Legno genera il Fuoco, lo Shi e' nutrito e vince -> LONG, che e'
l'esito (+266). Cablata come `T2c la copia di se'` (MLCOPIA), prima del raduno.
Cablato anche che l'autocombinazione non conta come passo nullo in NESSUNA delle tracce della
mobile (prima liuyao la segnava movimentoNullo e bloccava porte, ladro, copia).

**STATO ALLA FINE DI QUESTO GIRO — da guardare prima di continuare.**
Mazzo 49,52% (+876 pip), recente 49,84%. Stamattina era 51,53%. Le dodici carte di riferimento
sono tutte giuste, quindi non e' un problema di regole di Edu: e' l'ampiezza con cui Claude le
applica. Il buco principale e' uno solo:
  T3 il raduno serve la mobile: 405 carte, 48,15%, -1.290 pip — il gradino piu' grande e il
  peggiore. E' cresciuto da 127 a 405 carte man mano che le mobili smettevano di essere "ferme".
  T7 il duello: 181 carte, 46,41%.  T2c la copia di se': 38 carte, 42,11%.
Prossimo passo indicato: leggere le perdenti di T3, non aggiungere tracce.

**Carta letta da Claude da solo · USDJPY 10/02/2026 seme 156 · `DA VALIDARE`**
Peggiore perdente del gradino del raduno fra le carte in cui la mobile e' una W (-175 pip).
Palazzo 巽 Xun (Legno), mese 寅 (Legno di stagione), giorno 乙卯, ora 亥, anno 午, vuoti 子 丑.
Mobile L5, lo Shi, W 未 Terra, FUORI stagione, che si scarica in 申 (caso 2: la partenza genera
l'arrivo).
Il motore faceva servire la linea dal trigono 亥卯未 e le lasciava il carattere W: sede alta
vince -> LONG. Sbagliato.
Lettura di Claude: quel trigono e' di LEGNO, e il Legno nel mese 寅 e' prospero. Un raduno di
stagione non si limita a servire la linea: se la tira dentro. Il 未 e' la fine del trigono di
Legno, e viene inghiottito — L5 non e' piu' una W di Terra, e' Legno, che nel palazzo 巽 di
Legno e' una B. La B fa perdere la propria squadra: sede alta perde -> SHORT. Esito: SHORT -175.
La distinzione regge sulla carta di Edu: su USDJPY 30/09/2025 il raduno 寅卯辰 e' di Legno ma nel
mese 酉 il Legno e' morto, quindi non ha la forza di trasformare niente e la serve soltanto,
lasciandole la W. Quella carta resta giusta.
Cablato come `MLRADTRASF`: raduno di stagione -> trasforma la linea nel proprio elemento e il
carattere si rilegge nel palazzo; raduno fuori stagione -> serve la linea e le lascia il suo.
Il gradino passa dal 48,15% al 50,00% su 410 carte. Mazzo da 49,52% a 50,19% (+2.971 pip contro
+876), recente 50,44%. Dodici carte di riferimento tutte giuste.
DOVE PERDE ANCORA: dentro il gradino, le carte in cui un raduno FUORI stagione serve una mobile
che e' una W fanno 72 carte al 34,7% — cioe' vanno quasi sempre al contrario. E' il prossimo
posto da cui prendere una carta. (serve G 107 al 46,7%, serve B 87 al 59,8%, serve P 57 al 56,1%.)

**CORREZIONE DI EDU su USDJPY 10/02/2026 — `CONFERMATA DA EDU`**
"Shi si muove per combinarsi con L6 巳. Su Ying arrivano anno e ora e diventa 午. S e Y sono
uguali ma chi ha le bestie dal suo lato vince sempre, short."
Lettura di Edu passo per passo: lo Shi mobile 未 va in 申 e 申 combina il 巳 di L6, quindi lo Shi
si lega al Fuoco. Sulla Ying L2 (寅 Legno) arrivano l'anno 丙午 e l'ora 丁亥, tutte e due Uccello
Rosso: la catena 亥 -> 寅 -> 午 finisce sul Fuoco, la Ying e' 午. Le due sedi sono tutte e due
Fuoco, quindi pari — e allora vince chi ha le bestie dalla propria parte, cioe' la Ying: SHORT.

**NUOVA REGOLA cablata: chi ha le bestie dal suo lato vince sempre.** Quando il confronto fra le
due sedi non si decide (stesso elemento, oppure nessuno dei due comanda e le forze pareggiano),
vince la sede su cui sono cadute piu' bestie. Prima in quei casi il motore taceva.
Mazzo da 50,19% a 50,29% (+3.267 pip), recente 50,68%. Dodici carte tutte giuste.

**NON CABLATO, e va chiarito con Edu.** Il primo passo della lettura — "lo Shi si muove per
combinarsi con L6, quindi prende quell'elemento" — non e' stato cablato perche' come regola
generale rompe una carta di Edu: su USDJPY 30/09/2025 la mobile e' anche lei lo Shi (辰) e il
suo arrivo 亥 combina il 寅 di L2, quindi scatterebbe la stessa strada e quella carta andrebbe
persa, mentre Edu l'ha letta col raduno. Serve sapere che cosa distingue le due.
Sulla carta di oggi comunque le due strade concordano: il raduno di stagione che trasforma la
mobile in B da' SHORT come la lettura di Edu.

**RISOLTO il punto aperto: che cosa distingue le due carte.**
E' il passo. Su USDJPY 30/09/2025 il giorno 壬寅 COMBINA l'arrivo 亥 (寅亥合): il passo e' nullo,
la mobile arriva e si ferma e non salta da nessuna parte — sono le parole di Edu su USDJPY
08/02/2024. Quindi lo Shi non va a combinare il 寅 di L2, e la carta si legge col raduno, come
l'ha letta Edu. Su USDJPY 10/02/2026 il passo e' vivo (caso 2, scarico), e allora lo Shi ci va.
Cablato `T2d la sede si combina` (MLSEDECOMB), prima del raduno: se la mobile e' una SEDE e il
passo NON e' nullo, va a combinare la linea ferma che trova e si lega al suo elemento; da li'
parte il confronto con l'altra sede. Il bersaglio della combinazione non deve "fare qualcosa" —
quel test serve per i membri di un raduno, non per chi riceve.
Adesso USDJPY 10/02/2026 si legge esattamente come l'ha letta Edu: lo Shi si lega al Fuoco di
L6, la Ying e' Fuoco per la catena 亥->寅->午, le due sedi si equivalgono e le bestie stanno dalla
parte della Ying, 2 contro 1 -> SHORT.
T2d: 99 carte al 55,56% (+902 pip). Mazzo 50,44% (+3.616 pip). Dodici carte tutte giuste.

**Carta letta da Claude da solo · EURGBP 18/03/2020 seme 90 · `DA VALIDARE`**
Peggiore perdente del gradino "il giorno distrugge l'arrivo" (-332 pip), che stava al 41,33% su
75 carte mentre il suo gemello "il giorno tiene l'arrivo" stava al 60,67%.
Palazzo 艮 Gen (Terra), mese 卯 (Legno di stagione), giorno 庚申, ora 巳, anno 子, vuoti 子 丑.
Mobile L2, G 卯 Legno prospero, che RETROCEDE in 寅 (退神); il giorno 庚申 clasha l'arrivo 寅.
Il motore diceva: l'arrivo e' distrutto, la linea resta se' stessa, il G fa vincere la propria
sede -> SHORT. Sbagliato di 332 pip.
Lettura di Claude: quel G si sta ritirando. La regola di Edu validata su USDJPY 01/12/2022 dice
che un danno che si ritira porta via il danno e la sua squadra vince. Per simmetria un VANTAGGIO
che si ritira porta via il vantaggio, e la sua squadra perde: sede bassa perde -> LONG.
Esito: LONG +332.
Cablato come `MLPROGBEN`, solo per la RITIRATA. La simmetria completa (anche l'avanzata) l'ho
provata e misurata: "il vantaggio retrocede" fa 56,34% su 71 carte (+761 pip), ma "il vantaggio
avanza" fa 28,57% su 28 carte (-639 pip) — cioe' un G o una W che avanza NON fa vincere la
propria sede, anzi il contrario. Nessuna carta letta spiega perche', quindi l'avanzata resta
fuori finche' non ne leggo una: e' un buon posto da cui prendere la prossima.
Il gradino "il giorno distrugge" scende da 75 a 69 carte. Mazzo da 50,44% a 50,52% (+3.873 pip).
Dodici carte di riferimento tutte giuste.

## S45 · DOTTRINA RIVISTA DA EDU — LA LINEA INCOMPATIBILE · `CONFERMATA DA EDU`
"La dottrina va cambiata perche' la linea incompatibile non puo' stare dove sta.
1) linea incompatibile ferma: diventa mobile
2) linea incompatibile mobile: non puo' essere fermata ne' da un clash ne' da una combinazione.
Con il caso 2 L2 non puo' essere fermata."
Sostituisce la vecchia lettura ("parte ma non arriva", movimento nullo, progressione azzerata).
Le tre coppie restano quelle: 卯 in 兌 · 午 in 坎 · 申 in 艮, col ponte della data (Acqua, Legno,
Acqua) che salva se l'elemento in mezzo sta in almeno due dei quattro rami.

PESO SUL MAZZO: 174 carte su 2.788 (6,2%) hanno la mobile su una coppia incompatibile; il ponte
ne salva 20, quindi 154 (5,5%) sono incompatibili davvero. 卯 in 兌: 63 (59 senza ponte) ·
申 in 艮: 64 (54) · 午 in 坎: 47 (41). Di quelle senza ponte, 59 avevano una progressione.

MISURA DELLE DUE CONDIZIONI, separate e insieme (baseline con la vecchia dottrina: 50,13%, +2.057):
  solo caso 2 (la mobile incompatibile non si ferma)   50,51%  +3.928 pip  · recente 50,23%
  solo caso 1 (la ferma incompatibile diventa mobile)  50,80%  +4.744 pip  · recente 50,35%
  tutte e due                                          50,79%  +4.798 pip  · recente 50,42%
Cablate tutte e due. Il gradino nuovo `T4d la ferma incompatibile` (con la mobile fuori dai
giochi agisce la ferma incompatibile) fa 30 carte al 63,33% (+475 pip).
EURGBP 18/03/2020 torna giusta col caso 2: la mobile L2 (卯 in 兌) non e' fermata dal clash del
giorno sull'arrivo, quindi la ritirata si compie davvero e il G che si ritira porta via il
vantaggio — sede bassa perde -> LONG (+332).
Dodici carte di riferimento tutte giuste.

## S45 · PROVA: DUE LINEE IN MOVIMENTO
Se la ferma incompatibile "diventa mobile", quelle carte hanno DUE linee che si muovono. Provati
tre modi di leggerle (interruttore DUEMOB), tutti misurati sul mazzo intero:
  conferma  (decide la mobile; la incompatibile parla solo se la mobile non conclude)
            2463 carte · 50,79% · +4.798 pip · DODICI CARTE DI RIFERIMENTO TUTTE GIUSTE
  prima     (decide la incompatibile, prima di tutto)
            2531 carte · 51,36% · +5.850 pip · MA rompe due carte di Edu
  concordi  (si conclude solo se le due dicono la stessa cosa)
            2164 carte · 51,25% · +5.366 pip · MA tace sulle stesse due carte di Edu
Le due carte rotte sono sempre le stesse:
  · USDJPY 28/04/2025 — L3 e' incompatibile ed e' un B; farla decidere da' LONG, ma Edu quella
    carta l'ha letta sulla mobile L6 impigliata dal giorno, e l'esito e' SHORT.
  · AUDUSD 22/12/2025 — L2 e' incompatibile ed e' un G; farla decidere da' SHORT, mentre la
    lettura e' la mobile che combina la W di L5, ed e' LONG.
CONCLUSIONE: la seconda linea in movimento NON ha la precedenza sulla mobile e non le mette il
veto. Tenuto il modo `conferma`. I mezzo punto in piu' del modo `prima` sono un guadagno di
statistica pagato con due letture certificate: non si prende.
Resta aperto che cosa faccia davvero la seconda mobile quando la prima conclude — probabilmente
non decide la direzione ma entra nel conto in altro modo (forza di una sede, bersaglio, energia).

## S45 (11/09/2026) · TEST DI EDU: LA SECONDA MUTAZIONE
Edu mostra la carta di USDJPY 28/04/2025 con DUE linee mobili, L6 e L3 (Tun 33 -> Cui 45): L3 e'
la ferma incompatibile 申 in 艮, e mutando va in 卯. Nota di Edu: "se fosse cosi' L3 finirebbe
per combinarsi con L6 (卯戌合) e il risultato short comunque non cambierebbe".
CALCOLO: la seconda mutazione si ottiene senza toccare la catena, chiedendo a liuyao la mutazione
della linea incompatibile come se fosse lei la mobile (l'arrivo dipende solo dal trigramma e
dalla posizione). Verificato: L3 申 -> 卯 come nella carta di Edu. Nel mazzo 723 carte hanno
esattamente una seconda mutazione.
COSA FA IL SECONDO ARRIVO (sulle 723): combina una linea ferma 245 · niente 135 · combina la
PARTENZA della prima mobile 93 · combina la Ying 91 · clasha una ferma 81 · clasha la Ying 49 ·
clasha l'ARRIVO della prima 29 · combina l'ARRIVO della prima 26 · clasha la PARTENZA 23 ·
clasha lo Shi 17 · combina lo Shi 5.
TEST (interruttore DUEMUT), il secondo arrivo agisce sulla prima mobile come il giorno:
  senza seconda mutazione                                    50,79%  +4.798 pip
  il secondo arrivo TIENE o DISTRUGGE l'arrivo della prima    50,93%  +5.326 pip  (il migliore)
  + il secondo arrivo IMPIGLIA o BLOCCA la partenza della     50,67%  +4.646 pip
    prima, che resta se' stessa e parla (T0e)
  T0e la seconda impiglia: 65 carte al 46,15% · T0e la seconda blocca: 21 al 52,38%.
Dodici carte di riferimento giuste in tutte e tre le versioni. USDJPY 28/04/2025 si legge come
l'ha descritta Edu: 卯 di L3 impiglia il 戌 di L6, il P resta e fa perdere la sua squadra, SHORT.
Lasciato tutto cablato e ACCESO (versione completa) in attesa del giudizio di Edu: la parte che
tiene/distrugge l'arrivo aiuta, la parte che impiglia la partenza e fa parlare la mobile costa.
Non cablato ancora: il secondo arrivo che agisce su ALTRE linee (combina/clasha ferme, Shi, Ying),
che sono i casi piu' numerosi (245+91+81+49+17+5).

**TEST 2 (11/09/2026): il secondo arrivo sulle ALTRE linee — richiesto da Edu**
Cablato dietro DUEMUT2=on, con le regole gia' in uso: il secondo arrivo che COMBINA una ferma la
impiglia (non fa niente, non e' membro di raduno, se e' una sede e' fuori dal duello); che la
CLASHA la sveglia (agisce come la svegliata dal giorno); e se la prima mobile non conclude, la
seconda passa dalle tre porte e "parla chi riceve" (non puo' scavalcare la prima: i test "prima"
e "concordi" l'hanno escluso).
  senza (solo il secondo arrivo sulla prima mobile)   50,67%  +4.646 pip
  con il secondo arrivo anche sulle altre linee        50,44%  +3.847 pip  · recente 50,34%
  T5b le porte della seconda: 67 carte al 47,76%. T4c scende da 23 a 8 carte (piu' linee
  svegliate -> piu' carte con due svegliate -> il gradino si astiene).
Dodici carte di riferimento giuste in tutte e due. Lasciato SPENTO di default (DUEMUT2=on per
riaccenderlo): e' un'estrapolazione di Claude e misura peggio. Decide Edu.

**TEST 3 (11/09/2026): mutazione vera o 暗動? — domanda di Edu**
"E' meglio la versione simile a una linea ferma clashata, che si muove ma non cambia da yin a
yang nel nuovo esagramma?" Misurato: la seconda agisce col PROPRIO ramo (暗動, ANDONG=si) oppure
con l'ARRIVO (mutazione vera), in tutte le combinazioni:
  nessuna seconda in movimento                                50,79%  +4.798
  暗動, agisce sulla prima mobile (partenza e arrivo)           50,71%  +4.417
  暗動, agisce solo sull'arrivo della prima                     50,40%  +3.779  · recente 49,92%
  暗動, anche sulle altre linee                                 50,44%  +3.481
  mutazione vera, agisce sulla prima (partenza e arrivo)       50,67%  +4.646
  mutazione vera, agisce SOLO sull'arrivo della prima          50,93%  +5.326  · recente 50,66%  <-- la migliore
  mutazione vera, anche sulle altre linee                      50,44%  +3.847
RISPOSTA: no, la versione 暗動 non e' migliore — sta sotto perfino al non far muovere niente.
La versione buona e' la mutazione vera, cioe' L3 che cambia davvero in 卯 (Tun 33 -> Cui 45),
ma limitata a quello che il suo arrivo fa all'ARRIVO della prima mobile: lo tiene se lo combina,
lo distrugge se lo clasha. Tutto il resto (impigliare la partenza della prima, agire sulle altre
linee) costa. Dodici carte giuste in tutte le versioni.
Interruttori: DUEMUT (seconda mutazione), DUEMUTPART (impiglia/blocca la partenza), DUEMUT2=on
(altre linee), ANDONG=si (暗動 invece di mutazione). Default lasciato: mutazione vera, solo
sull'arrivo della prima (DUEMUTPART=off).

**TEST 4 (11/09/2026): la seconda mobile resta col carattere dell'arrivo — domanda di Edu**
"Se L3 si muove per diventare W 卯, questo puo' rimanere cosi' e fare vincere la propria
squadra. Non va bene?" Provato (SECONDACAR): la seconda, compiuto il passo, parla col
carattere dell'ARRIVO nel palazzo sulla propria sede.
  decide PRIMA della prima mobile     49,55%     +74 pip · recente 48,42%  · rompe AUDUSD 22/12/2025
  decide solo se la prima NON conclude 51,01%  +4.522 pip · recente 50,83%  · dodici carte giuste
  (riferimento: 50,93%  +5.326)
Dentro il secondo modo, per carattere dell'arrivo: diventa G 49 carte al 55,1% · diventa W 50
carte al 46,0% (-717 pip) · diventa P 10 al 50% · diventa B 4 al 25%.
Quindi: come decisione PRIMA della mobile no, e di molto. Come ultima voce, quando la prima non
conclude, e' pari o poco sopra nella percentuale e sotto nei pip — e il pezzo che tira giu' e'
proprio la seconda che diventa W: 46%. Cioe' la W nata dalla mutazione della incompatibile NON
fa vincere la propria sede nella maggioranza dei casi. La G invece si'. Lasciato SPENTO
(SECONDACAR=dopo per riaccenderlo).

## S45 (11/09/2026) · AUDUSD 22/12/2025 — LE CINQUE COPPIE E IL FUTURO COMUNE
Edu manda la carta vera (Lin 19 -> Shi He 21): girano TRE linee, L6 (la mobile), L4 e L2.
"Le incompatibili sono due. Qui la vittoria del Long e' nettissima."
1. **Le coppie incompatibili sono CINQUE, non tre.** Claude aveva cablato solo quelle col
   controllo (卯 in 兌 · 午 in 坎 · 申 in 艮, con ponte). Mancavano le due col CLASH del ramo
   proprio del trigramma, senza ponte: 丑 in 坤 (未丑冲) e 辰 in 乾 (戌辰冲), che stanno nel
   registro dal 27/08 (§109). L4 丑 in 坤 e' la seconda incompatibile di questa carta. Cablate.
2. **Piu' di una seconda mobile.** Il motore ne gestiva una sola; ora tutte.
3. **L'esagramma futuro va calcolato con tutte le linee che girano insieme.** Mutando L4 da
   sola 坤 fa 震 e L4 andrebbe in 午; con L6 e L4 insieme 坤 fa 離 e L4 va in 酉, come nella carta
   di Edu. E cambia anche l'arrivo della PRIMA mobile: L6 non va in 寅 ma in 巳. Il calcolo
   della carta di Edu ora e' riprodotto esattamente: L6 酉->巳, L4 丑->酉, L2 卯->寅.
   Lettura del motore col futuro comune: l'arrivo 巳 clasha la W 亥 della Ying, parla chi
   riceve, la W fa vincere l'alto -> LONG (+46). Prima ci arrivava con 寅 che COMBINAVA la
   stessa W: stessa porta, altra chiave.
MISURA (cinque coppie; interruttore FUTURO):
  sola     (ogni seconda mutata da sola)                  50,78%  +4.369 · recente 50,96%
  seconde  (le seconde dal futuro comune, la prima no)    50,70%  +3.770 · recente 50,80%
  insieme  (tutto dal futuro comune, anche la prima)      50,76%  +2.518 · recente 51,80%
Dodici carte giuste in tutte e tre. Messo `insieme` come default: e' il calcolo giusto per
dottrina (riproduce la carta di Edu), a pari percentuale, con meno pip sul totale ma il recente
migliore di tutta la giornata. Nota: le due coppie col clash da sole costano circa 0,15 punti
rispetto alle tre (50,93% -> 50,78% a parita' di tutto il resto).

**LETTURA DI EDU su AUDUSD 22/12/2025 (parte alta) — `CONFERMATA DA EDU`**
"1. L4 ed L6 si muovono e insieme formano un trigono di metallo che circonda la W di Y. Long.
 2. L2 G si muove per retrocedere: Long."
1. NUOVA REGOLA cablata (`T0g il trigono in movimento`, MLTRIGMOB): le linee che girano — la
   mobile e le incompatibili — mettono in gioco partenze E arrivi. Se fra quei rami c'e' un
   trigono intero, e le linee che lo portano stanno una sotto e una sopra una sede, il trigono
   la CIRCONDA: se il suo elemento genera quello della sede, la nutre e la sede vince. Qui 酉
   (partenza di L6, arrivo di L4), 巳 (arrivo di L6) e 丑 (partenza di L4) fanno 巳酉丑 di
   Metallo; L4 e L6 stanno attorno alla Ying L5, W 亥 Acqua; il Metallo genera l'Acqua ->
   LONG (+46). Messa in testa, subito dopo la guerra fra titani.
2. Il G che retrocede fa perdere la propria sede: e' la regola ricavata da Claude su EURGBP
   18/03/2020 (MLPROGBEN), qui confermata da Edu su una seconda mobile. Vale da conferma.

## S46 (11/09/2026) · USDJPY 02/10/2024 seme 143 — CARTA DI RIFERIMENTO ROTTA DAL FUTURO COMUNE · `DA VALIDARE`
Nel controllo d'avvio, delle venti carte di riferimento (dodici + otto da aggiungere) diciannove
sono giuste; USDJPY 02/10/2024 (letta da Edu in S45, LONG +265) e' sbagliata. Si e' rotta col
futuro comune (FUTURO=insieme, da AUDUSD 22/12/2025): con FUTURO=seconde le venti sono tutte
giuste, ma AUDUSD non si legge piu' col trigono in movimento di Edu. Mazzo: insieme 50,74% +2.445 ·
seconde 50,70% +3.770. Nessun cambio fatto.
Lettura di Claude, col metodo di Edu (traccia -> dove porta -> chi smentisce -> solo alla fine):
1. Protagonista: L2, lo Shi, G 午 Fuoco mobile, fuori stagione (Fuoco in prigione nel mese 酉).
2. L3 申 nel trigramma 艮 e' incompatibile: ponte d'Acqua assente (rami: solo 亥 del giorno;
   steli di giorno e ora 己 Terra e 甲 Legno). Ferma -> diventa mobile. Futuro con L2 e L3
   insieme: 艮 -> 坎, e L2 non va in 亥 ma in 辰. (Edu aveva letto la carta PRIMA di dettare la
   regola della ferma incompatibile che diventa mobile.)
3. Traccia: 辰 e' vuoto e il giorno 亥 non lo clasha -> arrivo nel vuoto (§114, Edu 29/08/2026):
   il passo non ha effetto, la mobile resta G, lo Shi fa vincere la sede bassa -> SHORT.
   Smentita dal mercato (LONG +265).
4. Chi toglie di mezzo la G: nessun pilastro su L2 (mese 癸酉 su L3, giorno 己亥 su L1, anno 甲辰
   e ora 甲戌 su L4 in clash = guerra fra titani); il secondo arrivo di L3 e' 午, stesso ramo
   della G: la carica. Unico candidato: il 亥 del giorno, che controlla il Fuoco dello Shi e
   combina e genera la W 寅 nascosta sotto lo Shi — lo stesso gesto che nella lettura di Edu
   faceva l'arrivo 亥. La W 寅 sullo Shi e' Legno morto nel mese 酉, la Ying B 申 Metallo di
   stagione lo clasha e lo controlla -> lo Shi perde -> LONG.
5. NON pronunciato: la regola di Edu fa prendere la sede al nascosto quando e' l'ARRIVO a
   eliminare il carattere (controllo indietro, MLFUSHEN). Qui l'arrivo e' vuoto; farlo fare al
   giorno sarebbe allargare la regola oltre la carta. Carta aperta, niente cablato.
Due regole di Edu perse nella ricostruzione del motore di lettura (S45), da rimettere:
 - l'arrivo nel vuoto non agisce (principio 6, §114): oggi il motore fa clashare L6 dall'arrivo
   vuoto 辰;
 - [RITIRATO, vedi sotto "CORREZIONE DI EDU su NZDUSD 10/08/2022"] il ponte coi rami PIU' gli
   steli: la correzione di Edu del 30/08 riguarda il ponte dell'ARRIVO, non la linea
   incompatibile di S45, che si conta sui quattro rami.

**LETTURA DI EDU su USDJPY 02/10/2024 (seme 143) — `CONFERMATA DA EDU`** · 11/09/2026, S46
Edu manda la sua carta: Tun 33 -> Song 6, girano L3 (O) e L2 (X); anno 辰, mese 酉, giorno 己亥,
vuoti 辰 巳. Parole di Edu: "Effetto scala. L3 si muove in G w, L2 continua il movimento e arriva
a P cn. Poiche' l'intero movimento finisce su P questo fa perdere la propria squadra. Long."
1. La sua carta conferma il futuro comune: con L3 incompatibile in movimento, L2 va in 辰, non in
   亥 (la lettura di S45 con 亥 era stata data prima della regola della ferma che diventa mobile).
2. NUOVA REGOLA, l'EFFETTO SCALA: la seconda linea in movimento arriva sul ramo da cui parte la
   mobile (qui L3 申 -> 午, e L2 parte da 午); il movimento non si ferma li': prosegue lungo la
   mobile fino al suo arrivo, e parla il carattere dell'arrivo FINALE nel palazzo, sulla sede
   della mobile. Qui 辰 e' P: la sede bassa perde -> LONG (+265).
3. Sulla carta l'arrivo finale 辰 e' VUOTO e il giorno 亥 non lo clasha: Edu lo legge lo stesso.
   Nella regola quindi nessuna condizione sul vuoto. Da tenere presente prima di rimettere nel
   motore di lettura "l'arrivo nel vuoto non agisce": non puo' stare prima della scala.
4. La lettura di Claude del turno precedente (il 亥 del giorno che tira fuori il nascosto 寅)
   era una falsa pista: resta a registro come tale, non cablata.
Cablato come `T0s l'effetto scala` (MLSCALA), SUBITO DOPO il trigono in movimento: su AUDUSD
22/12/2025 la stessa scala c'e' (L4 arriva in 酉, da cui parte L6) ma Edu la legge col trigono che
circonda la Ying; messa prima del trigono, la scala rompeva AUDUSD (fine su 巳 = P in alto -> SHORT).
Perimetro solo quello della carta: seconda linea -> mobile, stesso ramo. Il verso contrario (la
mobile che arriva sul ramo da cui parte la seconda) NON e' cablato.
Estensione di Claude, SPENTA: la scala che finisce su G/W fa vincere la sede (MLSCALAGW=on) — non
detta da Edu; misura peggio.
MISURA (base LY canonica + MOTORE=lettura PRINCIPI=1):
  prima della scala                  2489 carte  50,74%  +2.445 pip · recente 51,76%
  con la scala (P/B)                 2490 carte  51,29%  +5.603 pip · recente 51,99%
    gradino T0s                        97 carte  60,82%  +1.965 pip (z circa 2,1)
  con anche G/W (Claude, spenta)     2494 carte  51,12%  +4.689 pip · T0s 158 carte 55,70%
Venti carte di riferimento (dodici + otto di S45) TUTTE giuste: USDJPY 02/10/2024 torna LONG per
la scala, AUDUSD 22/12/2025 resta LONG per il trigono.

## S46 (11/09/2026) · LA BASE DEL LIU YAO — `DECISA DA EDU`
Edu: "Tieni le nuove regole." La base del Liu Yao resta col software com'e': le due regole di S44
accese (l'arrivo della mobile entra nel flusso del qi, FLUSSOARR; il raduno dei tre rami della
stagione solo con linee che fanno qualcosa ed elemento di stagione, R6 nuova).
Base: S17 58,54% · z 9,01 · +35.016 pip (vecchio 56,73 · recente 60,68). Il 59,15% della
ripartenza di S44 si otteneva solo spegnendole: non e' piu' la base. base_canonica.json aggiornato
nella storia (i flag non cambiano).

## S46 (11/09/2026) · IL PONTE CONTATO ANCHE SUGLI STELI — `RITIRATO` (era un allargamento di Claude)
Regola di Edu del 30/08/2026 ("l'Acqua si conta tutta": rami della data PIU' gli steli del giorno
e dell'ora), persa nella ricostruzione di S45: la linea incompatibile del motore di lettura
contava solo i rami, mentre liuyao.js conta anche gli steli. Rimessa (interruttore MLPONTE=rami
per il vecchio conto; distinto da PONTEMODO, che tocca anche liuyao).
  solo rami (S45)            2490 carte  51,29%  +5.603 pip · recente 51,99%
  rami + steli (Edu)         2488 carte  51,00%  +4.715 pip · recente 51,88%
Venti carte di riferimento tutte giuste. Costa 0,29 punti: regola di Edu, si tiene. Da cercare
la carta (falsa pista) fra quelle che il ponte degli steli ha cambiato.

**Carta letta da Claude · NZDUSD 10/08/2022 seme 62 · `DA VALIDARE` (NON CHIUSA)** · S46
La peggiore delle carte che il ponte sugli steli ha ROTTO (era giusta, ora -115). Palazzo 離 Li
(Fuoco), 艮 sopra 坎, mese 戊申, giorno 乙未, anno 壬寅, ora 丁丑, vuoti 辰 巳. Mobile L3, B 午
Fuoco fuori stagione, verso 酉. Con gli steli il ponte di Legno regge (寅 dell'anno + stelo 乙
del giorno): L3 non e' piu' incompatibile, quindi il giorno puo' fermarla.
Lettura di Claude col metodo:
1. Protagonista L3, B 午. Il giorno 未 combina la partenza: la linea resta impigliata e non parte
   (come USDJPY 28/04/2025). Un B che resta fa perdere la propria squadra -> LONG, provvisoria.
2. Salta all'occhio anche il trigono di Fuoco 寅午戌 completo (寅 dell'anno, 午 la mobile, 戌 lo
   Shi): ha la mobile fra i membri, la serve e ne prende il carattere, B -> conferma LONG.
3. Candidato a smentire: il mese 戊申 cade su L3 con la sua bestia; il 午 lo controlla ma e' fuori
   stagione, quindi la bestia si impadronisce della linea: L3 diventa 申 Metallo = W -> SHORT.
   E' quello che fa ora il motore (sostituzione), smentito dal mercato (LONG +115).
4. Chi toglie di mezzo il mese: l'unico candidato trovato e' il trigono — il 午 non sta da solo,
   ha intorno il suo trigono di Fuoco contro un 申 solo. Ma il trigono non rende il Fuoco di
   stagione (la stagione la fanno mese e ora), quindi "la linea tenuta dal suo trigono non si
   lascia prendere dalla bestia" sarebbe una regola di Claude. NON pronunciato, niente cablato.
Prima del cambio la carta era giusta solo perche' L3, incompatibile, non poteva essere fermata e
la sostituzione non entrava.
Stesso nodo sul mazzo: 22 carte in cui la sostituzione e il raduno che serve la mobile dicono il
contrario; giusta la sostituzione 10, giusto il raduno 12. I numeri non decidono.

**CORREZIONE DI EDU su NZDUSD 10/08/2022 (seme 62) — `CONFERMATA DA EDU`** · 11/09/2026, S46
Edu: "Non avevamo detto che una linea mobile incompatibile non puo' essere fermata da clash e
combinazioni?"
La carta si chiude con le regole che c'erano gia': L3 午 nel trigramma 坎 e' incompatibile (ponte
di Legno: nei quattro rami della data un solo 寅), quindi il giorno 未 che combina la partenza
non la ferma; e se il passo non e' chiuso il mese 戊申 non puo' sostituirsi alla mobile. Resta il
trigono di Fuoco 寅午戌 con la mobile fra i membri: la serve e ne prende il carattere, B -> la
sede bassa perde -> LONG (+115). Il nodo "pilastro contro trigono" era falso: nasceva dal mio
cambio, non dalla carta.
ERRORE DI CLAUDE, da non ripetere: in S46 avevo "rimesso" nel ponte della linea incompatibile gli
steli del giorno e dell'ora, chiamandola una regola di Edu persa nella ricostruzione. Non lo era:
la correzione del 30/08 ("l'acqua si conta tutta") riguarda il ponte dell'ARRIVO incompatibile
col trigramma futuro (liuyao.js, dove resta); la dottrina di S45 sulla linea incompatibile dice
"almeno due dei quattro rami". Ho portato una regola da un posto all'altro: allargamento vietato.
Ritirato: il motore conta di nuovo i soli quattro rami; gli steli restano dietro MLPONTE=steli,
spento, dichiarato come mio.
Mazzo di nuovo 2490 carte 51,29% +5.603 pip (recente 51,99%). Carte di riferimento: le venti
piu' NZDUSD 10/08/2022, ventuno su ventuno giuste.

**LETTURA DI EDU su NZDUSD 10/08/2022 (seme 62) — `CONFERMATA DA EDU`** · 11/09/2026, S46
Edu: "Aspetta, L3 si muove (non viene fermata) e arriva a combinarsi con una vuota C in L2. Il
movimento finisce in niente. Long."
Corregge la chiusura scritta sopra: la carta NON si legge col trigono 寅午戌 (quella era la
strada del motore, giusta di verso ma non di motivo). La mobile incompatibile non si ferma,
arriva in 酉, 酉 combina (辰酉合) il 辰 di L2, che e' VUOTO e nel palazzo 離 e' un C: il movimento
finisce in niente. LONG (+115).
NUOVA REGOLA cablata come `T2n finisce in niente` (MLNIENTE), prima della sede che combina (T2d)
e del raduno: passo vivo; l'arrivo combina una linea ferma vuota non svegliata che e' C. La
mobile resta quello che era e parla il suo carattere, come nell'arrivo nel vuoto (§114): B/P ->
la sua sede perde; G/W -> vince; C -> tace. Sulla carta e' un B -> sede bassa perde -> LONG.
NOTA: "perche' Long" Edu non l'ha detto; il carattere della partenza e' la lettura coerente con
§114, e sulla carta coincide con l'altra possibile ("la sede che si muove perde sempre").
MISURA:
  prima                                   2490 carte  51,29%  +5.603 pip · recente 51,99%
  con T2n (perimetro della carta)         2490 carte  51,33%  +5.356 pip · recente 52,07%
    gradino T2n                              9 carte  66,67%  +37 pip
  estensione Claude: qualunque vuota      T2n 46 carte 47,83% -502 pip -> SPENTA (MLNIENTE=tutte)
  estensione Claude: la sede perde sempre T2n 12 carte 58,33% -123 pip -> SPENTA (MLNIENTE=perde)
Ventuno carte di riferimento tutte giuste (NZDUSD 10/08/2022 ora per T2n).

**PRECISAZIONE DI EDU sulla regola T2n — `CONFERMATA DA EDU`** · 11/09/2026, S46
Edu: "La regola e' una delle prime: chi non vince, perde. Se il movimento della linea non porta a
niente quella squadra perde."
E' il §25 dell'archivio (chi non vince perde). Il perche' del LONG su NZDUSD 10/08/2022 non e' il
carattere B della mobile: e' che il movimento non porta a niente. Cambiato il default di T2n: la
sede della mobile perde, qualunque carattere (anche C). La lettura col carattere (analogia di
Claude col §114) resta dietro MLNIENTE=carattere, spenta.
Perimetro invariato: l'arrivo combina una ferma vuota non svegliata che e' C.
MISURA:
  T2n col carattere (Claude)        9 carte  66,67%   +37 pip · mazzo 51,33% +5.356
  T2n chi non vince perde (Edu)    12 carte  58,33%  -123 pip · mazzo 51,33% +5.206 · recente 51,92%
Regola di Edu: si tiene. Ventuno carte di riferimento tutte giuste.

**Carta letta da Claude · EURJPY 15/08/2024 seme 162 · `DA VALIDARE`** · S46
Peggiore perdente del gradino peggiore del motore, "T4 il giorno distrugge l'arrivo" (63 carte al
41,27%, -958 pip). Palazzo 兌 Dui (Metallo), 震 sopra 兌, mese 壬申, giorno 辛亥, anno 甲辰, ora
癸巳, vuoti 寅 卯. Mobile L6, la Ying, P 戌 Terra fuori stagione, verso 巳.
Il motore diceva: il giorno 亥 clasha l'arrivo 巳, la linea parte e non arriva, resta P, la sede
alta perde -> SHORT. Mercato LONG +164.
ORIGINE di quel gradino: "altrimenti resta se' stessa" e' un'aggiunta di Claude in S44 (Edu
valido' solo la sostituzione col pilastro, USDJPY 09/02/2026). Per Edu il giorno che clasha
l'arrivo SOSPENDE la mobile: movimento nullo (regola fissata, sospensione dal giorno).
Lettura di Claude col metodo:
1. Protagonista L6, la Ying, P 戌. Il giorno 亥 clasha l'arrivo 巳: la mobile e' sospesa, il
   movimento e' nullo.
2. L2 卯 nel trigramma 兌 e' incompatibile (una sola Acqua, 亥) e si muoverebbe, ma su L2 cadono
   il mese 壬申 e l'ora 癸巳, in penalita': guerra fra titani, annullata. Niente si muove.
3. Nessun raduno ne' trigono completo.
4. L'unica azione: il giorno 亥 clasha L1, G 巳 Fuoco, PIENA e fuori stagione nel mese 申.
   E' il §69 di Edu (17/08/2026, USDJPY 13/02/2024): "se non ci sono migliori alternative si va
   verso l'unica disponibile... e' l'azione che guida l'interpretazione". Ferma piena clashata
   dal giorno -> si rompe -> la sua sede (bassa) perde -> LONG.
5. Chi potrebbe smentire: nessun pilastro possiede le sedi in modo che cambi (anno 甲辰 sullo Shi
   丑: stesso elemento, lo carica, non lo prende); il giorno sveglia L1 con la bestia ma L1 e'
   fuori stagione: non si muove, si rompe (come nella catena: clashata e untimely = rotta).
   Esito LONG +164.
Cablato come `T4z l'unica azione` (MLUNICA), prima del giorno che tiene/distrugge l'arrivo:
mobile sospesa dal giorno (non incompatibile, nessuna seconda mobile viva), nessun raduno, il
giorno clasha UNA sola ferma -> vuota: sua sede; piena: sede opposta. E' la regola di Edu come
fissata nella catena; nessun allargamento.
MISURA:
  prima                        2490 carte  51,33%  +5.206 pip · recente 51,92%
  con T4z                      2492 carte  51,36%  +5.683 pip · recente 52,11%
    gradino T4z                  20 carte  50,00%  +135 pip
    "il giorno distrugge"        da 63 carte 41,27% a 57 carte 40,35% (-843 pip)
Carte di riferimento: le ventuno + EURJPY 15/08/2024 + le due carte sorgente del §69 (USDJPY
13/02/2024, USDCHF 27/12/2023): ventiquattro su ventiquattro giuste.
APERTO: "il giorno distrugge l'arrivo, parla la partenza" resta al 40% su 57 carte ed e' una
regola di Claude, non di Edu.

**CORREZIONI DI EDU su EURJPY 15/08/2024 (seme 162) — `CONFERMATE DA EDU`** · 11/09/2026, S46
Edu: "Buona interpretazione ma alcune correzioni:
1. Se l'arrivo e' clashato la linea rimane attiva ma non cambia. Quindi P Xu farebbe perdere la
   propria squadra.
2. La penalita' e' quando Yin penalizza Si, ma Si penalizza Shen solo se c'e' anche Yin,
   altrimenti i due fanno una combinazione.
4. Il clash del giorno su L1 non danneggia L1 perche' la combinazione con il mese la protegge. Si
   spezza solo la combo a niente altro."
(Il punto 3 di Claude, nessun raduno, non e' corretto.)
CABLATO:
1. "Il giorno distrugge l'arrivo, parla la partenza" (T4) e' CONFERMATA DA EDU: non e' piu' solo
   un'aggiunta di Claude. Di conseguenza T4z (§69) non entra quando il giorno clasha l'arrivo: la
   mobile non e' fuori dai giochi.
2. Guerra fra titani: 巳 e 申 sulla stessa linea sono in penalita' solo se 寅 e' presente (fra i
   quattro rami della data o i rami delle linee); altrimenti si combinano, nessuna guerra.
   MLPEN3=off per il vecchio conto. (Perimetro: la sola coppia 巳申, come detto da Edu.)
3. Una ferma combinata col ramo del mese e clashata dal giorno NON e' rotta: si spezza solo la
   combinazione. Vale ovunque il motore di lettura usava lo stato "rotta" (forza, porte, sede che
   combina, bersagli) e in T4z. MLMESEPROT=off per il vecchio stato.
NON toccato: liuyao.js (la catena) ha ancora la penalita' 巳申 senza 寅 e lo stato "rotta" senza
la protezione del mese.
MISURA:
  prima (T4z com'era)                      2492 carte  51,36%  +5.683 pip · recente 52,11%
  con le tre correzioni                    2488 carte  51,45%  +5.687 pip · recente 52,15%
    senza la 2 (MLPEN3=off)                            51,41%  +5.588
    senza la 3 (MLMESEPROT=off)                        51,40%  +5.644
  T4 il giorno distrugge: 63 carte 41,27% (-958) · T4z: 13 carte 46,15% (+85)
Carte di riferimento (le ventuno + le due sorgenti del §69): ventitre su ventitre giuste.
LA CARTA con le correzioni: L6 P 戌 attiva e immutata -> la sede alta perde -> SHORT (mercato
LONG +164). Senza guerra L2 non e' annullata: incompatibile, si muove, W 卯 -> 寅 (retrocede);
ma sopra ci sono le due bestie del mese 申 e dell'ora 巳 che si combinano. APERTO: che cosa fanno
a L2, e se la W che retrocede conta (su AUDUSD 22/12/2025 il G che retrocede su una seconda
mobile era una conferma).

**LETTURA DI EDU su EURJPY 15/08/2024 (seme 162), CONCLUSIONE — `CONFERMATA DA EDU`** · 11/09/2026
Edu: "Il trade va long perche' le bestie arrivano su L2 mobile che e' un W che retrocede. Questa
indicazione e' piu' forte che la P su L6."
L2 卯 nel trigramma 兌 e' incompatibile, quindi da ferma diventa mobile; nel futuro comune va in
寅 (退神): e' una W che retrocede. Su di lei arrivano il mese 壬申 e l'ora 癸巳 (che si combinano,
nessuna guerra). La W che retrocede porta via il vantaggio: la sede bassa perde -> LONG (+164).
Comanda sulla P della Ying L6 (attiva e immutata, che da sola direbbe SHORT).
NUOVA REGOLA cablata come `T0r le bestie sulla seconda che retrocede` (MLBESTIESEC), subito dopo
l'effetto scala: seconda linea in movimento non annullata, con DUE o piu' bestie sopra, W, che
retrocede nel futuro comune -> la sua sede perde; piu' forte della prima mobile.
Estensioni di Claude provate e SPENTE (misurano peggio, fuori dal perimetro della carta):
  anche il G (analogia con AUDUSD 22/12/2025)   T0r 12 carte 41,67%  -48 pip · mazzo 51,41%
  basta una bestia, G o W                        T0r 57 carte 45,61% -158 pip · mazzo 51,54%
MISURA (perimetro della carta, solo W con due bestie):
  prima                        2488 carte  51,45%  +5.687 pip · recente 52,15%
  con T0r                      2488 carte  51,53%  +6.121 pip · recente 52,30%
    gradino T0r                   2 carte 100,00%  +217 pip (EURJPY 15/08/2024 +164, EURJPY 24/03/2025 +53)
Carte di riferimento: ventiquattro su ventiquattro giuste (con EURJPY 15/08/2024).
PRECISAZIONE DI EDU (11/09/2026): "Abbiamo gia' detto che una linea incompatibile si muove e si
trasforma vero? Di cosa ti stupisci allora? L'unica differenza qui e' che le due bestie gli danno
piu' energia e fanno uscire dal vuoto l'arrivo."
Quindi T0r non e' una regola nuova sul movimento: e' la linea incompatibile che si muove e si
trasforma (gia' detto), con la W che retrocede. Il pezzo nuovo e' solo questo: le due bestie le
danno energia (per questo pesa piu' della P su L6) e fanno uscire dal vuoto l'arrivo 寅 (vuoto
nel giorno 辛亥 — Claude non l'aveva notato). Nessun cambio al conto; aggiornato il racconto.

## S46 · IL METODO DI EDU, SEMPRE (11/09/2026)
Edu, dopo tre richiami: "Devi cambiare il modo in cui leggi la carta anche conoscendo gia' il
risultato. Io individuo una traccia, vedo dove porta, verifico che non ci sia altro che dimostra il
contrario e solo alla fine mi pronuncio. Voglio vederti fare cosi' SEMPRE."
Causa degli errori di Claude in S46: leggeva la traccia del motore (stati della catena come
"rotta", "movimento nullo", la tabella delle penalita') invece della carta, e si fermava appena
trovava una strada che portava all'esito. D'ora in poi: carta nuda (dati, niente stati ne'
verdetti), scheda linea per linea, traccia, verifica, conclusione; il motore solo alla fine. Una
conclusione che non coincide con l'esito e' un risultato legittimo: non si cerca la strada per
arrivarci.

**Carta letta da Claude col metodo · EURJPY 10/08/2023 seme 157 · `DA VALIDARE`**
Palazzo 離 (Fuoco), 離 sopra 巽 (鼎 50), mese 庚申, giorno 庚子, anno 癸卯, ora 丙子, vuoti 辰 巳.
Scheda: L6 B 巳 vuota, combinata dal mese, niente la sveglia -> non agisce. L5 Ying C 未, nessuna
bestia, Terra a riposo. L4 W 酉, l'ora 丙子 la drena e la prende -> 子 Acqua, G. L3 W 酉 mobile,
di stagione, verso 午 B; il giorno 子 clasha l'arrivo. L2 Shi G 亥, di stagione; l'anno 癸卯 la
drena e la prende -> 卯 Legno, P, morto nel mese. L1 C 丑 (nascosto 卯 P), giorno 庚子 e mese 庚申:
nessuna guerra, due bestie, catena 丑->申->子 -> Acqua. Nessuna linea incompatibile; l'arrivo 午
cade in 坎 senza ponte di Legno (un solo 卯), e comunque e' clashato dal giorno.
Raduni: 亥子丑 d'Acqua completo e di stagione (Shi, data, L1); 亥卯未 di Legno completo e fuori
stagione (Shi, anno, Ying); nessuno ha la mobile fra i membri.
Traccia: la mobile, W di stagione, ha l'arrivo clashato: resta attiva e immutata (Edu), la W fa
vincere la sede bassa -> SHORT.
Verifica: nessuna bestia sulla mobile; lo Shi preso dall'anno diventa Legno e nel confronto il
Legno controlla la Terra della Ying -> ancora SHORT; il raduno d'Acqua sta dalla parte dello Shi
-> SHORT; il trigono di Legno e' fuori stagione e non serve nessuna mobile. Unica cosa dall'altra
parte: L4 presa dall'ora diventa G in alto, ma e' una ferma non sede e nessuna regola la fa
decidere.
Conclusione: SHORT. Mercato LONG (-113). Con le regole che conosco la carta si legge SHORT e va
persa; non ho trovato che cosa lo smentisca.

**CORREZIONE DI EDU su EURJPY 10/08/2023 (seme 157) — `CONFERMATA DA EDU`** · 11/09/2026, S46
Edu: "L2 Hai e' incompatibile."
Sesta coppia della linea incompatibile: 亥 nel trigramma 巽 (巳亥冲). Edu non ha detto se ha un
ponte: cablata SENZA ponte (MLPONTEHAI=legno prova il ponte di Legno, 亥->木->巳, come 申 in 艮).
Sulla carta non cambia: nella data c'e' un solo Legno (卯 dell'anno).
RILETTURA DI CLAUDE col metodo · `DA VALIDARE`
Scheda nuova: L2, lo Shi G 亥, e' incompatibile: da ferma diventa mobile. Con L2 e L3 insieme
巽 diventa 坤: L3 va in 卯, L2 va in 巳.
- L3 W 酉 -> 卯 (P, morto): il giorno 子 penalizza l'arrivo 卯 (e pesa di piu', Acqua di
  stagione): l'arrivo non agisce, la partenza resta attiva e ferma, W -> la sede bassa vince.
- L2 Shi G 亥 -> 巳 (B), vuoto e non svegliato; sopra cade l'anno 癸卯, che drena il 亥 e si
  prende la linea: lo Shi diventa 卯 Legno, P, morto nel mese.
Traccia: lo Shi non puo' stare dove sta e l'anno se lo prende: P sullo Shi -> la sede bassa
perde -> LONG. Anche contando l'arrivo 巳 sarebbe un B -> LONG.
Verifica: contro c'e' la W di L3 attiva (SHORT); pesa di meno: e' ferma, senza bestie, col suo
arrivo abbattuto dal giorno, mentre lo Shi e' la sede stessa e ha la bestia (come la seconda
mobile con le bestie su EURJPY 15/08/2024). L4 presa dall'ora diventa G in alto -> LONG,
concorde. Il raduno 亥子丑 perde il suo 亥 (lo Shi se ne va); il trigono di Legno e' fuori
stagione.
Conclusione: LONG (mercato LONG +113). Punto non coperto da una carta: una bestia sola (su
EURJPY 15/08/2024 erano due). Non cablato: il motore su questa carta tace.
MISURA della sola coppia 亥 in 巽:
  prima                  2488 carte  51,53%  +6.121 pip · recente 52,30%
  亥 in 巽, senza ponte   2498 carte  52,64%  +9.334 pip · recente 53,52%
  亥 in 巽, ponte Legno   2498 carte  52,40%  +8.683 pip · recente 53,52%
ROTTA: USDJPY 13/02/2024 (seme 149), la carta sorgente del §69. Stesso trigramma basso 巽 con L2
亥: ora L2 si muove, il futuro comune porta L3 in 卯 (vuoto) e il motore dice SHORT (mercato
LONG +137). Edu l'aveva letta il 17/08, prima della dottrina della linea incompatibile. Da
rileggere col metodo.

**CORREZIONE DI EDU sulla rilettura di EURJPY 10/08/2023 — `CONFERMATA DA EDU`** · 11/09/2026
Edu: "Qui hai fatto un errore. Quando S o Y vengono presi dalle bestie da quel momento in poi la
partita diventa esclusivamente fra S vs Y."
Errore di Claude: presa la sede, l'aveva fatta parlare col carattere (P sullo Shi). Invece da li'
conta solo il confronto fra le sedi.
Rilettura: lo Shi preso dall'anno e' 卯 Legno; la Ying L5 未 Terra, senza bestie. Il Legno
controlla la Terra: vince lo Shi, sede bassa -> SHORT. Nient'altro conta (ne' la W di L3, ne' L4).
Conclusione: SHORT. Mercato LONG (-113): la carta si legge SHORT e si perde.
CABLATO `T0y la sede presa si muove` (MLSEDESEC), prima di T0r: la seconda mobile (ferma
incompatibile) e' lo Shi o la Ying e una bestia se la prende -> confronto diretto Shi/Ying.
PROVATO IN LARGO e SPENTO (MLSOLOSY=tutto): "appena una sede qualunque e' presa, solo Shi contro
Ying" in testa alla lettura -> 1.525 carte al 49,25%, rompe otto carte di riferimento di Edu
(fra cui USDJPY 08/02/2024, dove Edu fa parlare col carattere il pilastro che prende lo Shi
mobile: "寅 e' sempre un B perdente"). Il perimetro largo va chiarito con Edu.
MISURA:
  prima (con 亥 in 巽)       2498 carte  52,64%  +9.334 pip · recente 53,52%
  con T0y                    2516 carte  52,86% +10.647 pip · recente 53,68%
    gradino T0y               136 carte  47,06%   -274 pip
Carte di riferimento: 23 su 25 (sbagliate USDJPY 13/02/2024, rotta da 亥 in 巽 e da rileggere,
ed EURJPY 10/08/2023, che con le regole di Edu si legge SHORT e va persa).

**LETTURA DI EDU su EURJPY 10/08/2023 (seme 157) — `CONFERMATA DA EDU`** · 11/09/2026, S46
Edu: "Altro errore: quando arriva una bestia su una linea non ci sono piu' vuoti! Quindi arriva
Mao che fa da ponte fra Hai e Si quindi il flusso arriva fino a Si che genera Ying con Wei e fa
vincere il Long!"
Lettura: lo Shi L2 亥 si muove (incompatibile) verso 巳; l'arrivo 巳 era vuoto, ma sulla linea
arriva la bestia dell'anno 癸卯, quindi non c'e' piu' vuoto. 卯 fa da ponte: 亥 Acqua -> 卯
Legno -> 巳 Fuoco. Lo Shi e' Fuoco; nel confronto il Fuoco genera la Terra della Ying 未: la Ying
e' nutrita e vince -> LONG (+113).
Due errori di Claude: aveva preso il vuoto del giorno per buono su una linea con la bestia, e
aveva fermato lo Shi sull'elemento della bestia invece di seguire il flusso fino all'arrivo.
CABLATO:
1. `vuotaL` (MLBESTIAPIENA): una linea su cui cade un pilastro con la sua bestia non e' vuota.
   Vale in tutti i punti in cui il motore di lettura guarda il vuoto di una linea (forza, bersagli
   delle porte, sede che combina, finisce in niente, unica azione, svegliate).
2. Nel T0y (sede in movimento presa dalle bestie): la bestia fa da PONTE — dal ramo della linea,
   di bestia in bestia per generazione, fino all'arrivo se la catena lo genera. MLPONTEBESTIA=off
   per fermarsi sulla bestia. Perimetro: la sede che si muove, come sulla carta.
MISURA:
  prima                              2516 carte  52,86% +10.647 pip · recente 53,68%
  con le due regole                  2514 carte  52,78% +10.151 pip · recente 53,41%
    senza la linea piena (1 spenta)              52,90% +10.582
    senza il ponte (2 spenta)                    52,74% +10.216
  T0y: 135 carte 48,15% (-312)
Regole di Edu: si tengono. Carte di riferimento 24 su 25 (EURJPY 10/08/2023 ora giusta; resta
USDJPY 13/02/2024).

**Carta riletta da Claude col metodo · USDJPY 13/02/2024 seme 149 · `DA VALIDARE`** · S46
Carta sorgente del §69 (Edu 17/08: mobile sospesa dal giorno, "due tentativi non riusciti, chi
non vince perde", il giorno rompe la Ying piena -> LONG +137). Rotta da 亥 in 巽.
Palazzo 震 (Legno), 兌 sopra 巽 (大過 28), mese 丙寅, giorno 丁未, anno 甲辰, ora 甲辰, vuoti 寅 卯.
Scheda: L6 W 未, sul ramo del giorno, anno e ora 甲辰 sopra (stesso ramo, nessuna guerra) -> resta
Terra. L5 G 酉, niente. L4 Shi P 亥, il mese 寅 lo combina, nessuna bestia. L3 G 酉 mobile, fuori
stagione, nessuna bestia. L2 P 亥 in 巽: incompatibile (un solo Legno), da ferma diventa mobile.
L1 Ying W 丑: giorno 丁未 (clasha: la fa muovere, non la prende) e mese 丙寅 (la controlla: la
prende); nessuna guerra; con la bestia sopra non e' vuota.
Futuro comune (L2+L3): 巽 -> 坤, L3 va in 卯 (vuoto, nessuna bestia su L3), L2 va in 巳 (C).
Traccia 1, la mobile: l'arrivo 卯 e' vuoto, il movimento non porta a niente -> chi non vince
perde (come Edu su questa carta il 17/08) -> sede bassa perde -> LONG. [Col §114 invece la G
resterebbe e farebbe vincere la bassa -> SHORT.]
Traccia 2, la Ying presa dal mese: da li' solo Shi contro Ying. Ying 寅 Legno (non vuoto sotto la
bestia) contro Shi 亥 Acqua: l'Acqua nutre il Legno, vince la Ying, sede bassa -> SHORT. (Anche
tenendo la Ying Terra: la Terra controlla l'Acqua, vince la Ying -> SHORT.)
Verifica: su EURJPY 10/08/2023 Edu ha dato la precedenza al confronto fra le sedi sopra L3; qui
lo stesso ordine da' SHORT. Raduno 寅卯辰 di Legno di stagione con l'arrivo 卯: chiuderebbe solo
contando un arrivo vuoto come membro, non coperto.
Conclusione: SHORT, contro il mercato e contro la lettura di Edu del 17/08. Punto aperto: che
cosa viene prima, il movimento che finisce nel vuoto o la Ying presa dal mese.

**LETTURA DI EDU su USDJPY 13/02/2024 (seme 149) — `CONFERMATA DA EDU`** · 11/09/2026, S46
Edu: "Ying clashato dal giorno diventa mobile e questo trasforma l'intero trigramma inferiore in un
total clash. Poiche' sotto e' in uno stato di confusione totale, vince il sopra."
Si muovono tutte e tre le linee di 巽: L3 (la mobile), L2 (亥 incompatibile), L1 (la Ying, clashata
dal giorno 丁未 che ci cade sopra con la sua bestia). Il trigramma basso e' in confusione totale:
vince l'alto -> LONG (+137). La domanda di Claude (chi viene prima fra L3 e la Ying presa) era
mal posta: la cosa che decide e' il trigramma intero.
NUOVA REGOLA cablata come `T0z confusione totale` (MLCONFUSIONE), subito dopo la guerra fra
titani: si muovono la mobile, le ferme incompatibili, le ferme clashate dal giorno (col pilastro
del giorno e la sua bestia sopra, in ogni stagione; oppure di stagione) salvo se protette dalla
combinazione col mese; le annullate dalla guerra no. Tutte e tre le linee del trigramma basso in
movimento -> vince l'alto. L'alto nella stessa condizione (simmetria di Claude): MLCONFUSIONE=due,
spenta — sul mazzo non capita mai.
MISURA:
  prima                        2514 carte  52,78% +10.151 pip · recente 53,41%
  con T0z                      2518 carte  52,86% +10.245 pip · recente 53,45%
    gradino T0z                  29 carte  48,28%    -21 pip
Carte di riferimento: 25 su 25 giuste.
PRECISAZIONE DI EDU (11/09/2026): "Aspetta, qui il problema e' che le tre linee si muovono per
clashare se stesse, solo questo."
Non basta che le tre linee del basso si muovano: ognuna si muove per clashare se stessa. L3 酉 ->
卯, L2 亥 -> 巳 (arrivi del futuro comune che clashano la partenza), L1 丑 clashata dal giorno 未.
Il cablaggio T0z ora conta solo il movimento che clasha la propria partenza (la mobile e la ferma
incompatibile col loro arrivo; la ferma clashata dal giorno per il clash stesso). La versione
larga ("basta che si muovano", mia lettura sbagliata) resta dietro MLCONFUSIONE=muovere.
MISURA:
  T0z largo (si muovono)        29 carte  48,28%   -21 pip · mazzo 52,86% +10.245
  T0z di Edu (si clashano)       9 carte  66,67%  +323 pip · mazzo 52,96% +10.884 · recente 53,53%
Carte di riferimento: 25 su 25.

**Carta letta da Claude col metodo · EURJPY 17/07/2024 seme 172 · `DA VALIDARE`** · S46
Peggiore perdente del gradino piu' debole ("T4b sede presa, mobile non decide, una sede, una
bestia": 54 carte al 46,30%). STESSO ESAGRAMMA del §104 (巽 sopra 震, L4 未 -> 午; Edu 27/08).
Palazzo 巽 (Legno), mese 辛未, giorno 壬午, anno 甲辰, ora 癸卯, vuoti 申 酉.
Scheda: L6 Ying B 卯 (ramo dell'ora); il mese 辛未 ci cade sopra: il Legno lo controlla ma e'
fuori stagione -> il mese la prende, Ying = 未 Terra. L5 C 巳, niente. L4 W 未 mobile, sul ramo
del mese (caricata, §126), verso 午: il giorno 午 combina la partenza (impigliata) e siede
sull'arrivo 午 (autopenalita': l'arrivo non agisce). L3 Shi W 辰, Tai Sui, nascosto G 酉 (vuoto).
L2 B 寅, l'anno 甲辰 la prende -> Terra. L1 P 子: giorno 壬午 (clash, la muove) e ora 癸卯 (drena,
la prende); nessuna guerra. Nessuna incompatibile. Raduno 寅卯辰 completo ma fuori stagione, senza
la mobile. Nessuna confusione totale (L2 e L3 non si muovono).
Traccia: la mobile e' una W forte sul mese; l'arrivo penalizzato non agisce, la partenza resta
attiva e ferma e parla (regola certificata, EURUSD 14/07/2021): W -> sede alta vince -> LONG.
Verifica: la Ying presa dal mese -> solo Shi contro Ying: Terra contro Terra, pari, le bestie
stanno con la Ying -> LONG. Nel §104 la mobile usciva perche' fuori stagione e senza la
generazione all'indietro; qui e' di stagione e non ne ha bisogno. L'unica strada per SHORT e' "chi
non vince perde" sulla mobile tenuta ferma, ma contraddice la regola certificata dell'arrivo
penalizzato (parla la partenza). La difesa col nascosto 酉 dello Shi e' il vicolo cieco gia'
misurato sul §104: non usata.
Conclusione: LONG. Mercato SHORT (-181): con le regole che conosco la carta si perde.

**LETTURA DI EDU su EURJPY 17/07/2024 (seme 172) — `CONFERMATA DA EDU`** · 11/09/2026, S46
Edu: "L4 rimane attiva ma con la bestia Mao che arriva su L1 si crea un trigono di legno nel
trigramma inferiore, il Legno e' B che poi va ad alimentare la bestia di fuoco Wu che pure arriva
su L1 e che e' una C. Quando B genera una C la propria squadra vince."
Nel trigramma basso: 寅 (L2) + 卯 (bestia dell'ora 癸卯 su L1) + 辰 (L3) = 寅卯辰, Legno = B nel
palazzo 巽; il Legno alimenta il 午 della bestia del giorno 壬午 su L1, Fuoco = C. B genera C: la
squadra bassa vince -> SHORT (+181). Comanda sulla W di L4, attiva.
Errore di Claude: il raduno 寅卯辰 l'aveva visto ma scartato perche' fuori stagione e senza la
mobile; non aveva guardato che cosa alimentava.
NUOVA REGOLA cablata come `T0t il B genera la C` (MLBGENC), prima di T0r: raduno o trigono chiuso
dentro un trigramma (rami delle sue linee + rami delle bestie che ci cadono), di elemento B nel
palazzo, che genera la C di una bestia caduta su una linea dello stesso trigramma -> quella
squadra vince. Nessuna condizione di stagione (sulla carta il Legno e' fuori stagione).
Estensione di Claude SPENTA: anche una linea C, non solo una bestia (MLBGENC=linea: 127 carte
48,82%, mazzo 52,50%).
MISURA:
  prima                      2517 carte  52,96% +10.884 pip · recente 53,53%
  con T0t                    2526 carte  52,77% +10.711 pip · recente 53,52%
    gradino T0t                67 carte  59,70%  +1.039 pip
Regola di Edu: si tiene. Carte di riferimento 26 su 26.
APERTO: la Ying L6 卯 con sopra il mese 辛未 — il motore la dava presa (la linea controlla la
bestia ma e' fuori stagione: regola del motore, non di Edu). Nella lettura di Edu non entra.

**REGOLA DI EDU — LA LINEA CHE CONTROLLA LA BESTIA — `CONFERMATA DA EDU`** · 11/09/2026, S46
Domanda di Claude: quando e' la linea a controllare la bestia che le cade sopra, la bestia se la
prende o no? Edu: "Se e' una bestia sola e la linea e' timely puo' opporsi alla presa, ma se la
bestia e' il mese e' impossibile opporsi."
Prima il motore decideva solo con la stagione della linea (regola del motore, non di Edu); ora il
mese se la prende sempre. (Con due o piu' bestie la presa c'era gia' sempre.) MLMESEPRENDE=off
per il vecchio conto.
Su EURJPY 17/07/2024 la Ying 卯 col mese 辛未 sopra e' quindi presa comunque: la carta resta letta
per il B che genera la C nel trigramma basso, che viene prima.
MISURA: mazzo da 52,77% (+10.711) a 52,87% (+10.976), recente 53,48%. Carte di riferimento 26/26.

**Carta letta da Claude col metodo · EURJPY 29/09/2022 seme 140 · `DA VALIDARE`** · S46
Peggiore perdente di "T7 il duello" (118 carte al 46,61%). Palazzo 巽 (Legno), 乾 sopra 震
(無妄 25), mese 己酉, giorno 乙酉, anno 壬寅, ora 癸未, vuoti 午 未.
Scheda: L6 W 戌, anno 壬寅 e ora 癸未 sopra (nessuna guerra, presa in due, resta Terra). L5 G 申,
di stagione, niente. L4 Shi C 午 vuota, il mese 己酉 ci cade sopra: la linea controlla il mese ma
al mese non ci si oppone -> presa, e non piu' vuota: Shi = 酉 Metallo. L3 W 辰 mobile verso 亥: il
giorno 酉 (e il mese) combina la partenza -> impigliata, resta W. L2 B 寅 sul ramo dell'anno.
L1 Ying P 子, il giorno 乙酉 ci cade sopra e la nutre (non la prende). Nessuna incompatibile.
Trigramma alto: 寅 (bestia su L6) + 午 (L4) + 戌 (L6) = trigono di Fuoco, C nel palazzo.
Traccia: lo Shi e' preso dal mese -> da li' solo Shi contro Ying: il Metallo dello Shi genera
l'Acqua della Ying, la Ying e' nutrita e vince, sede bassa -> SHORT.
Verifica: la mobile, impigliata, resta W in basso -> SHORT, concorde (e comunque fuori dal
confronto). Unica cosa dall'altra parte: il trigono di Fuoco chiuso nel trigramma alto e' una C
che alimenta la W 戌 (L6) — sarebbe "C genera W" nell'alto, ma la regola di Edu e' "B genera C":
non coperta, non usata.
Conclusione: SHORT. Mercato LONG (-167): con le regole che conosco la carta si perde.

**LETTURA DI EDU su EURJPY 29/09/2022 (seme 140) — `CONFERMATA DA EDU`** · 11/09/2026, S46
Edu: "1a raccolta dati: con la Shi occupata dalla bestia Ji You, l'intero trigramma superiore
diventa un trigono direzionale di metallo (Shen, You, Xu) estremamente timely, e quando l'altra
bestia Yi You del giorno arriva su Ying, Shi penalizza Ying. Shi e' molto piu' forte perche' ha un
trigono dal suo lato. 2a raccolta dati: Ying pero' e' sempre Zi Acqua e potrebbe farsi generare e
vincere. Conclusione: Long. Perche'? Perche' i due You sono diversi. Ji You e' terra dello stelo
che genera il metallo. Yi You e' stelo di legno che, con Zi acqua su Ying, viene generato. Quindi,
su Y l'acqua di Zi perde energia generando il Legno dello stelo mentre su S la terra genera il
metallo."
IL METODO DI EDU, visto qui: prima raccolta dei dati di una parte, seconda raccolta dei dati che
potrebbero ribaltare, poi il discriminante e la conclusione. Claude si era fermato alla prima
relazione (il Metallo nutre l'Acqua) e NON aveva guardato gli STELI dei pilastri. Da ora nella
scheda, per ogni bestia: elemento dello stelo e sua relazione col ramo e con la linea.
CABLATO:
1. Nel confronto fra le sedi, quando uno genera l'altro: se chi riceve e' drenato dallo stelo
   della bestia che ha sopra (la linea genera lo stelo) e chi dona e' nutrito dallo stelo della
   sua (lo stelo genera il suo elemento), vince chi dona. MLSTELI=off; MLSTELI=drena (basta il
   drenaggio, estensione di Claude: peggio, spenta).
2. T7: se nessuna traccia conclude e una sede e' presa dalle bestie, il duello e' il confronto
   diretto Shi/Ying (regola di Edu: da quel momento solo S vs Y), non la sola forza.
   MLDUELLOPRESA=off.
3. Il duello non considera "fuori gioco" per vuoto una linea con la bestia sopra (lo stato
   dormiente della catena conta solo se la linea e' davvero vuota).
Non cablati (dati della prima raccolta): il trigono direzionale 申酉戌 dalla parte dello Shi e la
penalita' 酉酉 dello Shi sulla Ying.
MISURA:
  prima                                   2527 carte  52,87% +10.976 pip · recente 53,48%
  solo la 3                               2505 carte  52,85% +10.694
  1+2+3                                   2626 carte  52,67% +10.142 pip · recente 53,71%
    T7 duello (sede presa)                 161 carte  48,45%   -439 pip (senza steli 46,58%)
  MLSTELI=drena (Claude)                               52,55%  +9.721 -> spenta
Regole di Edu: si tengono. Il motore ora parla su 99 carte in piu'. Carte di riferimento 27/27.
CABLATI ANCHE I DUE DATI DELLA PRIMA RACCOLTA (Edu: "Devi cablarli questi due!"):
4. IL RADUNO DAL SUO LATO (MLRADLATO): raduno direzionale (三會) chiuso nel trigramma della sede,
   coi rami delle sue linee e delle bestie che ci cadono, dello stesso elemento della sede e di
   stagione -> +2 alla forza della sede (entra dove il motore pesa la forza).
5. LA PENALITA' FRA LE SEDI (MLPENSEDI): i rami della sede (della bestia che l'ha presa,
   altrimenti il suo) contro i rami dell'altra (il suo e quelli delle bestie che ci arrivano),
   con la tavola di Edu (寅巳申 con la regola del 寅, 丑戌未, 子卯, autopenalita' 辰午酉亥); se va
   nei due sensi penalizza la piu' forte; chi penalizza pesa almeno quanto chi riceve. Chi riceve
   la penalita' non fa vincere la sua squadra. Posizione: DOPO generazione e controllo — nella
   lettura di Edu la generazione ("Ying potrebbe farsi generare e vincere") puo' ribaltarla e
   decidono gli steli. MLPENSEDI=prima la mette prima della generazione.
MISURA:
  nessuno dei due                2623 carte  52,69% +10.142 · recente 53,75%
  solo raduno                                52,73% +10.204
  solo penalita'                             52,70% +10.010
  tutti e due, penalita' prima               52,74% +10.072 · recente 53,82%
  tutti e due, penalita' dopo    2626 carte  52,74% +10.268 · recente 53,89%  <- default
Carte di riferimento 27/27.

**Carta letta da Claude col metodo · USDJPY 19/12/2024 seme 154 · `DA VALIDARE`** · S46
La peggiore delle 60 carte nuove sbagliate (T7 duello con sede presa, SHORT, mercato LONG +277).
Carta di controllo della dottrina della cattura (Edu, §72 ripresa): "Acqua dominante — 申子辰 ...
l'Acqua controlla la Ying-Fuoco -> Ying spenta -> vince la Shi -> LONG".
Palazzo 艮 (Terra), 離 sopra 兌 (睽 38), mese 丙子, giorno 丁巳, anno 甲辰, ora 己酉, vuoti 子 丑.
Scheda: L6 P 巳 (ramo del giorno), l'anno 甲辰 la drena e la prende -> Terra. L5 B 未 mobile,
fuori stagione, nascosto W 子, verso 申 (C); il giorno 巳 combina l'arrivo (senza 寅: combinazione)
-> arriva e si ferma, parla l'arrivo: C, tace. L4 Shi C 酉 (ramo dell'ora), nessuna bestia.
L3 B 丑 vuota, l'ora 己酉 la drena e la prende (non piu' vuota) -> Metallo. L2 G 卯, di stagione,
niente. L1 Ying P 巳 (ramo del giorno): giorno 丁巳 (stesso ramo, carica) e mese 丙子 (la
controlla); due bestie, nessuna guerra: presa, ma la catena dal 巳 non passa a nessuna bestia per
generazione -> resta Fuoco. Steli sulla Ying 丁 e 丙: Fuoco, nessun drenaggio.
Trigono d'Acqua 申子辰: 申 (arrivo di L5), 子 (nascosto di L5, e mese), 辰 (anno su L6) — tutto nel
trigramma alto, dalla parte dello Shi; Acqua di stagione nel mese 子.
1a raccolta (Shi): il trigono d'Acqua di stagione sta dalla sua parte e l'Acqua controlla il
Fuoco della Ying; sulla Ying c'e' il mese stesso, 子, che la controlla.
2a raccolta (Ying): la Ying e' Fuoco e il Fuoco controlla il Metallo dello Shi -> potrebbe
vincere lei (e' quello che fa il motore: SHORT).
Discriminante: il Fuoco della Ying e' morto nel mese 子 (死) e ha il mese sopra che lo controlla:
non ha la forza di controllare il Metallo; l'Acqua dominante lo spegne. Vince lo Shi -> LONG.
Conclusione: LONG (mercato LONG +277), come la lettura di Edu nella dottrina della cattura.
PUNTO NON COPERTO: che nel confronto fra le sedi il controllo di un elemento morto non valga. La
regola di Edu dice che la linea di stagione puo' opporsi alla bestia; per il controllo fra le
sedi non c'e' una carta. Non cablato.

**CORREZIONE DI EDU su USDJPY 19/12/2024 (seme 154) — `CONFERMATA DA EDU`** · 11/09/2026, S46
Edu: "Ma non l'avevamo gia' letta? Non hai fatto muovere l'incompatibile L2?"
Errore di Claude: nella scheda L2 G 卯 in 兌 era scritta "niente". E' incompatibile (ponte
d'Acqua: nella data un solo 子), quindi da ferma diventa mobile: nel futuro comune va in 寅, cioe'
RETROCEDE. Il G che retrocede su una seconda mobile fa perdere la propria sede (AUDUSD 22/12/2025,
confermato da Edu): la sede bassa perde -> LONG (+277). Il "discriminante" di Claude (il Fuoco
morto della Ying) e la domanda sul controllo di un elemento morto erano fuori strada: ritirati.
Lezione: l'incompatibilita' va controllata su OGNI linea, sempre, prima di tutto il resto.
CABLATO: T0r ora vale per la seconda mobile G o W che retrocede, anche SENZA bestie (le bestie
servono a darle energia e a togliere il vuoto dell'arrivo, come su EURJPY 15/08/2024; senza
bestie un arrivo vuoto non conta). MLBESTIESEC=bestie2 per la versione di prima.
MISURA:
  prima (solo W con due bestie)   2626 carte  52,74% +10.268 · recente 53,89%
  G/W che retrocede               2642 carte  52,50%  +9.964 · recente 54,09%
    gradino T0r                    130 carte  50,00%    +335 pip
Carte di riferimento 28 su 28 (con USDJPY 19/12/2024).

**Carta letta da Claude col metodo · EURUSD 03/01/2023 seme 106 · `DA VALIDARE`** · S46
La peggiore delle 34 rotte dalla T0r allargata (prima SHORT giusta via "agisce la ferma
incompatibile di L2, G"; ora LONG, mercato SHORT -129).
Palazzo 艮 (Terra), 巽 sopra 兌 (中孚 61), mese 壬子, giorno 辛酉, anno 壬寅, ora 丁酉, vuoti 子 丑.
Scheda (incompatibili per prime): L2 卯 in 兌 incompatibile (una sola Acqua, 子) -> mobile.
L6 G 卯 di stagione, il giorno 酉 la clasha -> si sveglia. L5 P 巳 mobile, morto, nascosto W 子,
verso 子 (W): arrivo vuoto, nessuna bestia su L5 -> il passo non porta a niente. L4 Shi B 未,
l'ora 丁酉 la drena e la prende -> 酉. L3 B 丑 vuota, nascosto C 申, nessuna bestia. L2 G 卯 di
stagione, incompatibile, mese 壬子 e anno 壬寅 sopra (nessuna guerra), il giorno 酉 la clasha (ma
non la ferma); nel futuro comune va in 寅 = RETROCEDE, e l'anno siede proprio sul ramo del suo
arrivo. L1 Ying P 巳 morta, il giorno 辛酉 ci cade sopra: la linea controlla la bestia ma e' fuori
stagione -> presa -> 酉.
1a raccolta (LONG): L2 G che retrocede con due bestie che le danno energia -> la sede bassa perde
(come la W di EURJPY 15/08/2024 e il G di USDJPY 19/12/2024).
2a raccolta (SHORT): la prima mobile P va in un arrivo vuoto: non vince, perde -> l'alto perde.
Tutte e due le sedi sono prese da un 酉 -> solo Shi contro Ying; ma i due 酉 sono diversi: sulla
Ying 辛酉 (stelo di Metallo sul Metallo), sullo Shi 丁酉 (stelo di Fuoco che controlla il suo
Metallo) -> la Ying e' piu' forte e penalizza lo Shi (酉酉) -> vince la Ying, sede bassa -> SHORT.
Conclusione di Claude: SHORT (mercato SHORT), ma NON e' coperta: su USDJPY 19/12/2024 la Ying era
presa e ha deciso lo stesso L2 che retrocede. Differenze possibili: qui sono prese TUTTE E DUE le
sedi; qui il giorno clasha L2; qui l'anno siede sul ramo dell'arrivo di L2. Non cablato.

**CORREZIONE DI EDU su EURUSD 03/01/2023 (seme 106) — `CONFERMATA DA EDU`** · 11/09/2026, S46
Edu: "L2 sebbene incompatibile e costretta a muoversi, e' clashata dal giorno e penalizzata dal
mese e poiche' se la vede cosi' male, viene sostituita dalla bestia dell'anno Ren Yin. Quindi il
problema che vedi tu non c'e'."
L2 卯: il giorno 酉 la clasha, il mese 子 la penalizza (子刑卯) -> la sostituisce la bestia
dell'anno 壬寅 (quella che non la attacca): L2 non retrocede. La conclusione SHORT resta (mercato
SHORT +129). Il contrasto con USDJPY 19/12/2024 non c'era: li' L2 non era colpita cosi'.
CABLATO (MLSOSTSEC), dentro T0r: la seconda mobile clashata dal giorno E penalizzata dal mese,
con sopra una bestia che non la attacca (ne' il mese, ne' il giorno, ne' un ramo che la clasha o
la controlla), e' sostituita da quella bestia e non retrocede.
MISURA:
  prima                         2642 carte  52,50%  +9.964 · recente 54,09%
  con la sostituzione           2642 carte  52,54% +10.222 · recente 54,09%
    T0r                          129 carte  50,39%    +464 pip
Carte di riferimento 29 su 29 (con EURUSD 03/01/2023). NOTA: sulla carta il motore arriva a
SHORT per la via "agisce la ferma incompatibile di L2, G" — il sostituto 寅 e' anch'esso un G,
quindi il verdetto coincide, ma la via non e' quella della lettura (Shi contro Ying coi due 酉).
CHIUSURA DI EDU su EURUSD 03/01/2023 (11/09/2026): "L2 ... viene sostituita dalla bestia dell'anno
Ren Yin. Questo e' il motivo per cui va Short. Se bene la nascosta su L5 sia forte in realta' non
fa nulla, mi ero sbagliato prima."
Quindi: sostituita L2, parla la bestia che l'ha sostituita, col proprio carattere e dalla sede di
L2 — 寅 nel palazzo 艮 e' un G -> la sede bassa vince -> SHORT (+129). Il nascosto 子 di L5, per
quanto forte (ramo del mese, arrivo della mobile), NON agisce: la pista del nascosto e' chiusa su
questa carta. La lettura Shi/Ying coi due 酉 resta un dato, non la via.
Cablato `T0q la seconda sostituita dalla bestia` (MLSOSTPARLA), dentro T0r: 1 carta, giusta.
Mazzo invariato 2642 · 52,54% · +10.222 · recente 54,09%. Carte di riferimento 29/29, ora per la
via giusta.

**Carta letta da Claude col metodo · USDJPY 12/01/2023 seme 131 · `DA VALIDARE`** · S46
La peggiore del gradino piu' grosso che non risponde ("T7 il duello (sede presa)": 151 carte al
46,36%). Motore LONG, mercato SHORT -264.
Palazzo 坎 (Acqua), 坤 sopra 離 (明夷 36), mese 癸丑, giorno 庚午, anno 壬寅, ora 丙戌, vuoti 戌 亥.
Scheda (incompatibili per prime): nessuna delle cinque coppie (卯兌 午坎 申艮 丑坤 辰乾 亥巽) —
L2 丑 sta in 離, non in 坤; L4/L5 stanno in 坤 ma sono 丑 e 亥 di 坤? no: L4 丑 in 坤 SI'.
  -> L4, lo Shi, 丑 nel trigramma 坤: INCOMPATIBILE (coppia senza ponte) -> da ferma diventa
     mobile. Futuro comune con L6: 坤 -> 艮; L6 va in 寅 (non piu' 寅? verifica) e L4 va in 戌.
L6 P 酉 mobile, di stagione? Metallo nel mese 丑 e' 養/休: fuori stagione; verso 寅; l'ora 丙戌 ci
cade sopra (drena? 戌 Terra genera Metallo: la nutre, non la prende). L5 B 亥 vuota, nessuna
bestia -> non agisce. L4 Shi C 丑, mese 癸丑 sopra (stesso ramo: la carica), incompatibile.
L3 B 亥 vuota, nascosto W 午 (ramo del giorno, fortissimo). L2 C 丑, l'anno 壬寅 la controlla e la
prende -> 寅 Legno. L1 Ying G 卯, il giorno 庚午 la drena e la prende -> 午 Fuoco.
Traccia 1: lo Shi incompatibile si muove e va in 戌 — 丑戌 e' PENALITA': lo Shi si muove per
penalizzare se stesso. Chi riceve la penalita' non fa vincere la sua squadra -> la sede alta
perde -> SHORT.
Traccia 2 (quella del motore): sedi prese, solo Shi contro Ying; Ying 午 Fuoco genera la Terra
dello Shi -> Shi nutrito vince -> LONG. Ma lo Shi e' penalizzato dal proprio arrivo: non puo'
far vincere la sua squadra.
Verifica: L6, la prima mobile, arriva in 寅 che combina il 亥 vuoto di L3 -> il movimento finisce
in niente -> chi non vince perde -> la sede alta perde -> SHORT, concorde. Il nascosto 午 di L3 e'
forte ma la linea che lo copre (亥 vuota) non e' fuori stagione in modo da farlo uscire: non
agisce (come su EURUSD 03/01/2023).
Conclusione: SHORT (mercato SHORT +264). Da verificare con Edu: 1) L4 丑 in 坤 e' davvero
incompatibile (il trigramma 坤 non compare fra le cinque coppie come trigramma ospite: la coppia
"丑坤" e' il ramo 丑 nel trigramma 坤 — SI'); 2) la penalita' del proprio arrivo sulla sede.

**LETTURA DI EDU su USDJPY 12/01/2023 (seme 131) — `CONFERMATA DA EDU`** · 11/09/2026, S46
Edu (con la sua carta): "La tua lettura va bene, ma questa e' piu' veloce. Un trigono di metallo si
forma nel trigramma superiore. Il metallo e' P che fa perdere la propria squadra."
Trigramma alto: 酉 (L6, che si muove) + 亥 (L5) + 丑 (L4, 丑 in 坤 incompatibile, si muove) — il
trigono 巳酉丑 si chiude coi rami del trigramma e gli arrivi. Metallo = P nel palazzo 坎: la sede
alta perde -> SHORT (+264). La lettura di Claude (penalita' 丑戌 sullo Shi in movimento + il
movimento che finisce in niente) e' confermata giusta ma piu' lunga; la domanda sulla penalita'
del proprio arrivo resta aperta e non cablata.
NUOVA REGOLA cablata come `T0u il trigono nel trigramma` (MLTRIGTRIG): dentro un trigramma, rami
delle sue tre linee piu' gli arrivi delle linee che si muovono li'; se chiudono un trigono (三合)
parla il suo carattere nel palazzo per quella squadra (P/B: quella sede perde; G/W: vince).
Serve almeno una linea in movimento fra i portatori. POSIZIONE: dopo "la sede presa che si muove"
— su EURJPY 10/08/2023 (letta da Edu) lo stesso 巳酉丑 si chiude nel basso, ma li' decide il
flusso dello Shi che si muove con la bestia che fa da ponte; messo prima, rompeva quella carta.
MISURA:
  prima                        2642 carte  52,54% +10.222 · recente 54,09%
  con T0u                      2653 carte  52,77% +11.219 · recente 54,54%
    gradino T0u                  96 carte  54,17%    +491 pip
Carte di riferimento: 30 su 30 giuste.

**Carta letta da Claude col metodo · USDJPY 13/09/2022 seme 142 · `DA VALIDARE`** · S46
La peggiore rimasta del gradino grosso (T7 duello con sede presa, 142 carte al 46%). Motore
SHORT, mercato LONG +210.
Palazzo 離 (Fuoco), 乾 sopra 坎 (訟 6), mese 己酉, giorno 己巳, anno 壬寅, ora 癸酉, vuoti 戌 亥.
Scheda (incompatibili per prime): L3 午 in 坎 e' INCOMPATIBILE (ponte di Legno: un solo 寅 nella
data) -> da ferma diventa mobile. Futuro comune (L1 + L3): 坎 -> 乾, quindi L1 寅 -> 子 (non piu'
巳) e L3 午 -> 辰.
L6 C 戌 vuota, nessuna bestia -> non agisce. L5 W 申 di stagione, nessuna bestia. L4 Shi B 午
fuori stagione, nessuna bestia. L3 B 午 incompatibile, nascosto G 亥 (vuoto), verso 辰. L2 C 辰,
nessuna bestia. L1 Ying P 寅 mobile, ramo dell'anno, verso 子; sopra l'anno 壬寅 (stesso ramo: la
carica, non la prende).
Traccia: la Ying, P, si muove e va in 子 Acqua, che GENERA il suo stesso 寅 Legno: l'arrivo nutre
la partenza, la P resta se stessa e parla — il P fa perdere la propria squadra -> la sede bassa
perde -> LONG (+210).
Verifica: L3, la seconda mobile, e' un B che va in 辰: non retrocede (辰 non e' il passo indietro
di 午), quindi la regola della seconda che retrocede non entra. Trigono 寅午戌 di Fuoco: non si
chiude dentro un solo trigramma. Nessuna sede e' PRESA da una bestia (sull'anno su L1, stesso
ramo = carica): il motore entra nel duello per una presa che non c'e', e li' assegna la vittoria
a chi ha piu' bestie (SHORT).
Conclusione: LONG. Punto da chiarire con Edu: il motore considera "presa" anche la bestia che
carica col proprio stesso ramo — sulla carta non lo e'.

**LETTURA DI EDU su USDJPY 13/09/2022 (seme 142) — `CONFERMATA DA EDU`** · 11/09/2026, S46
Edu: "The reason for the Long is L3 moving to generate L5 W. Remember, when a line moves and is
not combined or clashed it looks doing something. It can combine, clash or generate another line.
If it doesn't do any of the above then it stays quiet at arrival."
L3 (午 in 坎, incompatibile) si muove verso 辰 e non e' ne' combinata ne' clashata: cerca qualcosa
da fare e GENERA la W 申 di L5 (Terra -> Metallo). Parla chi riceve: la W fa vincere la sede alta
-> LONG (+210). La traccia di Claude (l'arrivo 子 che nutre la P della Ying) non era la via.
NUOVA REGOLA cablata come `T0p le tre porte della seconda` (MLPORTESEC): le tre porte
(combinare, clashare, generare) valgono anche per la seconda mobile — la ferma incompatibile —
se non e' combinata ne' clashata dal giorno; parla chi riceve l'azione; se non trova niente resta
zitta all'arrivo.
POSIZIONE: dopo le regole della prima mobile e dopo T0r/T0u. Messa in testa (prima di T0r)
rompeva EURJPY 15/08/2024, dove decide L2 che retrocede con le bestie, e il mazzo scendeva a
51,94% (gradino 727 carte, 48,83%).
MISURA:
  prima                            2653 carte  52,77% +11.219 · recente 54,54%
  con T0p in testa                 2703 carte  51,94%  +9.581 · recente 52,13%   (scartata)
  con T0p dopo la prima mobile     2703 carte  52,35% +10.282 · recente 53,62%   <- cablata
    gradino T0p                     210 carte  48,57%     -30 pip
Regola di Edu: si tiene. Il motore parla su 50 carte in piu'. Carte di riferimento 31 su 31.

## S46 · PIU' MOTIVI PER LA STESSA CARTA (Edu, 11/09/2026)
Edu: "Ricorda che possono esserci piu' motivi e piu' interpretazioni per cui un esagramma va Short
o Long."
Conseguenze per il lavoro:
1. Una carta letta per una via NON chiude le altre vie: la lettura di Edu e' la via giusta, non
   l'unica. Le altre tracce trovate restano scritte come motivi concorrenti, non come errori
   (esempio in questa sessione: NZDUSD 10/08/2022 — il trigono 寅午戌 e la combinazione con la C
   vuota portano tutti e due a LONG).
2. Un gradino che misura male non significa che la regola sia sbagliata: puo' essere l'ordine, cioe'
   un altro motivo che su quelle carte viene prima (T0p, T0u, T0r spostati per questo).
3. Quando due motivi danno la stessa direzione, l'ordine non conta: conta solo dove si
   contraddicono. Sono quelle le carte da portare a Edu.
4. Nel registro, per ogni carta: la via di Edu marcata come tale, e sotto gli altri motivi
   trovati con la loro direzione.

**Carta letta da Claude col metodo · EURJPY 23/10/2024 seme 163 · `DA VALIDARE`** · S46
Peggiore rimasta del gradino grosso (T7 duello con sede presa, 90 carte). Motore SHORT, mercato
LONG +146.
Palazzo 坎 (Acqua), 震 sopra 離 (噬嗑 21), mese 甲戌, giorno 庚申, anno 甲辰, ora 壬午, vuoti 子 丑.
Scheda (incompatibili per prime): nessuna delle sei coppie (卯兌 午坎 申艮 丑坤 辰乾 亥巽) —
L4 午 sta in 震, L2 丑 in 離: nessuna incompatibile.
L6 G 戌 (ramo del mese), nessuna bestia. L5 Shi P 申, sul ramo del giorno, di stagione; il giorno
庚申 ci cade sopra con lo stesso ramo: lo carica. L4 W 午 mobile, sul ramo dell'ora, verso 丑
(vuoto, nessuna bestia su L4 -> resta vuoto): l'arrivo combina 子, che non c'e' fra le linee.
L3 B 亥: mese 甲戌 e anno 甲辰 sopra, coi rami in clash -> guerra fra titani, annullata.
L2 Ying G 丑, VUOTA, l'ora 壬午 ci cade sopra: con la bestia non e' piu' vuota; il Fuoco controlla
la Terra ed e' una bestia sola, ma la linea 丑 Terra e' di stagione nel mese 戌 -> puo' opporsi:
NON presa (il motore invece la da' presa e la fa Fuoco). L1 C 卯, nessuna bestia.
Motivi raccolti:
 a) La mobile W va in 丑 vuoto e non trova nessun bersaglio (ne' combinare, ne' clashare, ne'
    generare fra le ferme): il movimento non porta a niente -> chi non vince perde -> la sede
    alta perde -> SHORT. [contro il mercato]
 b) Confronto fra le sedi: Shi P 申 Metallo di stagione e caricato dal giorno, contro Ying G 丑
    Terra di stagione: la Terra GENERA il Metallo -> lo Shi e' nutrito e vince -> sede alta ->
    LONG. (Il motore fa vincere la Ying solo perche' la crede presa e la legge Fuoco.)
 c) Il trigramma alto 戌申午 non chiude nessun trigono; nessun raduno completo.
Conclusione: LONG per (b), se la Ying di stagione si oppone alla presa dell'ora — regola di Edu
(11/09/2026) applicata a una linea che non e' una sede in movimento. Il punto debole e' (a), che
dice SHORT: non so quale dei due venga prima.
DOMANDA APERTA PER EDU: la mobile che arriva in una casella vuota senza bersagli, oppure il
confronto fra le sedi dove la Terra nutre il Metallo?

**CORREZIONE DI EDU su EURJPY 23/10/2024 (seme 163) — `CONFERMATA DA EDU`** · 11/09/2026, S46
Edu: "Anche se la bestia dell'ora arriva su Y, la presenza contemporanea del vuoto e del mese
fuoco nella tomba lo rende inutile. Per quanto riguarda il tuo dubbio su L4 devi usare l'effetto
'scalino'. Se Wu in L4 si muove per diventare Chou, e Chou e' lo Y, allora e' come se Wu si muove
per arrivare su Y. Questo non cambia il risultato nel caso sopra ma ti fa capire come funziona
l'effetto 'scalino'."
CABLATI:
1. LA BESTIA IN TOMBA SU UNA LINEA VUOTA (MLTOMBA): una bestia il cui elemento e' nella propria
   tomba nel mese (辰 Acqua/Terra · 戌 Fuoco · 丑 Metallo · 未 Legno), su una linea VUOTA, non fa
   niente: non la prende e non le toglie il vuoto. Qui l'ora 壬午 (Fuoco) col mese 戌 = tomba del
   Fuoco, su Y 丑 vuota.
2. EFFETTO SCALINO, seconda faccia (MLSCALINO): se l'arrivo della mobile porta il ramo di
   un'altra linea, il movimento arriva SU quella linea — quindi non "finisce in niente". Qui
   L4 午 -> 丑 = il ramo dello Y: la mobile arriva sullo Y.
La carta si chiude cosi': la Ying non e' presa; nessuna traccia della mobile conclude; restano le
due sedi e lo Shi P 申, di stagione e caricato dal giorno, e' piu' forte -> la sede alta vince ->
LONG (+146). Il motivo (a) di Claude ("il movimento non porta a niente") cade proprio per lo
scalino.
MISURA:
  prima                          2703 carte  52,35% +10.282 · recente 53,62%
  con i due                      2703 carte  52,57% +11.888 · recente 53,90%
    senza la tomba                           52,42% +10.918
    senza lo scalino                         52,53% +11.312
Carte di riferimento: 32 su 32 giuste.

**Carta letta da Claude col metodo · EURJPY 06/02/2025 seme 158 · `DA VALIDARE`** · S46
Peggiore di "T0y la sede presa si muove" (131 carte al 48,09%). Motore LONG, mercato SHORT -147.
Palazzo 離 (Fuoco), 離 sopra 坎 (未濟 64), mese 戊寅, giorno 丙午, anno 乙巳, ora 己丑, vuoti 寅 卯.
Scheda (incompatibili per prime): L3 午 nel trigramma 坎 e' INCOMPATIBILE — ponte di Legno: 寅 del
mese e 寅 di L1, ma il 寅 di L1 e' VUOTO e nella data il 寅 compare una volta sola -> non regge ->
L3, lo Shi, da ferma diventa mobile. Futuro comune (L3 + L4): 坎 -> 艮? (il motore da' L3 午 -> 酉).
L6 Ying B 巳, ramo dell'anno, di stagione (Fuoco 相 nel mese 寅), nessuna bestia. L5 C 未, niente.
L4 W 酉 mobile, morta nel mese 寅, verso 戌; l'arrivo 戌 vorrebbe combinare 卯, che nelle linee non
c'e'; nessuna linea porta il ramo 戌 -> niente scalino. L3 Shi B 午, ramo del giorno, di stagione,
nascosto G 亥; sopra il giorno 丙午 (stesso ramo: carica) e l'ora 己丑? no, l'ora 己丑 cade su L3
per la bestia 螣蛇 (stelo 己) -> il 丑 dell'ora drena il Fuoco? 丑 e' Terra: il Fuoco la genera ->
DRENA -> prende. L2 C 辰, niente. L1 P 寅 vuota, di stagione ma vuota, nessuna presa utile.
Motivi raccolti:
 a) Lo Shi si muove (incompatibile) ed e' preso dall'ora 丑: da li' solo Shi contro Ying. Col
    ponte della bestia il flusso 午 -> 丑 -> 酉 da' Shi Metallo contro Ying Fuoco: il Fuoco
    controlla il Metallo -> vince la Ying -> sede alta -> LONG. [e' la via del motore, sbagliata]
 b) La W di L4 e' morta nel mese e il suo arrivo 戌 non trova nessun bersaglio (ne' combinare, ne'
    clashare, ne' generare, ne' scalino): il movimento non porta a niente -> chi non vince perde
    -> la sede alta perde -> SHORT.
 c) Lo Shi 午, di stagione e caricato dal giorno (stesso ramo), che si muove verso 酉: il Fuoco
    controlla il Metallo del proprio arrivo -> lo Shi domina il suo passo e non perde: sede bassa
    -> SHORT.
 d) Raduni: 巳午未 di Fuoco completo nel quadro (L6, L3, L5) ma non dentro un solo trigramma;
    il Fuoco e' di stagione e sta su Shi e Ying insieme: non separa le due parti.
Conclusione: SHORT per (b) e (c), contro la via del motore.
DUBBIO PER EDU: il ponte della bestia (dal ramo della sede al ramo dell'arrivo, passando per la
bestia) e' stato cablato su EURJPY 10/08/2023, dove la bestia era l'anno 癸卯 e il flusso 亥->卯->
巳 era una catena di generazione. Qui invece il 丑 dell'ora DRENA il 午 e porta a 酉: il flusso
consuma la sede invece di portarla avanti. Vale lo stesso?

**LETTURA DI EDU su EURJPY 06/02/2025 (seme 158) — `CONFERMATA DA EDU`** · 11/09/2026, S46
Edu: "Conviene vederla cosi': Shi si muove e, per 'Effetto Scala' arriva fino a C Xu sull'arrivo
di L4, quindi S diventa C Xu. A questo punto scatta il confronto con Y e vince lo short."
Lo Shi L3 午 (incompatibile) si muove e arriva in 酉, lo stesso ramo da cui parte la mobile L4:
per l'effetto scala prosegue lungo di lei fino a 戌, quindi lo Shi DIVENTA C 戌 (Terra). Confronto
con la Ying B 巳 Fuoco: il Fuoco genera la Terra, lo Shi e' nutrito e vince -> sede bassa ->
SHORT (+147).
Risposta al dubbio di Claude (il ponte della bestia che drena): non si usa il ponte, si usa la
scala. La scala viene PRIMA del ponte della bestia.
CABLATO (MLSCALASEDE), dentro T0y: quando la sede in movimento arriva sul ramo di partenza della
mobile, il movimento prosegue fino all'arrivo della mobile e la sede diventa quell'arrivo; il
ponte della bestia si usa solo se non c'e' la scala.
I due motivi di Claude (il movimento della W che non porta a niente; lo Shi che controlla il
proprio arrivo) portavano anch'essi a SHORT: restano registrati come motivi concorrenti, non
cablati.
MISURA:
  prima                        2703 carte  52,57% +11.888 · recente 53,90%
  con la scala sulla sede      2703 carte  52,65% +12.598 · recente 53,97%
    T0y                         131 carte  49,62%    +606 pip (era 48,09%, -105)
Carte di riferimento: 33 su 33 giuste.

**Carta letta da Claude col metodo · USDCAD 13/09/2022 seme 129 · `DA VALIDARE`** · S46
Peggiore di "T0p le tre porte della seconda" (212 carte al 49,06%). Motore SHORT, mercato LONG
+188. Palazzo 坤 (Terra), 坤 sopra 乾 (泰 11), mese 己酉, giorno 己巳, anno 壬寅, ora 壬申,
vuoti 戌 亥.
Scheda (incompatibili per prime): L3, lo Shi, 辰 nel trigramma 乾: incompatibile (coppia senza
ponte), ed e' gia' la mobile -> non puo' essere fermata. L4 丑 nel trigramma 坤: incompatibile
(coppia senza ponte) -> da ferma diventa mobile.
L6 Ying C 酉, di stagione, nessuna bestia. L5 W 亥 VUOTA, nessuna bestia -> non agisce. L4 B 丑
incompatibile, nessuna bestia, va verso 午 (futuro comune). L3 Shi B 辰 mobile verso 丑; sopra
cadono anno 壬寅 e ora 壬申, in penalita' fra loro (寅巳申 senza il 巳... il 巳 c'e': e' il ramo del
giorno 己巳) -> penalita' piena -> guerra fra titani, L3 ANNULLATA. L2 G 寅, ramo dell'anno,
nascosto P 巳 (ramo del giorno). L1 W 子, nessuna bestia.
Motivi raccolti:
 a) L4, seconda mobile, va in 午 e clasha il 子 di L1 (W): parla chi riceve, la W fa vincere la
    sede bassa -> SHORT. [e' la via del motore, sbagliata; e il motore usa l'arrivo 午->子 come
    clash mentre la porta andrebbe letta sull'arrivo]
 b) L3 e' annullata dalla guerra: la mobile e' fuori dai giochi. Resta L4, incompatibile, che
    agisce: e' un B e il B fa perdere la propria squadra -> la sede alta perde -> SHORT.
 c) Effetto scala: L3 (lo Shi) parte da 辰 e arriva in 丑, che e' il ramo di L4; per lo scalino
    la mobile arriva SU L4. L4 a sua volta si muove e va in 午: il movimento prosegue e finisce
    su 午 Fuoco, che nel palazzo 坤 e' un G -> il G fa vincere la propria squadra, sede alta ->
    LONG (+188). [concorde col mercato]
 d) Confronto fra le sedi: Shi B 辰 Terra (annullata) contro Ying C 酉 Metallo di stagione: la
    Terra genera il Metallo -> la Ying e' nutrita e vince -> sede alta -> LONG.
Conclusione: LONG per (c) e (d). Dubbio: L3 e' annullata dalla guerra fra titani — una linea
annullata puo' ancora fare da primo gradino della scala? Su USDJPY 02/10/2024 (la carta della
scala) nessuna delle due era annullata.

**LETTURA DI EDU su USDCAD 13/09/2022 (seme 129) — `CONFERMATA DA EDU`** · 11/09/2026, S46
Edu: "L3 raggiunge L4 Wu che genera indietro. Una linea che retrocede non puo' piu' farlo se viene
generata indietro perche' retrocedere significa perdere energia e generare significa acquisire
energia. Poiche' questo avviene con S, si deve subito confrontare Chou con Y e vince Long."
Lo Shi L3 辰 -> 丑 sta RETROCEDENDO (退神) e per lo scalino raggiunge L4, che porta proprio 丑;
L4 manda avanti 午, che GENERA il 丑. Chi retrocede perde energia, chi e' generato la acquista:
la sede non retrocede piu', la catena si ferma sul gradino e lo Shi porta 丑. Confronto con la
Ying C 酉: la Terra genera il Metallo, la Ying e' nutrita e vince -> sede alta -> LONG (+188).
Risposta al dubbio di Claude (L3 annullata dalla guerra fra titani): la scala funziona lo stesso —
Edu non pone quella condizione, e la carta lo mostra.
CABLATO `T0s la scala fermata dalla generazione` (MLSCALAGEN), prima dell'effetto scala: la sede
in movimento che retrocede e arriva sul ramo di una seconda mobile il cui arrivo genera quel ramo
-> la catena si ferma, la sede porta il ramo raggiunto e si confronta con l'altra sede.
MISURA:
  prima                        2703 carte  52,65% +12.598 · recente 53,97%
  con la scala fermata         2703 carte  52,57% +12.806 · recente 54,04%
    gradino                      21 carte  47,62%    +145 pip
Carte di riferimento: 34 su 34 giuste.
MOTIVI CONCORRENTI registrati su questa carta (non cablati): il confronto diretto Shi/Ying senza
la scala da' anch'esso LONG (Terra genera Metallo); le vie del motore (le tre porte di L4, il B
che agisce) davano SHORT e sono sbagliate.

**Carta letta da Claude col metodo · GBPUSD 17/06/2025 seme 135 · `DA VALIDARE`** · S46
Peggiore rimasta di "T0p le tre porte della seconda" (208 carte). Motore LONG, mercato SHORT -143.
Palazzo 兌 (Metallo), 坤 sopra 艮 (剥 23), mese 壬午, giorno 丁巳, anno 辛巳, ora 壬寅, vuoti 子 丑.
Scheda (incompatibili per prime): L3 申 in 艮 incompatibile (ponte d'Acqua: nella data nessun ramo
d'Acqua) ed e' gia' la mobile. L4 丑 in 坤 incompatibile (coppia senza ponte) -> da ferma diventa
mobile, verso 午.
L6 B 酉, fuori stagione (Metallo in 午), nessuna bestia. L5 Shi C 亥, il giorno 丁巳 la CLASHA:
si sveglia (暗動) — ma il 亥 e' morto nel mese 午 e ha contro due 巳 (giorno e anno): rotta, non
svegliata. L4 P 丑 VUOTA, l'ora 壬寅 sopra: il Legno controlla la Terra, bestia sola, la linea non
e' di stagione -> presa; con la bestia non e' piu' vuota -> L4 diventa 寅 Legno, che nel palazzo
兌 e' una W. L3 B 申 mobile verso 卯 (l'arrivo combina 戌, che non c'e'). L2 Ying G 午, ramo del
mese, di stagione, nascosto W 卯 (che e' anche l'arrivo di L3). L1 P 辰, nessuna bestia.
Motivi raccolti:
 a) [via del motore, sbagliata] L4 si muove e genera L1 P 辰 -> parla la P, la sede bassa perde
    -> LONG.
 b) Effetto scalino: L4 (丑) va in 午, che e' il ramo della Ying L2: il movimento di L4 arriva
    sulla Ying. L4 e' presa dall'ora ed e' Legno (W): il Legno genera il Fuoco della Ying ->
    la Ying e' nutrita -> vince la sede bassa -> SHORT.
 c) L'arrivo della mobile 卯 e' il NASCOSTO della Ying (W 卯): la mobile porta alla Ying quello
    che le sta sotto. Anche qui la Ying e' servita -> SHORT.
 d) Confronto fra le sedi: Shi C 亥 Acqua morta e rotta dal doppio 巳, contro Ying G 午 Fuoco di
    stagione sul ramo del mese: la Ying e' molto piu' forte -> SHORT.
 e) Raduno 巳午未 non completo (manca 未); trigono 寅午戌 non chiuso dentro un trigramma.
Conclusione: SHORT, per (b), (c) e (d) che concordano. La via del motore (a) e' l'unica che dice
LONG, e legge la porta di L4 senza tenere conto che L4 e' stata presa dall'ora e che il suo
arrivo cade sulla Ying.
DOMANDA PER EDU: quando la seconda mobile e' PRESA da una bestia, le sue tre porte si leggono
col ramo della bestia (qui 寅 Legno) invece che col proprio?

**LETTURA DI EDU su GBPUSD 17/06/2025 (seme 135) — `CONFERMATA DA EDU`** · 11/09/2026, S46
Edu (con la sua carta, 謙 15 -> 豫 16): "Interessante, ci sono ben due linee che sfruttano
l'effetto scala e portano la vittoria su Y."
L4 (丑, incompatibile) va in 午, il ramo della Ying: arriva sulla Ying. L3 (la mobile) va in 卯,
il nascosto della Ying: arriva anche lei sulla Ying. Due arrivi su Y -> la vittoria e' sua ->
sede bassa -> SHORT (+143). Confermati i motivi (b) e (c) di Claude; la via del motore (le porte
di L4 che genera L1) era sbagliata.
NUOVA REGOLA cablata come `T0w lo scalino porta su una sede` (MLSCALASEDEV): se l'arrivo di una
linea in movimento porta il ramo di una sede o del suo NASCOSTO, il movimento arriva su quella
sede e le porta la vittoria. Con arrivi su sedi diverse non si conclude.
LIMITE trovato misurando: se ad arrivare e' l'ALTRA sede, non vale — su EURJPY 28/07/2025 (carta
di riferimento letta da Edu) la Ying si muove e arriva sul ramo dello Shi, e li' decide la mobile
che si occupa di se'. Cablato cosi': lo scalino porta la vittoria solo quando ad arrivare non e'
una sede.
MISURA:
  prima                              2703 carte  52,57% +12.806 · recente 54,04%
  con T0w (senza il limite)          2711 carte  52,45% +13.122 — rompe EURJPY 28/07/2025
  con T0w e il limite                2708 carte  52,44% +13.172 · recente 53,86%
    gradino T0w                       302 carte  50,33%    +619 pip
Carte di riferimento: 35 su 35 giuste.

**Carta letta da Claude col metodo · USDJPY 05/12/2022 seme 134 · `DA VALIDARE`** · S46
Peggiore di "T0w lo scalino porta su una sede" (302 carte). Motore SHORT, mercato LONG +227.
Palazzo 坎 (Acqua), 坤 sopra 坎 (師 7), mese 辛亥, giorno 壬辰, anno 壬寅, ora 辛丑, vuoti 午 未.
Scheda (incompatibili per prime): L3, lo Shi, 午 in 坎 incompatibile (ponte di Legno: solo 寅
dell'anno, uno) -> da ferma diventa mobile, verso 辰. L4 丑 in 坤 incompatibile (senza ponte) ->
mobile, verso 午.
L6 Ying P 酉, nessuna bestia, fuori stagione (Metallo in 亥: 休). L5 B 亥, ramo del mese, di
stagione, nessuna bestia. L4 G 丑, ramo dell'ora; l'ora 辛丑 ci cade sopra (stesso ramo: carica).
L3 Shi W 午 VUOTO, incompatibile, nessuna bestia -> resta vuoto. L2 G 辰, ramo del giorno; il
giorno 壬辰 ci cade sopra (stesso ramo: carica). L1 C 寅 mobile, ramo dell'anno (Tai Sui), verso
子 nel futuro comune; l'anno 壬寅 sopra (stesso ramo: carica).
Motivi raccolti:
 a) [via del motore, sbagliata] L4 arriva in 午, ramo dello Shi -> scalino sullo Shi -> vince lo
    Shi, sede bassa -> SHORT.
 b) Lo Shi 午 e' VUOTO e si muove perche' incompatibile: se ne va dalla sua casella (verso 辰) e
    la lascia. Il 午 su cui arriva L4 non e' piu' abitato dallo Shi: lo scalino porta su una
    casella vuota, non su una sede.
 c) Lo Shi W 午, vuoto e morto d'Acqua nel mese 亥, si muove in 辰 Terra: il W che diventa G
    perde il vantaggio -> la sede bassa perde -> LONG (+227).
 d) La mobile L1 C 寅 va in 子, che GENERA il proprio 寅 (Acqua -> Legno): l'arrivo nutre la
    partenza, la C resta se' stessa e tace.
 e) Confronto fra le sedi: Shi W 午 Fuoco vuoto e morto contro Ying P 酉 Metallo fuori stagione:
    l'Acqua del mese spegne il Fuoco, la Ying e' piu' forte -> sede alta -> LONG.
Conclusione: LONG per (c) ed (e).
DOMANDA PER EDU: lo scalino su una sede vale anche quando quella sede e' VUOTA e a sua volta si
muove via (qui lo Shi 午 e' vuoto e incompatibile)? Mi pare di no: la casella e' abbandonata.

**CORREZIONE DI EDU su USDJPY 05/12/2022 (seme 134) — `CONFERMATA DA EDU` (parziale)** · S46
Edu: "Shi vuota si muove perche' incompatibile quindi non e' vuota (cio' che si muove non e'
vuoto), raggiunge G cn quindi diventa G cn. A questo punto si confronta con Y che vince. Long."
1. CABLATO (MLMOSSANONVUOTA): cio' che si muove non e' vuoto — vale per la mobile e per la ferma
   incompatibile che diventa mobile, in tutti i punti dove il motore guarda il vuoto di una linea.
   Mazzo da 52,44% (+13.172) a 52,46% (+13.537), recente 53,90%.
2. La sede che si muove DIVENTA la linea raggiunta (Shi 午 -> 辰 = il G di L2): provata in largo
   -> 262 carte al 47,71%, mazzo 51,96%: SPENTA (MLSEDEDIVENTA=on), perimetro da chiarire.
PUNTO APERTO sulla carta: con la sede che diventa G 辰 Terra, il confronto con la Ying dipende da
come si legge la Ying. Sulla Ying L6 酉 cadono DUE pilastri (mese 辛亥 e ora 辛丑: stesso stelo
辛, quindi la stessa bestia, la Tigre Bianca, che siede su L6). Col possesso delle due bestie la
catena porta 酉 Metallo -> 亥 Acqua, e la Ying diventa Acqua: allora la Terra dello Shi controlla
l'Acqua e vincerebbe lo Shi (SHORT). Se invece la Ying resta 酉 Metallo, la Terra genera il
Metallo, la Ying e' nutrita e vince (LONG, come dice Edu). DA CHIEDERE A EDU.

**REGOLA DI EDU — DUE BESTIE CHE COLLABORANO — `CONFERMATA DA EDU`** · 11/09/2026, S46
Edu: "Se due bestie arrivano su una linea e non si combattono collaborano per farla vincere.
Xin Chou aiuta Y P you, ma Xin Hai invece la farebbe perdere quindi non agisce."
Con piu' bestie sulla stessa linea che non si combattono, agiscono solo quelle che la AIUTANO
(stesso elemento o che la generano); quelle che la indebolirebbero (la drenano o la controllano)
NON agiscono. Prima il motore faceva la catena su tutte e la Ying 酉 diventava 亥 Acqua; ora
resta Metallo, aiutata dal 丑. Cablato in elDopoLeBestie (MLBESTIEAIUTO).
MISURA: mazzo da 52,46% (+13.537) a 52,53% (+14.073), recente 54,18%.
CABLATO ANCHE (dalla stessa lettura): lo scalino non porta niente a una sede che se ne sta
andando (e' lei la mobile, o e' incompatibile e si muove) — sulla carta lo Shi 午 lascia la
casella, quindi l'arrivo di L4 in 午 non gli porta la vittoria.
MISURA: mazzo 52,81% (+14.596), recente 54,61%; T0w da 302 carte 50,33% a 149 carte 53,02%
(+1.019 pip).
STATO DELLA CARTA USDJPY 05/12/2022: ora il motore conclude SHORT per un'altra via (il giorno
壬辰 che prende la mobile e parla da G). Con la sede che diventa la linea raggiunta accesa
(MLSEDEDIVENTA=on) la carta torna LONG come la legge Edu, ma quel pezzo misura peggio (262 carte
47,71%/48,47%, mazzo 52,46%): resta spento e il perimetro va chiarito con Edu.
Carte di riferimento: 35 su 36 (manca solo questa).

**TERZA LETTURA DI EDU su USDJPY 05/12/2022 — `CONFERMATA DA EDU`** · 11/09/2026, S46
Edu: "C'e' ancora un altro modo per vedere la vittoria del long: Shi W si muove per combinarsi con
Y, quindi porta W su Ying che vince. L'uso delle bestie e' da fare dopo aver visto le varie
possibilita' che offrono il movimento delle linee."
Lo Shi W 午 si muove in 辰: 辰酉合 con la Ying 酉. Si muove per combinarsi con lei e le porta il
proprio carattere, W -> la Ying vince -> sede alta -> LONG (+227). Con questa via la carta si
chiude senza il pezzo "la sede diventa la linea raggiunta", che resta spento.
NUOVA REGOLA cablata come `T0k si muove per combinarsi con una sede` (MLCOMBSEDE): una linea in
movimento (mobile o ferma incompatibile) il cui ARRIVO combina (六合) il ramo di una sede diversa
da se stessa le porta il proprio carattere: G/W -> quella sede vince, P/B -> perde.
POSIZIONE: il principio di Edu ("le bestie dopo il movimento") direbbe di metterla prima di tutte
le regole con le bestie; messa li' pero' rompe USDJPY 09/02/2026, carta di Edu dove il pilastro
che prende lo Shi mobile comanda (gradino 354 carte 47,46%, mazzo 52,30%). Cablata quindi dopo le
sedi prese e lo scalino: 36/36 carte di riferimento.
MISURA:
  prima                                  2706 carte  52,81% +14.596 · recente 54,61%
  T0k prima di tutte le bestie           2713 carte  52,30% +12.052 — rompe USDJPY 09/02/2026
  T0k dopo le sedi prese (cablata)       2713 carte  52,34% +11.984 · recente 54,00%
    gradino T0k                           291 carte  48,11%  -1.153 pip
Regola di Edu: si tiene. Il motore parla su 7 carte in piu'. Carte di riferimento 36 su 36.
DA CHIARIRE CON EDU: dove sta esattamente il confine fra "il movimento" e "le bestie" — su
USDJPY 09/02/2026 la bestia viene prima, qui il movimento.

**CORREZIONE DI EDU — L2 INCOMPATIBILE VA FATTA MUOVERE — `CONFERMATA DA EDU`** · 11/09/2026, S46
Edu: "L2 incompatibile non l'hai fatta muovere. E' successo anche la scorsa volta e hai detto che
avresti sistemato. Eppure te lo sei dimenticato di nuovo."
Errore ripetuto di Claude: su USDJPY 09/02/2026 ha ripresentato la lettura vecchia del registro
(S44, 09/09, scritta PRIMA della dottrina della linea incompatibile), dove lo Shi L2 亥 in 巽
resta fermo ed e' "legato dal giorno". L2 e' incompatibile: si muove, verso 午.
LETTURA RIFATTA: lo Shi G 亥 si muove in 午 e 午未合 con la Ying 未 — si muove per combinarsi con
lei. Sullo Shi cade l'anno 丙午 e se lo prende (亥 Acqua, 休 nel mese 寅, non puo' opporsi): lo
Shi porta addosso 午, che nel palazzo 離 e' un B. Quindi alla Ying porta un B: il B fa perdere la
propria squadra -> la sede alta perde -> SHORT (+135), come il mercato e come la conclusione di
Edu del 09/09 (per altra via: confronto diretto dopo il possesso).
CABLATO: in `T0k si muove per combinarsi con una sede` il carattere portato e' quello che la linea
ha ADDOSSO dopo le bestie (se un pilastro se l'e' presa, il carattere del ramo della bestia), non
quello di partenza. MLCOMBPAR=partenza per il vecchio conto. Con questo T0k puo' stare PRIMA
delle regole con le bestie, come vuole il principio di Edu ("le bestie dopo il movimento"), senza
rompere USDJPY 09/02/2026.
MISURA:
  T0k dopo le sedi prese, carattere di partenza   2713 carte  52,34% +11.984 · recente 54,00%
  T0k prima delle bestie, carattere dopo le bestie 2712 carte  52,73% +12.995 · recente 54,11%
    gradino T0k                                    344 carte  50,29%    -897 pip
Carte di riferimento: 36 su 36. USDJPY 05/12/2022 resta letta col W che si combina (Edu), perche'
li' nessuna bestia prende lo Shi e il carattere addosso e' ancora il suo.

**LETTURA DI EDU su USDJPY 09/02/2026 (seme 157) — `CONFERMATA DA EDU`, non ancora nel motore** · S46
Edu: "S non puo' muoversi quindi rimane G. Y si muove per raggiungere L6 B si. Vince S. Non c'e'
bisogno di usare le bestie."
1. Lo Shi 亥 in 巽 e' incompatibile ma il giorno 甲寅 lo combina (寅亥合): la ferma incompatibile
   che vorrebbe muoversi viene tenuta dal giorno. (La regola "l'incompatibile non si ferma" vale
   per la linea gia' mobile, NZDUSD 10/08/2022.) Cablato MLINCFERMATA: la ferma incompatibile
   combinata o clashata dal giorno non parte.
2. La Ying 未 va in 申 (il giorno 寅 clasha l'arrivo: resta attiva, non cambia) e 巳申合 con L6 B
   巳: la Ying raggiunge un B e ne prende il carattere -> la sede alta perde -> SHORT (+135).
   Cablato `T0k la sede raggiunge una linea` (MLCOMBPRESA): la sede che si muove e col suo
   arrivo combina una linea FERMA non-sede ne prende il carattere.
PROBLEMA DI ORDINE, aperto: messa PRIMA delle bestie, questa via legge la carta come Edu ma rompe
EURJPY 15/08/2024 (carta di Edu: la Ying raggiunge L5, ma li' decide L2 che retrocede con le
bestie) e il mazzo scende a 51,99%. Messa DOPO, la carta viene letta dal possesso delle bestie
(T1b: mese sulla Ying, anno sullo Shi, confronto diretto) — stessa direzione SHORT, ma non e' la
via di Edu. Tenuta dopo.
MISURA (stato attuale): 2714 carte 52,21% +10.333 · recente 53,18% (prima di questo giro:
52,73% +12.995). Il freno sulla ferma incompatibile costa da solo circa 0,3 punti. Carte di
riferimento 36/36.

## S46 · L'ORDINE FRA MOVIMENTO E BESTIE (Edu, 14/09/2026) — `CONFERMATO DA EDU`
Edu: "La differenza e' che in EURJPY 15/08/2024 a bloccare la linea dal retrocedere e' la data ed
e' quindi proprio alle bestie della data che poi si deve guardare per vedere se loro forniscono
una soluzione. In sintesi: 1. Si cerca di risolvere una carta semplicemente usando le linee
mobili. 2. Se c'e' un blocco nel movimento, e non si giunge ad una soluzione, si usano le bestie."
E (13/09): "Lo Shi non puo' muoversi perche' ci sono due 寅 nella data a combinarlo. Eccezione
alla regola per le incompatibili: se combinato una volta si muove lo stesso, se due no."
CABLATO:
1. MLINCFERMATA: la ferma incompatibile non parte solo se DUE (o piu') rami della data la
   combinano; con uno solo parte.
2. `T0k la sede raggiunge una linea` spostata subito dopo la seconda che retrocede (T0r, il caso
   in cui la data blocca il movimento e le bestie della data danno la soluzione) e PRIMA di tutte
   le regole del possesso (T1, T1b). USDJPY 09/02/2026 e' letta ora per la via di Edu (la Ying
   raggiunge L6 B, vince S, senza bestie); EURJPY 15/08/2024 resta letta con L2 che retrocede.
MISURA: 2716 carte 51,95% +8.782 · recente 53,53% (prima 52,14% +10.282; prima ancora, senza
tutto questo giro, 52,73% +12.995). Gradini: T0k raggiunge 151 carte 49,67%; T0k combinarsi con
una sede 355 carte 49,01%. Carte di riferimento 36/36, tutte per la via di Edu.
NOTA DI CLAUDE: il giro USDJPY 05/12/2022 -> 09/02/2026 e' costato ~0,8 punti sul mazzo pur
tenendo giuste tutte le carte di riferimento. Le regole sono di Edu e si tengono; i due gradini
T0k sotto il 50% sono il prossimo mucchio da cui prendere carte.

**Carta letta da Claude col metodo · USDJPY 01/05/2024 seme 157 · `DA VALIDARE`** · S46
Peggiore di "T0k si muove per combinarsi con una sede" (355 carte al 49,01%). Motore LONG,
mercato SHORT -346. Stesso esagramma di USDJPY 09/02/2026 (離 sopra 巽, 鼎 50).
Palazzo 離 (Fuoco), 離 sopra 巽, mese 戊辰, giorno 乙丑, anno 甲辰, ora 丙子, vuoti 戌 亥.
Scheda (incompatibili per prime): L2, lo Shi, G 亥 in 巽: incompatibile, VUOTO, senza bestie
sopra (il giorno 乙 e' Drago Azzurro su L1, l'ora 丙 Serpente su L4, mese 戊 e anno 甲 Gancio
e Drago su L3 e L1). Un solo ramo lo combina (寅? no: 亥 combina 寅, nella data non c'e' 寅) ->
si muove, e cio' che si muove non e' vuoto; futuro comune (L2 + L4): 巽 -> ? il motore da'
亥 -> 午 e L4 酉 -> 戌.
L6 B 巳, niente. L5 Ying C 未, nessuna bestia; il giorno 丑 la clasha -> 暗動, di stagione
(Terra nel mese 辰) -> si sveglia, e va in 子? (l'arrivo della svegliata: 未 -> 子 nel futuro).
L4 W 酉 mobile, fuori stagione (Metallo 死 nel mese 辰... 辰 e' Terra, Metallo 相: di stagione),
verso 戌, VUOTO; sopra l'ora 丙子 (drena? 子 Acqua: il Metallo la genera -> drena -> prende).
L3 W 酉, sopra mese 戊辰 e anno 甲辰 (stesso ramo, nessuna guerra; 辰 Terra genera il Metallo:
la nutrono). L1 C 丑, ramo del giorno, giorno 乙丑 sopra (stesso ramo: carica), nascosto P 卯.
Motivi raccolti:
 a) [via del motore, sbagliata] Lo Shi G 亥 si muove in 午 e 午未合 con la Ying: le porta il G ->
    la Ying vince -> LONG.
 b) L'arrivo dello Shi 午 e' ANCHE il proprio... no. Ma: la Ying 未 e' clashata dal giorno 丑 ed
    e' di stagione -> si sveglia e si muove (暗動): una sede che se ne va non riceve niente dallo
    scalino/combinazione (regola gia' cablata per lo scalino, USDJPY 05/12/2022) -> il G non le
    arriva.
 c) La Ying svegliata C 未 va in 子 e 子丑合 con L1 C 丑 (ferma, sul ramo del giorno): la Ying
    raggiunge una C e ne prende il carattere -> tace. Oppure: la Ying, sede in movimento, e
    lo Shi in movimento -> confronto? 
 d) La mobile L4 W 酉 va in 戌 (vuoto): l'ora 丙子 la drena e la prende -> 子 Acqua = G in 離 ->
    la W diventa G, il vantaggio si perde -> la sede alta perde -> SHORT.
 e) L3 W 酉 nutrita da due 辰 (mese + anno): il Metallo forte in basso -> W ferma forte -> la
    sede bassa vince -> SHORT.
 f) Confronto fra le sedi: Shi 亥 Acqua (mosso, in 午 Fuoco -> B) contro Ying 未 Terra di
    stagione svegliata dal giorno: la Terra controlla l'Acqua -> vince la Ying -> LONG. Ma se
    lo Shi porta 午 Fuoco (B): il Fuoco genera la Terra -> Ying nutrita -> LONG.
Conclusione: SHORT per (d) ed (e) — la W che si prende l'ora e diventa G, e la W ferma di L3
nutrita dai due 辰. Contro: (a) e (f) dicono LONG. Il nodo e' se la Ying svegliata dal giorno e'
ancora nella sua casella per ricevere la combinazione dello Shi.
DOMANDA PER EDU: la Ying clashata dal giorno e di stagione (暗動) riceve lo Shi che si muove
per combinarsi con lei, o se n'e' gia' andata?

**LETTURA DI EDU su USDJPY 01/05/2024 (seme 157) — `CONFERMATA DA EDU`** · 14/09/2026, S46
Edu: "Prima la lettura normale: L4 si muove in una linea vuota (non arriva da nessuna parte). La
bestia della linea aiuta? No. Risultato: niente. L2 incompatibile si muove e arriva su Ying
portando G. Long. La bestia della linea intralcia? Si'. L'ora Bing Zi arriva su L2 e blocca Wu
quindi G rimane su S. Short (non si comparano piu' S e Y perche' il movimento e' stato bloccato
dalla bestia)."
ERRORE DI CLAUDE nella scheda: l'ora 丙子 l'avevo messa su L4; lo stelo 丙 e' l'Uccello Rosso, che
con giorno 乙 siede su L2. Da qui la lettura sbagliata (la W presa dall'ora). Da rifare sempre:
pilastro -> stelo -> bestia -> linea, prima di dire dove cade.
IL METODO, per ogni linea che si muove: 1) dove arriva (vuoto = da nessuna parte); 2) la bestia
sulla linea aiuta o intralcia? Se intralcia (il suo ramo clasha l'arrivo) il movimento e'
bloccato e la linea resta col proprio carattere sulla propria sede; le sedi non si confrontano.
CABLATO `T0k la bestia blocca la combinazione` (MLBESTIABLOCCA), dentro "si muove per combinarsi
con una sede": perimetro la sede che si muove; MLBESTIABLOCCA=tutte per ogni linea (estensione di
Claude: 9 carte 66,67%, mazzo 52,06% — misura meglio ma resta spenta finche' Edu non lo dice).
MISURA: 2716 carte 51,99% +9.336 · recente 53,60% (prima 51,95% +8.782). Gradino: 7 carte 57,14%
+307. Carte di riferimento 37/37.
ESTENSIONE CONFERMATA DA EDU (14/09/2026): "Puoi estendere, il principio e' giusto e deve valere
anche per altre linee." Il blocco della bestia vale per ogni linea che si muove per combinarsi
con una sede, sede o no. Default cambiato; MLBESTIABLOCCA=sede per il solo perimetro della carta.
MISURA: 2716 carte 52,06% +9.608 · recente 53,60%; gradino 9 carte 66,67% +443. Carte di
riferimento 37/37.

**Carta letta da Claude col metodo · USDCAD 25/03/2020 seme 144 · `DA VALIDARE`** · S46
Peggiore rimasta di "si muove per combinarsi con una sede". Motore LONG, mercato SHORT -250.
Palazzo 兌 (Metallo), 兌 sopra 坤 (萃 45), mese 己卯, giorno 丁卯, anno 庚子, ora 丁亥, vuoti 戌 亥.
Pilastri -> bestie (giorno 丁: 朱雀 su L1, 勾陳 L2, 螣蛇 L3, 白虎 L4, 玄武 L5, 青龍 L6): mese 己 ->
勾陳 su L2 (lo Shi); giorno 丁 e ora 丁 -> 朱雀 su L1; anno 庚 -> 白虎 su L4.
Scheda (incompatibili per prime): nessuna delle sei coppie (卯 sta in 坤, non in 兌).
L6 P 未, niente. L5 Ying B 酉, il giorno 卯 la clasha: fuori stagione (Metallo 死 nel mese 卯) ->
non si sveglia, si rompe (nessuna combinazione col mese la protegge: 卯 e' anche il mese, che la
clasha pure). L4 W 亥 VUOTA, ramo dell'ora, l'anno 庚子 sopra (Acqua su Acqua: carica, e con la
bestia non e' piu' vuota). L3 G 卯, ramo del giorno e del mese, di stagione, nessuna bestia.
L2 Shi G 巳 mobile, fuori stagione (Fuoco 相 nel mese 卯: di stagione!) -> 巳 Fuoco in 卯: 相, di
stagione; verso 辰 (辰酉合 con la Ying); sopra il mese 己卯: il Legno GENERA il Fuoco -> la
nutre, non la prende, non la blocca (卯 non clasha 辰). L1 P 未, giorno e ora sopra (stesso
stelo 丁, due bestie 卯 e 亥 che non si combattono: 亥卯 mezzo trigono di Legno -> il Legno
controlla la Terra della linea: la indeboliscono -> non agiscono).
Lettura normale, linea che si muove: lo Shi G 巳 va in 辰 e 辰酉合 con la Ying 酉 -> porta il G
sulla Ying -> LONG. La bestia intralcia? No (卯 non clasha 辰, e nutre il Fuoco). -> LONG.
Ma la Ying 酉 e' ROTTA: clashata da giorno E mese (doppio 卯), fuori stagione. Una sede rotta
puo' ricevere la combinazione? Qui il mercato dice di no (-250).
Motivi per SHORT: (b) la Ying e' rotta dal doppio clash -> non c'e' piu' nessuno da far vincere
in alto -> vince il basso. (c) 辰 dell'arrivo e' anche il ramo... no. (d) L3 G 卯, sul ramo di
giorno e mese, di stagione: un G ferma fortissima in basso -> la sede bassa vince -> SHORT.
Conclusione: SHORT per (b)/(d).
DOMANDA PER EDU: la combinazione dell'arrivo con una sede ROTTA (clashata dal giorno e dal mese,
fuori stagione) porta ancora il carattere, o la sede rotta non riceve niente?

**CORREZIONE DI EDU su USDCAD 25/03/2020 — la bestia dello stelo 己** · 14/09/2026, S46
Edu: "Ji Mao non sta su L2 ma su L3. Wu e Ji sono sempre Gancio e Serpente e ognuno di loro ha la
sua linea SEMPRE." Errore di Claude nella scheda (il motore lo aveva giusto: 戊 = 勾陳, 己 = 螣蛇).
Con giorno 丁: 朱雀 L1, 勾陳 L2, 螣蛇 L3, 白虎 L4, 玄武 L5, 青龍 L6 -> il mese 己卯 cade su L3 (G 卯,
stesso ramo: la carica), NON sullo Shi. Sullo Shi L2 non cade nessuna bestia.
RILETTURA: lo Shi G 巳 si muove in 辰 e 辰酉合 con la Ying 酉 -> porta il G -> LONG; nessuna
bestia lo intralcia. Restano i motivi per SHORT: la Ying 酉 rotta dal doppio 卯 (giorno + mese),
fuori stagione; e L3 G 卯 sul ramo di giorno e mese, caricata dal mese, fortissima in basso.
La domanda per Edu resta la stessa: la sede ROTTA riceve la combinazione o no?
Tavola fissa stelo -> bestia (da tenere davanti, sempre): 甲乙 青龍 · 丙丁 朱雀 · 戊 勾陳 · 己 螣蛇 ·
庚辛 白虎 · 壬癸 玄武; la linea di partenza (青龍 su L1) e' data dallo stelo del GIORNO.

**REGOLA DI EDU su USDCAD 25/03/2020 — `CONFERMATA DA EDU`** · 14/09/2026, S46
Edu: "una Ying rotta non puo' ricevere il G che le viene portato."
CABLATO (MLCOMBROTTA): in "si muove per combinarsi con una sede", se la sede raggiunta e' ROTTA
(clashata dal giorno, fuori stagione, senza la protezione del mese) non riceve la combinazione.
La carta si chiude col duello: lo Shi G 巳 di stagione contro la Ying rotta -> vince lo Shi ->
SHORT (+250). Il motivo concorrente registrato (L3 G 卯 fortissima in basso) dice anch'esso SHORT.
MISURA: 2716 carte 51,91% +9.354 · recente 53,32% (prima 52,06% +9.608). Gradino "combinarsi con
una sede": 320 carte 48,75%. Carte di riferimento 38/38.
NOTA: costa 0,15 punti; le carte che il motore leggeva LONG per la combinazione su una sede rotta
ora vanno al duello e li' si sbaglia piu' spesso. Regola di Edu: si tiene.

**LETTURA DI EDU su USDCAD 25/03/2020 (seme 144), CONCLUSIONE — `CONFERMATA DA EDU`** · 14/09/2026
Edu: "Shi si muove in una P e questo fa perdere la propria squadra PERO' Yong sta messa peggio
perche' You e' untimely e doppiamente clashata. Di fatto e' completamente eliminata. Quindi S
vince perche' il nemico sta molto peggio."
Lo Shi G 巳 va in 辰, che nel palazzo 兌 e' P: la sua squadra perderebbe. Ma la Ying 酉 e' fuori
stagione e clashata da due rami della data (giorno e mese 卯): eliminata. Vince chi ha il nemico
messo peggio: lo Shi -> sede bassa -> SHORT (+250).
CABLATO `T0k il nemico sta peggio` (MLNEMICOPEGGIO): la sede che si muove in un P/B perderebbe,
ma se l'altra sede e' eliminata (fuori stagione, clashata da due o piu' rami della data, senza la
protezione del mese) vince comunque la sede che si muove. Viene subito dopo il rifiuto della
combinazione sulla sede rotta.
MISURA: 2716 carte 51,95% +9.476 · recente 53,39% (prima 51,91% +9.354). Gradino: 11 carte
63,64% +355. Carte di riferimento 38/38, questa ora per la via di Edu.

**Carta letta da Claude col metodo · EURJPY 31/10/2023 seme 158 · `DA VALIDARE`** · S46
Peggiore rimasta di "si muove per combinarsi con una sede". Motore SHORT, mercato LONG +213.
Palazzo 離 (Fuoco), 離 sopra 坎 (未濟 64), mese 壬戌, giorno 壬戌, anno 癸卯, ora 辛丑, vuoti 子 丑.
Pilastri -> bestie (giorno 壬: 玄武 L1, 青龍 L2, 朱雀 L3, 勾陳 L4, 螣蛇 L5, 白虎 L6): mese 壬 e giorno
壬 -> 玄武 su L1; anno 癸 -> 玄武 su L1; ora 辛 -> 白虎 su L6 (la Ying).
Scheda (incompatibili per prime): L3, lo Shi, 午 in 坎: incompatibile (ponte di Legno: 卯
dell'anno, uno solo) -> si muove; un solo ramo lo combina? 午 combina 未, non nella data -> parte.
Futuro comune (L2 + L3): 坎 -> 兌: L2 辰 -> 午, L3 午 -> 申.
L6 Ying B 巳, Fuoco 死 nel mese 戌 (fuori stagione); sopra l'ora 辛丑: 丑 Terra, il Fuoco la
genera -> la drena, bestia sola, linea non timely -> la PRENDE: la Ying diventa 丑 Terra, C nel
palazzo... 丑 e' VUOTO ma con la bestia non e' vuoto? La bestia stessa e' vuota (丑 in 旬空):
"una bestia col ramo vuoto non prende possesso" (Edu, S45) -> NON la prende. La Ying resta B 巳.
L5 C 未, niente. L4 W 酉 di stagione, niente. L3 Shi B 午 incompatibile, nascosto G 亥, verso 申
(申 combina 巳 della Ying). L2 C 辰 mobile, verso 午 (= il ramo dello Shi!): scalino sullo Shi —
ma lo Shi se ne sta andando (incompatibile) -> lo scalino non gli porta niente. L1 P 寅, sopra
mese, giorno e anno (戌 戌 卯: 卯戌合, nessuna guerra; tre bestie: 戌 Terra e' controllata dal
Legno della linea... il Legno controlla la Terra: la linea le domina; 卯 Legno la aiuta).
Lettura normale, linee che si muovono:
 - L2 C 辰 va in 午 = ramo dello Shi: effetto scala: lo Shi parte proprio da 午 -> il movimento
   prosegue lungo lo Shi fino al suo arrivo 申, Metallo = W in 離 -> l'intero movimento finisce
   su W -> la squadra bassa vince? (scala: parla l'arrivo finale sulla sede della mobile L2:
   W -> vince) -> SHORT. [via del motore: diversa ma stessa direzione]
 - Lo Shi B 午 va in 申 e 巳申合 con la Ying: le porta il B -> la Ying perde -> SHORT. La bestia
   su L3 intralcia? Nessuna bestia su L3. -> SHORT.
Contro: la Ying B 巳 e' fuori stagione, la bestia dell'ora (vuota) non la prende. Il B che le
arriva la fa perdere... eppure il mercato e' LONG (+213).
Altri motivi: (c) l'arrivo dello Shi 申 e' Metallo W di stagione: lo Shi DIVENTA W (si
trasforma: incompatibile che si muove e si trasforma) -> il W sullo Shi fa vincere la sede bassa
-> SHORT. (d) L2 C 辰 -> 午 Fuoco: B in 離; l'arrivo 午 e' anche il ramo dello Shi... (e) Nascosto
G 亥 sotto lo Shi: 亥 clasha 巳 della Ying; l'anno 卯 forma 亥卯 mezzo trigono...
Conclusione di Claude: SHORT, da tre vie. Il mercato dice LONG e non trovo che cosa lo smentisca.
DOMANDA PER EDU: che cosa fa vincere l'alto qui?
CORREZIONE DI EDU (14/09/2026) sulla scheda di EURJPY 31/10/2023: "La bestia non e' mai vuota e
qui prende possesso quindi Y diventa Chou." Errore di Claude: aveva ripescato la nota di S45 ("una
bestia col ramo vuoto non prende"), gia' superata dalla regola di Edu del 09/09 ("una bestia che
arriva non e' mai vuota"), che il motore applica. La Ying B 巳 e' presa dall'ora 辛丑 e diventa
丑 Terra, di stagione nel mese 戌 (C nel palazzo 離).

**LETTURA DI EDU su EURJPY 31/10/2023 (seme 158) — `CONFERMATA DA EDU`** · 14/09/2026, S46
Edu: "Ti avevo detto di mettere le bestie DOPO i movimenti delle linee. Facciamo ordine: prima
L3 si muove per combinarsi con Y, porta un loser B su Y. Poi interviene la bestia e sostituisce
la untimely B su Y con Chou che e' C che vince."
ORDINE: 1) lo Shi B 午 (incompatibile) va in 申 e 巳申合 con la Ying: le porta un B perdente
(SHORT). 2) Poi la bestia: l'ora 辛丑 prende la Ying (untimely) e sostituisce il B 巳 con 丑,
Terra di stagione, C nel palazzo 離 -> la Ying vince -> LONG (+213).
CABLATO `T0k la bestia sostituisce il perdente sulla sede` (MLBESTIASOSTSEDE): dopo la
combinazione che porta un P/B su una sede, se quella sede e' presa da una bestia il cui carattere
non e' un perdente, la sede vince. Se ANCHE l'altra sede e' presa, da li' e' solo Shi contro Ying
(EURJPY 10/02/2026, carta di Edu: senza questo si rompeva) -> `T0k le due sedi prese`.
MISURA: 2716 carte 52,36% +11.575 · recente 53,60% (prima 51,95% +9.476). Gradini: sostituzione
25 carte 68,00% +969; due sedi prese 5 carte 80%. Carte di riferimento 39/39.

**Carta letta da Claude col metodo · USDCAD 17/03/2020 seme 140 · `DA VALIDARE`** · S46
Peggiore rimasta di "si muove per combinarsi con una sede" (290 carte). Motore SHORT, mercato
LONG +195. Palazzo 巽 (Legno), 乾 sopra 震 (無妄 25), mese 丁卯, giorno 己未, anno 庚子, ora 辛未,
vuoti 子 丑.
Pilastri -> bestie (giorno 己: 螣蛇 L1, 勾陳 L2? no — con 己 si parte da 螣蛇: L1 螣蛇, L2 白虎,
L3 玄武, L4 青龍, L5 朱雀, L6 勾陳): mese 丁 -> 朱雀 su L5; giorno 己 -> 螣蛇 su L1 (la Ying);
anno 庚 e ora 辛 -> 白虎 su L2.
Scheda (incompatibili per prime): nessuna delle sei coppie (子 sta in 震, 午 in 乾).
L1 Ying P 子 mobile, VUOTA, ramo dell'anno (Tai Sui), verso 未; il giorno 未 e' anche l'arrivo
(autocombinazione... il giorno siede sull'arrivo: 未未 autopenalita' -> l'arrivo non agisce?) e
il giorno 己未 cade sulla Ying con la bestia: 未 Terra controlla l'Acqua, bestia sola, la linea 子
Acqua nel mese 卯 e' 休 (non timely) -> la PRENDE -> la Ying diventa 未 Terra = W in 巽. E cio'
che si muove non e' vuoto.
L4 Shi C 午, di stagione (Fuoco 相 in 卯), nessuna bestia. L2 B 寅, di stagione, anno 庚子 e ora
辛未 sopra (子未 non si combattono; 子 Acqua genera il Legno: aiuta; 未 Terra e' controllata:
non agisce). L5 G 申, mese 丁卯 sopra (卯 Legno controllato dal Metallo... il Metallo controlla il
Legno: la linea domina la bestia, ma e' il mese -> lo prende? "al mese non ci si oppone" ->
L5 diventa 卯 Legno = B). L3 W 辰, L6 W 戌: niente.
Lettura normale: la Ying P 子 va in 未 e 午未合 con lo Shi 午: porta il P (il carattere che ha
addosso PRIMA delle bestie) -> lo Shi perde -> LONG (+195)! Ma il motore porta il carattere
DOPO le bestie (B? no: la Ying presa dal giorno 未 e' W... il motore dice B: da 子 -> 未? W).
VERIFICA nel motore: dice "porta il carattere che ha addosso, B" — 未 in 巽 e' W (Terra e'
妻財 nel palazzo Legno). Da controllare.
Poi la bestia: il giorno 己未 prende la Ying e la sostituisce con 未 (W): lo Shi, che aveva
ricevuto un P perdente... qui la sede che riceve e' lo SHI, non la Ying; la Ying e' la linea che
porta. Lo Shi non e' preso da nessuna bestia.
Conclusione: LONG per la lettura normale (la Ying porta il P allo Shi, lo Shi perde). Il motore
porta il carattere dopo la presa: qui il possesso della bestia sulla linea che PORTA cambia la
direzione. Sulla carta di Edu (USDJPY 09/02/2026) la presa sullo Shi mobile portava 午 B alla
Ying — ma li' Edu poi ha detto che S non si muove affatto (due 寅). Quindi "carattere dopo le
bestie" nella combinazione non ha piu' una carta di Edu che lo sostenga.
DOMANDA PER EDU: nella combinazione con una sede si porta il carattere di PARTENZA (P 子) o quello
dopo la presa della bestia (未)?

**CORREZIONE DI EDU su USDCAD 17/03/2020 (seme 140) — `CONFERMATA DA EDU`, in conflitto** · 14/09/2026
Edu: "Non puo' portare su una linea gia' combinata." Lo Shi 午 e' gia' combinato dal giorno 未
(午未合): la Ying che arriva in 未 non gli porta niente.
CABLATO (MLCOMBLEGATA): la sede gia' combinata da un ramo della data non riceve la combinazione.
CONFLITTO trovato misurando: USDJPY 05/12/2022 (letta da Edu: "Shi W si muove per combinarsi
con Y, porta W su Ying che vince") ha la STESSA struttura — la Ying 酉 e' gia' combinata dal
giorno 辰, e lo Shi arriva proprio in 辰. Con la regola nuova quella carta si rompe (va al
possesso del giorno e dice SHORT). Differenze fra le due carte: su USDCAD 17/03/2020 la linea che
porta (la Ying 子) e' VUOTA ed e' presa dalla bestia del giorno che le cade sopra; su USDJPY
05/12/2022 la linea che porta (lo Shi 午) non ha bestie sopra e la Ying che riceve ha due bestie
che la aiutano. Da chiarire con Edu.
TEST DI EDU (dal basso alla sede in alto = LONG?): 224 carte, LONG 47,3% -> non e' una regola
generale; nessun sotto-insieme regge (sede che parte 49,4%, non sede 46%, mobile 41%, ferma
incompatibile 49%). Dall'alto alla sede bassa: 66 carte, LONG 53%; solo la sede che parte
dall'alto fa 63% su 19 carte.
MISURA con MLCOMBLEGATA: 2716 carte 52,43% +12.226 · recente 53,88% (prima 52,36% +11.575);
gradino 192 carte 51,56%. Col carattere di PARTENZA nella combinazione (MLCOMBPAR=partenza):
52,36% +12.467, recente 54,03%. Carte di riferimento 38/40 (rotte USDJPY 05/12/2022 e USDCAD
17/03/2020 stessa, che ora va al possesso del giorno e dice SHORT).

**LETTURA DI EDU su USDCAD 17/03/2020 (seme 140) — `CONFERMATA DA EDU`** · 14/09/2026, S46
Edu: "In effetti hai ragione su un punto, la bestia mese Ji Mao penalizza la prima linea che non si
muove proprio."
ERRORE DI CLAUDE nella scheda: il mese era scritto 丁卯; nell'anno 庚子 il mese di 卯 e' 己卯. Con
giorno 己 il Serpente sta su L1: il mese 己卯 cade sulla Ying 子 e la PENALIZZA (子卯刑): la linea
non si muove proprio. Chi riceve la penalita' non fa vincere la propria squadra -> la sede bassa
perde -> LONG (+195).
CABLATO: nell'azione delle bestie, un pilastro il cui ramo penalizza (刑, con la regola del 寅 per
巳申, e le autopenalita' 辰午酉亥) il ramo della linea la penalizza (non la prende, non la
sveglia). `T0j la bestia penalizza la sede` (MLBESTIAPEN): la mobile che e' una sede, penalizzata
da una bestia, non si muove e la sua squadra perde. Messa prima dell'effetto scala.
MISURA: 2713 carte 52,67% +12.739 · recente 54,10% (prima 52,43% +12.226). Gradino 38 carte
55,26%. Carte di riferimento 39/40: resta rotta USDJPY 05/12/2022 dalla regola "non puo' portare
su una linea gia' combinata" (che senza quella regola tornerebbe: MLCOMBLEGATA=off da' 52,45%,
cioe' la regola vale +0,22 sul mazzo ma rompe quella carta). Da chiarire con Edu.

**LETTURA DI EDU su USDJPY 05/12/2022 (seme 134), RIVISTA — `CONFERMATA DA EDU`** · 14/09/2026
Edu: "Hai ragione, L3 non puo' portare W su Y non solo perche' Y e' gia' combinata ma anche
perche' il giorno penalizza l'arrivo di Shi. La penalita' si riflette sulla sede Shi che non puo'
vincere."
La lettura dell'11/09 ("porta W su Ying che vince") e' superata: lo Shi 午 va in 辰, il giorno
壬辰 lo penalizza (辰辰 autopenalita') -> lo Shi non puo' vincere -> LONG (+227). Cosi' la regola
"non puo' portare su una linea gia' combinata" (USDCAD 17/03/2020) resta senza conflitto.
CABLATO `T0i la data penalizza l'arrivo della sede` (MLPENARRIVO): una sede che si muove (mobile
o ferma incompatibile) il cui arrivo e' penalizzato dal GIORNO non puo' vincere: vince l'altra.
Prima dell'effetto scala. Perimetro: il giorno — con tutti i rami della data (MLPENARRIVO=data)
si rompeva EURJPY 11/07/2024 (carta di Edu: l'anno 辰 penalizza l'arrivo dello Shi, ma Edu legge
il confronto con la Ying presa dalle bestie), e il gradino era 429 carte 50,82%.
MISURA: 2713 carte 52,45% +11.734 · recente 54,10% (prima 52,67% +12.739). Gradino 153 carte
49,67% -212. Carte di riferimento 40/40, tutte per la via di Edu.

**Carta letta da Claude col metodo · USDJPY 06/09/2022 seme 140 · `DA VALIDARE`** · S46
Peggiore di "T0i la data penalizza l'arrivo della sede" (153 carte al 49,67%). Motore SHORT,
mercato LONG +234. Palazzo 巽 (Legno), 乾 sopra 震 (無妄 25), mese 戊申, giorno 壬戌, anno 壬寅,
ora 丁未, vuoti 子 丑.
Pilastri -> bestie (giorno 壬: 玄武 L1, 青龍 L2, 朱雀 L3, 勾陳 L4, 螣蛇 L5, 白虎 L6): mese 戊 -> 勾陳
su L4 (lo Shi); giorno 壬 e anno 壬 -> 玄武 su L1 (la Ying); ora 丁 -> 朱雀 su L3.
Scheda (incompatibili per prime): nessuna delle sei coppie.
L4 Shi C 午 mobile, Fuoco 死 nel mese 申 (fuori stagione), verso 未 (未 e' anche il ramo dell'ora);
il giorno 戌 penalizza l'arrivo 未 (戌未刑) -> per la regola di USDJPY 05/12/2022 lo Shi non puo'
vincere -> LONG. [e' il contrario di quello che dice il motore!]
Sopra lo Shi cade il mese 戊申: 申 Metallo controllato dal Fuoco della linea, ma al mese non ci si
oppone -> lo prende -> lo Shi diventa 申 Metallo (G in 巽), di stagione.
L1 Ying P 子 VUOTA: giorno 壬戌 (Terra controlla l'Acqua -> la prende; e con la bestia non e'
vuota) e anno 壬寅 (il Legno e' generato dall'Acqua -> drena -> prende): due bestie, 戌寅 non si
combattono, tutte e due la indeboliscono -> nessuna la aiuta -> catena: 子 -> 寅 (generazione).
L3 W 辰: il giorno 戌 la clasha (di stagione: la Terra in 申 e' 休... la Terra e' timely nei
mesi di Terra e nell'estate; in 申 no) -> si rompe? ma l'ora 丁未 le cade sopra (未 Terra: carica).
L6 W 戌 ramo del giorno. L5 G 申 ramo del mese, di stagione. L2 B 寅 ramo dell'anno.
ERRORE DEL MOTORE: il gradino T0i dice "la sede penalizzata NON puo' vincere" e su questa carta
conclude SHORT — cioe' fa vincere la sede bassa (lo Shi L4 e' in ALTO! Shi=L4, sede alta).
Verifica: sede(4) = LONG, opposto = SHORT: il motore ha fatto perdere lo Shi (alto) -> SHORT.
Giusto per la regola: lo Shi penalizzato non vince -> vince la Ying (basso) -> SHORT. Ma il
mercato e' LONG (+234).
Motivi raccolti per LONG: (a) lo Shi preso dal mese diventa G 申 di stagione: contro la Ying 子
presa da due bestie che la indeboliscono, il Metallo dello Shi genera l'Acqua della Ying... (b)
la Ying e' presa da due bestie che la rendono 寅 Legno: 寅 e' sul ramo dell'anno; lo Shi 申
Metallo controlla il Legno -> vince lo Shi -> LONG. (c) L3 svegliata dal giorno con l'ora sopra.
Il nodo: con lo Shi penalizzato all'arrivo (USDJPY 05/12/2022: "non puo' vincere") ma PRESO dal
mese (che lo trasforma in 申 di stagione): quale viene prima? Su 05/12/2022 sullo Shi non cadeva
nessuna bestia.
DOMANDA PER EDU: la bestia del mese che prende lo Shi e lo trasforma cancella la penalita' del
giorno sul suo arrivo?

**LETTURA DI EDU su USDJPY 06/09/2022 (seme 140) — `CONFERMATA DA EDU`** · 14/09/2026, S46
Edu: "Y non puo' vincere perche' e' vuoto."
Lo Shi penalizzato all'arrivo non puo' vincere; ma la Ying 子 e' VUOTA: le due bestie che le
cadono sopra (giorno 戌 e anno 寅) la indeboliscono tutte e due, quindi nessuna agisce e nessuna
le toglie il vuoto. Nemmeno lei puo' vincere: prevale lo Shi -> LONG (+234).
CABLATO: (1) con piu' bestie sulla stessa linea, se nessuna la aiuta nessuna agisce, e il vuoto
resta (estende la regola dell'11/09 "collaborano solo quelle che aiutano"); (2) `T0i la sede
penalizzata contro la vuota` (MLPENVUOTA): se l'altra sede e' vuota, vince la sede penalizzata.
MISURA: 2713 carte 52,41% +12.143 · recente 53,88% (prima 52,45% +11.734). Gradini: T0i 137
carte 48,91%; penalizzata contro vuota 16 carte 43,75% +162. Carte di riferimento 41/41.
Regola di Edu: si tiene anche se il gradino misura male.
PRECISAZIONE DI EDU (14/09/2026): "Se nessuno vince, alla fine vince la piu' forte che nel nostro
caso e' L5 Shen. E' molto vibrante ed e' citata dal clash con l'anno."
Quando nessuna delle due sedi puo' vincere (una penalizzata, l'altra vuota), decide la linea
PIU' FORTE della carta: L5 G 申, di stagione, sul ramo del mese, citata dal clash con l'anno 寅
-> vince la sua squadra (alta) -> LONG. Sostituisce "prevale la penalizzata" (MLPENVUOTA=
penalizzata per quella versione). Punteggio di forza: stagione + 2 se sul ramo del mese + 1 se
sul ramo del giorno + 1 per ogni ramo della data che la clasha; vuote e annullate escluse; con
due pari, nessuna decisione.
MISURA: 2713 carte 52,56% +12.378 · recente 54,03% (prima 52,41% +12.143). Gradino "nessuno
vince: la piu' forte" 15 carte 66,67% +341. Carte di riferimento 41/41.

**Carta letta da Claude col metodo · USDJPY 02/08/2022 seme 131 · `DA VALIDARE`** · S46
Prima carta del gradino "la data penalizza l'arrivo della sede" (138 carte al 49,3%). Motore
SHORT, mercato LONG +181. Palazzo 坎 (Acqua), 坤 sopra 離 (明夷 36) — stesso esagramma di USDJPY
12/01/2023, la carta del trigono nel trigramma. Mese 丁未, giorno 丁亥, anno 壬寅, ora 庚戌,
vuoti 午 未.
Pilastri -> bestie (giorno 丁: 朱雀 L1, 勾陳 L2, 螣蛇 L3, 白虎 L4, 玄武 L5, 青龍 L6): mese 丁 e
giorno 丁 -> 朱雀 su L1 (la Ying); anno 壬 -> 玄武 su L5 (la mobile); ora 庚 -> 白虎 su L4 (lo Shi).
Scheda (incompatibili per prime): L4, lo Shi, 丑 in 坤: incompatibile (senza ponte); nessun ramo
della data lo combina due volte (子 non c'e') -> si muove. Futuro comune (L4 + L5): 坤 -> 兌:
L5 亥 -> 酉, L4 丑 -> 亥.
L5 B 亥 mobile, ramo del giorno (caricata), fuori stagione (Acqua 囚 in 未), verso 酉; sopra
l'anno 壬寅: 寅 Legno, l'Acqua lo genera -> la drena -> bestia sola, linea non timely -> la
prende -> L5 diventa 寅 Legno = C in 坎. L4 Shi G 丑, di stagione (Terra in 未), verso 亥; il
giorno 亥 e' ANCHE il suo arrivo: 亥亥 autopenalita' -> l'arrivo e' penalizzato dal giorno;
sopra l'ora 庚戌: 戌 Terra su Terra, la carica (e 丑戌 e' penalita'! 戌 penalizza 丑 -> la bestia
dell'ora PENALIZZA lo Shi). L1 Ying C 卯, Legno 休 in 未; sopra mese 丁未 e giorno 丁亥 (亥卯未
trigono di Legno con la linea stessa! le due bestie con la Ying chiudono 亥卯未): 未 Terra e'
controllata dal Legno (non aiuta), 亥 Acqua genera il Legno (aiuta) -> agisce 亥 -> la Ying
resta Legno, nutrita. L3 B 亥 ramo del giorno, nascosto W 午 vuoto. L2 G 丑. L6 P 酉.
Lettura normale, linee che si muovono:
 - Lo Shi 丑 -> 亥: il giorno 亥 penalizza l'arrivo (亥亥) -> lo Shi non puo' vincere (USDJPY
   05/12/2022) -> vince la Ying -> sede bassa -> SHORT. [via del motore]
 - La Ying L1 卯 non e' vuota; e' nutrita dalla bestia 亥 e chiude 亥卯未 di Legno con le sue due
   bestie: la Ying e' fortissima. -> conferma SHORT.
 - L5 B 亥 -> 酉: 酉 combina 辰? no; l'arrivo 酉 e' Metallo P; presa dall'anno diventa 寅 C.
Contro (LONG): (c) trigono nel trigramma alto? 酉 (arrivo L5) + 亥 (L5/L3... nell'alto: L6 酉, L5
亥->酉, L4 丑->亥): rami dell'alto con arrivi: 酉 亥 酉 丑 亥 -> 巳酉丑 manca 巳 -> no. (d) l'ora 庚戌
sullo Shi lo PENALIZZA (戌 penalizza 丑): bestia che penalizza la sede -> la sua squadra perde ->
sede alta perde -> SHORT (ancora). (e) Lo Shi si muove in 亥 = il ramo di L3 e L5 (scalino su
L3 B 亥, ferma): la sede raggiunge una linea e ne prende il carattere B -> perde -> SHORT.
Tutto dice SHORT. Il mercato e' LONG (+181). Non trovo che cosa lo smentisca.
UNICA cosa dalla parte dell'alto: lo Shi 丑 e' di stagione e caricato dall'ora 戌 (Terra su
Terra), e nel confronto diretto la Terra controlla l'Acqua... no, la Ying e' Legno: il Legno
controlla la Terra -> vince la Ying.
DOMANDA PER EDU: che cosa fa vincere l'alto qui?

**LETTURA DI EDU su USDJPY 02/08/2022 (seme 131) — `CONFERMATA DA EDU`** · 14/09/2026, S46
Edu: "S raggiunge you. Y e' mao. Long."
Lo Shi 丑 (incompatibile) si muove in 亥, il ramo da cui parte la mobile L5: per l'effetto scala
prosegue lungo di lei fino a 酉 e diventa 酉 Metallo. Contro la Ying 卯 Legno: il Metallo
controlla il Legno -> vince lo Shi -> sede alta -> LONG (+181). La penalita' del giorno sul
primo gradino (亥亥) non conta: lo Shi non si ferma li'.
Claude non l'aveva vista perche' aveva fermato lo Shi al primo gradino (亥) invece di seguire la
scala fino in fondo — lo stesso gesto gia' letto da Edu su EURJPY 06/02/2025.
CABLATO `T0h la sede sale la scala` (MLSCALASEDE2), prima della penalita' sull'arrivo: una sede
che si muove e arriva sul ramo di PARTENZA di un'altra linea in movimento prosegue fino
all'arrivo di quella e lo diventa; poi confronto con l'altra sede. Senza bisogno di bestie.
MISURA: 2713 carte 52,56% +12.775 · recente 54,03% (prima 52,56% +12.378). Gradino T0h: 150 carte
56,67% +1.971; T0i scende da 138 carte 49,3% a 110 carte 49,1%. Carte di riferimento 42/42.

**Carta letta da Claude col metodo · GBPUSD 09/03/2026 seme 133 · `DA VALIDARE`** · S46
Seconda carta del gradino "la data penalizza l'arrivo della sede" (110 carte). Motore SHORT,
mercato LONG +137. Palazzo 震 (Legno), 坤 sopra 巽 (升 46), mese 辛卯, giorno 壬午, anno 丙午,
ora 庚子, vuoti 申 酉.
Pilastri -> bestie (giorno 壬: 玄武 L1, 青龍 L2, 朱雀 L3, 勾陳 L4, 螣蛇 L5, 白虎 L6): mese 辛 e ora
庚 -> 白虎 su L6; giorno 壬 -> 玄武 su L1 (la Ying); anno 丙 -> 朱雀 su L3.
Scheda (incompatibili per prime): L4, lo Shi, 丑 in 坤: incompatibile, senza ponte, nessun ramo
lo combina (子 dell'ora combina 丑! un ramo solo -> si muove lo stesso). L2 亥 in 巽:
incompatibile ma e' gia' la mobile. Futuro comune (L2 + L4): 巽 -> 坎? il motore: L2 亥 -> 午,
L4 丑 -> 午.
L2 P 亥 mobile, Acqua 休 nel mese 卯, verso 午 (vuoti 申酉: no); l'arrivo 午 e' il ramo del giorno
e dell'anno: doppio 午 -> l'arrivo e' penalizzato (午午 autopen.) e caricato; nessuna bestia su L2.
Nascosto B 寅 (di stagione). L4 Shi W 丑 (Terra 死 in 卯), incompatibile, verso 午; l'ora 子 lo
combina (una volta: si muove); l'arrivo 午 e' penalizzato dal giorno (午午) -> per la regola lo
Shi non puo' vincere -> SHORT [via del motore]. Nascosto C 午. L6 G 酉 vuota: mese 卯 e ora 子
sopra, 子卯 penalita' -> guerra fra titani, annullata. L3 G 酉 vuota, anno 丙午 sopra (Fuoco
controlla il Metallo, bestia sola, linea morta -> la prende -> 午 Fuoco = C; e non piu' vuota).
L5 P 亥. L1 Ying W 丑, giorno 壬午 sopra: 午 Fuoco genera la Terra -> la NUTRE (non la prende);
l'ora 子 la combina (子丑合) -> legata? una ferma combinata dal ramo dell'ora: tenuta.
Lettura normale, linee che si muovono:
 - Lo Shi 丑 -> 午 = arrivo anche della mobile L2 (stesso arrivo): i due movimenti finiscono
   nello stesso 午, ramo del giorno e dell'anno. Lo Shi diventa 午 Fuoco = C in 震. La mobile
   P 亥 diventa 午 C. Due C: tacciono?
 - Effetto scala: L2 parte da 亥 e lo Shi arriva in 午: nessuno arriva sul ramo di partenza
   dell'altro -> niente scala.
 - Il giorno penalizza l'arrivo dello Shi (午午): lo Shi non puo' vincere -> vince la Ying ->
   SHORT. MA anche la mobile L2 arriva in 午 penalizzato... L2 non e' una sede.
Contro (LONG): (c) la Ying W 丑 e' combinata dall'ora 子 (legata) e nutrita dal giorno 午: una
sede legata non puo' vincere? (d) Lo Shi W 丑 sale... no. (e) L'arrivo 午 e' sul ramo dell'anno
E del giorno: doppiamente "citato": lo Shi che diventa 午 e' fortissimo (di stagione? Fuoco 相 in
卯: SI', di stagione) -> nel confronto Fuoco dello Shi genera la Terra della Ying -> Ying
nutrita -> SHORT ancora. (f) Se "nessuno vince" (Shi penalizzato, Ying legata dall'ora): la piu'
forte... L5 P 亥? L1 stessa? Il nascosto 寅 B sotto L2, di stagione.
Conclusione: SHORT da tutte le vie che conosco; mercato LONG (+137).
DOMANDA PER EDU: che cosa fa vincere l'alto?

**LETTURA DI EDU su GBPUSD 09/03/2026 (seme 133) — `CONFERMATA DA EDU`, cablata a meta'** · 14/09/2026
Edu: "L6 clashata dalla bestia del mese muove per generare indietro. Long. L2 e L4 sono
bloccate dall'autopenalita' di Wu."
CABLATO (MLPENBLOCCA): quando piu' linee arrivano sullo stesso ramo penalizzato dal giorno
(qui L2 e L4 in 午, 午午), il movimento e' bloccato per tutte: annullate, non muovono. (Prima la
regola diceva "la sede non puo' vincere": questo vale quando e' UNA sola sede ad arrivarci.)
Il motore ora TACE su questa carta: per chiudere manca la parte di L6.
DUE PUNTI DA CHIARIRE prima di cablare L6:
1. Su L6 cadono il mese 辛卯 e l'ora 庚子 (stesso posto: la Tigre), e 子卯 e' una penalita' ->
   per la regola cablata (guerra fra titani) L6 sarebbe annullata. Edu invece la fa svegliare
   dal clash del mese 卯 su 酉. Quindi la guerra non c'e' quando... ? (le due bestie non si
   combattono fra loro perche' una CLASHA la linea?)
2. "muove per generare indietro": L6 酉 in 坤 che si muove va in 寅 (艮). Che cosa genera
   indietro: il 酉 Metallo che genera il 亥 di L5 sotto di lei, oppure l'arrivo 寅 nutrito dal 亥
   di L5? E perche' da' LONG: perche' e' un G in alto che si muove?
MISURA: 2708 carte 52,58% +12.889 · recente 53,97%. Carte di riferimento 42/42.

**LETTURA DI EDU su GBPUSD 09/03/2026 (seme 133), COMPLETATA — `CONFERMATA DA EDU`** · 14/09/2026
Edu: "Due bestie si accordano se possibile per far vincere la propria linea protetta. L6 酉 che
si muove non va in 寅: va su 戌, che genera indietro. Questa e' una linea ferma quindi quando
clashata non cambia da yin a yang o viceversa."
Due cose nuove:
1. LE BESTIE SI ACCORDANO (MLGUERRASVEGLIA): su L6 cadono mese 卯 e ora 子 (子卯 penalita'), ma
   il 卯 clasha la linea e la sveglia: le bestie si accordano per farla vincere, nessuna guerra
   fra titani. Perimetro cablato: una delle due bestie clasha la linea.
2. LA FERMA SVEGLIATA AVANZA (MLSVEGLIAAVANZA): la ferma clashata da una bestia non cambia
   polarita' (non e' l'esagramma futuro a darle l'arrivo): avanza di un ramo, 酉 -> 戌. Se
   l'arrivo genera la partenza (戌 Terra -> 酉 Metallo) la linea e' nutrita e parla col proprio
   carattere: G in alto -> LONG (+137). Perimetro: G (la W: MLSVEGLIAAVANZA=gw, misura peggio).
MISURA: 2713 carte 52,60% +13.018 · recente 54,03% (prima 52,58% +12.889). Gradino T0m: 15
carte 40,00%. Carte di riferimento 43/43.
Regole di Edu: si tengono. Il gradino misura male: da guardare in seguito.

**Carta letta da Claude col metodo · USDCAD 11/05/2023 seme 133 · `DA VALIDARE`** · S46
Peggiore del gradino nuovo "la svegliata avanza generata indietro" (15 carte al 40%). Motore
SHORT, mercato LONG +116. Stesso esagramma di GBPUSD 09/03/2026 (坤 sopra 巽, 升 46).
Mese 丁巳, giorno 己巳, anno 癸卯, ora 甲子, vuoti 戌 亥.
Pilastri -> bestie (giorno 己: 螣蛇 L1, 白虎 L2, 玄武 L3, 青龍 L4, 朱雀 L5, 勾陳 L6): anno 癸 -> 玄武
su L3; ora 甲 -> 青龍 su L4 (lo Shi); mese 丁 -> 朱雀 su L5; giorno 己 -> 螣蛇 su L1 (la Ying).
Scheda (incompatibili per prime): L4 Shi 丑 in 坤: incompatibile, nessun ramo lo combina due
volte -> si muove. L2 亥 in 巽: incompatibile, ponte di Legno: 卯 dell'anno, uno -> si muove.
Futuro comune (L1 + L2 + L4): 巽 -> 震? il motore: L1 丑 -> 卯, L2 亥 -> 丑, L4 丑 -> 午.
L1 Ying W 丑 mobile, verso 卯 (ramo dell'anno); il giorno 己巳 le cade sopra: 巳 Fuoco genera la
Terra -> la nutre. L4 Shi W 丑, verso 午 (= il nascosto dello Shi stesso, C 午); l'ora 甲子 cade
sopra: 子丑合 -> la bestia dell'ora COMBINA lo Shi -> lo tiene? (bestia che combina la linea:
regola?) L2 P 亥 VUOTA, verso 丑 (= ramo di L1 e L4: scalino), nessuna bestia (ma vuota, e cio'
che si muove non e' vuoto). L3 G 酉: l'anno 癸卯 la clasha -> si sveglia, avanza in 戌 (VUOTO!),
戌 Terra genera 酉 -> nutrita -> parla il G in basso -> SHORT [via del motore].
L5 P 亥 vuota, mese 丁巳 sopra: il Fuoco e' controllato dall'Acqua... 亥 e' 休 in 巳 -> il mese la
prende (al mese non ci si oppone) -> 巳 Fuoco = C. L6 G 酉, niente.
Confronto con GBPUSD 09/03/2026 (stesso esagramma, letta da Edu): la' le altre linee erano
BLOCCATE (autopenalita' 午午) e restava solo la G svegliata; qui invece L1, L2, L4 si muovono
davvero. Quindi la G svegliata NON dovrebbe venire per prima: prima le linee che si muovono.
Lettura normale, linee che si muovono: (a) L2 亥 -> 丑 = ramo dello Shi L4 e della Ying L1:
scalino su una sede — su tutte e due? Lo Shi 丑 se ne va (incompatibile); la Ying 丑 e' la mobile
e se ne va anche lei -> nessuna sede riceve lo scalino. (b) La Ying W 丑 va in 卯 (ramo dell'anno,
Legno: G? 卯 in 震 = B): la W diventa B -> la sede bassa perde -> LONG. (c) Lo Shi W 丑 va in 午,
il proprio nascosto C: la W diventa C (tace); ma l'ora 子 lo combina. (d) Lo Shi W 丑 -> 午 e' il
ramo del ... 午 non e' nella data.
Conclusione: LONG per (b) — la Ying W che si trasforma in B (卯 e' B nel palazzo 震) fa perdere
la propria squadra. La G svegliata di L3 avanza in 戌 VUOTO: forse per questo non conta.
DA CHIEDERE A EDU: 1) la G svegliata che avanza in un ramo VUOTO (戌) e' nutrita lo stesso?
2) l'ordine: la ferma svegliata viene dopo le linee che si muovono davvero?

**LETTURA DI EDU su USDCAD 11/05/2023 (seme 133) — `CONFERMATA DA EDU`** · 14/09/2026, S46
Edu: "Perche' e' difficile questa? Shi muove per generare indietro e vince. Non c'e' bisogno di
usare la bestia. Te lo ripeto di nuovo: le bestie sono li' PER AIUTARE LA PROPRIA LINEA A VINCERE!
Se la sua linea gia' si muove e vince, la bestia non fa niente che possa alterare il risultato."
Lo Shi W 丑 (incompatibile) si muove in 午: il Fuoco genera la Terra, lo Shi e' nutrito dal
proprio arrivo, resta se' stesso e parla il suo W -> la sede alta vince -> LONG (+116).
PRINCIPIO (da tenere davanti): le bestie aiutano la propria linea a vincere; se la linea gia' si
muove e vince, la bestia non cambia niente. Prima il movimento, sempre.
CABLATO `T0g2 la sede generata indietro` (MLGENINDIETRO), prima della ferma svegliata e prima
di tutte le regole con le bestie: una sede che si muove (mobile o ferma incompatibile) il cui
arrivo genera la partenza e' nutrita, resta se' stessa e parla col proprio carattere (W/G vince,
P/B perde — USDJPY 13/09/2022, carta di Edu: la Ying P 寅 nutrita dal 子 perde).
MISURA: 2718 carte 52,58% +14.394 · recente 54,33% (prima 52,60% +13.018). Gradino T0g2: 260
carte 55,38% +2.429. T0m scende a 11 carte. Carte di riferimento 44/44.

**Carta letta da Claude col metodo · USDJPY 30/07/2024 seme 153 · `DA VALIDARE`** · S46
Terza carta del gradino "la data penalizza l'arrivo della sede" (101 carte). Motore LONG,
mercato SHORT +109. Palazzo 乾 (Metallo), 離 sopra 乾 (大有 14), mese 辛未, giorno 乙未, anno 甲辰,
ora 甲申, vuoti 辰 巳.
Pilastri -> bestie (giorno 乙: 青龍 L1, 朱雀 L2, 勾陳 L3, 螣蛇 L4, 白虎 L5, 玄武 L6): giorno 乙 e anno
甲 e ora 甲 -> 青龍 su L1 (tre bestie); mese 辛 -> 白虎 su L5.
Scheda (incompatibili per prime): L3 Shi 辰 in 乾: incompatibile, VUOTO, senza ponte; il ramo 辰
dell'anno lo carica (Tai Sui) ma non lo combina -> si muove; cio' che si muove non e' vuoto.
Futuro comune (L3 + L6): 乾 -> 兌 sotto, 離 -> 震 sopra: L3 辰 -> 丑, L6 巳 -> 戌.
L6 Ying G 巳 mobile VUOTA (ma si muove -> non vuota), Fuoco di stagione (未: Fuoco 相), verso 戌;
il giorno 未 e il mese 未 penalizzano 戌? 戌未 e' penalita': 未 penalizza 戌 -> l'arrivo della
Ying e' penalizzato dal giorno (e dal mese) -> la Ying non puo' vincere?
L3 Shi P 辰 verso 丑: il giorno 未 clasha 丑 (丑未冲) -> arrivo clashato: la linea resta attiva e
non cambia -> P sullo Shi; e 未 penalizza 丑? no: 丑戌未 e' la penalita' a tre; 未 penalizza 丑 (未->丑
nella tavola) -> arrivo penalizzato -> lo Shi non puo' vincere. [via del motore: SHORT? no, il
motore dice LONG: fa perdere lo Shi (basso) -> LONG]. Ma anche la Ying ha l'arrivo penalizzato.
L5 P 未, ramo del giorno e del mese, mese 辛未 sopra (stesso ramo: carica). L4 B 酉 di stagione?
(Metallo in 未: 相? la Terra genera il Metallo: si'). L2 W 寅, ramo dell'ora? no, l'ora e' 申: 申
clasha 寅 -> L2 svegliata dall'ora? (dalla data, non da una bestia). L1 C 子: tre bestie (giorno
未 la controlla, anno 辰 la controlla, ora 申 la genera -> agisce 申 -> resta Acqua, aiutata).
Lettura normale, linee che si muovono:
 - Lo Shi P 辰 -> 丑: giorno 未 penalizza 丑 e lo clasha: doppio colpo sull'arrivo. Lo Shi non
   puo' vincere -> LONG. [motore]
 - La Ying G 巳 -> 戌: il giorno 未 penalizza 戌 (e il mese pure) -> la Ying non puo' vincere ->
   SHORT.
 TUTTE E DUE le sedi hanno l'arrivo penalizzato dal giorno. Nessuna vince -> "alla fine vince la
 piu' forte" (Edu, USDJPY 06/09/2022): L5 P 未 sul ramo del giorno E del mese, di stagione,
 caricata dal mese: la piu' forte, in ALTO -> l'alto vince -> LONG. Ma il mercato e' SHORT.
 Oppure L4 B 酉 di stagione... o L1 C 子 con tre bestie (aiutata dall'ora): in basso -> SHORT.
Conclusione di Claude: non chiusa. Il motore ha guardato solo lo Shi e ha ignorato che anche la
Ying e' penalizzata. DA CHIEDERE A EDU: con tutte e due le sedi penalizzate all'arrivo dal
giorno, chi decide? (la piu' forte: L5 未 in alto, o L1 子 con tre bestie in basso?)

**LETTURA DI EDU su USDJPY 30/07/2024 (seme 153) — `CONFERMATA DA EDU`** · 14/09/2026, S46
Edu: "Y: line moves into its own tomb. S: cannot retreat. Short."
La Ying G 巳 Fuoco va in 戌, la tomba del Fuoco: si sotterra, la sua squadra perde -> SHORT
(+109). Lo Shi 辰 -> 丑 retrocederebbe, ma il giorno 未 clasha 丑: non puo' retrocedere, resta
dov'e' e non decide.
CABLATO `T0f2 la sede nella propria tomba` (MLTOMBASEDE), prima della sede generata indietro:
una sede che si muove (mobile o ferma incompatibile) il cui arrivo e' la tomba del proprio
elemento perde. (Lo Shi che "non puo' retrocedere" qui non decide: non cablato a parte.)
MISURA: 2718 carte 52,43% +13.988 · recente 54,12% (prima 52,58% +14.394). Gradino 58 carte
46,55% -201. Carte di riferimento 45/45. Regola di Edu: si tiene.

**Carta letta da Claude col metodo · GBPUSD 25/09/2024 seme 134 · `DA VALIDARE`** · S46
Quarta carta del gradino "la data penalizza l'arrivo della sede" (82 carte). Motore LONG,
mercato SHORT +104. STESSO ESAGRAMMA di USDJPY 05/12/2022 (坤 sopra 坎, 師 7). Mese 癸酉, giorno
壬辰, anno 甲辰, ora 辛丑, vuoti 午 未.
Pilastri -> bestie (giorno 壬: 玄武 L1, 青龍 L2, 朱雀 L3, 勾陳 L4, 螣蛇 L5, 白虎 L6): giorno 壬 e mese
癸 -> 玄武 su L1 (la mobile); anno 甲 -> 青龍 su L2; ora 辛 -> 白虎 su L6 (la Ying).
Scheda (incompatibili per prime): L3 Shi 午 in 坎: incompatibile, VUOTO, ponte di Legno: nessun
Legno nella data -> si muove (non piu' vuoto) verso 辰. L4 丑 in 坤: incompatibile, ramo dell'ora
(caricata), verso 午. Futuro comune (L1+L3+L4): L1 寅 -> 子, L3 午 -> 辰, L4 丑 -> 午.
L3 Shi W 午 -> 辰: 辰 e' la tomba del Fuoco? No: la tomba del Fuoco e' 戌; 辰 e' la tomba
dell'Acqua/Terra. Il giorno 辰 e l'anno 辰 penalizzano l'arrivo (辰辰) -> lo Shi non puo' vincere
-> LONG [motore]. Ma: L3 -> 辰 = il ramo di L2 (G 辰, ferma, sul ramo del giorno e dell'anno,
caricata due volte): SCALINO: lo Shi arriva su L2 e ne prende il carattere G? -> il G fa
vincere la sede -> SHORT. Oppure: lo Shi 午 Fuoco genera 辰 Terra: lo Shi si scarica
nell'arrivo? (il contrario di "generato indietro": drenato dall'arrivo).
L4 G 丑 -> 午 = ramo dello Shi (che se ne va: niente scalino) e 午 e' VUOTO: arriva nel vuoto.
L1 C 寅 mobile -> 子: 子 Acqua genera 寅: nutrita, resta C, tace; sopra giorno 壬辰 e mese 癸酉:
辰 Terra e' controllata dal Legno, 酉 Metallo controlla il Legno -> 酉 la prende? due bestie,
nessuna la aiuta -> nessuna agisce.
L6 Ying P 酉, ramo del mese, di stagione; ora 辛丑 sopra (Terra genera Metallo: la nutre). L5 B
亥 (酉亥: il Metallo la genera). L2 G 辰 ramo del giorno e dell'anno.
Lettura normale: lo Shi W 午 -> 辰: (a) il giorno penalizza l'arrivo -> lo Shi non vince ->
LONG. (b) Ma 辰 GENERA? 午 Fuoco genera 辰 Terra: la sede si muove per generare l'arrivo -> si
scarica -> perde? (c) Scalino su L2 G 辰 ferma (sul ramo del giorno): lo Shi raggiunge L2 e ne
prende il G -> la sede bassa vince -> SHORT. (d) La Ying P 酉 di stagione, sul ramo del mese,
nutrita dall'ora: forte in alto, ma P -> la sua squadra perde -> SHORT.
Sul gemello USDJPY 05/12/2022 (stessa struttura: Shi 午 -> 辰, giorno 辰) Edu ha detto "il giorno
penalizza l'arrivo di Shi -> Shi non puo' vincere -> LONG". Qui il mercato e' SHORT. Differenze:
li' la Ying 酉 aveva due bestie che la aiutavano ed era gia' combinata dal giorno 辰; qui la Ying
酉 e' sul ramo del MESE (di stagione, fortissima) e ha l'ora 丑 che la nutre, e nessun ramo della
data la combina (辰 combina 酉! il giorno 辰 la combina anche qui). Li' L4 丑 arrivava in 午 sullo
Shi; qui uguale. La differenza vera: la Ying qui e' sul ramo del mese.
DOMANDA PER EDU: due carte gemelle con esito opposto — che cosa cambia? La Ying sul ramo del
mese (P fortissima che fa perdere la propria squadra)?

**LETTURA DI EDU su GBPUSD 25/09/2024 (seme 134) — `CONFERMATA DA EDU`** · 14/09/2026, S46
Edu: "L1 fa vincere la propria squadra."
La mobile L1 C 寅 va in 子, che la genera indietro (Acqua -> Legno): nutrita, fa vincere la sua
squadra -> sede bassa -> SHORT (+104). La C nutrita VINCE. Viene prima della penalita' del giorno
sull'arrivo dello Shi; e il clash dell'arrivo di L4 (午) sull'arrivo della mobile (子) non la ferma.
GEMELLA USDJPY 05/12/2022 (stesso esagramma, stessa mobile 寅 -> 子, Shi 午 -> 辰 penalizzato dal
giorno 辰): li' Edu ha letto lo Shi penalizzato -> LONG. La differenza trovata: li' sulla mobile
cadono giorno 辰 e anno 寅, e il 寅 e' del suo stesso elemento -> AGISCE e se la prende in due; qui
cadono giorno 辰 e mese 酉, nessuna la aiuta -> nessuna agisce -> la mobile decide per se'.
CABLATO `T0g3 la mobile generata indietro` (MLGENINDIETROMOB): la mobile (non sede) il cui arrivo
genera la partenza, senza bestie che agiscono sopra: C -> la sua squadra vince; W/G vince; P/B
perde. POSIZIONE: dopo la scala, il trigono nel trigramma, il B che genera la C (carte di Edu
02/08/2022, 17/07/2024, 06/02/2025 che altrimenti si rompevano), e PRIMA della penalita'
sull'arrivo, che e' stata spostata dopo (ora sta prima della seconda che retrocede).
MISURA: 2718 carte 52,58% +14.838 · recente 54,40% (prima 52,43% +13.988). Gradini: T0g3 87
carte 45,98%; T0i scende a 54 carte. Carte di riferimento 46/46.

**PRINCIPIO DI EDU (14/09/2026): "Una linea mobile non puo' penalizzare il proprio arrivo, non
avrebbe senso alcuno. E' solo la data che puo' farlo."**
Verificato nel motore: la penalita' sull'arrivo (T0i, il blocco a piu' linee, la sostituzione
della seconda) usa SOLO i rami della data (giorno; mese per la sostituzione); l'autopenalita'
辰午酉亥 conta solo quando e' un ramo della DATA a cadere sull'arrivo. Il punto aperto di USDJPY
12/01/2023 ("lo Shi si muove per penalizzare se stesso, 丑戌") e' CHIUSO: era un'idea di Claude
senza senso, ritirata. La carta resta letta col trigono nel trigramma (Edu).

# S47 (14/09/2026) — GRADINO 1, LA PENALITA' SULL'ARRIVO

## GBPUSD 05/03/2025 seme 127 — LETTURA DI EDU · `CONFERMATA`
Peggiore perdente rimasta del gradino "la data penalizza l'arrivo della sede" (54 carte, 48,15%).
Carta: palazzo 艮 Gen, giorno 癸酉, mese 寅, anno 巳, ora 午, vuoti 戌亥. Shi L6 (G 寅 Legno, di
stagione, mobile -> 酉), Ying L3 (C 申, ferma incompatibile in 艮 senza ponte d'Acqua nella data,
combinata UNA sola volta dall'anno 巳 quindi si muove: 申 -> 卯). Esito LONG +101; il motore
diceva SHORT.

**PAROLE DI EDU:**
"Y si muove e raggiunge una linea vuota.
S si muove per essere controllata indietro ma il giorno penalizza quindi il controllo indietro
non funziona.
Long"

LETTURA DI CLAUDE PRIMA (giusta come direzione, incompleta come via): l'arrivo 酉 e' in prigione
nel mese 寅, autopenalizzato dal giorno 酉 e clashato dall'arrivo 卯 della seconda, quindi il
controllo indietro non prende e il G di stagione resta sullo Shi e fa vincere la sede alta.
Edu conferma il pezzo della penalita' e aggiunge la traccia della Ying, che Claude aveva
accantonato perche' "la seconda non decide".

CABLATO 1 — `MLPENINDIETRO` (dentro T0i): quando il movimento della sede e' un controllo
indietro (l'arrivo controlla la partenza) e la data penalizza l'arrivo, la penalita' NON
condanna la sede: uccide il controllo indietro. La sede resta se' stessa e la lettura prosegue.
NON contraddice USDJPY 05/12/2022 (l'origine di T0i): li' il movimento dello Shi non era un
controllo indietro, e la penalita' si rifletteva sulla sede.

PRECISAZIONE DI EDU, SUBITO DOPO: "Anche se non fosse vuota sarebbe una B che farebbe comunque
perdere Ying. Le bestie le usiamo se portano un vantaggio."
Due conseguenze.
1) Il vuoto di L4 non e' il punto: la linea raggiunta e' un B, e il B fa perdere la propria
   squadra comunque. La carta NON dimostra che sia il VUOTO a far perdere la sede che lo
   raggiunge. Percio' `MLSEDEVUOTA` (gradino `T0n la sede raggiunge una vuota`, allargamento di
   T2n alle sedi e a una vuota di qualunque carattere) resta scritto ma SPENTO, dichiarato come
   estensione di Claude: da spento pip 14.630, da acceso 14.114. Per decidere serve una carta in
   cui la vuota raggiunta sia una W o una G, dove le due vie danno direzioni diverse.
2) "Le bestie le usiamo se portano un vantaggio" — il motore qui e' gia' d'accordo: su L4 cadono
   mese 戊寅 e ora 戊午; il 午 Fuoco genera la Terra della linea, quindi porta un vantaggio, agisce
   e toglie il vuoto (regola MLBESTIEAIUTO, con piu' bestie agiscono solo quelle che aiutano; se
   nessuna aiuta, nessuna agisce e il vuoto resta). Nessuna modifica.

MISURA FINALE (solo MLPENINDIETRO acceso): 2718 carte 52,58% +14.630 · recente 54,62% (da
54,40%) · gradino T0i da 54 carte 48,15% a 42 carte 50,00% · carte di riferimento 47/47
(GBPUSD 05/03/2025 aggiunta alla lista).

## USDCHF 28/02/2022 seme 92 — LETTURA DI EDU · `CONFERMATA`
Seconda peggiore del gradino. Palazzo 巽 Xun (Legno), giorno 壬子, mese 寅, anno 寅, ora 未,
vuoti 寅卯. Shi L5 (W 未 Terra, morta di stagione, nessun pilastro sopra), Ying L2 (B 寅 Legno,
mobile -> 卯, di stagione, Tai Sui, vuota ma riempita da mese e anno; l'arrivo 卯 resta vuoto ed
e' penalizzato dal giorno 子). Esito SHORT -99; il motore diceva LONG.

**PAROLE DI EDU:**
"Y cannot advance and yet Yin is the strongest line of the hexagram.
Y controls S, short"

LETTURA DI CLAUDE PRIMA — SBAGLIATA COME VIA (direzione giusta per caso): aveva letto il B che
AVANZA e ruba la W dello Shi (進神, T0c). Edu dice il contrario: la Ying **non puo' avanzare**.
Non c'e' nessun furto in avanzamento: la linea resta dov'e', e quello che conta e' che 寅 e' la
linea piu' forte della carta e **controlla** il 未 dello Shi. Da qui la direzione.

CABLATO — `MLFORTECONTROLLA`, dentro T0i, gradino `T0i la più forte controlla l'altra sede`:
quando il passo e' nullo (arrivo vuoto) la sede non avanza ma resta dov'e'; se la sua linea e' la
piu' forte della carta (funzione forza, strettamente sopra tutte le altre) e il suo elemento
controlla la linea dell'altra sede, vince la sua squadra. La penalita' della data sull'arrivo non
la condanna, perche' l'arrivo non e' mai nato.

MISURA: mazzo da 52,58% +14.630 a **52,65% +14.882** · recente da 54,62% a 54,69% ·
gradino T0i da 42 carte 50,00% a **40 carte 52,50%** · gradino nuovo 2 carte 100% +126 pip ·
carte di riferimento **48/48** (USDCHF 28/02/2022 aggiunta alla lista).

NOTA DI METODO PER CLAUDE: due volte di fila, su questo gradino, l'errore e' stato leggere come
compiuto un movimento che non si compie. Quando l'arrivo e' vuoto o penalizzato dalla data, il
primo passo e' chiedersi se la linea si muove davvero; se non si muove, si legge la linea ferma
dov'e', con la sua forza e i suoi controlli.

## GBPUSD 02/08/2022 seme 122 — LETTURA DI EDU · `CONFERMATA`
Palazzo 艮 Gen (Terra), giorno 丁亥, mese 未, anno 寅, ora 丑, vuoti 午未. Shi L3 (B 丑, mobile),
Ying L6 (G 寅, legata dal giorno). L2 卯 G e' incompatibile in 兌 (ponte d'Acqua: solo il giorno 亥,
non basta) e si muove anche lei: con due linee che girano lo Shi va in 亥, L2 va in 丑.
Esito SHORT -94; il motore diceva LONG (T0i, penalita' 亥 su 亥).

**PAROLE DI EDU:** "L2 G moves to reach S. Short"

LETTURA DI CLAUDE PRIMA (direzione giusta, via diversa): lo Shi da B diventa W arrivando in 亥.
Edu non passa di li': e' la seconda mobile, il G di L2, che arrivando in 丑 raggiunge lo Shi e
gli porta il suo G. Il G fa vincere la sede che raggiunge.

CABLATO — `MLGRAGGIUNGE`, gradino nuovo `T0h il G raggiunge una sede`, PRIMA di T0i: una linea
che NON e' una sede, e' un G e si muove (mobile o ferma incompatibile), e il cui arrivo porta lo
STESSO RAMO della linea di una sede, raggiunge quella sede e la fa vincere. Solo G (la W non e'
provata da nessuna carta). `MLGRAGGIUNGE=seconda` restringe alla sola seconda mobile.

MISURA:
  prima (tre correzioni S47 precedenti)   2718  52,65%  +14.882 · recente 54,69%
  accesa, perimetro largo                  2718  52,80%  +15.323 · recente 55,04%
  accesa, solo seconda mobile              2718  52,76%  +15.060 · recente 54,90%
  gradino T0i "la data penalizza"          da 40 carte 52,50% a 32 carte 56,25%
  IL GRADINO NUOVO DA SOLO: 44 carte 47,73% -111 pip (larga) · 39 carte 46,15% -208 (seconda).
  Il mazzo sale perche' le carte escono da gradini che le leggevano peggio, ma il gradino in se'
  e' sotto il 50%: il perimetro "stesso ramo della sede" prende carte che Edu non ha letto.
  Carte di riferimento 49/49.

NOTA: durante la cablatura era comparso nel file un blocco `MLGENRITORNO` con la prima
versione della frase di Edu, "L2 G moves to reach S which then moves to generate back". Edu ha
poi chiarito (15/09/2026): "Visto che il giorno penalizza l'arrivo l'ho riscritto togliendo quella
parte." La seconda parte (lo Shi che si muove in 亥 e genera indietro il G) e' RITIRATA da Edu,
perche' il giorno 亥 penalizza l'arrivo 亥 e quel movimento non si compie. Il blocco e' stato
rimosso; vale solo "L2 G moves to reach S. Short".

# S47 · 15/09/2026 — USDJPY 05/12/2022 RILETTA DA EDU · `CONFERMATA`
**PAROLE DI EDU:**
"Lower trigram:
L1: moves to generate back
L3: cannot change into G as Chen is penalized
Result: L1 generates S
Upper trigram: L4 goes into void
YING: Beasts help. Xin Chou and Xin Hai arrives here. Metal generates water.
Conclusion: Ying with water beats Shi with fire. LONG"

Lettura: L1 C 寅 va in 子, che la genera indietro (nutrita); lo Shi 午 non puo' diventare il G 辰
perche' il giorno 辰 penalizza l'arrivo -> resta W Fuoco, e L1 Legno lo genera. L4 G 丑 va in 午,
che e' nel vuoto: va nel vuoto e non raggiunge nessuno. Sulla Ying 酉 cadono ora 辛丑 e mese 辛亥
(stessa bestia, Tigre Bianca): le bestie aiutano, il Metallo genera l'Acqua, la Ying tiene
l'Acqua (di stagione nel mese 亥). Acqua batte Fuoco: vince la Ying, LONG (+227).

CABLATO — dentro `MLGRAGGIUNGE` (T0h): l'arrivo del G che "raggiunge" una sede NON deve essere
nel vuoto del giorno; se lo e', va nel vuoto e non raggiunge nessuno. Questa e' la differenza con
GBPUSD 02/08/2022, dove l'arrivo 丑 non era vuoto.
MISURA: mazzo 52,80% +15.727 (da +15.323) · recente 54,90% · gradino T0h da 44 carte 47,73% a
**35 carte 51,43% +238** · T0i 37 carte 54,05% · carte di riferimento **49/49**.
Il motore chiude la carta LONG per la via della penalita' (T0i), non per la via di Edu.

DA CHIEDERE A EDU (tensione con S46): l'11/09 su questa stessa carta Edu aveva detto "Xin Chou
aiuta Y P you, ma Xin Hai invece la farebbe perdere quindi non agisce" (da cui MLBESTIEAIUTO:
agisce solo la bestia che aiuta la linea). Oggi dice che tutte e due aiutano e che il Metallo
genera l'Acqua. Lettura di Claude della differenza: la bestia si usa se porta un VANTAGGIO nel
confronto con l'altra sede (Edu, 14/09: "le bestie le usiamo se portano un vantaggio"). L'11/09
lo Shi era letto come 辰 Terra, e l'Acqua sarebbe stata controllata dalla Terra: nessun vantaggio.
Oggi lo Shi resta 午 Fuoco, e l'Acqua lo batte: vantaggio. NON cablato finche' Edu non conferma.

**REGOLA DI EDU — LA BESTIA SI USA SE PORTA UN VANTAGGIO NEL CONFRONTO — `CONFERMATA DA EDU`** · 15/09/2026, S47
Alla domanda "la bestia si usa se porta un vantaggio nel confronto con l'altra sede: l'11/09 lo
Shi era letto come 辰 Terra e l'Acqua non serviva; oggi lo Shi resta 午 Fuoco e l'Acqua lo batte"
Edu: "Sì è così".
CABLATO — `MLBESTIAVANTAGGIO`, dentro elDopoLeBestie: su una SEDE, una bestia che la linea
genera (Metallo -> Acqua) si usa lo stesso se l'elemento che porta controlla l'elemento dell'altra
sede. L'elemento dell'altra sede e' quello della sua linea. Non tocca il resto di MLBESTIEAIUTO.
MISURA: mazzo da 52,80% +15.727 a **52,83% +15.764** · recente 54,97% · riferimento 49/49.
La carta resta LONG per la via della penalita' (T0i), che scatta prima del confronto fra sedi.

## AUDUSD 21/11/2022 seme 66 — LETTURA DI EDU · `CONFERMATA`
Palazzo 坤 Kun (Terra), giorno 戊寅, mese 亥, anno 寅, ora 巳, vuoti 申酉. Shi L2 (G 卯, incompatibile
in 兌, va in 巳), Ying L5 (W 亥, di stagione). L1 P 巳 mobile -> 未; L4 B 丑 incompatibile -> 午.
Il giorno 寅 penalizza l'arrivo 巳 dello Shi. Esito SHORT -77; il motore diceva LONG (T0i).

**PAROLE DI EDU:** "Both lines go nowhere as they both make their side to lose. Beasts didn't
help. S vs Y: S wins. Short"

CABLATO — `MLPENCONFRONTO`, dentro T0i, dopo MLFORTECONTROLLA e prima della condanna: la data
penalizza l'arrivo della sede -> la sede non parte e resta se' stessa; se TUTTE le altre linee in
movimento (mobile e incompatibili non-sedi) sono P o B, fanno perdere la propria squadra e non
vanno da nessuna parte; allora confronto diretto fra le due sedi come stanno (elementi dopo le
bestie, che si usano solo se portano vantaggio). Qui: l'Acqua della Ying genera il Legno dello
Shi, la Shi e' nutrita e vince, SHORT.
Non tocca USDJPY 05/12/2022 (le altre mobili sono C e G, il perimetro non prende).
MISURA: mazzo da 52,83% +15.764 a **52,80% +15.606** · recente 54,97% · gradino nuovo 15 carte
53,33% +88 · "la data penalizza" resta 24 carte 54,17% · riferimento 50/50.
Regola di Edu: si tiene anche se costa (−158 pip, −0,03 punti).

## NZDUSD 10/03/2020 seme 63 — LETTURA DI EDU · `CONFERMATA`
Palazzo 艮 Gen (Terra), giorno 壬子, mese 卯, anno 子, ora 寅, vuoti 寅卯. Shi L6 (G 寅, vuoto, ramo
dell'ora, anno 庚子 sopra), Ying L3 (C 申 mobile -> 卯: vuoto e penalizzato dal giorno 子).
L2 P 午 clashata dal giorno 子: si muove nel buio in 巳 (退神). Esito SHORT -74; motore LONG.

**PAROLE DI EDU:** "L3 cannot move into a G because of the penalty from the day. L2 P is clashed
by the day to retreat. A retreating P wins its side: short"

LETTURA DI CLAUDE PRIMA (direzione giusta, via sbagliata): la Ying ferma 申 Metallo controlla e
clasha il 寅 dello Shi. Edu non passa dal confronto: decide la P che si ritira.

CABLATO — `MLPENRITIRO`, dentro T0i, dopo MLPENCONFRONTO e prima della condanna: la sede
penalizzata non parte; una P ferma, non sede, clashata dal giorno (暗動) il cui arrivo e' il
passo indietro (退神) -> il malus si ritira e la sua squadra vince. Solo P (la B non e' provata).
MISURA: mazzo da 52,80% +15.606 a **52,72% +15.231** · recente 55,04% (da 54,97%) · gradino
nuovo **6 carte 33,33% -188** (2 giuste, 4 storte) · "la data penalizza" 19 carte 47,37% ·
riferimento 51/51. Regola di Edu: tenuta anche se costa; sei carte sono poche per dire altro.

**EDU, 15/09/2026 — LE QUATTRO STORTE DEL GRADINO "LA P CHE SI RITIRA"**
Le sei carte del gradino sono la stessa carta (艮/艮, L3 mobile, giorno 子); cambia solo la data.
1) "Sulle prime due e' ovvio che il vuoto non fa retrocedere la linea" (USDCAD 15/08/2022 e
   NZDUSD 13/12/2022, vuoti 辰巳: il passo indietro 巳 cade nel vuoto). CABLATO dentro
   MLPENRITIRO: la P non si ritira se l'arrivo e' nel vuoto. Gradino da 6 carte 33% a 4 carte 50%.
2) USDCAD 04/01/2021 (Edu l'ha chiamata GBPUSD 20/12/2023, ma i tre 子 nella data — giorno 壬子,
   mese 戊子, anno 庚子 — sono di USDCAD 04/01/2021; la GBPUSD ha due 子 ed e' giusta): "L2 viene
   spazzata via da tre 子 nella data ed L5 diventa la linea piu' potente dell'esagramma e vince."
   CABLATO dentro MLPENRITIRO: clashata da TRE rami della data la P non si ritira, e' spazzata
   via. Gradino a 3 carte 66,67% +57.
3) "Non hai cablato che in assenza di soluzioni e quando tutto il resto fallisce (incluse bestie
   e S vs Y) si vede semplicemente la linea piu' forte??" — NO, era cablata solo dentro T0i
   (14/09, "nessuno vince: la piu' forte"). CABLATO ORA — `MLPIUFORTE`, gradino `T9 la linea piu'
   forte`, ultimo prima del silenzio: fra le linee non vuote e non annullate vince la squadra
   della piu' forte (stagione, ramo del mese +2, del giorno +1, dell'anno +1, +1 per ogni clash
   della data che la cita); serve un massimo netto, a parita' tace.
MISURA: tace da 70 a 60 carte · T9 10 carte 60% +185 · mazzo da 52,83% +15.720 (2718) a
**52,86% +15.905 (2728)** · recente 55,02% · riferimento 52/52.
STATO DI USDCAD 04/01/2021: il motore la chiude LONG, ma per la condanna della penalita' (T0i),
non per la linea piu' forte: la condanna scatta prima e T9 non viene raggiunto. Da decidere con
Edu se la condanna "quella sede non puo' vincere" deve restare o cedere il passo.

# S47 · 15/09/2026 — LA SPINA DORSALE: I QUATTRO PRINCIPI COME ORDINE DEL MOTORE
Edu: "Come e' possibile che io leggo le carte, fornisco le risposte e queste vengono
dimenticate? La questione della linea piu' forte era gia' uscita in 2-3 occasioni eppure...
non serve a niente." Claude: ogni lettura di Edu era stata cablata come gradino stretto legato
alla carta; il principio generale non aveva un posto nel motore. Edu: "Fallo assolutamente."

FATTO (tutto dietro interruttore, la vecchia catena e' riproducibile esatta):
1. Principio 1 — la penalita' della data sull'arrivo e' la MORTE DEL MOVIMENTO: la sede non parte
   e resta se' stessa, la lettura prosegue. La vecchia condanna "quella sede non puo' vincere"
   resta dietro MLPENCONDANNA=on. Le cinque letture di Edu del 14-15/09 sono casi di questo.
   La seconda mobile con l'arrivo nel vuoto va nel vuoto e non fa niente (MLSECVUOTA=off).
2. Principio 2 — le bestie solo se portano vantaggio (MLBESTIEAIUTO + MLBESTIAVANTAGGIO, gia' cablati).
3. Principio 3 — T8 SHI CONTRO YING (MLSVSY=off): quando ne' le mobili ne' le bestie concludono,
   confronto diretto fra le due sedi come stanno. Prima si arrivava qui solo col duello T7 (una
   sede fuori e l'altra no) e poi si taceva; il silenzio del duello resta dietro MLDUELLOTACE=on.
4. Principio 4 — T9 la linea piu' forte (MLPIUFORTE=off), ultimo gradino prima del silenzio.
Il quadro dei quattro principi e' scritto in testa a motore_lettura.js.

MISURA — prima (MLPENCONDANNA=on MLDUELLOTACE=on MLSVSY=off MLSECVUOTA=off) e dopo:
  prima   parla 2728 · tace 60 · 52,86% · +15.905 · recente 55,02%
  dopo    parla 2775 · tace 13 · 52,76% · +16.177 · recente 54,72%
  T8 Shi contro Ying: 50 carte 40,00% -221 (i verdetti "vince la Shi" 10/30, "vince la Ying" 10/15)
  T9 la linea piu' forte: 12 carte 66,67% +373
  T7 il duello (sede presa) 82 carte 53,66% · T7 il duello 31 carte 51,61%
  Carte di riferimento 52/52.
Lettura della misura: 47 carte in piu' parlano; il punto debole e' il confronto diretto T8,
che sotto il 50% vale meno del silenzio. E' il principio 3 come lo ha scritto Claude
(generazione -> nutrito vince; controllo -> chi controlla vince; forza) su carte che Edu non ha
letto: da rileggere con Edu, non da aggiustare a mano.

**IL PRINCIPIO 3 (SHI CONTRO YING) MISURATO IN TRE FORMULE — 15/09/2026**
Edu: "voglio capire cosa non funziona nella regola #3, sicuro che la soluzione per quelle 30
carte non esiste gia'?" Sulle ~50 carte dove ne' le mobili ne' le bestie concludono:
  elementi (generazione -> nutrito vince; controllo -> chi controlla vince)  50 carte 40,0%
  carattere delle sedi (G/W fanno vincere, P/B fanno perdere, C tace)        42 carte 38,1%
  la piu' forte delle due sedi (stagione, rami della data, clash)             49 carte 36,7%
  T8 SPENTO -> le carte scendono a T9, la piu' forte dell'ESAGRAMMA           43 carte 55,8%
Risposta: la soluzione esiste gia' ed e' il principio 4 di Edu, la linea piu' forte
dell'esagramma. Nessuna formula di confronto fra le due sedi scritta da Claude regge; la piu'
forte delle due sedi perde addirittura due volte su tre. T8 resta SPENTO finche' Edu non detta
la sua regola di confronto (nelle sue letture — USDJPY 05/12/2022, AUDUSD 21/11/2022 — il
confronto arriva dopo che le mobili e le bestie hanno gia' fissato gli elementi, e quelle carte
il motore le chiude prima).
MISURA DEFINITIVA S47: parla 2756 · tace 32 · **52,98% +16.474** · recente 55,21% ·
riferimento 52/52. (Base S46: 2718 · tace 70 · 52,58% +14.838 · recente 54,40%.)

## EURUSD 11/03/2022 seme 110 — LETTURA DI EDU · `CONFERMATA`
Palazzo 離 Li (Fuoco), giorno 癸亥, mese 卯, anno 寅, ora 丑, vuoti 子丑. Shi L5 (B 巳 mobile -> 子:
il giorno clasha la partenza, l'arrivo e' vuoto), Ying L2 (C 辰 Terra). Tutti e quattro i pilastri
su L1 (P 寅, legata dal giorno). Esito SHORT -102; il motore diceva LONG (T9, L6 P 卯 la piu' forte).
**PAROLE DI EDU:** "L5 cannot move because of the clash. Still survive as the month generate it.
S generates Y. Short"
Lo Shi non si muove ma sopravvive perche' il mese 卯 Legno genera il suo Fuoco; poi S contro Y:
il Fuoco dello Shi genera la Terra della Ying, la Ying e' nutrita e vince, SHORT.
E' esattamente il principio 3 nella formula "elementi" (T8), che era stata SPENTA perche' su 50
carte fa il 40%. Riaccesa come regola di Edu (si tiene anche se costa); le sue storte vanno a
Edu una per una, a partire dalla peggiore (GBPUSD 06/05/2020, -103).
Variante provata e scartata: confronto solo fra sedi "vive" (di stagione, non vuote/legate/rotte)
-> 16 carte 31%, e questa carta non ci entra (la Ying 辰 e' fuori stagione).
Variante provata e scartata su T9: la piu' forte parla col suo carattere -> 39 carte 48,7% contro
43 al 55,8%.
MISURA con T8 acceso: 2775 carte · tace 13 · 52,76% +16.177 · recente 54,72%.

## GBPUSD 06/05/2020 seme 124 — LETTA DA CLAUDE COL METODO · `DA VALIDARE`
Peggiore storta del principio 3. Palazzo 巽 (Legno), giorno 己酉, mese 巳, anno 子, ora 卯, vuoti
寅卯. Shi L4 (W 戌 Terra, di stagione), Ying L1 (P 子 Acqua, Tai Sui). L3 W 辰 mobile -> 亥 ma legata
dal giorno (辰酉): non parte. Sulla Ying cade il giorno 己酉: il Metallo del 酉 genera l'Acqua.
Esito SHORT -103; il motore diceva LONG (Terra dello Shi controlla l'Acqua della Ying).
LETTURA DI CLAUDE: la mobile e' legata e non si muove; le bestie: quella del giorno sulla Ying
porta un vantaggio — se la Ying prende il Metallo, la Terra dello Shi la genera invece di
controllarla — quindi si usa (Edu, 14/09: "le bestie le usiamo se portano un vantaggio"). S vs Y:
la Terra genera il Metallo, la Ying e' nutrita e vince, SHORT.
CABLATO — dentro MLBESTIAVANTAGGIO: con UNA sola bestia su una sede, senza possesso, se il suo
elemento fa vincere la sede nel confronto con l'altra (la controlla, o ne e' generato), la sede lo
prende. Prima con una bestia sola contava solo il possesso.
MISURA: T8 da 50 carte 40% (-221) a **50 carte 48% (+187)** · mazzo da 52,72% +16.140 a
**52,92% +16.456** · recente 54,86% · riferimento 53/53.
CONFERMA DI EDU su GBPUSD 06/05/2020: "L3 cannot move, no beast can help the line. S vs Y sees S
winning but the beast comes to rescue Y by providing the bridge. Y win. Short"
Il PONTE: l'elemento dell'altra sede genera quello della bestia, che genera quello della sede
(Terra -> Metallo -> Acqua): il controllo diventa generazione. Cablato come tale.
MISURA: solo ponte -> T8 50 carte 42% (-133), mazzo 52,83% +16.428; ponte + bestia che controlla
l'altra sede (USDJPY 05/12/2022, Acqua batte Fuoco) -> T8 50 carte 48% (+187), mazzo 52,92%
+16.456. Default: tutte e due, perche' sono due letture di Edu; MLBESTIAVANTAGGIO=ponte per il
solo ponte. Riferimento 53/53.
PRECISAZIONE DI MISURA: la versione "larga" da 52,92% includeva anche il caso "l'altra sede genera
la bestia ma la bestia non genera la linea", che non e' nessuna delle due letture di Edu. Tolto.
Default fedele (ponte + bestia che controlla l'altra sede): mazzo **52,81% +16.183** · recente
54,65% · T8 50 carte 48% +187 · riferimento 53/53.

## USDJPY 05/11/2020 seme 104 — LETTA DA CLAUDE COL METODO · `DA VALIDARE`
巽 Xun su 坤 Kun, mutante L2, palazzo 乾 (Metallo), giorno 壬子, mese 戌, anno 子, ora 未, vuoti 寅卯.
Shi L4 P 未 (di stagione, ramo dell'ora), Ying L1 P 未 (di stagione, ramo dell'ora, nascosta la C 子).
Sulla Ying cadono giorno 壬子 e anno 壬子 (stesso pilastro): il 子 coincide col nascosto e lo
tirava fuori, la Ying diventava Acqua; la Terra dello Shi controlla l'Acqua -> LONG. Esito SHORT -92.
LETTURA DI CLAUDE (logica, con regole gia' di Edu): 1) il G di L2 drena in 辰 P: si dissolve,
nessun G/W parla (le W sono vuote); 2) le bestie si usano solo se portano vantaggio: il nascosto
子 Acqua tirato fuori PERDE contro la Terra dello Shi, quindi la Ying non lo prende e resta 未 P;
3) le due sedi sono identiche (P 未 Terra, di stagione, sul ramo dell'ora): "S e Y sono uguali ma
chi ha le bestie dal suo lato vince sempre" (Edu, 09/09) -> la Ying ha il giorno e l'anno sopra,
lo Shi nessuno -> vince la Ying, SHORT.
CABLATO — dentro MLBESTIAVANTAGGIO: il nascosto tirato fuori dalla bestia su una sede si prende
solo se non perde il confronto con l'altra sede (se l'altra lo controlla, la sede resta se' stessa).
MISURA: T8 da 50 carte 48% a 49 carte 48,98% +285 · mazzo 52,81% (uguale) da +16.183 a
**+16.432** · recente 54,58% · riferimento 54/54.
CORREZIONE DI EDU su USDJPY 05/11/2020 · `CONFERMATA` (la lettura di Claude "chi ha le bestie dal
suo lato" NON e' quella di Edu):
"In questa carta nessuno vince. L2 si trasforma in una P e fa perdere la propria squadra ma
nell'altro campo non c'e' nulla che faccia vincere perche' la G su L5 e' legata dalla linea
nascosta. S e Y sono lo stesso quindi anche qui non c'e' vittoria. Non c'e' una linea piu' forte.
A questo punto si vede l'esagramma futuro: c'e' una incompatibile su L3. E' un G e quella fa
vincere lo Short."
PRINCIPIO 5 — L'ESAGRAMMA FUTURO. CABLATO `MLFUTURO`, gradino `T10 l'esagramma futuro`, dopo
T9 e prima del silenzio: una linea incompatibile nel suo trigramma FUTURO parla col suo
carattere nel palazzo (G/W fanno vincere, P/B fanno perdere, C tace). Qui L2 gira, il basso
diventa 坎, L3 e' 午 in 坎, incompatibile, nel palazzo 乾 e' G -> vince il basso, SHORT.
CABLATO ANCHE `MLBESTIEUTILI`: sedi uguali -> nessuna vittoria; la forza si pesa senza le bestie
e a parita' contano solo le bestie che AIUTANO la sede (qui il 子 del giorno e dell'anno sulla
Ying 未 non la aiuta: nessuna vittoria). La regola di Claude "il nascosto si prende solo se porta
vantaggio" resta (non contraddetta), ma non decide piu' la carta.
La G su L5 legata dal nascosto 申 (巳申): notato, non serve un gradino (nessun passo la faceva
parlare).
MISURA: MLFUTURO da solo: 52,82% +16.725 (T10 5 carte, 3 giuste). Con MLBESTIEUTILI (regola di
Edu, si tiene anche se costa): **52,77% +15.842 · tace 8 · recente 54,65% · T10 7 carte 3 giuste**
· riferimento 55/55. Provato a contare le sole bestie utili nella forza di tutto il motore:
-1.600 pip, tolto.
CORREZIONE TECNICA (15/09/2026): il conteggio "solo bestie utili" non arrivava al ramo "stesso
elemento" di confrontoDiretto, e la carta si chiudeva ancora con "chi ha le bestie dal suo lato".
Sistemato: ora USDJPY 05/11/2020 si chiude in T10 come la legge Edu (L3 午 in 坎 nel futuro, G,
vince il basso). MISURA: 2783 carte · tace 5 · **52,71% +15.884** · recente 54,50% · T10 5 carte
3 giuste · T8 53 carte 43,4% · T9 13 carte 61,5% · riferimento 55/55.

## USDJPY 17/01/2024 seme 147 — LETTURA DI EDU · `CONFERMATA`
兌 Dui su 離 Li, mutante L4, palazzo 坎 (Acqua), giorno 庚辰, mese 丑, anno 卯, ora 寅, vuoti 申酉.
Shi L4 B 亥 mobile -> 申 (vuoto). Ying L1 C 卯 col giorno 庚辰 sopra. Esito LONG +92; motore SHORT
(la Terra della bestia sulla Ying controlla l'Acqua dello Shi). Claude, con tutte le strade, non
trovava LONG.
**PAROLE DI EDU:** "L4 move into void means upper trigram cannot lose"
Lo Shi e' un B, che farebbe perdere la propria squadra; muovendosi in un arrivo nel vuoto il suo
malus va nel vuoto, e il trigramma alto non puo' perdere -> LONG.
CABLATO — `MLMALUSVUOTO`, gradino `T0v il malus nel vuoto` (principio 1), dopo T0i: la sede
mobile P o B con l'arrivo nel vuoto del giorno -> la sua squadra non puo' perdere, vince.
MISURA: mazzo da 52,71% +15.884 a **52,77% +16.489** · recente 54,46% · tace 4 · il gradino da
solo **40 carte 45,0% -474** (prende carte da gradini che le leggevano peggio) · T8 50 carte 44%
· riferimento 56/56.
PERIMETRO (subito dopo): il gradino rompeva EURUSD 11/03/2022 (Edu: "L5 cannot move because of
the clash"). Differenza fra le due carte: la' il giorno clasha la PARTENZA e la linea non si muove
affatto, niente va nel vuoto; qui la linea si muove e il malus va nel vuoto. Aggiunto: il malus
va nel vuoto solo se il giorno non clasha la partenza.
MISURA: **52,80% +16.693** · recente 54,46% · tace 4 · T0v 38 carte 44,7% -399 · riferimento 56/56.

## USDCAD 16/03/2020 seme 137 — LETTA DA CLAUDE COL METODO · `CONFERMATA DA EDU`
Edu (15/09/2026): "Y P cannot retreat so it will make its own side to lose"
乾 su 乾, mutante L3, palazzo 乾 (Metallo), giorno 戊午, mese 卯, anno 子, ora 辰, vuoti 子丑.
Shi L6 P 戌 (l'ora 丙辰 sopra la clasha), Ying L3 P 辰 mobile -> 丑: vuoto, ed e' un PASSO INDIETRO.
L4 G 午 sul ramo del giorno, di stagione (alto); L2 W 寅 di stagione col mese 己卯 sopra (basso).
Esito LONG +220; il motore diceva SHORT ("il malus nel vuoto", poi "il malus retrocede").
LETTURA DI CLAUDE: la Ying e' una P che vorrebbe ritirarsi in 丑, ma 丑 e' nel vuoto, e "il vuoto
non fa retrocedere la linea" (Edu, 15/09, sulle carte 辰巳): la ritirata non avviene, la P resta
sulla Ying e fa perdere la propria squadra -> il basso perde, LONG. E in alto il G 午 sul ramo del
giorno concorda.
CABLATO — due confini, tutti e due da parole di Edu:
1) `T0v il malus nel vuoto` vale solo per il passo AVANTI: un passo indietro nel vuoto non porta
   via il malus (USDJPY 17/01/2024 era un passo avanti, 亥 -> 申).
2) `MLRITIROVUOTO` dentro T1a: il malus che retrocede in un arrivo nel vuoto non si ritira, resta
   e fa perdere la propria squadra.
MISURA: T0v da 38 carte 44,7% a 29 carte 48,3% +141 · nuovo "il malus non si ritira nel vuoto"
15 carte 53,3% +436 · mazzo da 52,80% +16.693 a **52,84% +17.587** · recente 54,33% · tace 4 ·
riferimento 57/57.
CORREZIONE DI EDU su USDCAD 16/03/2020 · `CONFERMATA` (la via di Claude era sbagliata):
"Y P can retreat because of the beast Geng Zi so it will make its own side to lose"
Il vuoto dell'arrivo 丑 e' riempito dalla bestia sulla linea: l'anno 庚子 porta il 子 che COMBINA
il 丑 (子丑合). La P quindi SI RITIRA; e la SEDE che si ritira fa perdere la propria squadra.
Differenza con NZDUSD 10/03/2020 ("a retreating P wins its side"): la' la P che si ritirava NON
era una sede (L2, clashata dal giorno) e portava via il danno; qui a ritirarsi e' la Ying stessa.
CABLATO — 1) dentro MLRITIROVUOTO: il vuoto dell'arrivo non blocca la ritirata se una bestia
sulla linea combina l'arrivo; 2) `MLSEDERITIRA` in T1a: la sede P/B che retrocede fa perdere la
propria squadra (le non-sedi restano com'erano: il malus si ritira e la loro squadra vince).
MISURA: "il malus retrocede" (non-sedi) da 53 carte 54,7% a **35 carte 60,0% +967**; "la sede
che si ritira" 18 carte 55,6% +102; mazzo **52,87% +17.321** · recente 54,46% · tace 4 ·
riferimento 57/57.
RETTIFICA (subito dopo): "la sede che si ritira perde" ROMPEVA USDJPY 01/12/2022, carta di
riferimento validata da Edu il 09/09 (la Ying P 辰 -> 丑 si ritira e fa VINCERE la sua squadra).
Stesso palazzo, stessa sede, stessa ritirata, verdetto opposto. La lettura coerente con tutte
e due: la ritirata che SI COMPIE porta via il danno (USDJPY 01/12/2022: il giorno 子 combina
l'arrivo, la linea arriva e si ferma); la ritirata BLOCCATA lascia il danno sulla sede (USDCAD
16/03/2020: il 子 dell'anno 庚子 sta SULLA linea e combina l'arrivo 丑, lo tiene: la P non si
ritira). La frase di Edu si legge quindi "Y P can[not] retreat because of the beast Geng Zi".
CABLATO — `MLBESTIATIENE` in T1a: la bestia sulla linea che porta il ramo che combina l'arrivo
tiene la ritirata; il malus resta e fa perdere. MLSEDERITIRA ritirata (=on per la misura).
MISURA: "la bestia tiene la ritirata" 3 carte (1 giusta, +158) · "il malus retrocede" 50 carte
54% · mazzo **52,77% +17.433** · recente 54,33% · riferimento 57/57. DA CONFERMARE CON EDU la
lettura "cannot".
COMPLETAMENTO DI EDU: "Scusa ho dimenticato di citare L4, la linea piu' forte." Lettura intera:
la Ying P PUO' ritirarsi perche' la bestia 庚子 sulla linea porta il 子 che combina l'arrivo 丑 e
riempie il vuoto; la ritirata si compie e porta via il danno; ma L4 G 午, sul ramo del giorno e
di stagione, e' la linea PIU' FORTE dell'esagramma, sta dall'altra parte ed e' un G: vince la sua
squadra, LONG. Coerente con USDJPY 01/12/2022 (la stessa ritirata fa vincere la sua sede, perche'
la' la piu' forte non sta dall'altra parte come G/W).
CABLATO — 1) il vuoto dell'arrivo e' riempito da una bestia sulla linea che combina l'arrivo:
la ritirata si compie (dentro MLRITIROVUOTO); 2) `MLRITIROFORTE` in T1a: il malus si ritira, ma
se la linea piu' forte dell'esagramma e' un G/W dall'altra parte, vince quella. La "bestia che
tiene la ritirata" (lettura di Claude) e' RITIRATA (MLBESTIATIENE=on per la misura).
MISURA: "la ritirata e la piu' forte" 8 carte 62,5% +149 · "il malus retrocede" 45 carte 57,8%
+1.014 · mazzo **52,87% +17.415** · recente 54,46% · tace 4 · riferimento **57/57**.

## USDJPY 31/07/2024 seme 152 — LETTA DA CLAUDE COL METODO · `DA VALIDARE`
離 Li su 坤 Kun, mutante L2, palazzo 乾 (Metallo), giorno 丙申, mese 未, anno 辰, ora 未, vuoti 辰巳.
Shi L4 B 酉 (di stagione; il mese 辛未 sopra, Terra che genera il Metallo). Ying L1 P 未 (di
stagione, ramo dell'ora; il giorno 丙申 sopra, Metallo che la drena). I due G 巳 (L6 e L2 mobile)
sono vuoti e legati dal giorno 申: nessun G/W parla. Esito SHORT -275; motore LONG (sedi uguali
Metallo contro Metallo, "le bestie stanno dalla parte dello Shi").
LETTURA DI CLAUDE: la bestia sullo Shi lo nutre — ma lo Shi e' un B: nutrire un malus ne
ingrossa il danno, e il danno fa perdere la squadra alta. La bestia sulla Ying la drena — ma la
Ying e' una P: drenare un malus lo indebolisce, e la squadra bassa ne guadagna. Il "vantaggio"
di una bestia si pesa col CARATTERE della sede. Vince la Ying, SHORT.
CABLATO — `MLBESTIECAR` dentro chiHaLeBestie (parita' in T8): per ogni bestia sulla sede,
nutrire un G/W +1, nutrire un P/B -1, drenare/controllare un P/B +1, drenare/controllare un
G/W -1; vince la sede col punteggio maggiore.
MISURA: T8 da 51 carte 45,1% -224 a **55 carte 63,6% +1.339** · mazzo da 52,87% +17.415 a
**53,21% +18.856** · recente 54,88% · tace 3 · riferimento 58/58.
CORREZIONE DI EDU su USDJPY 31/07/2024 · `CONFERMATA` (direzione uguale, via diversa da Claude):
"L2 cannot move, nothing else happens so we are at S vs Y. Y loses but the day beast comes to
rescue and move the Qi from earth to water and wins."
La Ying 未 Terra genera il Metallo del giorno 申, e il Metallo genera l'Acqua del NASCOSTO 子 sotto
la Ying: il qi si sposta sul nascosto, la Ying diventa Acqua, e il Metallo dello Shi la genera:
vince la Ying, SHORT.
CABLATO — `MLQINASCOSTO` in elDopoLeBestie: con una bestia sulla sede, se la sede genera la bestia
e la bestia genera l'elemento del nascosto, e cosi' la sede vince il confronto, la sede prende
l'elemento del nascosto (con o senza possesso). La carta ora si chiude nel duello (sede presa).
La regola di Claude `MLBESTIECAR` (vantaggio pesato col carattere) resta accesa come DA VALIDARE:
da sola Edu -> 52,91% +17.981; tutte e due -> **53,18% +18.768**, T8 52 carte 61,5% +968;
recente 54,81% · tace 3 · riferimento 59/59.
ORDINE (Edu): "La mia e' piu' elegante, fa vedere come la bestia si rende utile, quindi questa
regola dovrebbe precedere." Confermato nel codice: lo spostamento del qi sul nascosto e' il PRIMO
uso della bestia su una sede, prima del possesso, del ponte e della bestia che controlla; il
conteggio pesato col carattere (MLBESTIECAR, regola di Claude) resta solo come ultimo spareggio
quando le due sedi si equivalgono. Nessuna misura cambia (era gia' cosi' nel flusso).
EDU (15/09/2026): "La mia e' piu' elegante perche' fa vedere come la bestia si rende utile,
quindi questa regola dovrebbe precedere." ORDINE CONFERMATO nel motore: la regola di Edu
(MLQINASCOSTO, il qi che si sposta sul nascosto) agisce quando si calcolano gli elementi delle
sedi dopo le bestie, cioe' PRIMA del confronto; la regola di Claude (MLBESTIECAR, il vantaggio
pesato col carattere) interviene solo alla parita' del confronto, quando gli elementi non
decidono. La carta si chiude con la regola di Edu nel duello (T7) e non arriva alla parita'.
Principio 2 arricchito: la bestia si rende utile anche portando il qi della sede sul nascosto.

## EURGBP 17/01/2023 seme 88 — LETTA DA CLAUDE COL METODO · `DA VALIDARE`
離 Li su 坤 Kun, mutante L5, palazzo 乾 (Metallo), giorno 乙亥, mese 丑, anno 寅, ora 卯, vuoti 申酉.
Shi L4 B 酉 VUOTO (sopra l'ora 己卯: Legno che il Metallo della linea controlla). Ying L1 P 未
di stagione (sopra il giorno 乙亥). L5 P 未 mobile -> 申 vuoto: non parte. I due G 巳 rotti dal
giorno. L3 W 卯 di stagione sul ramo dell'ora (basso). Esito SHORT -90; motore LONG (lo Shi
prendeva il Legno della bestia e controllava la Terra della Ying; senza, la Terra lo nutriva).
LETTURA DI CLAUDE: la bestia sullo Shi e' un Legno che il Metallo della linea CONTROLLA: la
linea la batte, non ne prende l'elemento, e la bestia non le porta niente — quindi non toglie
neanche il vuoto. Lo Shi resta VUOTO, e una sede vuota non vince il confronto: nel duello
la Ying, piena e di stagione, e' la piu' forte. SHORT.
CABLATO — 1) `MLBESTIAGEN`: la bestia singola presta il suo elemento alla sede solo se e' in
generazione con la linea (in un verso o nell'altro), com'e' in tutte le carte di Edu; una
bestia controllata dalla linea no. 2) `MLVUOTOAIUTO` in vuotaL: la bestia toglie il vuoto solo
se si rende utile alla linea (stesso elemento, la genera, ponte, qi sul nascosto).
MISURA: mazzo da 53,18% +18.768 a **53,30% +19.363** · T8 51 carte 62,7% +1.129 · recente
54,85% · tace 4 · riferimento 59/59.
CONFERMA DI EDU su EURGBP 17/01/2023: "Se la bestia arriva su Shi la clasha e il movimento la
porta su Ying. Quindi sia che rimane vuota o che sia clashata il risultato e' lo stesso. Vince lo
Short." La bestia dell'ora 卯 CLASHA il 酉 dello Shi (卯酉): la linea ferma clashata dalla bestia
avanza di un ramo (酉 -> 戌, Terra), cioe' lo stesso elemento della Ying 未: il movimento porta lo
Shi sulla Ying. Vuoto o clashato, lo Shi non vince: SHORT. Il motore chiude per la via del vuoto;
la via del clash coincide. Le due letture di Claude su questa carta (bestia controllata non
presta, non riempie) restano DA VALIDARE come regola generale, confermate nell'esito.

# S47 · 16/09/2026 — CHIUSURA: IL MOTORE DI LETTURA ENTRA NELL'APP
NZDUSD 15/09/2026 dal vivo (seme 57, 艮 su 乾, mutante L1, giorno 壬辰, mese 酉, anno 午): l'app
diceva LONG, il mercato SHORT. Ricostruita da data e seme: PB "NON SEGUE" -> SHORT; motore di
lettura SHORT (T0w, la W di L1 arriva sul ramo dello Shi 寅 con L3 辰 incompatibile che gira
insieme e va nel vuoto 午); la lettura vecchia (sola L1, giorno sulla B di L3) dava LONG.
Edu: "Quindi fai i tre zip e inserisci nell'app tutte le modifiche!"
FATTO: motore_lettura.js entra nella PWA (index.html, sw.js v60); app.js mostra la voce
"Lettura S47" nel report e il riquadro col racconto nel pannello. Voce MOSTRATA, NON CONTATA
nella scala (parità 0 differenze invariata) finché non è misurata dentro la scala.
STATO FINALE S47: motore di lettura 2.784 carte · tace 4 · 53,30% · +19.363 · recente 54,85%;
basi LY/DLR/guida/parità invariate; 59 carte di riferimento 59/59.

---

# S48 — 16/09/2026 · La scala torna A/B/C, con la Lettura S47 come livello D

## Basi verificate all'avvio (tutte esatte)
Liu Yao S17 2.788 · 58,54% · z 9,01 · 35.016 pip · motore DLR 3.253 lette · tace 18 · fuori 204 ·
60,81% · z 12,33 · 41.467 · carte guida 78/110 · parità 0 · motore di lettura 2.784 · tace 4 ·
53,30% · +19.363 · recente 54,85% · carte di riferimento 59/59.

## CONFRONTO DELLE SCALE (chiesto da Edu il 16/09/2026) — sui sei anni, 3.180 carte, |move| > 20
Dump TRESIST (`TRESIST=1 SOGLIAPIP=20 TRESISTDUMP=/tmp/tresist.json` + base canonica); la Lettura S47
da `MOTORE=lettura PRINCIPI=1 DUMPGRAD="*"` sugli stessi flag (adesso e' nel dump come campo `lett`).
"dal 2024" = carte dal 01/01/2024 (1.367).

| modo | trade | giusti | pip | dal 2024 | giusti | pip |
|---|---|---|---|---|---|---|
| 1 A/B/C originale | 1.672 | 68,1% | +38.481 | 702 | 67,2% | +15.552 |
| · A PB+LY+DLR | 820 | 70,9% | +20.998 | 338 | 71,0% | +8.909 |
| · B attuale+DLR | 759 | 64,8% | +15.460 | 331 | 63,7% | +5.885 |
| · C PB+LY, DLR muto | 93 | 69,9% | +2.023 | 33 | 63,6% | +758 |
| 2 Lettura S47 al posto del LY | 1.958 | 66,5% | +42.179 | 823 | 66,6% | +17.842 |
| · A PB+Lett+DLR | 721 | 68,0% | +18.260 | 305 | 69,8% | +8.445 |
| (con la Lettura anche nel B: 1.573 · 64,7% · +31.006) | | | | | | |
| 3 Lettura S47 accanto al LY (A = PB+LY+DLR+Lett) | 1.672 | 68,1% | +38.481 | 702 | 67,2% | +15.552 |
| · A a quattro | 414 | 74,2% | +13.500 | 177 | 74,6% | +5.801 |
| · A senza la Lettura (cade nel B) | 406 | 67,5% | +7.498 | | | |
| 4 solo DLR e Lettura S47 concordi | 1.469 | 64,7% | +29.248 | 631 | 66,7% | +13.937 |
| sei voci (app fino a oggi) | 2.719 | 61,5% | +45.220 | | recente(23-26) 59,3% | |
| ferme dell'ABC: DLR contro PB+LY concordi | 744 | 49,1% | +3.736 | | | |

Seconda domanda di Edu ("il LY vecchio prima, S47 sulle carte che non rispondono"): il LY tace su 16
carte su 3.180, quindi letto come "A/B/C prima, la Lettura sulle 1.507 carte ferme":

| sulle ferme | trade totali | giusti | pip | dal 2024 | giusti | pip |
|---|---|---|---|---|---|---|
| DLR e Lettura concordi (653 · 57,6% · +5.720) | 2.325 | 65,1% | +44.201 | 977 | 65,9% | +19.305 |
| PB e Lettura concordi (329 · 58,7%) | 2.001 | 66,5% | +42.935 | 837 | 66,4% | +18.001 |
| la Lettura da sola (1.507 · 53,4%) | 3.179 | 61,1% | +47.281 | 1.367 | 61,6% | +20.462 |

Dentro le ferme: Lettura col DLR 653 al 57,6%; Lettura contro il DLR nei contrasti a due 350 al 43,4%.

## SCELTA DI EDU (16/09/2026): "Certo, S47 col DLR per tutte le altre" — `IN PRODUZIONE`
Scala A → B → C → D: A, B, C come al 05/09/2026; **D = su tutte le carte che A/B/C lasciano
ferme, motore DLR e Lettura S47 concordi** (compresa la casella dove il DLR contrasta PB+LY concordi:
351 carte al 57,0%, dal 2024 63,0%). Le voci Spirito e stelo del giorno restano mostrate ma non
contano piu'. Cablata in `app.js` (`livelloTreSistemi`, nota del report, badge, conteggi), in
`index.html` (bottone "Scala A/B/C/D"), in `pb_stress.js` (TRESIST: `lett` nel dump, righe Z-D,
Z-D+/Z-D-, Z-Dy/Z-Dn, Z-TOT48; la vecchia riga Z-D delle forme escluse e' ora Z-Dvecchio) e in
`parita_tre.js` (livBT, confronto anche sulla Lettura). `sw.js` cache v61.
Misura: Z-TOT48 2.325 · 65,12% · z 14,58 · +44.200 · vecchio 64,83% · recente 65,73%.
Parità: 455 carte · 0 differenze su pb, ly, attuale, dlr, lettura, livello, direzione.
Nota: la sezione "CONFRONTO DELLE SCALE" di S47 citata dalla ripartenza NON era nell'archivio
(ultima copia del registro delle 01:22 del 16/09): il confronto e' stato rifatto qui, e le cifre di
controllo di S47 (ABC 1.672 · 68,1% · +38.481; sei voci 2.719 · 61,5%) tornano identiche.

## S48 · LE INCOMPATIBILI NELLA CATENA (Edu, 16/09/2026: "Fallo ora") — `FERMATO ALLE CARTE GUIDA`
Motivo: NZDUSD 15/09/2026 seme 57, persa dalla catena perche' non ha le incompatibili (la Lettura
S47 la legge SHORT con L3 incompatibile che gira insieme alla mobile L1).
Archivio consultato prima: la catena ha gia' §109 (incompatibile in ultima istanza), §128 (Shi/Ying
incompatibile perde il duello) e il caso -5 (arrivo incompatibile col futuro); NON ha la dottrina
di S45 (ferma incompatibile diventa mobile; mobile incompatibile non si ferma; futuro comune), che
sta solo in motore_lettura.js.
PRIMO PASSO cablato in liuyao.js (`build`, interruttore INCFUTURO): la ferma incompatibile (sei
coppie, ponte sui quattro rami, freno delle due combinazioni) gira INSIEME alla mobile e l'arrivo
della mobile viene dal futuro comune; la carta espone `incompatibili` (posizioni).
MISURA: S17 da 58,54% (+35.016) a 57,32% (+29.652); carte guida da 78 a 74 giuste. Cambiano
verdetto SEI letture certificate da Edu, tutte fatte in agosto senza le incompatibili:
NZDUSD 22/06/2023 s62 · NZDUSD 15/06/2022 · USDJPY 29/11/2024 s151 · USDJPY 16/10/2024 s149 ·
USDJPY 06/11/2024 s151 (+320: L3 申 in 艮 gira con la mobile L2, che arriva in 辰 invece che in 亥)
· USDJPY 09/12/2024 s149. Due carte guida si raddrizzano (USDJPY 25/07/2023, EURGBP 20/03/2026).
Regola: dopo ogni modifica al LY si rifanno le carte guida e ci si ferma se una cambia verdetto.
FERMATO: INCFUTURO spento per default, basi invariate. Da portare a Edu: le sei carte guida, una
alla volta — sono sue letture, decide lui se restano valide con le incompatibili.

## S48 · USDJPY 06/11/2024 seme 151 RILETTA DA EDU CON LE INCOMPATIBILI · `CONFERMATA` — e la difesa del Tai Sui `ABOLITA`
Prima carta guida delle sei che cambiavano verdetto con INCFUTURO. Edu ha chiesto conferma del mese
(vicino a 立冬): verificato, 立冬 cade il 06/11/2024 alle 22:20 GMT, la carta delle 00:00 GMT e' nel mese 戌.
Parole di Edu: "L3 moves to control back. L2 moves and bring the winner line to L4. Long".
Trovata nella carta: L3 = Shi, B 申 (vuota), incompatibile in 艮 -> si muove; girando con L2 il
trigramma inferiore diventa 坎 e L3 arriva in 午: il Fuoco controlla indietro il Metallo, il B della
Shi e' abbattuto. L2 = G 午, arriva in 亥 = il ramo di L4: la linea vincente e' portata su L4, l'alto
vince -> LONG (+320).
PUNTO APERTO (chiesto a Edu, non risposto): l'arrivo 亥 di L2 e' quello della mobile che gira DA SOLA
(艮->巽); con le due linee girate insieme L2 andrebbe in 辰. Su GBPUSD 02/08/2022 Edu aveva letto la
Shi 丑 -> 亥, che viene dal futuro comune. Da chiarire se la mobile tiene il proprio arrivo e solo
l'incompatibile prende il futuro comune. Misura nel motore di lettura: FUTURO=seconde (mobile da
sola) 52,98% e rompe 5 carte di riferimento (GBPUSD 02/08/2022, USDJPY 02/08/2022, USDJPY 13/09/2022,
USDJPY 05/12/2022, USDJPY 13/02/2024); FUTURO=insieme resta il default (53,30%, 59/59).
Conseguenza per INCFUTURO in liuyao.js: cambiava l'ARRIVO della mobile, e per questo rompeva le
carte guida; da rifare come "solo l'incompatibile si muove", resta spento.

**REGOLA ABOLITA DA EDU (16/09/2026): "L1 non puo' essere clashata perche' il Tai Sui la difende"**
(cablata il 31/08/2026 proprio su questa carta, `clashSu` in liuyao.js). Sostituita da due principi:
1) le bestie si usano DOPO che il movimento delle linee non produce un effetto chiaro;
2) e anche quando si usano, lo fanno per aiutare la lettura a trovare una direzione chiara e razionale.
Cablato: difesa spenta per default (TSDIFENDE=1 per la misura). Misura: S17 da 58,54% (+35.016) a
58,46% (+34.850, -166 pip); carte guida 78/110 invariate, nessun verdetto cambia (la guida resta
LONG per §62); motore di lettura da 53,30% a 53,34%. Tenuta perche' regola di Edu.

**RISCRITTURA DI EDU (16/09/2026) — la lettura giusta di USDJPY 06/11/2024, `CONFERMATA`**
Parole di Edu: "una linea incompatibile puo' controllare indietro ma non puo' rimanere in quel trigramma
quindi dopo aver controllato indietro comunque si muove in avanti e cerca qualcosa da fare. Qui si combina
con Y portando la G w la' sopra su Y. L2 invece puo' muoversi perche' il clash contro il Tai Sui non annulla
o blocca la linea ma la spinge in avanti, quindi per effetto scala G w arriva su L1 che e' ancora clashato
in avanti per diventare Yin e combinarsi con L4. Risultato: il trigramma superiore riceve due winner G w"
-> il basso, che le cede, perde -> LONG (+320).
Precisazione di Edu: "G w capita dentro il trigramma futuro Kan quindi questo e' un altro motivo per cui e'
spinta in avanti e non puo' rimanere li'" — 午 dentro 坎 e' esso stesso una coppia incompatibile.
GLI ARRIVI SONO QUELLI DEL FUTURO COMUNE (L2 e L3 girate insieme, 艮 -> 坎: L1 寅, L2 辰, L3 午): chiude il
punto aperto sopra, la mobile NON tiene l'arrivo "da sola". Il 亥 di L2 era un errore di Claude.
Meccaniche nuove per il motore di lettura (principio 1, le linee mobili), DA CABLARE:
 1. l'incompatibile che controlla indietro non si ferma: va avanti (anche perche' arriva in un trigramma dove
    e' di nuovo incompatibile) e combina; il carattere che ha addosso dopo il controllo indietro va sulla
    linea combinata (qui il G su 未 = Ying);
 2. l'arrivo clashato dal giorno sul ramo del Tai Sui non e' bloccato: effetto scala, la linea vincente scende
    sulla linea con quel ramo (L1 辰), che avanza al proprio ramo futuro (寅) e combina (寅亥 -> L4).
CABLATO — `MLPORTATE`, gradino "T0x le vincenti portate", PRIMA del vecchio effetto scala (T0s, di
Claude, che dava LONG per un'altra strada: la lettura di Edu precede). Due portate: a) la seconda
(incompatibile) il cui arrivo controlla indietro la partenza ed e' G/W nel palazzo combina con la
linea che porta il ramo combinato; b) la mobile G/W il cui arrivo e' il ramo del Tai Sui clashato dal
giorno scende sulla linea con quel ramo, che avanza al proprio ramo del futuro comune e combina.
Se tutte le linee raggiunte stanno nello stesso trigramma, quel trigramma vince. Perimetro stretto
come sulla carta: servono entrambe (1 carta, +320). Il motore rifa' la lettura di Edu passo per passo.
Mazzo 53,34% (+19.417); carte di riferimento 60/60 (aggiunta USDJPY 06/11/2024).
ESTENSIONE DI CLAUDE, spenta: `MLPORTATE=una` (basta una portata) -> 12 carte, 9 giuste (+664),
mazzo 53,38%. Da validare da Edu prima di accenderla.
VALIDATA DA EDU (16/09/2026): "Puoi accenderla. E' frequente che in una lettura ci siano piu' motivi
attraverso cui si ottiene un risultato positivo" -> basta una portata: ACCESA per default
(MLPORTATE=due per il perimetro stretto). Misura: 12 carte, 9 giuste, +664; mazzo 53,38% (+19.492);
carte di riferimento 60/60.

## S48 · NZDUSD 22/06/2023 seme 62 RILETTA DA EDU CON LE INCOMPATIBILI · `CONFERMATA`
Seconda delle sei carte guida. Lettura di agosto (padrone del giorno + duello per generazione):
SHORT, giusta. Con le incompatibili L3 (B 午 in 坎) gira insieme a L1: 坎 -> 乾, L1 -> 子, L3 -> 辰.
Claude aveva letto: la Ying vuota e combinata dal giorno non parte, il movimento non decide, la
lettura di agosto regge. Edu ha risposto con un'altra via:
Parole di Edu: "L3 moves into an healthy C which cannot stay in Qian and have to scale down to L2.
L1 at Y cannot change into G Zi because of the day combining but it's awake out of the void. Then
Y controls S and wins."
-> 1) l'arrivo 辰 di L3 (C sano) e' a sua volta incompatibile dentro 乾: non puo' restarci e SCENDE
sulla linea che porta 辰 (L2, gia' un C: non decide); 2) la Ying P 寅, vuota, con la partenza
combinata dal giorno 亥 non puo' trasformarsi nel G 子, ma LA COMBINAZIONE LA SVEGLIA DAL VUOTO:
e' piena e porta il Legno; 3) il Legno della Ying controlla la Terra dello Shi 戌: la Ying vince
-> SHORT (esito SHORT -27).
Principio nuovo: la combinazione del giorno sulla partenza di una sede vuota non la lascia inerte
(come diceva la lettura di agosto): la sveglia. Poi si confronta con l'altra sede per controllo.
CABLATO — `MLSVEGLIACOMB`, gradino "T0a la sede svegliata dalla combinazione", subito dopo T0x.
Perimetro: sede mobile, partenza vuota e combinata dal giorno; la seconda incompatibile che scende e'
raccontata (non decide); confronto per controllo con l'altra sede, altrimenti si prosegue.
Misura: 9 carte, 5 giuste (-30 pip); mazzo da 53,38% a 53,41% (+19.488); riferimento 61/61.
Le quattro storte: EURUSD 22/04/2026 s117, GBPUSD 19/12/2023 s126, USDCHF 16/05/2024 s90,
NZDUSD 19/12/2023 s62 (stessa carta della guida, sei mesi dopo).
PRECISAZIONE DI EDU (16/09/2026): "Non e' la combinazione che la sveglia, e' il fatto che e' comunque
una linea mobile. E' come un treno in partenza, subisce un ritardo ma ha comunque i motori accesi."
-> il vuoto della partenza non e' la condizione (la mobile non e' mai vuota, 動不為空). Gradino
rinominato "T0a la sede in ritardo": sede mobile con la partenza combinata dal giorno -> non si
trasforma, ma e' viva col proprio elemento; confronto per controllo con l'altra sede.
Misura senza la condizione del vuoto: 40 carte, 19 giuste (47,5%, -463 pip); mazzo pero' da 53,41%
a 53,52% (+19.762), perche' quelle carte prima erano lette peggio dai gradini successivi.
Riferimento 61/61. Tenuto come detto da Edu (MLSVEGLIACOMB=vuota per il perimetro stretto: 9 carte,
5 giuste). Da riguardare: nelle 21 storte il confronto per controllo con l'altra sede non basta.
VERIFICA CHIESTA DA EDU (16/09/2026: "Si usa se non c'e' nient'altro da leggere. Hai fatto la stessa
verifica?"): no, non era fatta. Aggiunta: la sede in ritardo agisce sull'altra sede solo se nessuna
seconda (incompatibile) ha un arrivo vivo (fuori dal vuoto e non a sua volta incompatibile col futuro);
altrimenti il ritardo resta raccontato e si prosegue. Misura: 27 carte, 11 giuste (40,7%, -616);
mazzo 53,45% (+19.394). Senza la verifica (MLSVEGLIACOMB=subito): 40 carte, 19 giuste, mazzo 53,52%.
Le 13 carte in cui c'e' altro da leggere erano 8 giuste su 13: la verifica NON spiega le storte.
Tenuta la forma con la verifica (e' il principio di Edu); riferimento 61/61. Le 16 storte restano
da guardare una per una.

## S48 · LE TRE GEMELLE NZDUSD (seme 62, 艮 su 坎, mobile L1, giorno 亥) — LETTURA DI CLAUDE · `DA VALIDARE`
Rimprovero di Edu (16/09/2026): "Continui ad evitare di pensare, a procedere per raccolta dati, test di
soluzioni e scelta della via che da' risultati." Quindi: le carte, pensate.
Le tre carte: 22/06/2023 (giorno 辛亥, mese 午, anno 卯, vuoti 寅卯) esito SHORT -27, letta da Edu;
15/06/2022 (giorno 己亥, mese 午, anno 寅, vuoti 辰巳) esito LONG +60 = carta guida 3;
19/12/2023 (giorno 辛亥, mese 子, anno 卯, vuoti 寅卯) esito LONG +57.
In tutte e tre la Ying P 寅 e' in ritardo (il giorno 亥 combina la partenza) e viva; L3 B 午 e'
incompatibile e vuole andare in 辰. Cosa cambia:
- 22/06/2023: 辰 e' sano, il B se ne va e scende su L2 come C; il mese 午 restava su L3 ma la linea
  e' partita; non c'e' altro; la Ying controlla lo Shi -> SHORT.
- 15/06/2022: 辰 e' VUOTO, il B va nel vuoto e RESTA su L3, seduto sul ramo del mese 午: la linea
  piu' forte dell'esagramma e' un B nel trigramma basso, che fa perdere la propria squadra -> LONG.
- 19/12/2023: il mese 子 siede su L5, G, in alto: il G piu' forte fa vincere l'alto -> LONG.
Principio proposto: la linea seduta sul ramo del mese, se resta (non si muove via), e' la piu' forte
e col suo carattere decide PRIMA del controllo della sede in ritardo, che e' una P e vale poco.
Cablato dietro `MLRITARDOMESE=on` dentro T0a: le tre gemelle tornano tutte giuste, ma sul mazzo la
linea sul mese decide 25 carte al 40% (-262) e il gradino intero scende: SPENTO, dichiarato di Claude,
in attesa di Edu. Con MLRITARDOMESE spento il mazzo torna a 53,45%.

## S48 · IL MOVIMENTO DELLE LINEE — DOTTRINA DETTATA DA EDU (16/09/2026) · `PRINCIPIO 1, DA CABLARE`
Parole di Edu (testuali):
"Se una linea si muove per andare nel vuoto si invalida l'intera linea, non solo l'arrivo. E' come un
treno che parte e si ferma in mezzo alla campagna.
Se una linea si muove ma il suo arrivo e' clashato o combinato, solo l'arrivo e' annullato ma la
partenza e' ancora attiva. E' come un treno che ha la tabella di marcia modificata.
Se una linea mobile viene clashata o combinata alla partenza non parte proprio e non si puo' usare.
Se una linea vuota e' mobile e viene clashata o combinata alla partenza non parte ma rimane attiva,
si puo' usare.
Eccezioni alla regola di cui sopra sono il Tai Sui e le incompatibili.
Le incompatibili non possono rimanere nel trigramma incompatibile con loro, si muovono comunque.
Tai Sui: un TS clashato alla partenza o all'arrivo puo' muoversi. Se combinato non puo'.
Le bestie possono intervenire ad aiutare il movimento anche quando la linea non potrebbe muoversi
ma devono essere compatibili con la linea (o stesso elemento, o drenano o generano). Se controllano
o clashano si impadroniscono della linea ma solo se questo serve a trovare una soluzione!"
Correzione implicita: "la sede in ritardo" (T0a) vale solo per la mobile VUOTA combinata alla
partenza (NZDUSD 22/06/2023: la Ying 寅 era nei vuoti 寅卯); la mobile piena combinata alla partenza
non parte e non si usa. Il vuoto quindi c'entra, ma al contrario di come lo avevo cablato prima.
CABLATO (16/09/2026, "Cabla e misura") — `MLSTATOMOV`, gradino "T0m lo stato del movimento", dopo le
guerre e prima delle bestie: arrivo nel vuoto -> linea invalidata (annullata); partenza clashata o
combinata dal giorno -> non parte (vuota: attiva, va a T0a; piena: inusabile, annullata); arrivo
toccato -> solo l'arrivo; Tai Sui e incompatibili come dettato. Conclusione aggiunta da Claude: se la
sede mobile e' fuori uso e nessuna seconda resta viva, "resta in piedi solo l'altra sede" (chi non
vince perde). Le bestie che aiutano il movimento NON cablate.
MISURA: mazzo da 53,45% (+19.394) a 53,31% (+15.931); "resta solo l'altra sede" 137 carte al 48,9%;
NZDUSD 15/06/2022 giusta (aggiunta ai riferimenti, 62). MA OTTO carte di riferimento lette da Edu
cambiano verdetto: USDCHF 28/02/2022 (Edu: "Y cannot advance and yet Yin is the strongest line... Y
controls S" — la Ying B 寅 va nel vuoto 卯 e per Edu RESTA in piedi, non e' invalidata); USDJPY
05/12/2022 (Edu: "L4 goes into void... Ying: beasts help" — la linea nel vuoto resta, le bestie
aiutano); EURUSD 17/06/2026 (Edu: il giorno 戌 clasha la partenza 辰 del G e la SVEGLIA, 暗動 — non
"non parte e non si usa"); USDJPY 17/01/2024 (Edu: "L4 move into void means upper trigram cannot
lose" — il B nel vuoto porta via il danno, non invalida la sede); USDJPY 02/10/2024; NZDUSD 10/03/2020;
EURJPY 10/08/2023; EURJPY 15/08/2024. Fermato: MLSTATOMOV SPENTO, mazzo torna a 53,45%, riferimento
62/62 con la carta di oggi ancora storta per il motore (T0a). Da chiarire con Edu: la linea che va nel
vuoto e' invalidata sempre, o resta in piedi come sede (28/02/2022, 17/01/2024)?
SECONDA PASSATA (16/09/2026), dopo USDCHF 28/02/2022 (Edu: "se la linea e' super-timely e avanza lo fa
lo stesso!"): cablata l'eccezione (linea in stagione sul ramo del mese o dell'anno che AVANZA verso un
arrivo vuoto: si muove); cablate le bestie compatibili che aiutano la linea ferma alla partenza (resta
in gioco col proprio carattere, EURUSD 17/06/2026); tolta la conclusione precoce "resta solo l'altra
sede" (T0m fissa solo lo stato, concludono i gradini che seguono). Con T0m acceso: mazzo 53,36%
(+15.535, tace 24), riferimento 55/62 — restano storte per il motore EURUSD 11/03/2022, USDJPY
05/12/2022, USDJPY 17/01/2024, USDJPY 02/10/2024, NZDUSD 10/03/2020, EURJPY 10/08/2023, EURJPY
15/08/2024: in tutte, la linea che oggi verrebbe invalidata o resa inusabile era stata USATA da Edu
(quasi sempre con le bestie che la aiutano o che riempiono il vuoto). T0m resta SPENTO (MLSTATOMOV=on);
con T0m spento riferimento 62/62 ma NZDUSD 15/06/2022 storta per il motore (LONG via T0t? vedi sotto).
Prossimo passo: portare a Edu quelle sette carte una alla volta, e cablare la parte delle bestie che
aiutano il movimento nel modo che dira' lui.
TERZA PASSATA (16/09/2026) — Edu: "Tutte e tre giuste. Si', se la bestia combina con una linea vuota e
farla uscire dal vuoto aiuterebbe a trovare una soluzione (qualsiasi) allora fa uscire dal vuoto."
Cablato in T0m, e ogni pezzo viene da una lettura di Edu, non da una misura:
 1. bestie che aiutano: nel vuoto la linea arriva se sopra c'e' una bestia compatibile (stesso elemento,
    la genera, o la linea la genera = drena) o il cui ramo combina l'arrivo (USDCAD 16/03/2020); piena e
    toccata alla partenza: con bestia compatibile si muove lo stesso. Vale la definizione del 16/09
    (drena compresa), piu' larga di quella dell'11/09 usata per Q.agisce (EURJPY 15/08/2024: 巳 sopra 卯);
 2. ordine: prima la partenza — se non parte non va nel vuoto; la piena ferma alla partenza che il mese
    genera o sostiene sopravvive (EURUSD 11/03/2022: "still survive as the month generate it");
 3. l'arrivo penalizzato dalla data muore anche se vuoto: la linea resta se' stessa (NZDUSD 10/03/2020);
 4. la linea spinta da una seconda che arriva sulla sua partenza non si ferma nel vuoto (effetto scala,
    USDJPY 02/10/2024);
 5. la sede invalidata nel vuoto e' il malus che se ne va: T0v resta valido (USDJPY 17/01/2024);
 6. col futuro comune il ritorno che nutre (回頭生) si ricalcola sull'arrivo vero, e la mobile nutrita
    "non puo' fare altro": niente porte con l'arrivo (USDJPY 05/12/2022: "L1 moves to generate back";
    ora il motore rifa' la lettura di Edu: la Ying con l'Acqua batte lo Shi col Fuoco -> LONG);
 7. la superTimely che avanza nel vuoto si muove (USDCHF 28/02/2022).
T0m ACCESO per default (MLSTATOMOV=off spegne). Misura: mazzo 53,54% (+19.378, tace 16), recente 54,66%;
carte di riferimento 62/62; scala A/B/C/D 2.308 trade 65,34% +44.419 (livello D 638 al 58,3%, dal 2024
62,2%); parita' 0. NZDUSD 15/06/2022 giusta ma per T0t (il B del trigramma alto genera la C), non per
"resta in piedi solo lo Shi": la conclusione "resta solo l'altra sede" e' spenta (MLSTATOMOVFINE=on).

## S48 (16/09/2026) · L'APP MOSTRA SOLO LA SCALA A/B/C/D · `CONFERMATA DA EDU`
Edu, dal vivo: il Report giornaliero (regola del 28/08) e la scala davano liste diverse (4 contro i cross
della scala); i nove bottoni dei cross e i pannelli Plum Blossom / Da Liu Ren "portano solo confusione".
Rifatta la pagina: all'apertura carica il feed delle 00:00 GMT e mostra subito "Da tradare oggi" con la
scala A/B/C/D; un solo bottone, "Aggiorna". I fermi stanno chiusi sotto un dettaglio a tocco. Tutto il
resto (controlli, bottoni dei cross, PB/DLR, carta) e' in `#avanzato`, nascosto; `localStorage AVANZATO=1`
lo riaccende per il lavoro di sviluppo. Il Report giornaliero non ha piu' un bottone. Nessuna logica di
lettura toccata: parita' 455 carte, 0 differenze. sw.js cache v62.

## S49 (16/09/2026) · USDJPY 02/07/2026 seme 162 · IL TRIGONO CHIUSO DALLA RITIRATA GENERA L'ALTRA SEDE · `CONFERMATA DA EDU`
Carta di livello A (PB, LY, DLR tutti LONG; Lettura S47 LONG), esito SHORT -143. Palazzo 兌 Dui (Metallo),
震 sopra 兌, mutante L2. Giorno 丁丑, mese 甲午, anno 丙午, ora 乙巳, vuoti 申酉. Shi L3 P 丑, Ying L6 P 戌.
L2 W 卯 incompatibile in 兌 (unica), retrocede in 寅. Giorno e anno cadono su L1 G 巳, mese e ora sulla Ying.
Il Liu Yao vecchio (R5, la mobile che retrocede senza clash dell'anno) e il motore di lettura (T1a, il
vantaggio che retrocede fa perdere la propria sede) davano LONG.
Lettura di Claude portata a Edu: la ritirata non porta via niente, perche' l'arrivo 寅 chiude con 午 (mese
e anno) e 戌 (Ying) il trigono di Fuoco, di stagione; il trigono serve il Fuoco, cioe' i G; L4 G 午 in
autopenalita' col 午 di mese e anno; L1 G 巳 con gli steli di Fuoco di giorno e anno e' il G piu' forte, in
basso -> SHORT.
Edu: "Sono d'accordo con te con l'unica variante che il trigono di fuoco che si forma sulla Y (con l'aiuto
di y mobile) va a generare S che vince". Cioe': non passa per L1, il trigono si forma sulla Ying e il
Fuoco genera la Terra dello Shi 丑, che vince -> SHORT.
Principio a cui si aggancia: 1, le linee mobili (la ritirata della mobile e cosa fa il suo arrivo).
Cablato come `MLRITIROTRIG` dentro T1a, prima del "vantaggio retrocede". Perimetro stretto, quello della
carta: G/W mobile non sede che retrocede; l'arrivo non vuoto chiude un trigono intero col ramo di una sede
non vuota e un terzo membro non vuoto fra i rami della data o le linee; elemento del trigono di stagione;
il trigono GENERA l'elemento dell'altra sede -> vince l'altra sede. Se non genera, la regola non si
pronuncia (nessuna estensione). MLRITIROTRIG=off spegne.
Misura: gradino 1 carta (questa); "il vantaggio retrocede" da 55 carte 49,1% a 54 carte 50,0%; mazzo da
53,54% (+19.378) a 53,57% (+19.663); carte di riferimento 63/63 (aggiunta questa); scala A/B/C/D invariata
(carta di livello A, decisa dal Liu Yao vecchio); parita' 455 carte, 0 differenze.
Punto aperto: nella scala dell'app la carta resta LONG perche' il livello A la legge col Liu Yao vecchio,
dove la via della mobile che retrocede non conosce il trigono.
PORTATA NEL LIU YAO VECCHIO (Edu, 16/09/2026: "Si controlla"). Stessa regola e stesso perimetro dentro la via
della mobile che retrocede (R5), prima del suo verdetto; RITIROTRIG=off spegne.
Controllo: carte guida 110 · 78 giuste · 32 storte identiche a prima (nessuna cambia verdetto).
Misura: S17 da 58,46% (z 8,94, +34.850) a 58,50% (z 8,98, +35.135) — cambia solo questa carta.
Scala: la carta non e' piu' di livello A (PB LONG, LY SHORT, DLR LONG) e resta ferma; Z-TOT A+B+C 1.669 ·
68,06% · +38.538; Z-TOT48 A/B/C/D 2.307 · 65,37% · +44.561; livello D invariato 638 · 58,31%.
Parita' 455 carte, 0 differenze su pb, ly, attuale, dlr, lettura, livello, direzione.

## S49 (16/09/2026) · EURJPY 17/06/2026 seme 186 · LA BESTIA TOGLIE LO SHI DAL VUOTO · `INDICATA DA EDU`
Carta di livello D (DLR e Lettura S47 LONG; PB e LY vecchio SHORT), esito SHORT -157. Palazzo 艮 Gen (Terra),
艮 sopra 兌, mutante L2 G 卯 incompatibile in 兌 che retrocede in 寅. Giorno 壬戌, mese 甲午, anno 丙午, ora 乙巳,
vuoti 子丑. Shi L3 B 丑 (vuota), Ying L6 G 寅. Il giorno cade su L1, mese e ora su L2, l'anno sullo Shi.
Stessa struttura della seme 162, ma MLRITIROTRIG taceva: la Ying porta lo stesso ramo dell'arrivo e lo Shi e'
vuoto. Claude aveva portato la lettura (trigono di Fuoco sulla Ying, aiutato dalla mobile, genera lo Shi ->
SHORT) col dubbio dello Shi vuoto e penalizzato dal giorno 戌.
Edu: "La bestia non arriva su Shi, la genera e la fa uscire dal vuoto?" — l'anno 丙午 cade sullo Shi con la
sua bestia, il 午 Fuoco genera il 丑 Terra: la linea non e' vuota. E' la regola di Edu dell'11/09 ("quando
arriva una bestia su una linea non ci sono piu' vuoti", EURJPY 10/08/2023) con la condizione di Claude che la
bestia aiuti la linea (stesso elemento o la genera): questa carta ne e' un esempio. Errore di Claude: ha
guardato il vuoto del giorno senza passare dalle bestie sulla sede.
Cablato in MLRITIROTRIG: il vuoto delle due sedi si legge con vuotaL (bestie comprese); la sede generata deve
essere piena; la sede su cui si forma il trigono puo' portare lo stesso ramo dell'arrivo (la mobile la aiuta).
Misura: gradino 3 carte, 3 giuste, +341 (seme 162, seme 186, e NZDUSD 23/07/2026 seme 58 +41); "il vantaggio
retrocede" 52 carte 51,9%; mazzo 53,64% (+20.060); riferimento 64/64; scala A/B/C/D 2.307 · 65,41% · +44.760,
livello D 638 · 58,46%; parita' 0. Liu Yao vecchio non toccato (su questa carta diceva gia' SHORT).

## S49 (16/09/2026) · NZDUSD 05/06/2026 seme 58 · DECIDE LA YING VUOTA · `LETTA DA EDU`
Carta di livello D (DLR e Lettura S47 LONG; LY vecchio SHORT), esito SHORT -72. Palazzo 艮 Gen, 艮 sopra 兌,
mutante L2 G 卯 incompatibile in 兌 che retrocede in 寅, nel vuoto. Giorno 庚戌, mese 癸巳 (芒种 entra alle 15:48
GMT del 05/06: alle 00:00 GMT comanda ancora 巳), anno 丙午, ora 乙酉, vuoti 寅卯. Shi L3 B 丑 (sopra l'ora 乙酉),
Ying L6 G 寅 vuota senza bestie; mese su L2, anno su L4, giorno su L1.
Claude aveva proposto il trigono di Fuoco su L4 che genera lo Shi, e aveva scritto per errore che sullo Shi
cade il mese: corretto passando pilastro -> stelo -> bestia -> linea (sullo Shi cade l'ora).
Edu: "Non c'e' bisogno del trigono. Y e' vuoto e non c'e' niente che lo salvi. L2 arriva sul vuoto e si puo'
cancellare l'importanza dell'intera linea. Su S arriva la bestia del mese. Vince lo short." Dopo la
correzione del mese: "Gui Si arriva su L2. Gui acqua da' un po' di energia al legno e Si usa il legno per
generare Shi. Vince. Comunque quello che decide e' Y vuoto."
E' la regola di Edu del 29/08/2026 ("se Shi o Ying sono vuoti [...] fa perdere immediatamente la parte
vuota"), gia' a registro. Principio 1 (la mobile nel vuoto si cancella) che lascia il posto al 3 (le sedi).
Cablato come `MLRITIROVUOTASEDE` in T1a, prima del trigono della ritirata. Perimetro della carta: G/W mobile
non sede che retrocede in un arrivo nel vuoto del giorno; una sede vuota che nessuna bestia salva (vuotaL),
l'altra piena -> vince la piena. MLRITIROVUOTASEDE=off spegne.
Misura: gradino 2 carte, 1 giusta (questa, +72) e 1 storta: EURJPY 29/07/2026 seme 186 (-73; stessa carta,
giorno 甲辰 che clasha L4 戌, mese 乙未, ora 己巳; livello A SHORT, persa anche dalla scala). Mazzo 53,64%
(+20.059); riferimento 65/65; scala A/B/C/D 2.306 · 65,44% · +44.832, livello D 637 · 58,56%; parita' 0.
Da portare a Edu: EURJPY 29/07/2026 seme 186, per vedere perche' e' storta.

## S49 (16/09/2026) · EURJPY 29/07/2026 seme 186 · LA DATA PASSA PER LA BESTIA · `CONFERMATA DA EDU`
La carta storta di MLRITIROVUOTASEDE: stesso esagramma della seme 58 (L2 G 卯 incompatibile che retrocede
nel vuoto, Ying 寅 vuota senza bestie), esito LONG +73; livello A SHORT, persa dalla scala. Giorno 甲辰, mese
乙未, anno 丙午, ora 己巳, vuoti 寅卯. Giorno e mese su L1 P 巳, anno su L2, ora su L4 B 戌 (clashata dal giorno);
su L5 W 子 la bestia 白虎. Claude aveva proposto la penalita' completa 丑戌未 sullo Shi (eccezione del 29/08) e
poi la linea piu' carica L1 P -> LONG, dubitando del passo finale.
Edu: "Hai considerato gli steli? La terra nella data e' cosi' forte che basterebbe anche uno stelo metallo a
far vincere. E' cio' che succede con L5 Zi. Long." Spiegazione di Claude confermata da Edu ("Si e' giusto"):
steli 甲乙 (Legno) -> 丙 (Fuoco) -> 己 (Terra), rami 辰未 Terra e 午巳 Fuoco, mese di Terra: la data va tutta
verso la Terra; la Terra passa nel Metallo della bestia su L5 (白虎 — conta l'elemento della bestia della
linea, regola di Edu su NZDUSD 17/06/2025 seme 60); il Metallo genera il 子 della W di L5: vince l'alto.
Viene prima della Ying vuota. Nella seme 58 il mese era 巳 (Fuoco): la data non era di Terra.
Errore di Claude: non ha guardato gli steli della data.
Cablato come `MLDATAPASSA` in T1a, prima della ritirata nel vuoto. Perimetro della carta: G/W mobile non sede
che retrocede; ogni stelo e ramo della data e' l'elemento del mese o uno dei due che lo precedono nella
generazione; l'elemento del mese e' fra gli steli; una sola linea G/W non vuota con la bestia dell'elemento
generato dalla data e il ramo dell'elemento generato da quello -> vince la sua squadra. MLDATAPASSA=off.
Misura: gradino 1 carta (questa, +73); la ritirata nel vuoto torna a 1 carta giusta; mazzo 53,68%
(+20.204); riferimento 66/66. Liu Yao vecchio non toccato (la carta resta di livello A SHORT nella scala).
PORTATA NEL LIU YAO VECCHIO (Edu, 16/09/2026: "Porta"). Nuova via `R5_datapassa`, stesso perimetro di
MLDATAPASSA, messa subito prima della via della mobile che retrocede (sulla carta la ritirata nel vuoto e'
nulla e la catena arrivava alla §114). DATAPASSA=off spegne.
Controllo: carte guida 110 · 78 giuste · 32 storte identiche (nessuna cambia verdetto).
Misura: la via prende 1 carta (questa); S17 da 58,50% (+35.135) a 58,54% (z 9,01, +35.280).
Scala: la carta non e' piu' di livello A (PB SHORT, LY LONG, DLR SHORT) e resta ferma; Z-TOT A+B+C 1.668 ·
68,11% · +38.610; Z-TOT48 A/B/C/D 2.305 · 65,47% · +44.905; livello D 637 · 58,56%. Parita' 455 carte, 0.
